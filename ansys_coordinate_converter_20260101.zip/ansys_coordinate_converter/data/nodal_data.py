"""
Data classes for nodal information storage and manipulation.
"""

from dataclasses import dataclass, field
from enum import Enum
from typing import Optional, List
import numpy as np


class DataType(Enum):
    """Type of nodal data: scalar or vector."""
    SCALAR = "scalar"
    VECTOR = "vector"


class CoordinateSystem(Enum):
    """Coordinate system type."""
    CARTESIAN = "cartesian"
    CYLINDRICAL = "cylindrical"


class CylindricalAxis(Enum):
    """Axis for cylindrical coordinate system."""
    X = "x"
    Y = "y"
    Z = "z"


class TransformDirection(Enum):
    """Direction of coordinate transformation."""
    CART_TO_CYL = "cartesian_to_cylindrical"
    CYL_TO_CART = "cylindrical_to_cartesian"


@dataclass
class TransformSettings:
    """Settings for coordinate transformation."""
    direction: TransformDirection = TransformDirection.CART_TO_CYL
    cylindrical_axis: CylindricalAxis = CylindricalAxis.Z
    origin: np.ndarray = field(default_factory=lambda: np.array([0.0, 0.0, 0.0]))
    
    def copy(self) -> 'TransformSettings':
        """Create a copy of the settings."""
        return TransformSettings(
            direction=self.direction,
            cylindrical_axis=self.cylindrical_axis,
            origin=self.origin.copy()
        )


@dataclass
class NodalData:
    """
    Container for nodal data including positions and values.
    
    Attributes:
        node_ids: Array of node identifiers
        positions: Nx3 array of node positions (X, Y, Z)
        data_type: Whether data is scalar or vector
        scalar_values: Array of scalar values (if data_type is SCALAR)
        vector_values: Nx3 array of vector components (if data_type is VECTOR)
        coordinate_system: Current coordinate system of the data
        column_names: Names of the data columns (from headers or auto-generated)
    """
    node_ids: np.ndarray
    positions: np.ndarray
    data_type: DataType
    scalar_values: Optional[np.ndarray] = None
    vector_values: Optional[np.ndarray] = None
    coordinate_system: CoordinateSystem = CoordinateSystem.CARTESIAN
    column_names: List[str] = field(default_factory=list)
    
    def __post_init__(self):
        """Validate data consistency."""
        n_nodes = len(self.node_ids)
        
        if self.positions.shape != (n_nodes, 3):
            raise ValueError(f"Positions shape {self.positions.shape} doesn't match node count {n_nodes}")
        
        if self.data_type == DataType.SCALAR:
            if self.scalar_values is None:
                raise ValueError("Scalar data type requires scalar_values")
            if len(self.scalar_values) != n_nodes:
                raise ValueError(f"Scalar values count {len(self.scalar_values)} doesn't match node count {n_nodes}")
        
        if self.data_type == DataType.VECTOR:
            if self.vector_values is None:
                raise ValueError("Vector data type requires vector_values")
            if self.vector_values.shape != (n_nodes, 3):
                raise ValueError(f"Vector values shape {self.vector_values.shape} doesn't match expected ({n_nodes}, 3)")
    
    @property
    def num_nodes(self) -> int:
        """Return the number of nodes."""
        return len(self.node_ids)
    
    @property
    def data_magnitude(self) -> np.ndarray:
        """Return the magnitude of the data for visualization."""
        if self.data_type == DataType.SCALAR:
            return np.abs(self.scalar_values)
        else:
            return np.linalg.norm(self.vector_values, axis=1)
    
    def copy(self) -> 'NodalData':
        """Create a deep copy of the nodal data."""
        return NodalData(
            node_ids=self.node_ids.copy(),
            positions=self.positions.copy(),
            data_type=self.data_type,
            scalar_values=self.scalar_values.copy() if self.scalar_values is not None else None,
            vector_values=self.vector_values.copy() if self.vector_values is not None else None,
            coordinate_system=self.coordinate_system,
            column_names=self.column_names.copy()
        )
    
    def get_position_column_names(self) -> List[str]:
        """Get column names for position - always Cartesian since positions don't transform."""
        return ["X", "Y", "Z"]
    
    def get_data_column_names(self) -> List[str]:
        """Get appropriate column names for data based on type and coordinate system."""
        if self.data_type == DataType.SCALAR:
            return ["Value"]
        
        if self.coordinate_system == CoordinateSystem.CARTESIAN:
            return ["Fx", "Fy", "Fz"]
        else:
            return ["Fr", "Ftheta", "Fz"]


@dataclass
class ParsedRawData:
    """
    Raw data parsed from file before column mapping.
    
    Attributes:
        data: 2D array of parsed values (all as strings initially)
        headers: List of column headers (empty if no headers)
        has_headers: Whether the file had headers
        separator: The separator used to parse the file
        num_columns: Number of columns detected
        num_rows: Number of data rows
    """
    data: np.ndarray
    headers: List[str]
    has_headers: bool
    separator: str
    
    @property
    def num_columns(self) -> int:
        """Return the number of columns."""
        return self.data.shape[1] if len(self.data.shape) > 1 else 1
    
    @property
    def num_rows(self) -> int:
        """Return the number of data rows."""
        return self.data.shape[0]
    
    def get_column_options(self) -> List[str]:
        """Get list of column options for dropdown menus."""
        if self.headers:
            return [f"Col {i+1}: {h}" for i, h in enumerate(self.headers)]
        else:
            return [f"Column {i+1}" for i in range(self.num_columns)]


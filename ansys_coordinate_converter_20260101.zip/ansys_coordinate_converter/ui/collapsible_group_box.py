"""
Collapsible group box widget for foldable UI sections.
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QFrame,
    QSizePolicy
)
from PyQt5.QtCore import Qt, pyqtSignal, QPropertyAnimation, QEasingCurve
from PyQt5.QtGui import QFont


class CollapsibleGroupBox(QWidget):
    """A group box that can be collapsed/expanded by clicking the header."""
    
    # Signals
    collapsed = pyqtSignal()
    expanded = pyqtSignal()
    
    def __init__(self, title: str = "", parent=None):
        super().__init__(parent)
        
        self._is_collapsed = False
        self._title = title
        
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup the widget UI."""
        main_layout = QVBoxLayout(self)
        main_layout.setContentsMargins(0, 0, 0, 0)
        main_layout.setSpacing(0)
        
        # Header (clickable)
        self._header = QFrame()
        self._header.setObjectName("collapsibleHeader")
        self._header.setCursor(Qt.PointingHandCursor)
        self._header.setStyleSheet("""
            QFrame#collapsibleHeader {
                background-color: #e8e8e8;
                border: 1px solid #d0d0d0;
                border-radius: 6px;
                padding: 4px;
            }
            QFrame#collapsibleHeader:hover {
                background-color: #dcdcdc;
            }
        """)
        
        header_layout = QHBoxLayout(self._header)
        header_layout.setContentsMargins(10, 6, 10, 6)
        header_layout.setSpacing(8)
        
        # Arrow indicator
        self._arrow_label = QLabel("▼")
        self._arrow_label.setFixedWidth(16)
        font = QFont()
        font.setPointSize(8)
        self._arrow_label.setFont(font)
        header_layout.addWidget(self._arrow_label)
        
        # Title
        self._title_label = QLabel(self._title)
        title_font = QFont()
        title_font.setBold(True)
        self._title_label.setFont(title_font)
        header_layout.addWidget(self._title_label)
        
        header_layout.addStretch()
        
        # Status hint (shows when collapsed)
        self._status_label = QLabel("")
        self._status_label.setStyleSheet("color: #666;")
        self._status_label.hide()
        header_layout.addWidget(self._status_label)
        
        main_layout.addWidget(self._header)
        
        # Content container
        self._content = QFrame()
        self._content.setObjectName("collapsibleContent")
        self._content.setStyleSheet("""
            QFrame#collapsibleContent {
                border: 1px solid #d0d0d0;
                border-top: none;
                border-bottom-left-radius: 6px;
                border-bottom-right-radius: 6px;
                background-color: #f8f8f8;
            }
        """)
        
        self._content_layout = QVBoxLayout(self._content)
        self._content_layout.setContentsMargins(8, 8, 8, 8)
        self._content_layout.setSpacing(6)
        
        main_layout.addWidget(self._content)
        
        # Make header clickable
        self._header.mousePressEvent = self._on_header_clicked
    
    def _on_header_clicked(self, event):
        """Handle header click to toggle collapse state."""
        self.toggle()
    
    def set_content_widget(self, widget: QWidget):
        """Set the content widget to display inside the collapsible area."""
        # Clear existing content
        while self._content_layout.count():
            item = self._content_layout.takeAt(0)
            if item.widget():
                item.widget().setParent(None)
        
        self._content_layout.addWidget(widget)
    
    def add_widget(self, widget: QWidget):
        """Add a widget to the content area."""
        self._content_layout.addWidget(widget)
    
    def add_layout(self, layout):
        """Add a layout to the content area."""
        self._content_layout.addLayout(layout)
    
    def content_layout(self):
        """Get the content layout for adding widgets directly."""
        return self._content_layout
    
    def set_status_text(self, text: str):
        """Set status text shown in header when collapsed."""
        self._status_label.setText(text)
        if text:
            self._status_label.show()
        else:
            self._status_label.hide()
    
    def toggle(self):
        """Toggle between collapsed and expanded state."""
        if self._is_collapsed:
            self.expand()
        else:
            self.collapse()
    
    def collapse(self):
        """Collapse the content area."""
        if self._is_collapsed:
            return
        
        self._is_collapsed = True
        self._content.hide()
        self._arrow_label.setText("▶")
        
        # Update header style when collapsed
        self._header.setStyleSheet("""
            QFrame#collapsibleHeader {
                background-color: #e8e8e8;
                border: 1px solid #d0d0d0;
                border-radius: 6px;
                padding: 4px;
            }
            QFrame#collapsibleHeader:hover {
                background-color: #dcdcdc;
            }
        """)
        
        self.collapsed.emit()
    
    def expand(self):
        """Expand the content area."""
        if not self._is_collapsed:
            return
        
        self._is_collapsed = False
        self._content.show()
        self._arrow_label.setText("▼")
        
        # Update header style when expanded (no bottom radius)
        self._header.setStyleSheet("""
            QFrame#collapsibleHeader {
                background-color: #e8e8e8;
                border: 1px solid #d0d0d0;
                border-top-left-radius: 6px;
                border-top-right-radius: 6px;
                border-bottom-left-radius: 0px;
                border-bottom-right-radius: 0px;
                padding: 4px;
            }
            QFrame#collapsibleHeader:hover {
                background-color: #dcdcdc;
            }
        """)
        
        self.expanded.emit()
    
    def is_collapsed(self) -> bool:
        """Check if the group box is collapsed."""
        return self._is_collapsed
    
    def set_title(self, title: str):
        """Set the title text."""
        self._title = title
        self._title_label.setText(title)


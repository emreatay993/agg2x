"""
Data preview table with tabs for original and transformed data.
"""

from typing import Optional, List

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QTabWidget, QTableWidget, 
    QTableWidgetItem, QHeaderView, QAbstractItemView
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QColor
import numpy as np

from data.nodal_data import NodalData, ParsedRawData, DataType, CoordinateSystem


class PreviewTableWidget(QWidget):
    """Widget containing tabbed data preview tables."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup the UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Tab widget
        self.tabs = QTabWidget()
        
        # Raw data table
        self.raw_table = QTableWidget()
        self._configure_table(self.raw_table)
        self.tabs.addTab(self.raw_table, "Raw Data")
        
        # Original data table
        self.original_table = QTableWidget()
        self._configure_table(self.original_table)
        self.tabs.addTab(self.original_table, "Original Data")
        
        # Transformed data table
        self.transformed_table = QTableWidget()
        self._configure_table(self.transformed_table)
        self.tabs.addTab(self.transformed_table, "Transformed Data")
        
        layout.addWidget(self.tabs)
    
    def _configure_table(self, table: QTableWidget):
        """Configure table appearance and behavior."""
        table.setAlternatingRowColors(True)
        table.setSelectionBehavior(QAbstractItemView.SelectRows)
        table.setSelectionMode(QAbstractItemView.SingleSelection)
        table.horizontalHeader().setStretchLastSection(True)
        table.horizontalHeader().setSectionResizeMode(QHeaderView.Interactive)
        table.verticalHeader().setVisible(False)
        table.setEditTriggers(QAbstractItemView.NoEditTriggers)
    
    def show_raw_data(self, raw_data: ParsedRawData):
        """Display raw parsed data in the table."""
        table = self.raw_table
        
        # Setup columns
        if raw_data.headers:
            headers = raw_data.headers
        else:
            headers = [f"Column {i+1}" for i in range(raw_data.num_columns)]
        
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        
        # Setup rows
        table.setRowCount(raw_data.num_rows)
        
        # Fill data
        for i in range(raw_data.num_rows):
            for j in range(raw_data.num_columns):
                value = raw_data.data[i, j]
                if np.isnan(value):
                    text = ""
                else:
                    text = f"{value:.6g}"
                item = QTableWidgetItem(text)
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                table.setItem(i, j, item)
        
        # Resize columns to content
        table.resizeColumnsToContents()
        
        # Switch to raw data tab
        self.tabs.setCurrentIndex(0)
    
    def show_nodal_data(self, data: NodalData, tab_label: str = "Original"):
        """Display nodal data in the appropriate table."""
        table = self.original_table
        
        # Build headers
        headers = ["Node ID"]
        headers.extend(data.get_position_column_names())
        headers.extend(data.get_data_column_names())
        
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        
        # Setup rows
        table.setRowCount(data.num_nodes)
        
        # Fill data
        for i in range(data.num_nodes):
            col = 0
            
            # Node ID
            item = QTableWidgetItem(str(int(data.node_ids[i])))
            item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            table.setItem(i, col, item)
            col += 1
            
            # Positions
            for j in range(3):
                value = data.positions[i, j]
                item = QTableWidgetItem(f"{value:.6g}")
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                table.setItem(i, col, item)
                col += 1
            
            # Data values
            if data.data_type == DataType.SCALAR:
                value = data.scalar_values[i]
                item = QTableWidgetItem(f"{value:.6g}")
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                table.setItem(i, col, item)
            else:
                for j in range(3):
                    value = data.vector_values[i, j]
                    item = QTableWidgetItem(f"{value:.6g}")
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    table.setItem(i, col, item)
                    col += 1
        
        # Resize columns
        table.resizeColumnsToContents()
        
        # Switch to original data tab
        self.tabs.setCurrentIndex(1)
    
    def show_transformed_data(self, data: NodalData):
        """Display transformed data in the transformed table."""
        table = self.transformed_table
        
        # Build headers
        headers = ["Node ID"]
        headers.extend(data.get_position_column_names())
        headers.extend(data.get_data_column_names())
        
        table.setColumnCount(len(headers))
        table.setHorizontalHeaderLabels(headers)
        
        # Setup rows
        table.setRowCount(data.num_nodes)
        
        # Fill data
        for i in range(data.num_nodes):
            col = 0
            
            # Node ID
            item = QTableWidgetItem(str(int(data.node_ids[i])))
            item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
            table.setItem(i, col, item)
            col += 1
            
            # Positions (always X, Y, Z - positions don't transform)
            for j in range(3):
                value = data.positions[i, j]
                item = QTableWidgetItem(f"{value:.6g}")
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                table.setItem(i, col, item)
                col += 1
            
            # Data values
            if data.data_type == DataType.SCALAR:
                value = data.scalar_values[i]
                item = QTableWidgetItem(f"{value:.6g}")
                item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                table.setItem(i, col, item)
            else:
                for j in range(3):
                    value = data.vector_values[i, j]
                    item = QTableWidgetItem(f"{value:.6g}")
                    item.setTextAlignment(Qt.AlignRight | Qt.AlignVCenter)
                    table.setItem(i, col, item)
                    col += 1
        
        # Resize columns
        table.resizeColumnsToContents()
        
        # Switch to transformed data tab
        self.tabs.setCurrentIndex(2)
    
    def clear_all(self):
        """Clear all tables."""
        self.raw_table.setRowCount(0)
        self.raw_table.setColumnCount(0)
        self.original_table.setRowCount(0)
        self.original_table.setColumnCount(0)
        self.transformed_table.setRowCount(0)
        self.transformed_table.setColumnCount(0)


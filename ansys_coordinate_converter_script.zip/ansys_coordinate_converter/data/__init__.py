# Data structures module for coordinate converter


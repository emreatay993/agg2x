"""
Nodal Data Coordinate System Converter

A PyQt5 + PyVista application for loading nodal data (forces/displacements),
previewing parsed columns, converting between Cartesian and Cylindrical 
coordinate systems, and visualizing the results in an interactive 3D viewport.
"""

import sys
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import Qt

from ui.main_window import MainWindow


def main():
    """Application entry point."""
    # Enable high DPI scaling
    QApplication.setAttribute(Qt.AA_EnableHighDpiScaling, True)
    QApplication.setAttribute(Qt.AA_UseHighDpiPixmaps, True)
    
    app = QApplication(sys.argv)
    app.setApplicationName("Nodal Coordinate Converter")
    app.setOrganizationName("EngineeringTools")
    
    window = MainWindow()
    window.show()
    
    sys.exit(app.exec_())


if __name__ == "__main__":
    main()


"""
Column mapping panel for assigning data columns.
"""

from typing import List, Optional

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QComboBox, QRadioButton, QButtonGroup, QGroupBox, QFrame,
    QMessageBox
)
from PyQt5.QtCore import pyqtSignal

from core.data_parser import DataParser
from data.nodal_data import NodalData, DataType, ParsedRawData


class ColumnMappingPanel(QWidget):
    """Panel for mapping file columns to data fields."""
    
    # Signals
    mapping_applied = pyqtSignal(object)  # Emitted with NodalData
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.raw_data: ParsedRawData = None
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup the panel UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Group box
        group = QGroupBox("Column Mapping")
        group_layout = QVBoxLayout(group)
        group_layout.setSpacing(6)
        
        # Fixed width for labels to align combos
        label_width = 65
        
        # Node ID
        node_row = QHBoxLayout()
        node_label = QLabel("Node ID:")
        node_label.setFixedWidth(label_width)
        node_row.addWidget(node_label)
        self.node_id_combo = QComboBox()
        self.node_id_combo.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        self.node_id_combo.setMinimumWidth(180)
        node_row.addWidget(self.node_id_combo, stretch=1)
        group_layout.addLayout(node_row)
        
        # X coordinate
        x_row = QHBoxLayout()
        x_label = QLabel("X Coord:")
        x_label.setFixedWidth(label_width)
        x_row.addWidget(x_label)
        self.x_combo = QComboBox()
        self.x_combo.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        self.x_combo.setMinimumWidth(180)
        x_row.addWidget(self.x_combo, stretch=1)
        group_layout.addLayout(x_row)
        
        # Y coordinate
        y_row = QHBoxLayout()
        y_label = QLabel("Y Coord:")
        y_label.setFixedWidth(label_width)
        y_row.addWidget(y_label)
        self.y_combo = QComboBox()
        self.y_combo.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        self.y_combo.setMinimumWidth(180)
        y_row.addWidget(self.y_combo, stretch=1)
        group_layout.addLayout(y_row)
        
        # Z coordinate
        z_row = QHBoxLayout()
        z_label = QLabel("Z Coord:")
        z_label.setFixedWidth(label_width)
        z_row.addWidget(z_label)
        self.z_combo = QComboBox()
        self.z_combo.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        self.z_combo.setMinimumWidth(180)
        z_row.addWidget(self.z_combo, stretch=1)
        group_layout.addLayout(z_row)
        
        # Separator line
        line = QFrame()
        line.setFrameShape(QFrame.HLine)
        line.setFrameShadow(QFrame.Sunken)
        group_layout.addWidget(line)
        
        # Data type selection
        type_label = QLabel("Data Type:")
        group_layout.addWidget(type_label)
        
        self.data_type_group = QButtonGroup(self)
        
        type_row = QHBoxLayout()
        self.scalar_radio = QRadioButton("Scalar")
        self.vector_radio = QRadioButton("Vector (3D)")
        self.scalar_radio.setChecked(True)
        
        self.data_type_group.addButton(self.scalar_radio, 0)
        self.data_type_group.addButton(self.vector_radio, 1)
        
        type_row.addWidget(self.scalar_radio)
        type_row.addWidget(self.vector_radio)
        type_row.addStretch()
        group_layout.addLayout(type_row)
        
        # Scalar value column
        self.scalar_widget = QWidget()
        scalar_layout = QHBoxLayout(self.scalar_widget)
        scalar_layout.setContentsMargins(0, 0, 0, 0)
        value_label = QLabel("Value:")
        value_label.setFixedWidth(label_width)
        scalar_layout.addWidget(value_label)
        self.value_combo = QComboBox()
        self.value_combo.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        self.value_combo.setMinimumWidth(180)
        scalar_layout.addWidget(self.value_combo, stretch=1)
        group_layout.addWidget(self.scalar_widget)
        
        # Vector component columns
        self.vector_widget = QWidget()
        vector_layout = QVBoxLayout(self.vector_widget)
        vector_layout.setContentsMargins(0, 8, 0, 8)
        vector_layout.setSpacing(10)
        
        vx_row = QHBoxLayout()
        vx_label = QLabel("Comp X:")
        vx_label.setFixedWidth(label_width)
        vx_row.addWidget(vx_label)
        self.vx_combo = QComboBox()
        self.vx_combo.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        self.vx_combo.setMinimumWidth(180)
        vx_row.addWidget(self.vx_combo, stretch=1)
        vector_layout.addLayout(vx_row)
        
        vy_row = QHBoxLayout()
        vy_label = QLabel("Comp Y:")
        vy_label.setFixedWidth(label_width)
        vy_row.addWidget(vy_label)
        self.vy_combo = QComboBox()
        self.vy_combo.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        self.vy_combo.setMinimumWidth(180)
        vy_row.addWidget(self.vy_combo, stretch=1)
        vector_layout.addLayout(vy_row)
        
        vz_row = QHBoxLayout()
        vz_label = QLabel("Comp Z:")
        vz_label.setFixedWidth(label_width)
        vz_row.addWidget(vz_label)
        self.vz_combo = QComboBox()
        self.vz_combo.setSizeAdjustPolicy(QComboBox.AdjustToContents)
        self.vz_combo.setMinimumWidth(180)
        vz_row.addWidget(self.vz_combo, stretch=1)
        vz_row.addStretch()
        vector_layout.addLayout(vz_row)
        
        group_layout.addWidget(self.vector_widget)
        self.vector_widget.setVisible(False)
        
        # Apply button
        self.apply_btn = QPushButton("Apply Mapping")
        self.apply_btn.clicked.connect(self._on_apply_clicked)
        self.apply_btn.setEnabled(False)
        group_layout.addWidget(self.apply_btn)
        
        layout.addWidget(group)
        
        # Connect data type toggle
        self.data_type_group.buttonClicked.connect(self._on_data_type_changed)
    
    def set_column_options(self, options: List[str]):
        """Set the column options for all combo boxes."""
        combos = [
            self.node_id_combo, self.x_combo, self.y_combo, self.z_combo,
            self.value_combo, self.vx_combo, self.vy_combo, self.vz_combo
        ]
        
        for combo in combos:
            combo.clear()
            combo.addItems(options)
        
        # Set default selections if enough columns
        n_cols = len(options)
        if n_cols >= 4:
            self.node_id_combo.setCurrentIndex(0)
            self.x_combo.setCurrentIndex(1)
            self.y_combo.setCurrentIndex(2)
            self.z_combo.setCurrentIndex(3)
        
        if n_cols >= 5:
            self.value_combo.setCurrentIndex(4)
        
        if n_cols >= 7:
            self.vx_combo.setCurrentIndex(4)
            self.vy_combo.setCurrentIndex(5)
            self.vz_combo.setCurrentIndex(6)
        
        self.apply_btn.setEnabled(True)
    
    def set_raw_data(self, raw_data: ParsedRawData):
        """Store the raw data for creating NodalData."""
        self.raw_data = raw_data
    
    def _on_data_type_changed(self):
        """Handle data type radio button change."""
        is_scalar = self.scalar_radio.isChecked()
        self.scalar_widget.setVisible(is_scalar)
        self.vector_widget.setVisible(not is_scalar)
    
    def _on_apply_clicked(self):
        """Handle apply button click."""
        # Get parent window's raw data
        parent = self.parent()
        while parent and not hasattr(parent, 'raw_data'):
            parent = parent.parent()
        
        if parent and hasattr(parent, 'raw_data'):
            raw_data = parent.raw_data
        else:
            QMessageBox.warning(self, "No Data", "Please parse a file first.")
            return
        
        if raw_data is None:
            QMessageBox.warning(self, "No Data", "Please parse a file first.")
            return
        
        try:
            data_type = DataType.SCALAR if self.scalar_radio.isChecked() else DataType.VECTOR
            
            nodal_data = DataParser.create_nodal_data(
                raw_data,
                node_id_col=self.node_id_combo.currentIndex(),
                x_col=self.x_combo.currentIndex(),
                y_col=self.y_combo.currentIndex(),
                z_col=self.z_combo.currentIndex(),
                data_type=data_type,
                value_col=self.value_combo.currentIndex() if data_type == DataType.SCALAR else None,
                vx_col=self.vx_combo.currentIndex() if data_type == DataType.VECTOR else None,
                vy_col=self.vy_combo.currentIndex() if data_type == DataType.VECTOR else None,
                vz_col=self.vz_combo.currentIndex() if data_type == DataType.VECTOR else None
            )
            
            self.mapping_applied.emit(nodal_data)
            
        except Exception as e:
            QMessageBox.critical(
                self, "Mapping Error",
                f"Failed to create nodal data:\n{str(e)}"
            )


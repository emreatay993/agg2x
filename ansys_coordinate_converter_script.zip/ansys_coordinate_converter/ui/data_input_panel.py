"""
Data input panel for file loading and parsing configuration.
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QRadioButton, QButtonGroup, QCheckBox, QFileDialog,
    QLineEdit, QMessageBox
)
from PyQt5.QtCore import pyqtSignal

from core.data_parser import DataParser
from data.nodal_data import ParsedRawData
from ui.collapsible_group_box import CollapsibleGroupBox


class DataInputPanel(QWidget):
    """Panel for loading and configuring data file input."""
    
    # Signals
    file_loaded = pyqtSignal(str)  # Emitted when file is selected
    parse_requested = pyqtSignal(object)  # Emitted with ParsedRawData
    parse_succeeded = pyqtSignal()  # Emitted when parsing succeeds
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self.current_filepath = None
        self._setup_ui()
    
    def _setup_ui(self):
        """Setup the panel UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Collapsible group box
        self.collapsible_group = CollapsibleGroupBox("Data Input")
        
        # Content widget
        content = QWidget()
        content_layout = QVBoxLayout(content)
        content_layout.setContentsMargins(0, 0, 0, 0)
        content_layout.setSpacing(8)
        
        # File selection
        file_layout = QHBoxLayout()
        self.file_path_edit = QLineEdit()
        self.file_path_edit.setPlaceholderText("No file selected...")
        self.file_path_edit.setReadOnly(True)
        file_layout.addWidget(self.file_path_edit)
        
        self.browse_btn = QPushButton("Browse...")
        self.browse_btn.clicked.connect(self.browse_file)
        file_layout.addWidget(self.browse_btn)
        
        content_layout.addLayout(file_layout)
        
        # Separator options
        sep_label = QLabel("Separator:")
        content_layout.addWidget(sep_label)
        
        self.separator_group = QButtonGroup(self)
        
        sep_options = [
            ('auto', 'Auto-detect'),
            ('space', 'Space'),
            ('tab', 'Tab'),
            ('comma', 'Comma'),
            ('semicolon', 'Semicolon'),
            ('colon', 'Colon')
        ]
        
        sep_row1 = QHBoxLayout()
        sep_row2 = QHBoxLayout()
        
        for i, (value, label) in enumerate(sep_options):
            radio = QRadioButton(label)
            radio.setProperty('separator_value', value)
            self.separator_group.addButton(radio, i)
            if i < 3:
                sep_row1.addWidget(radio)
            else:
                sep_row2.addWidget(radio)
            
            if value == 'auto':
                radio.setChecked(True)
        
        sep_row1.addStretch()
        sep_row2.addStretch()
        content_layout.addLayout(sep_row1)
        content_layout.addLayout(sep_row2)
        
        # Header option
        self.has_headers_check = QCheckBox("First row is header")
        self.has_headers_check.setChecked(True)
        content_layout.addWidget(self.has_headers_check)
        
        # Parse button
        self.parse_btn = QPushButton("Parse File")
        self.parse_btn.clicked.connect(self._on_parse_clicked)
        self.parse_btn.setEnabled(False)
        content_layout.addWidget(self.parse_btn)
        
        # Set content to collapsible group
        self.collapsible_group.set_content_widget(content)
        
        layout.addWidget(self.collapsible_group)
    
    def browse_file(self):
        """Open file browser dialog."""
        filepath, _ = QFileDialog.getOpenFileName(
            self, "Open Data File", "",
            "Data Files (*.txt *.csv *.dat);;All Files (*)"
        )
        
        if filepath:
            self.current_filepath = filepath
            self.file_path_edit.setText(filepath)
            self.parse_btn.setEnabled(True)
            self.file_loaded.emit(filepath)
    
    def _get_selected_separator(self) -> str:
        """Get the currently selected separator."""
        checked = self.separator_group.checkedButton()
        if checked:
            return checked.property('separator_value')
        return 'auto'
    
    def _on_parse_clicked(self):
        """Handle parse button click."""
        if not self.current_filepath:
            return
        
        try:
            separator = self._get_selected_separator()
            has_headers = self.has_headers_check.isChecked()
            
            raw_data = DataParser.parse_file(
                self.current_filepath,
                separator=separator,
                has_headers=has_headers
            )
            
            self.parse_requested.emit(raw_data)
            self.parse_succeeded.emit()  # Signal successful parse
            
        except Exception as e:
            QMessageBox.critical(
                self, "Parse Error",
                f"Failed to parse file:\n{str(e)}"
            )
    
    def collapse(self):
        """Collapse the data input panel."""
        # Extract just the filename from the path
        import os
        if self.current_filepath:
            filename = os.path.basename(self.current_filepath)
            self.collapsible_group.set_status_text(f"✓ {filename}")
        self.collapsible_group.collapse()
    
    def expand(self):
        """Expand the data input panel."""
        self.collapsible_group.expand()

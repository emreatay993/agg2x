# Coordinate Transformation: Behind the Scenes

This document explains exactly what happens when you transform vector data (forces or displacements) from Cartesian to Cylindrical coordinates in this program.

---

## Key Concept: Only Vector Components Transform, Not Positions!

**Important**: When you perform a transformation:
- **Node positions (X, Y, Z)** remain in Cartesian coordinates - they represent physical locations in space
- **Vector components (Fx, Fy, Fz)** are transformed to (Fr, Fθ, Fz) - they represent the same physical force/displacement, just expressed in a different coordinate system

---

## Example: 3 Nodes with Force Data

### Input Data (Cartesian)

| Node ID | X (mm) | Y (mm) | Z (mm) | Fx (N) | Fy (N) | Fz (N) |
|---------|--------|--------|--------|--------|--------|--------|
| 1       | 100    | 0      | 50     | 500    | 0      | 100    |
| 2       | 0      | 100    | 50     | 0      | 300    | 100    |
| 3       | 70.71  | 70.71  | 50     | 200    | 200    | 100    |

### Transformation Settings
- **Direction**: Cartesian → Cylindrical
- **Cylindrical Axis**: Z
- **Axis Origin**: (0, 0, 0)

---

## Step-by-Step Calculation

### Step 1: Calculate θ (theta) for Each Node

For each node, we calculate its angular position in the X-Y plane:

```
θ = atan2(Y, X)
```

| Node | X      | Y      | θ (radians) | θ (degrees) |
|------|--------|--------|-------------|-------------|
| 1    | 100    | 0      | 0.000       | 0°          |
| 2    | 0      | 100    | 1.571       | 90°         |
| 3    | 70.71  | 70.71  | 0.785       | 45°         |

**Visual representation (top view, looking down Z-axis):**

```
                Y
                ↑
                |     Node 3 (45°)
        Node 2  |    ·
           ·    |   /
                |  /
                | /
    ────────────┼────────────→ X
                |           Node 1 (0°)
                |              ·
                |
```

### Step 2: Transform Vector Components

The transformation formulas (for Z-axis cylindrical):

```
Fr = Fx × cos(θ) + Fy × sin(θ)     (radial component)
Fθ = -Fx × sin(θ) + Fy × cos(θ)    (tangential component)
Fz_cyl = Fz                         (axial component - unchanged)
```

---

### Node 1: Position (100, 0, 50), θ = 0°

```
cos(0°) = 1.0,  sin(0°) = 0.0

Fr = 500 × 1.0 + 0 × 0.0 = 500 N
Fθ = -500 × 0.0 + 0 × 1.0 = 0 N
Fz = 100 N
```

**Interpretation**: At θ = 0°, the +X direction IS the radial direction. So a force pointing in +X (500 N) becomes a purely radial force (500 N).

```
         Y
         ↑
         |
         |
    ─────┼─────●→→→→→  Node 1
         |     Fx=500 becomes Fr=500
         |     (radial = outward from axis)
```

---

### Node 2: Position (0, 100, 50), θ = 90°

```
cos(90°) = 0.0,  sin(90°) = 1.0

Fr = 0 × 0.0 + 300 × 1.0 = 300 N
Fθ = -0 × 1.0 + 300 × 0.0 = 0 N
Fz = 100 N
```

**Interpretation**: At θ = 90°, the +Y direction IS the radial direction. So a force pointing in +Y (300 N) becomes a purely radial force (300 N).

```
         Y
         ↑
         ●  Node 2
         ↑
         │ Fy=300 becomes Fr=300
         │ (radial = outward from axis)
    ─────┼─────────→ X
         |
```

---

### Node 3: Position (70.71, 70.71, 50), θ = 45°

```
cos(45°) = 0.7071,  sin(45°) = 0.7071

Fr = 200 × 0.7071 + 200 × 0.7071 = 141.42 + 141.42 = 282.84 N
Fθ = -200 × 0.7071 + 200 × 0.7071 = -141.42 + 141.42 = 0 N
Fz = 100 N
```

**Interpretation**: The force vector (200, 200) points at 45° - directly outward from the origin. This is a purely radial force with magnitude √(200² + 200²) = 282.84 N.

```
         Y
         ↑
         |    ·→ Node 3
         |   ↗   Force (200,200) points 
         |  /    directly outward = purely radial
         | /     Fr = 282.84 N, Fθ = 0 N
    ─────┼─────────→ X
         |
```

---

## Output Data (After Transformation)

| Node ID | X (mm) | Y (mm) | Z (mm) | Fr (N) | Fθ (N) | Fz (N) |
|---------|--------|--------|--------|--------|--------|--------|
| 1       | 100    | 0      | 50     | 500.00 | 0.00   | 100    |
| 2       | 0      | 100    | 50     | 300.00 | 0.00   | 100    |
| 3       | 70.71  | 70.71  | 50     | 282.84 | 0.00   | 100    |

**Notice**: 
- Positions (X, Y, Z) are **unchanged** - they stay in Cartesian
- Only the force components are now expressed in cylindrical coordinates

---

## Another Example: Tangential Force

If Node 1 had a force in the +Y direction instead:

| Node ID | X | Y | Z | Fx | Fy | Fz |
|---------|---|---|---|----|----|----|
| 1       |100| 0 |50 | 0  |500 |100 |

At θ = 0°:
```
Fr = 0 × cos(0°) + 500 × sin(0°) = 0 × 1.0 + 500 × 0.0 = 0 N
Fθ = -0 × sin(0°) + 500 × cos(0°) = 0 × 0.0 + 500 × 1.0 = 500 N
```

This force is purely **tangential** (Fθ = 500 N) - it points perpendicular to the radial direction, like a force trying to rotate the node around the Z-axis.

```
         Y
         ↑
         |
         |
    ─────┼─────●  Node 1
         |     ↑
         |     Fy=500 becomes Fθ=500
         |     (tangential = perpendicular to radius)
```

---

## What If Cylindrical Axis is X or Y?

The program handles this by permuting the coordinates:

| Cylindrical Axis | Radial Plane | Coordinate Mapping |
|------------------|--------------|-------------------|
| Z (default)      | X-Y plane    | No change         |
| X                | Y-Z plane    | (x,y,z) → (y,z,x) |
| Y                | Z-X plane    | (x,y,z) → (z,x,y) |

The transformation formulas are then applied in the permuted coordinate system.

---

## Non-Zero Origin

If you set the origin to (50, 50, 0):

1. The program subtracts this origin from all positions before calculating θ
2. Node 1 at (100, 0, 50) becomes (50, -50, 50) relative to the new origin
3. θ = atan2(-50, 50) = -45° = -0.785 radians
4. The force components are transformed using this new θ

This effectively places your cylindrical axis at a different location in space.

---

## Summary

1. **Positions stay Cartesian** - they are physical node locations
2. **θ is calculated** from each node's (X, Y) position relative to the cylindrical axis
3. **Vector components are rotated** by θ to align with radial/tangential directions
4. **The physical force doesn't change** - only its mathematical representation does

This is exactly like describing the same arrow using different rulers - the arrow itself hasn't moved, we're just measuring it differently!


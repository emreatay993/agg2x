# Core logic module for coordinate converter


"""
Data parser for loading nodal data from various file formats.
Supports space, tab, colon, and semicolon separated files.
"""

import re
from typing import Optional, Tuple, List
import numpy as np

from data.nodal_data import ParsedRawData, NodalData, DataType, CoordinateSystem


class DataParser:
    """Parser for loading and processing nodal data files."""
    
    # Separator options
    SEPARATORS = {
        'space': r'\s+',
        'tab': '\t',
        'colon': ':',
        'semicolon': ';',
        'comma': ','
    }
    
    SEPARATOR_DISPLAY = {
        'space': 'Space',
        'tab': 'Tab',
        'colon': 'Colon (:)',
        'semicolon': 'Semicolon (;)',
        'comma': 'Comma (,)',
        'auto': 'Auto-detect'
    }
    
    @classmethod
    def detect_separator(cls, content: str) -> str:
        """
        Auto-detect the separator used in the file content.
        
        Args:
            content: File content as string
            
        Returns:
            Detected separator key ('space', 'tab', 'colon', 'semicolon', 'comma')
        """
        lines = content.strip().split('\n')
        if not lines:
            return 'space'
        
        # Take a sample of lines (skip potential header)
        sample_lines = lines[1:min(10, len(lines))] if len(lines) > 1 else lines
        
        separator_counts = {}
        for sep_name, sep_pattern in cls.SEPARATORS.items():
            if sep_name == 'space':
                continue  # Handle space separately
            count = sum(len(re.findall(re.escape(sep_pattern) if sep_name != 'space' else sep_pattern, line)) 
                       for line in sample_lines)
            separator_counts[sep_name] = count
        
        # Check for consistent separators
        best_sep = max(separator_counts, key=separator_counts.get)
        
        # If no clear separator found, default to space/whitespace
        if separator_counts[best_sep] == 0:
            return 'space'
        
        return best_sep
    
    @classmethod
    def parse_file(cls, filepath: str, separator: str = 'auto', 
                   has_headers: bool = True) -> ParsedRawData:
        """
        Parse a data file into raw parsed data.
        
        Args:
            filepath: Path to the data file
            separator: Separator type or 'auto' for auto-detection
            has_headers: Whether the first row contains headers
            
        Returns:
            ParsedRawData object with the parsed content
        """
        with open(filepath, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return cls.parse_content(content, separator, has_headers)
    
    @classmethod
    def parse_content(cls, content: str, separator: str = 'auto',
                      has_headers: bool = True) -> ParsedRawData:
        """
        Parse string content into raw parsed data.
        
        Args:
            content: File content as string
            separator: Separator type or 'auto' for auto-detection
            has_headers: Whether the first row contains headers
            
        Returns:
            ParsedRawData object with the parsed content
        """
        if separator == 'auto':
            separator = cls.detect_separator(content)
        
        sep_pattern = cls.SEPARATORS.get(separator, r'\s+')
        
        lines = content.strip().split('\n')
        if not lines:
            raise ValueError("Empty file content")
        
        # Parse all lines
        parsed_lines = []
        for line in lines:
            line = line.strip()
            if not line:
                continue
            
            if separator == 'space':
                parts = re.split(sep_pattern, line)
            else:
                parts = line.split(sep_pattern)
            
            # Clean up parts
            parts = [p.strip() for p in parts if p.strip()]
            if parts:
                parsed_lines.append(parts)
        
        if not parsed_lines:
            raise ValueError("No data found in file")
        
        # Extract headers if present
        headers = []
        data_start = 0
        
        if has_headers and parsed_lines:
            headers = parsed_lines[0]
            data_start = 1
        
        # Convert remaining lines to data array
        data_lines = parsed_lines[data_start:]
        
        if not data_lines:
            raise ValueError("No data rows found")
        
        # Determine max columns
        max_cols = max(len(row) for row in data_lines)
        
        # Create uniform array, padding shorter rows
        data_array = []
        for row in data_lines:
            padded_row = row + [''] * (max_cols - len(row))
            data_array.append(padded_row)
        
        # Try to convert to numeric where possible
        numeric_array = np.zeros((len(data_array), max_cols))
        for i, row in enumerate(data_array):
            for j, val in enumerate(row):
                try:
                    numeric_array[i, j] = float(val)
                except (ValueError, TypeError):
                    numeric_array[i, j] = np.nan
        
        return ParsedRawData(
            data=numeric_array,
            headers=headers,
            has_headers=has_headers,
            separator=separator
        )
    
    @classmethod
    def create_nodal_data(cls, raw_data: ParsedRawData,
                          node_id_col: int,
                          x_col: int, y_col: int, z_col: int,
                          data_type: DataType,
                          value_col: Optional[int] = None,
                          vx_col: Optional[int] = None,
                          vy_col: Optional[int] = None,
                          vz_col: Optional[int] = None) -> NodalData:
        """
        Create NodalData from parsed raw data with column mapping.
        
        Args:
            raw_data: Parsed raw data
            node_id_col: Column index for node IDs
            x_col, y_col, z_col: Column indices for coordinates
            data_type: Type of data (scalar or vector)
            value_col: Column index for scalar value (if scalar)
            vx_col, vy_col, vz_col: Column indices for vector components (if vector)
            
        Returns:
            NodalData object with the mapped data
        """
        data = raw_data.data
        
        # Extract node IDs
        node_ids = data[:, node_id_col].astype(int)
        
        # Extract positions
        positions = np.column_stack([
            data[:, x_col],
            data[:, y_col],
            data[:, z_col]
        ])
        
        # Extract data values
        scalar_values = None
        vector_values = None
        
        if data_type == DataType.SCALAR:
            if value_col is None:
                raise ValueError("value_col required for scalar data")
            scalar_values = data[:, value_col]
        else:
            if vx_col is None or vy_col is None or vz_col is None:
                raise ValueError("vx_col, vy_col, vz_col required for vector data")
            vector_values = np.column_stack([
                data[:, vx_col],
                data[:, vy_col],
                data[:, vz_col]
            ])
        
        # Build column names
        column_names = []
        if raw_data.headers:
            col_indices = [node_id_col, x_col, y_col, z_col]
            if data_type == DataType.SCALAR:
                col_indices.append(value_col)
            else:
                col_indices.extend([vx_col, vy_col, vz_col])
            
            for idx in col_indices:
                if idx < len(raw_data.headers):
                    column_names.append(raw_data.headers[idx])
                else:
                    column_names.append(f"Column_{idx+1}")
        
        return NodalData(
            node_ids=node_ids,
            positions=positions,
            data_type=data_type,
            scalar_values=scalar_values,
            vector_values=vector_values,
            coordinate_system=CoordinateSystem.CARTESIAN,
            column_names=column_names
        )


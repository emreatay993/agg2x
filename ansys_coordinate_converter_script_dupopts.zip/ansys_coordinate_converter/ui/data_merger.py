"""
Component Data Merger Utility

Merges three tab-delimited text files containing X/Y/Z component data
into a single file after verifying that Node Number and XYZ locations match.

Supports any column names for the data (ENFOX, ENFOY, ENFOZ, or custom names).
"""

import os
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QDialog,
    QWidget,
    QLabel,
    QLineEdit,
    QPushButton,
    QFileDialog,
    QHBoxLayout,
    QVBoxLayout,
    QMessageBox,
    QGroupBox,
    QComboBox,
    QCheckBox,
    QFrame,
)


def _summarize_int_list(vals: List[int], max_items: int = 10) -> str:
    """Human-friendly list summary for dialogs."""
    if not vals:
        return "(none)"
    head = vals[:max_items]
    tail = "" if len(vals) <= max_items else f" ... (+{len(vals) - max_items} more)"
    return ", ".join(map(str, head)) + tail


# -----------------------------
# Parsing / validation helpers
# -----------------------------

# These are the coordinate columns that must exist and match across files
BASE_COLS_CANON = [
    "Node Number",
    "X Location (mm)",
    "Y Location (mm)",
    "Z Location (mm)",
]

# Alternative names for base columns (normalized -> canonical)
BASE_COL_ALIASES = {
    # Node ID variations
    "node number": "Node Number",
    "node": "Node Number",
    "nodeid": "Node Number",
    "node id": "Node Number",
    "node_id": "Node Number",
    "id": "Node Number",
    # X coordinate variations
    "x location (mm)": "X Location (mm)",
    "x location (m)": "X Location (mm)",
    "x location": "X Location (mm)",
    "x (mm)": "X Location (mm)",
    "x (m)": "X Location (mm)",
    "x": "X Location (mm)",
    "x_coord": "X Location (mm)",
    "xcoord": "X Location (mm)",
    # Y coordinate variations
    "y location (mm)": "Y Location (mm)",
    "y location (m)": "Y Location (mm)",
    "y location": "Y Location (mm)",
    "y (mm)": "Y Location (mm)",
    "y (m)": "Y Location (mm)",
    "y": "Y Location (mm)",
    "y_coord": "Y Location (mm)",
    "ycoord": "Y Location (mm)",
    # Z coordinate variations
    "z location (mm)": "Z Location (mm)",
    "z location (m)": "Z Location (mm)",
    "z location": "Z Location (mm)",
    "z (mm)": "Z Location (mm)",
    "z (m)": "Z Location (mm)",
    "z": "Z Location (mm)",
    "z_coord": "Z Location (mm)",
    "zcoord": "Z Location (mm)",
}


def _norm_col(s: str) -> str:
    """Normalize column name: strip, lowercase, collapse whitespace"""
    return " ".join(str(s).strip().lower().split())


def _find_base_columns(cols: List[str]) -> Dict[str, str]:
    """
    Map canonical base column names to actual column names in file.
    Returns dict: {canonical: actual} or empty dict if not all found.
    """
    norm_to_actual = {_norm_col(c): c for c in cols}
    mapping = {}
    
    for canon in BASE_COLS_CANON:
        canon_norm = _norm_col(canon)
        # Try exact match first
        if canon_norm in norm_to_actual:
            mapping[canon] = norm_to_actual[canon_norm]
            continue
        # Try aliases
        found = False
        for alias, target in BASE_COL_ALIASES.items():
            if target == canon and alias in norm_to_actual:
                mapping[canon] = norm_to_actual[alias]
                found = True
                break
        if not found:
            return {}
    
    return mapping


def _find_data_columns(cols: List[str], base_cols: List[str]) -> List[str]:
    """Find all columns that are not base columns (these are potential data columns)."""
    base_set = set(base_cols)
    return [c for c in cols if c not in base_set]


@dataclass
class ParsedFile:
    path: str
    df: pd.DataFrame
    base_col_mapping: Dict[str, str]  # canonical -> actual
    data_columns: List[str]  # Available data columns


def parse_file(path: str) -> ParsedFile:
    """Parse a data file and identify its structure."""
    if not os.path.isfile(path):
        raise ValueError(f"File does not exist:\n{path}")

    # Try to detect delimiter
    with open(path, "r", encoding="utf-8", errors="replace") as f:
        header_line = f.readline()
    
    # Determine separator
    if "\t" in header_line:
        sep = "\t"
    elif "," in header_line:
        sep = ","
    elif ";" in header_line:
        sep = ";"
    else:
        sep = r"\s+"  # Whitespace
    
    df_raw = pd.read_csv(path, sep=sep, engine="python")
    if df_raw.empty:
        raise ValueError(f"File has no data rows:\n{path}")

    # Find base columns
    base_map = _find_base_columns(df_raw.columns.tolist())
    if not base_map:
        raise ValueError(
            "Missing required base columns.\n"
            f"Required (or similar names):\n"
            f"  - Node Number (or Node, NodeID)\n"
            f"  - X Location (or X)\n"
            f"  - Y Location (or Y)\n"
            f"  - Z Location (or Z)\n\n"
            f"File:\n{path}\n\n"
            f"Columns found:\n{list(df_raw.columns)}"
        )

    # Find data columns (everything that's not a base column)
    base_actual_cols = list(base_map.values())
    data_cols = _find_data_columns(df_raw.columns.tolist(), base_actual_cols)
    
    if not data_cols:
        raise ValueError(
            f"No data columns found in file.\n"
            f"File only contains base columns (Node, X, Y, Z).\n\n"
            f"File:\n{path}"
        )

    # Build clean dataframe with canonical base column names
    df = pd.DataFrame()
    for canon in BASE_COLS_CANON:
        df[canon] = df_raw[base_map[canon]]
    
    # Add all data columns as-is
    for col in data_cols:
        df[col] = df_raw[col]

    # Coerce types
    try:
        df["Node Number"] = df["Node Number"].astype(int)
    except Exception as e:
        raise ValueError(f"Failed to parse 'Node Number' as integer in:\n{path}\n\n{e}")

    for c in ["X Location (mm)", "Y Location (mm)", "Z Location (mm)"] + data_cols:
        df[c] = pd.to_numeric(df[c], errors="coerce")

    return ParsedFile(
        path=path,
        df=df,
        base_col_mapping=base_map,
        data_columns=data_cols
    )


def validate_same_geometry(
    a: pd.DataFrame,
    b: pd.DataFrame,
    label_a: str,
    label_b: str,
    allow_input_duplicates: bool = False,
) -> List[str]:
    """Ensures Node Number and XYZ columns match.

    Returns a list of warning strings (empty if none).

    When allow_input_duplicates=True, duplicate nodes/rows are *allowed*:
    - Geometry checks are performed on the first occurrence of each Node Number.
    - Warnings are returned so the GUI can inform the user.
    """

    warnings: List[str] = []

    a2 = a[BASE_COLS_CANON].sort_values("Node Number").reset_index(drop=True)
    b2 = b[BASE_COLS_CANON].sort_values("Node Number").reset_index(drop=True)

    atol = 1e-6
    rtol = 1e-9

    # Duplicate Node Numbers can create extra rows after merge (cartesian product).
    dup_nodes_a = a2["Node Number"].duplicated(keep=False)
    dup_nodes_b = b2["Node Number"].duplicated(keep=False)
    if dup_nodes_a.any() or dup_nodes_b.any():
        ids_a = a2.loc[dup_nodes_a, "Node Number"].astype(int).drop_duplicates().tolist()
        ids_b = b2.loc[dup_nodes_b, "Node Number"].astype(int).drop_duplicates().tolist()
        msg = (
            "Duplicate Node Numbers detected.\n\n"
            "Duplicates can inflate the merged row count (cartesian product).\n"
            "If you enable output deduplication, only the first occurrence per node is kept.\n\n"
        )
        if ids_a:
            msg += f"{label_a} duplicates (examples): {_summarize_int_list(ids_a)}\n"
        if ids_b:
            msg += f"{label_b} duplicates (examples): {_summarize_int_list(ids_b)}\n"
        if allow_input_duplicates:
            warnings.append(msg)
        else:
            raise ValueError(msg)

    # Duplicate full rows (same Node+XYZ repeated)
    dup_rows_a = a2.duplicated(subset=BASE_COLS_CANON, keep=False)
    dup_rows_b = b2.duplicated(subset=BASE_COLS_CANON, keep=False)
    if dup_rows_a.any() or dup_rows_b.any():
        msg = (
            "Duplicate rows detected (same Node Number and XYZ repeated).\n\n"
            "This commonly happens when multiple load steps/substeps are appended\n"
            "into the same export, or when the exporter writes repeated rows.\n\n"
            "If allowed, merging will proceed using the first occurrence per node."
        )
        if allow_input_duplicates:
            warnings.append(msg)
        else:
            raise ValueError(msg)

    # Strict mode: require perfect 1:1 correspondence row-wise
    if not allow_input_duplicates:
        if len(a2) != len(b2):
            raise ValueError(
                f"Row count mismatch.\n"
                f"{label_a}: {len(a2)} rows\n"
                f"{label_b}: {len(b2)} rows"
            )

        na = a2["Node Number"].to_numpy()
        nb = b2["Node Number"].to_numpy()
        if not np.array_equal(na, nb):
            idx = int(np.argmax(na != nb))
            raise ValueError(
                f"Node Number mismatch.\n"
                f"First mismatch at sorted row {idx}:\n"
                f"{label_a} Node = {na[idx]}\n"
                f"{label_b} Node = {nb[idx]}"
            )

        for col in ["X Location (mm)", "Y Location (mm)", "Z Location (mm)"]:
            va = a2[col].to_numpy(dtype=float)
            vb = b2[col].to_numpy(dtype=float)
            ok = np.isclose(va, vb, rtol=rtol, atol=atol)
            if not np.all(ok):
                idx = int(np.argmax(~ok))
                node = int(na[idx])
                raise ValueError(
                    f"Coordinate mismatch in '{col}'.\n"
                    f"First mismatch at Node {node} (sorted row {idx}):\n"
                    f"{label_a}: {va[idx]:.12g}\n"
                    f"{label_b}: {vb[idx]:.12g}"
                )

        return warnings

    # Allow-duplicates mode: check geometry on unique Node Numbers only
    a_u = a2.drop_duplicates(subset=["Node Number"], keep="first").reset_index(drop=True)
    b_u = b2.drop_duplicates(subset=["Node Number"], keep="first").reset_index(drop=True)

    na = a_u["Node Number"].to_numpy()
    nb = b_u["Node Number"].to_numpy()
    if len(na) != len(nb):
        raise ValueError(
            "Unique node count mismatch.\n\n"
            f"{label_a}: {len(na)} unique nodes\n"
            f"{label_b}: {len(nb)} unique nodes\n\n"
            "(Duplicates are allowed, but both files still must contain the same node set.)"
        )

    if not np.array_equal(na, nb):
        # show a small diff hint
        set_a = set(map(int, na.tolist()))
        set_b = set(map(int, nb.tolist()))
        only_a = sorted(set_a - set_b)[:10]
        only_b = sorted(set_b - set_a)[:10]
        raise ValueError(
            "Unique Node Number sets do not match.\n\n"
            f"Only in {label_a} (examples): {_summarize_int_list(only_a)}\n"
            f"Only in {label_b} (examples): {_summarize_int_list(only_b)}"
        )

    for col in ["X Location (mm)", "Y Location (mm)", "Z Location (mm)"]:
        va = a_u[col].to_numpy(dtype=float)
        vb = b_u[col].to_numpy(dtype=float)
        ok = np.isclose(va, vb, rtol=rtol, atol=atol)
        if not np.all(ok):
            idx = int(np.argmax(~ok))
            node = int(na[idx])
            raise ValueError(
                f"Coordinate mismatch in '{col}'.\n"
                f"First mismatch at Node {node} (unique-node check, sorted row {idx}):\n"
                f"{label_a}: {va[idx]:.12g}\n"
                f"{label_b}: {vb[idx]:.12g}"
            )

    # Warn if duplicates exist with inconsistent coordinates within the same file
    def _inconsistent_dup_coords(df_sorted: pd.DataFrame) -> List[int]:
        if not df_sorted["Node Number"].duplicated(keep=False).any():
            return []
        g = df_sorted.groupby("Node Number")[
            ["X Location (mm)", "Y Location (mm)", "Z Location (mm)"]
        ]
        spread = (g.max() - g.min()).abs()
        bad = spread[(spread > atol).any(axis=1)].index.astype(int).tolist()
        return bad

    bad_a = _inconsistent_dup_coords(a2)
    bad_b = _inconsistent_dup_coords(b2)
    if bad_a:
        warnings.append(
            f"{label_a}: duplicate Node Numbers with inconsistent coordinates (examples): {_summarize_int_list(bad_a)}"
        )
    if bad_b:
        warnings.append(
            f"{label_b}: duplicate Node Numbers with inconsistent coordinates (examples): {_summarize_int_list(bad_b)}"
        )

    return warnings


def merge_files(
    file_x: ParsedFile, col_x: str, out_name_x: str,
    file_y: ParsedFile, col_y: str, out_name_y: str,
    file_z: ParsedFile, col_z: str, out_name_z: str,
    # Duplicate-handling options (wired to GUI)
    allow_input_duplicates: bool = False,
    drop_merged_duplicates: bool = False,
) -> Tuple[pd.DataFrame, Dict[str, object]]:
    """Merge three files using specified data columns.

    Returns:
        (merged_df, info_dict)
    """

    info: Dict[str, object] = {
        "warnings": [],
        "merged_duplicate_nodes_before_drop": 0,
        "merged_duplicate_node_examples_before_drop": [],
        "merged_rows_before_drop": None,
        "merged_duplicates_dropped": 0,
    }

    # Validate geometry
    warnings: List[str] = []
    warnings += validate_same_geometry(
        file_x.df, file_y.df, "File X", "File Y", allow_input_duplicates=allow_input_duplicates
    )
    warnings += validate_same_geometry(
        file_x.df, file_z.df, "File X", "File Z", allow_input_duplicates=allow_input_duplicates
    )
    info["warnings"] = warnings

    # Build merged dataframe
    # ----------------------------
    # NEW: merge by Node Number only
    # ----------------------------
    # We already validated geometry (Node + XYZ) with tolerance above.
    # Merging on float coordinate columns can be fragile (formatting / rounding).
    # Using Node Number as the join key is sufficient *after* geometry validation
    # and avoids accidental non-matches caused by float-string parsing.
    key_cols = ["Node Number"]
    
    # Keep coordinates from file_x in the output
    df1 = file_x.df[BASE_COLS_CANON + [col_x]].copy()
    df1 = df1.rename(columns={col_x: out_name_x})
    df1["__ord_x"] = np.arange(len(df1), dtype=int)

    df2 = file_y.df[key_cols + [col_y]].copy()
    df2 = df2.rename(columns={col_y: out_name_y})
    df2["__ord_y"] = np.arange(len(df2), dtype=int)

    df3 = file_z.df[key_cols + [col_z]].copy()
    df3 = df3.rename(columns={col_z: out_name_z})
    df3["__ord_z"] = np.arange(len(df3), dtype=int)

    merged = df1.merge(df2[key_cols + [out_name_y, "__ord_y"]], on=key_cols, how="inner")
    merged = merged.merge(df3[key_cols + [out_name_z, "__ord_z"]], on=key_cols, how="inner")

    # Strict mode: duplicates are not allowed anywhere; row count must match file_x.
    if not allow_input_duplicates:
        if len(merged) != len(df1):
            if len(merged) < len(df1):
                raise ValueError(
                    "Merge resulted in row loss. "
                    "Check that all files contain the same nodes."  # geometry validated earlier
                )
            raise ValueError(
                "Merge resulted in extra rows. "
                "This usually means duplicate Node Numbers exist in one or more inputs."
            )
    else:
        # Allow-duplicates mode: still ensure we didn't lose any unique nodes.
        unique_x = int(df1["Node Number"].nunique())
        unique_m = int(merged["Node Number"].nunique())
        if unique_m != unique_x:
            set_x = set(df1["Node Number"].astype(int).tolist())
            set_m = set(merged["Node Number"].astype(int).tolist())
            missing = sorted(set_x - set_m)
            raise ValueError(
                "Merge resulted in missing nodes (unique-node check).\n\n"
                f"Missing node examples: {_summarize_int_list(missing)}"
            )

    # Report duplicate nodes in merged output (before optional drop)
    dup_m = merged["Node Number"].duplicated(keep=False)
    if dup_m.any():
        dup_ids = (
            merged.loc[dup_m, "Node Number"].astype(int).drop_duplicates().tolist()
        )
        info["merged_duplicate_nodes_before_drop"] = int(len(dup_ids))
        info["merged_duplicate_node_examples_before_drop"] = dup_ids[:10]
    info["merged_rows_before_drop"] = int(len(merged))

    # Optional: remove duplicate node rows (keep first)
    if drop_merged_duplicates:
        # Deterministic: keep the earliest combination based on input row orders.
        merged = merged.sort_values(
            ["Node Number", "__ord_x", "__ord_y", "__ord_z"], kind="mergesort"
        ).reset_index(drop=True)
        before = len(merged)
        merged = merged.drop_duplicates(subset=["Node Number"], keep="first").reset_index(drop=True)
        info["merged_duplicates_dropped"] = int(before - len(merged))

        # After dropping, ensure we still have all unique nodes
        if int(merged["Node Number"].nunique()) != int(df1["Node Number"].nunique()):
            raise ValueError(
                "Output deduplication unexpectedly removed unique nodes. "
                "This indicates inconsistent input data."
            )

    # Final column order (drop internal ordering columns)
    merged = merged.drop(columns=["__ord_x", "__ord_y", "__ord_z"], errors="ignore")
    merged = merged[BASE_COLS_CANON + [out_name_x, out_name_y, out_name_z]]
    return merged, info


# -----------------------------
# UI Components
# -----------------------------

class FileInputRow(QWidget):
    """Widget for file selection with data column dropdown."""
    
    def __init__(self, label_text: str, parent=None):
        super().__init__(parent)
        
        self.parsed_file: Optional[ParsedFile] = None
        
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(4)
        
        # File path row
        path_row = QHBoxLayout()
        self.label = QLabel(label_text)
        self.label.setMinimumWidth(100)
        self.path_edit = QLineEdit()
        self.path_edit.setReadOnly(True)
        self.path_edit.setPlaceholderText("No file selected...")
        self.browse_btn = QPushButton("Browse...")
        
        path_row.addWidget(self.label)
        path_row.addWidget(self.path_edit, stretch=1)
        path_row.addWidget(self.browse_btn)
        layout.addLayout(path_row)
        
        # Column selection row
        col_row = QHBoxLayout()
        col_row.addSpacing(100)  # Align with path
        col_row.addWidget(QLabel("Data Column:"))
        self.column_combo = QComboBox()
        self.column_combo.setMinimumWidth(200)
        self.column_combo.setEnabled(False)
        col_row.addWidget(self.column_combo, stretch=1)
        layout.addLayout(col_row)
        
        self.setLayout(layout)
    
    def set_parsed_file(self, parsed: ParsedFile):
        """Set the parsed file and populate column dropdown."""
        self.parsed_file = parsed
        self.path_edit.setText(parsed.path)
        self.column_combo.clear()
        self.column_combo.addItems(parsed.data_columns)
        self.column_combo.setEnabled(True)
        
        # Auto-select if only one data column
        if len(parsed.data_columns) == 1:
            self.column_combo.setCurrentIndex(0)
    
    def clear(self):
        """Clear the file selection."""
        self.parsed_file = None
        self.path_edit.clear()
        self.column_combo.clear()
        self.column_combo.setEnabled(False)
    
    def get_selected_column(self) -> Optional[str]:
        """Get the selected data column name."""
        if self.column_combo.currentText():
            return self.column_combo.currentText()
        return None


class ComponentMergerDialog(QDialog):
    """Dialog for merging component data files."""
    
    def __init__(self, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Component Data Merger")
        self.setMinimumWidth(750)
        self.setMinimumHeight(550)

        self.output_path = ""
        self._build_ui()
        self._update_merge_enabled()

    def _build_ui(self):
        main = QVBoxLayout()
        main.setContentsMargins(14, 14, 14, 14)
        main.setSpacing(12)

        # Group: inputs
        gb_in = QGroupBox("Input Files (select file and data column for each component)")
        in_layout = QVBoxLayout()
        in_layout.setSpacing(12)

        self.row_x = FileInputRow("X Component:")
        self.row_y = FileInputRow("Y Component:")
        self.row_z = FileInputRow("Z Component:")

        self.row_x.browse_btn.clicked.connect(lambda: self._pick_input(self.row_x))
        self.row_y.browse_btn.clicked.connect(lambda: self._pick_input(self.row_y))
        self.row_z.browse_btn.clicked.connect(lambda: self._pick_input(self.row_z))
        
        # Connect combo changes to update merge button
        self.row_x.column_combo.currentTextChanged.connect(self._update_merge_enabled)
        self.row_y.column_combo.currentTextChanged.connect(self._update_merge_enabled)
        self.row_z.column_combo.currentTextChanged.connect(self._update_merge_enabled)

        in_layout.addWidget(self.row_x)
        in_layout.addWidget(self.row_y)
        in_layout.addWidget(self.row_z)
        gb_in.setLayout(in_layout)

        # Group: output column names
        gb_names = QGroupBox("Output Column Names")
        names_layout = QHBoxLayout()
        names_layout.setSpacing(12)
        
        names_layout.addWidget(QLabel("X:"))
        self.name_x_edit = QLineEdit("Fx")
        self.name_x_edit.setMaximumWidth(120)
        names_layout.addWidget(self.name_x_edit)
        
        names_layout.addWidget(QLabel("Y:"))
        self.name_y_edit = QLineEdit("Fy")
        self.name_y_edit.setMaximumWidth(120)
        names_layout.addWidget(self.name_y_edit)
        
        names_layout.addWidget(QLabel("Z:"))
        self.name_z_edit = QLineEdit("Fz")
        self.name_z_edit.setMaximumWidth(120)
        names_layout.addWidget(self.name_z_edit)
        
        names_layout.addStretch()
        gb_names.setLayout(names_layout)

        # Group: duplicates
        gb_dups = QGroupBox("Duplicate Handling")
        dups_layout = QVBoxLayout()
        dups_layout.setSpacing(6)

        self.allow_input_dups_cb = QCheckBox(
            "Allow duplicate nodes/rows in inputs (skip duplicate check)"
        )
        self.allow_input_dups_cb.setToolTip(
            "If enabled, the merger will not error out when duplicate Node Numbers exist in inputs. "
            "This can inflate the merged row count."
        )

        self.drop_merged_dups_cb = QCheckBox(
            "Remove duplicate node rows in merged output (keep first)"
        )
        self.drop_merged_dups_cb.setToolTip(
            "If the merged output contains multiple rows with the same Node Number, "
            "keep the first occurrence and remove subsequent rows."
        )

        dups_layout.addWidget(self.allow_input_dups_cb)
        dups_layout.addWidget(self.drop_merged_dups_cb)
        gb_dups.setLayout(dups_layout)

        # Group: output file
        gb_out = QGroupBox("Output File")
        out_layout = QHBoxLayout()
        
        self.out_path_edit = QLineEdit()
        self.out_path_edit.setReadOnly(True)
        self.out_path_edit.setPlaceholderText("Select output file...")
        self.out_browse_btn = QPushButton("Save as...")
        self.out_browse_btn.clicked.connect(self._pick_output)
        
        out_layout.addWidget(self.out_path_edit, stretch=1)
        out_layout.addWidget(self.out_browse_btn)
        gb_out.setLayout(out_layout)

        # Actions
        actions = QHBoxLayout()
        actions.setSpacing(10)

        self.btn_merge = QPushButton("Merge")
        self.btn_merge.clicked.connect(self._do_merge)

        self.btn_clear = QPushButton("Clear All")
        self.btn_clear.clicked.connect(self._clear_all)

        self.btn_close = QPushButton("Close")
        self.btn_close.clicked.connect(self.close)

        actions.addStretch(1)
        actions.addWidget(self.btn_clear)
        actions.addWidget(self.btn_merge)
        actions.addWidget(self.btn_close)

        # Notes
        note = QLabel(
            "This tool merges three files containing X, Y, Z component data into one file.\n"
            "Files must have matching Node Numbers and coordinates (with tight tolerance).\n"
            "Supports tab, comma, semicolon, or space-separated files."
        )
        note.setWordWrap(True)

        # Status label
        self.status_label = QLabel("Select three input files and specify output location.")

        main.addWidget(gb_in)
        main.addWidget(gb_names)
        main.addWidget(gb_dups)
        main.addWidget(gb_out)
        main.addLayout(actions)
        main.addWidget(note)
        main.addStretch()
        main.addWidget(self.status_label)

        self.setLayout(main)

    def _pick_input(self, row: FileInputRow):
        path, _ = QFileDialog.getOpenFileName(
            self,
            "Select data file",
            "",
            "Text files (*.txt *.dat *.csv);;All files (*.*)",
        )
        if not path:
            return

        try:
            parsed = parse_file(path)
            row.set_parsed_file(parsed)
            self.status_label.setText(f"Loaded: {os.path.basename(path)} ({len(parsed.data_columns)} data column(s))")
        except Exception as e:
            self._error(str(e))
            return

        self._update_merge_enabled()

    def _pick_output(self):
        default_name = "merged_data.txt"
        start_dir = ""
        if self.row_x.parsed_file:
            start_dir = os.path.dirname(self.row_x.parsed_file.path)
        
        path, _ = QFileDialog.getSaveFileName(
            self,
            "Save merged file as",
            os.path.join(start_dir, default_name) if start_dir else default_name,
            "Text files (*.txt);;CSV files (*.csv);;All files (*.*)",
        )
        if not path:
            return

        if not os.path.splitext(path)[1]:
            path += ".txt"

        self.output_path = path
        self.out_path_edit.setText(path)
        self.status_label.setText("Output path selected.")
        self._update_merge_enabled()

    def _update_merge_enabled(self):
        ok = (
            self.row_x.parsed_file is not None and
            self.row_y.parsed_file is not None and
            self.row_z.parsed_file is not None and
            self.row_x.get_selected_column() is not None and
            self.row_y.get_selected_column() is not None and
            self.row_z.get_selected_column() is not None and
            bool(self.output_path) and
            bool(self.name_x_edit.text().strip()) and
            bool(self.name_y_edit.text().strip()) and
            bool(self.name_z_edit.text().strip())
        )
        self.btn_merge.setEnabled(ok)

    def _clear_all(self):
        self.row_x.clear()
        self.row_y.clear()
        self.row_z.clear()
        self.output_path = ""
        self.out_path_edit.clear()
        self.name_x_edit.setText("Fx")
        self.name_y_edit.setText("Fy")
        self.name_z_edit.setText("Fz")
        self.allow_input_dups_cb.setChecked(False)
        self.drop_merged_dups_cb.setChecked(False)
        self.status_label.setText("Cleared all selections.")
        self._update_merge_enabled()

    def _do_merge(self):
        try:
            merged, info = merge_files(
                self.row_x.parsed_file, self.row_x.get_selected_column(), self.name_x_edit.text().strip(),
                self.row_y.parsed_file, self.row_y.get_selected_column(), self.name_y_edit.text().strip(),
                self.row_z.parsed_file, self.row_z.get_selected_column(), self.name_z_edit.text().strip(),
                allow_input_duplicates=self.allow_input_dups_cb.isChecked(),
                drop_merged_duplicates=self.drop_merged_dups_cb.isChecked(),
            )

            out_dir = os.path.dirname(self.output_path)
            if out_dir and not os.path.isdir(out_dir):
                raise ValueError(f"Output directory does not exist:\n{out_dir}")

            # Determine separator based on extension
            if self.output_path.endswith('.csv'):
                sep = ','
            else:
                sep = '\t'
            
            merged.to_csv(self.output_path, sep=sep, index=False, float_format="%.10g")

            self.status_label.setText("Merge complete!")

            # Build summary / warnings
            lines = [
                f"Merged file saved:\n{self.output_path}",
                f"Rows: {len(merged)}",
                f"Columns: {', '.join(merged.columns.tolist())}",
            ]

            dropped = int(info.get("merged_duplicates_dropped", 0) or 0)
            if dropped > 0:
                lines.append(f"Duplicate-node rows removed from output: {dropped}")

            dup_nodes_before = int(info.get("merged_duplicate_nodes_before_drop", 0) or 0)
            if dup_nodes_before > 0 and not self.drop_merged_dups_cb.isChecked():
                ex = info.get("merged_duplicate_node_examples_before_drop", [])
                lines.append(
                    "Merged output contains duplicate Node Numbers (examples): "
                    + _summarize_int_list(list(map(int, ex)))
                )
                lines.append(
                    "Tip: enable 'Remove duplicate node rows in merged output' to keep the first occurrence per node."
                )

            warnings = info.get("warnings", []) or []
            if warnings:
                lines.append("\nWarnings:\n" + "\n\n".join(map(str, warnings)))

            QMessageBox.information(self, "Merge Complete", "\n\n".join(lines))
        except Exception as e:
            self._error(str(e))

    def _error(self, msg: str):
        self.status_label.setText("Error occurred.")
        QMessageBox.critical(self, "Error", msg)


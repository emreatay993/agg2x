"""
Main application window for the Nodal Coordinate Converter.
"""

from PyQt5.QtWidgets import (
    QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
    QSplitter, QMenuBar, QMenu, QAction, QStatusBar,
    QMessageBox, QFileDialog, QLabel
)
from PyQt5.QtCore import Qt
from PyQt5.QtGui import QFont

import pyvista as pv
from pyvistaqt import QtInteractor

from ui.data_input_panel import DataInputPanel
from ui.column_mapping_panel import ColumnMappingPanel
from ui.transform_panel import TransformPanel
from ui.preview_table import PreviewTableWidget
from core.visualizer import Visualizer
from data.nodal_data import NodalData, ParsedRawData, TransformSettings


class MainWindow(QMainWindow):
    """Main application window."""
    
    def __init__(self):
        super().__init__()
        
        self.setWindowTitle("Nodal Coordinate System Converter")
        self.setMinimumSize(1400, 900)
        
        # Data storage
        self.raw_data: ParsedRawData = None
        self.nodal_data: NodalData = None
        self.transformed_data: NodalData = None
        self.current_transform_settings: TransformSettings = None
        
        # Setup UI
        self._setup_menu_bar()
        self._setup_central_widget()
        self._setup_status_bar()
        self._apply_stylesheet()
        
        # Connect signals
        self._connect_signals()
    
    def _setup_menu_bar(self):
        """Create the menu bar."""
        menubar = self.menuBar()
        
        # File menu
        file_menu = menubar.addMenu("File")
        
        open_action = QAction("Open Data File...", self)
        open_action.setShortcut("Ctrl+O")
        open_action.triggered.connect(self._on_open_file)
        file_menu.addAction(open_action)
        
        file_menu.addSeparator()
        
        export_action = QAction("Export Transformed Data...", self)
        export_action.setShortcut("Ctrl+E")
        export_action.triggered.connect(self._on_export_data)
        file_menu.addAction(export_action)
        
        file_menu.addSeparator()
        
        exit_action = QAction("Exit", self)
        exit_action.setShortcut("Ctrl+Q")
        exit_action.triggered.connect(self.close)
        file_menu.addAction(exit_action)
        
        # View menu
        view_menu = menubar.addMenu("View")
        
        reset_view_action = QAction("Reset 3D View", self)
        reset_view_action.setShortcut("Ctrl+R")
        reset_view_action.triggered.connect(self._on_reset_view)
        view_menu.addAction(reset_view_action)
        
        toggle_axes_action = QAction("Toggle Axes", self)
        toggle_axes_action.setShortcut("Ctrl+A")
        toggle_axes_action.triggered.connect(self._on_toggle_axes)
        view_menu.addAction(toggle_axes_action)
        
        view_menu.addSeparator()
        
        toggle_bg_action = QAction("Toggle Background (Dark/Light)", self)
        toggle_bg_action.setShortcut("Ctrl+B")
        toggle_bg_action.triggered.connect(self._on_toggle_background)
        view_menu.addAction(toggle_bg_action)
        
        view_menu.addSeparator()
        
        increase_size_action = QAction("Increase Point Size", self)
        increase_size_action.setShortcut("Ctrl++")
        increase_size_action.triggered.connect(self._on_increase_point_size)
        view_menu.addAction(increase_size_action)
        
        decrease_size_action = QAction("Decrease Point Size", self)
        decrease_size_action.setShortcut("Ctrl+-")
        decrease_size_action.triggered.connect(self._on_decrease_point_size)
        view_menu.addAction(decrease_size_action)
        
        reset_size_action = QAction("Reset Point Size", self)
        reset_size_action.setShortcut("Ctrl+0")
        reset_size_action.triggered.connect(self._on_reset_point_size)
        view_menu.addAction(reset_size_action)
        
        # Tools menu
        tools_menu = menubar.addMenu("Tools")
        
        component_merger_action = QAction("Component Data Merger...", self)
        component_merger_action.setShortcut("Ctrl+M")
        component_merger_action.triggered.connect(self._on_open_component_merger)
        tools_menu.addAction(component_merger_action)
        
        # Help menu
        help_menu = menubar.addMenu("Help")
        
        about_action = QAction("About", self)
        about_action.triggered.connect(self._on_about)
        help_menu.addAction(about_action)
    
    def _setup_central_widget(self):
        """Create the main layout with panels and visualization."""
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        main_layout = QHBoxLayout(central_widget)
        main_layout.setContentsMargins(8, 8, 8, 8)
        main_layout.setSpacing(8)
        
        # Left panel (controls)
        left_panel = QWidget()
        left_layout = QVBoxLayout(left_panel)
        left_layout.setContentsMargins(0, 0, 0, 0)
        left_layout.setSpacing(8)
        
        # Data input panel
        self.data_input_panel = DataInputPanel()
        left_layout.addWidget(self.data_input_panel)
        
        # Column mapping panel
        self.column_mapping_panel = ColumnMappingPanel()
        left_layout.addWidget(self.column_mapping_panel)
        
        # Transform panel
        self.transform_panel = TransformPanel()
        left_layout.addWidget(self.transform_panel)
        
        left_layout.addStretch()
        
        left_panel.setFixedWidth(340)
        
        # Right panel (visualization + preview)
        right_panel = QWidget()
        right_layout = QVBoxLayout(right_panel)
        right_layout.setContentsMargins(0, 0, 0, 0)
        right_layout.setSpacing(8)
        
        # 3D visualization
        viz_container = QWidget()
        viz_layout = QVBoxLayout(viz_container)
        viz_layout.setContentsMargins(0, 0, 0, 0)
        
        # PyVista plotter
        self.plotter = QtInteractor(viz_container)
        self.plotter.set_background('#ffffff')  # Default: white background
        self.plotter.add_axes()
        viz_layout.addWidget(self.plotter.interactor)
        
        # Visualization controls
        viz_controls = QWidget()
        viz_controls_layout = QHBoxLayout(viz_controls)
        viz_controls_layout.setContentsMargins(4, 4, 4, 4)
        
        from PyQt5.QtWidgets import QPushButton
        
        self.reset_view_btn = QPushButton("Reset View")
        self.reset_view_btn.clicked.connect(self._on_reset_view)
        viz_controls_layout.addWidget(self.reset_view_btn)
        
        self.toggle_axes_btn = QPushButton("Toggle Axes")
        self.toggle_axes_btn.clicked.connect(self._on_toggle_axes)
        viz_controls_layout.addWidget(self.toggle_axes_btn)
        
        self.toggle_vectors_btn = QPushButton("Toggle Vectors")
        self.toggle_vectors_btn.clicked.connect(self._on_toggle_vectors)
        viz_controls_layout.addWidget(self.toggle_vectors_btn)
        
        self.toggle_bg_btn = QPushButton("Toggle BG (Ctrl+B)")
        self.toggle_bg_btn.clicked.connect(self._on_toggle_background)
        viz_controls_layout.addWidget(self.toggle_bg_btn)
        
        self.color_vectors_btn = QPushButton("Color Vectors")
        self.color_vectors_btn.setCheckable(True)
        self.color_vectors_btn.setChecked(False)
        self.color_vectors_btn.clicked.connect(self._on_toggle_vector_colors)
        viz_controls_layout.addWidget(self.color_vectors_btn)
        
        viz_controls_layout.addStretch()
        
        # Data view indicator and toggle
        self.data_view_label = QLabel("View:")
        viz_controls_layout.addWidget(self.data_view_label)
        
        self.view_original_btn = QPushButton("Original")
        self.view_original_btn.setCheckable(True)
        self.view_original_btn.setChecked(True)
        self.view_original_btn.clicked.connect(self._on_view_original)
        viz_controls_layout.addWidget(self.view_original_btn)
        
        self.view_transformed_btn = QPushButton("Transformed")
        self.view_transformed_btn.setCheckable(True)
        self.view_transformed_btn.setChecked(False)
        self.view_transformed_btn.setEnabled(False)  # Disabled until transform is applied
        self.view_transformed_btn.clicked.connect(self._on_view_transformed)
        viz_controls_layout.addWidget(self.view_transformed_btn)
        
        viz_layout.addWidget(viz_controls)
        
        # Data preview table
        self.preview_table = PreviewTableWidget()
        
        # Splitter for viz and table
        splitter = QSplitter(Qt.Vertical)
        splitter.addWidget(viz_container)
        splitter.addWidget(self.preview_table)
        splitter.setSizes([500, 300])
        
        right_layout.addWidget(splitter)
        
        # Add to main layout
        main_layout.addWidget(left_panel)
        main_layout.addWidget(right_panel, stretch=1)
        
        # Initialize visualizer
        self.visualizer = Visualizer(self.plotter)
        self.show_axes = True
        self.show_vectors = True
        self.color_vectors_by_magnitude = False  # Color vectors by magnitude
        self.dark_background = False  # Track background state (default: light)
        self.BG_DARK = '#1e1e2e'
        self.BG_LIGHT = '#ffffff'
        self.point_size_factor = 1.0  # Point size multiplier
        self.viewing_transformed = False  # Track which data view is active
    
    def _setup_status_bar(self):
        """Create the status bar."""
        self.status_bar = QStatusBar()
        self.setStatusBar(self.status_bar)
        
        self.status_label = QLabel("Ready")
        self.status_bar.addWidget(self.status_label, stretch=1)
        
        self.node_count_label = QLabel("Nodes: 0")
        self.status_bar.addPermanentWidget(self.node_count_label)
    
    def _connect_signals(self):
        """Connect panel signals to handlers."""
        # Data input signals
        self.data_input_panel.file_loaded.connect(self._on_file_loaded)
        self.data_input_panel.parse_requested.connect(self._on_parse_requested)
        self.data_input_panel.parse_succeeded.connect(self._on_parse_succeeded)
        
        # Column mapping signals
        self.column_mapping_panel.mapping_applied.connect(self._on_mapping_applied)
        
        # Transform signals
        self.transform_panel.transform_requested.connect(self._on_transform_requested)
        self.transform_panel.reset_requested.connect(self._on_reset_transform)
        self.transform_panel.export_requested.connect(self._on_export_data)
    
    def _on_open_file(self):
        """Handle file open action."""
        self.data_input_panel.browse_file()
    
    def _on_file_loaded(self, filepath: str):
        """Handle file loaded signal."""
        self.status_label.setText(f"Loaded: {filepath}")
    
    def _on_parse_succeeded(self):
        """Handle successful parse - collapse the data input panel."""
        self.data_input_panel.collapse()
    
    def _on_parse_requested(self, raw_data: ParsedRawData):
        """Handle parse requested signal."""
        self.raw_data = raw_data
        
        # Update column mapping options
        self.column_mapping_panel.set_column_options(raw_data.get_column_options())
        
        # Show raw data preview
        self.preview_table.show_raw_data(raw_data)
        
        self.status_label.setText(f"Parsed {raw_data.num_rows} rows, {raw_data.num_columns} columns")
    
    def _on_mapping_applied(self, nodal_data: NodalData):
        """Handle mapping applied signal."""
        self.nodal_data = nodal_data
        self.transformed_data = None
        self.current_transform_settings = None
        
        # Reset view buttons
        self._update_view_buttons()
        
        # Update preview
        self.preview_table.show_nodal_data(nodal_data, "Original")
        
        # Update visualization
        self.visualizer.show_nodal_data(nodal_data, show_vectors=self.show_vectors, 
                                         point_size_factor=self.point_size_factor,
                                         color_vectors_by_magnitude=self.color_vectors_by_magnitude)
        self.plotter.reset_camera()
        
        # Update status
        self.node_count_label.setText(f"Nodes: {nodal_data.num_nodes}")
        self.status_label.setText("Data mapped - Viewing: Original Data")
        
        # Enable transform panel
        self.transform_panel.setEnabled(True)
    
    def _on_transform_requested(self, transformed_data: NodalData, settings: TransformSettings):
        """Handle transform requested signal."""
        self.transformed_data = transformed_data
        self.current_transform_settings = settings
        
        # Update preview with both original and transformed
        self.preview_table.show_nodal_data(self.nodal_data, "Original")
        self.preview_table.show_transformed_data(transformed_data)
        
        # Enable transformed view button and switch to transformed view
        self._update_view_buttons()
        self.viewing_transformed = True
        self.view_original_btn.setChecked(False)
        self.view_transformed_btn.setChecked(True)
        
        # Update visualization with transformed data and cylindrical coordinate system
        self.visualizer.show_nodal_data(
            transformed_data, 
            show_vectors=self.show_vectors,
            original_data=self.nodal_data,  # For Cartesian display
            cylindrical_axis=settings.cylindrical_axis,
            axis_origin=settings.origin,
            point_size_factor=self.point_size_factor,
            color_vectors_by_magnitude=self.color_vectors_by_magnitude
        )
        
        self.status_label.setText("Transform applied - Viewing: Transformed Data")
    
    def _on_reset_transform(self):
        """Handle reset transform signal."""
        self.transformed_data = None
        self.current_transform_settings = None
        
        # Update view buttons (will disable transformed button and switch to original)
        self._update_view_buttons()
        
        if self.nodal_data:
            self.preview_table.show_nodal_data(self.nodal_data, "Original")
            self.visualizer.show_nodal_data(self.nodal_data, show_vectors=self.show_vectors,
                                             point_size_factor=self.point_size_factor,
                                             color_vectors_by_magnitude=self.color_vectors_by_magnitude)
            
        self.status_label.setText("Transform reset - Viewing: Original Data")
    
    def _on_export_data(self):
        """Handle export data action."""
        data_to_export = self.transformed_data if self.transformed_data else self.nodal_data
        
        if data_to_export is None:
            QMessageBox.warning(self, "No Data", "No data available to export.")
            return
        
        filepath, _ = QFileDialog.getSaveFileName(
            self, "Export Data", "", 
            "CSV Files (*.csv);;Text Files (*.txt);;All Files (*)"
        )
        
        if filepath:
            self._export_to_file(data_to_export, filepath)
            self.status_label.setText(f"Exported to: {filepath}")
    
    def _export_to_file(self, data: NodalData, filepath: str):
        """Export nodal data to file."""
        import numpy as np
        
        # Build header
        headers = ["NodeID"]
        headers.extend(data.get_position_column_names())
        headers.extend(data.get_data_column_names())
        
        # Build data array
        export_data = [data.node_ids]
        export_data.extend([data.positions[:, i] for i in range(3)])
        
        if data.scalar_values is not None:
            export_data.append(data.scalar_values)
        elif data.vector_values is not None:
            export_data.extend([data.vector_values[:, i] for i in range(3)])
        
        export_array = np.column_stack(export_data)
        
        # Determine separator from extension
        sep = ',' if filepath.endswith('.csv') else '\t'
        
        with open(filepath, 'w') as f:
            f.write(sep.join(headers) + '\n')
            for row in export_array:
                f.write(sep.join([f"{val:.6g}" for val in row]) + '\n')
    
    def _on_reset_view(self):
        """Reset the 3D view."""
        self.plotter.reset_camera()
        self.plotter.view_isometric()
    
    def _on_toggle_axes(self):
        """Toggle axes visibility."""
        self.show_axes = not self.show_axes
        if self.show_axes:
            self.plotter.add_axes()
        else:
            self.plotter.hide_axes()
    
    def _on_toggle_background(self):
        """Toggle background color between dark and light."""
        self.dark_background = not self.dark_background
        if self.dark_background:
            self.plotter.set_background(self.BG_DARK)
            self.status_label.setText("Background: Dark")
        else:
            self.plotter.set_background(self.BG_LIGHT)
            self.status_label.setText("Background: Light")
    
    def _on_increase_point_size(self):
        """Increase point size by 25%."""
        self.point_size_factor *= 1.25
        self._refresh_visualization()
        self.status_label.setText(f"Point Size: {self.point_size_factor:.0%}")
    
    def _on_decrease_point_size(self):
        """Decrease point size by 20%."""
        self.point_size_factor *= 0.8
        self.point_size_factor = max(0.1, self.point_size_factor)  # Minimum 10%
        self._refresh_visualization()
        self.status_label.setText(f"Point Size: {self.point_size_factor:.0%}")
    
    def _on_reset_point_size(self):
        """Reset point size to default."""
        self.point_size_factor = 1.0
        self._refresh_visualization()
        self.status_label.setText("Point Size: Reset to 100%")
    
    def _refresh_visualization(self):
        """Refresh the 3D visualization with current settings."""
        # Determine which data to display based on view selection
        if self.viewing_transformed and self.transformed_data is not None:
            data = self.transformed_data
            show_cyl_axis = True
        else:
            data = self.nodal_data
            show_cyl_axis = False
        
        if data:
            if show_cyl_axis and self.current_transform_settings:
                self.visualizer.show_nodal_data(
                    data,
                    show_vectors=self.show_vectors,
                    original_data=self.nodal_data,
                    cylindrical_axis=self.current_transform_settings.cylindrical_axis,
                    axis_origin=self.current_transform_settings.origin,
                    point_size_factor=self.point_size_factor,
                    color_vectors_by_magnitude=self.color_vectors_by_magnitude
                )
            else:
                self.visualizer.show_nodal_data(
                    data,
                    show_vectors=self.show_vectors,
                    point_size_factor=self.point_size_factor,
                    color_vectors_by_magnitude=self.color_vectors_by_magnitude
                )
    
    def _on_toggle_vectors(self):
        """Toggle vector arrows visibility."""
        self.show_vectors = not self.show_vectors
        self._refresh_visualization()
    
    def _on_toggle_vector_colors(self):
        """Toggle vector coloring by magnitude."""
        self.color_vectors_by_magnitude = self.color_vectors_btn.isChecked()
        self._refresh_visualization()
        if self.color_vectors_by_magnitude:
            self.status_label.setText("Vectors: Colored by magnitude (jet)")
        else:
            self.status_label.setText("Vectors: Single color")
    
    def _on_view_original(self):
        """Switch to viewing original data."""
        self.viewing_transformed = False
        self.view_original_btn.setChecked(True)
        self.view_transformed_btn.setChecked(False)
        self._refresh_visualization()
        self.status_label.setText("Viewing: Original Data")
    
    def _on_view_transformed(self):
        """Switch to viewing transformed data."""
        if self.transformed_data is None:
            return
        self.viewing_transformed = True
        self.view_original_btn.setChecked(False)
        self.view_transformed_btn.setChecked(True)
        self._refresh_visualization()
        self.status_label.setText("Viewing: Transformed Data")
    
    def _update_view_buttons(self):
        """Update view toggle buttons based on transform state."""
        has_transform = self.transformed_data is not None
        self.view_transformed_btn.setEnabled(has_transform)
        if not has_transform:
            self.viewing_transformed = False
            self.view_original_btn.setChecked(True)
            self.view_transformed_btn.setChecked(False)
    
    def _on_open_component_merger(self):
        """Open the Component Data Merger utility dialog."""
        from ui.data_merger import ComponentMergerDialog
        dialog = ComponentMergerDialog(self)
        dialog.exec_()
    
    def _on_about(self):
        """Show about dialog."""
        QMessageBox.about(
            self, "About",
            "<h3>Nodal Coordinate System Converter</h3>"
            "<p>A tool for converting nodal data between Cartesian and "
            "Cylindrical coordinate systems.</p>"
            "<p><b>Tools included:</b></p>"
            "<ul><li>Component Data Merger - Merge X/Y/Z component files</li></ul>"
            "<p>Built with PyQt5, PyVista, and NumPy.</p>"
        )
    
    def _apply_stylesheet(self):
        """Apply the application stylesheet."""
        from ui.styles import get_stylesheet
        self.setStyleSheet(get_stylesheet())
    
    def get_nodal_data(self) -> NodalData:
        """Get the current nodal data (for transform panel)."""
        return self.nodal_data
    
    def closeEvent(self, event):
        """Handle window close event."""
        self.plotter.close()
        event.accept()


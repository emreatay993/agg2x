"""
Transform panel for coordinate system conversion controls.
"""

from PyQt5.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QRadioButton, QButtonGroup, QGroupBox, QDoubleSpinBox,
    QMessageBox, QFrame
)
from PyQt5.QtCore import pyqtSignal
import numpy as np

from core.coordinate_transformer import CoordinateTransformer
from data.nodal_data import (
    NodalData, TransformSettings, TransformDirection, 
    CylindricalAxis, CoordinateSystem
)


class TransformPanel(QWidget):
    """Panel for coordinate transformation controls."""
    
    # Signals
    transform_requested = pyqtSignal(object, object)  # Emitted with (NodalData, TransformSettings)
    reset_requested = pyqtSignal()
    export_requested = pyqtSignal()
    
    def __init__(self, parent=None):
        super().__init__(parent)
        
        self._setup_ui()
        self.setEnabled(False)
    
    def _setup_ui(self):
        """Setup the panel UI."""
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        
        # Group box
        group = QGroupBox("Coordinate Transform")
        group_layout = QVBoxLayout(group)
        group_layout.setSpacing(8)
        
        # Transform direction
        dir_label = QLabel("Direction:")
        group_layout.addWidget(dir_label)
        
        self.direction_group = QButtonGroup(self)
        
        self.cart_to_cyl_radio = QRadioButton("Cartesian → Cylindrical")
        self.cyl_to_cart_radio = QRadioButton("Cylindrical → Cartesian")
        self.cart_to_cyl_radio.setChecked(True)
        
        self.direction_group.addButton(self.cart_to_cyl_radio, 0)
        self.direction_group.addButton(self.cyl_to_cart_radio, 1)
        
        group_layout.addWidget(self.cart_to_cyl_radio)
        group_layout.addWidget(self.cyl_to_cart_radio)
        
        # Separator
        line1 = QFrame()
        line1.setFrameShape(QFrame.HLine)
        line1.setFrameShadow(QFrame.Sunken)
        group_layout.addWidget(line1)
        
        # Cylindrical axis selection
        axis_label = QLabel("Cylindrical Axis:")
        group_layout.addWidget(axis_label)
        
        self.axis_group = QButtonGroup(self)
        
        axis_row = QHBoxLayout()
        self.axis_x_radio = QRadioButton("X")
        self.axis_y_radio = QRadioButton("Y")
        self.axis_z_radio = QRadioButton("Z")
        self.axis_z_radio.setChecked(True)
        
        self.axis_group.addButton(self.axis_x_radio, 0)
        self.axis_group.addButton(self.axis_y_radio, 1)
        self.axis_group.addButton(self.axis_z_radio, 2)
        
        axis_row.addWidget(self.axis_x_radio)
        axis_row.addWidget(self.axis_y_radio)
        axis_row.addWidget(self.axis_z_radio)
        axis_row.addStretch()
        group_layout.addLayout(axis_row)
        
        # Separator
        line2 = QFrame()
        line2.setFrameShape(QFrame.HLine)
        line2.setFrameShadow(QFrame.Sunken)
        group_layout.addWidget(line2)
        
        # Axis origin
        origin_label = QLabel("Axis Origin:")
        group_layout.addWidget(origin_label)
        
        origin_row = QHBoxLayout()
        
        origin_row.addWidget(QLabel("X:"))
        self.origin_x_spin = QDoubleSpinBox()
        self.origin_x_spin.setRange(-1e10, 1e10)
        self.origin_x_spin.setDecimals(4)
        self.origin_x_spin.setValue(0.0)
        origin_row.addWidget(self.origin_x_spin)
        
        origin_row.addWidget(QLabel("Y:"))
        self.origin_y_spin = QDoubleSpinBox()
        self.origin_y_spin.setRange(-1e10, 1e10)
        self.origin_y_spin.setDecimals(4)
        self.origin_y_spin.setValue(0.0)
        origin_row.addWidget(self.origin_y_spin)
        
        origin_row.addWidget(QLabel("Z:"))
        self.origin_z_spin = QDoubleSpinBox()
        self.origin_z_spin.setRange(-1e10, 1e10)
        self.origin_z_spin.setDecimals(4)
        self.origin_z_spin.setValue(0.0)
        origin_row.addWidget(self.origin_z_spin)
        
        group_layout.addLayout(origin_row)
        
        # Buttons
        btn_row = QHBoxLayout()
        
        self.apply_btn = QPushButton("Apply Transform")
        self.apply_btn.clicked.connect(self._on_apply_clicked)
        btn_row.addWidget(self.apply_btn)
        
        self.reset_btn = QPushButton("Reset")
        self.reset_btn.clicked.connect(self._on_reset_clicked)
        btn_row.addWidget(self.reset_btn)
        
        group_layout.addLayout(btn_row)
        
        # Export button
        self.export_btn = QPushButton("Export Transformed Data...")
        self.export_btn.clicked.connect(self._on_export_clicked)
        group_layout.addWidget(self.export_btn)
        
        layout.addWidget(group)
    
    def _get_transform_settings(self) -> TransformSettings:
        """Get current transform settings from UI."""
        # Direction
        if self.cart_to_cyl_radio.isChecked():
            direction = TransformDirection.CART_TO_CYL
        else:
            direction = TransformDirection.CYL_TO_CART
        
        # Axis
        if self.axis_x_radio.isChecked():
            axis = CylindricalAxis.X
        elif self.axis_y_radio.isChecked():
            axis = CylindricalAxis.Y
        else:
            axis = CylindricalAxis.Z
        
        # Origin
        origin = np.array([
            self.origin_x_spin.value(),
            self.origin_y_spin.value(),
            self.origin_z_spin.value()
        ])
        
        return TransformSettings(
            direction=direction,
            cylindrical_axis=axis,
            origin=origin
        )
    
    def _on_apply_clicked(self):
        """Handle apply transform button click."""
        # Get parent window's nodal data
        parent = self.parent()
        while parent and not hasattr(parent, 'get_nodal_data'):
            parent = parent.parent()
        
        if not parent:
            return
        
        nodal_data = parent.get_nodal_data()
        if nodal_data is None:
            QMessageBox.warning(self, "No Data", "Please load and map data first.")
            return
        
        try:
            settings = self._get_transform_settings()
            
            # Set the coordinate system based on user's direction selection
            # User knows their data format - trust their selection
            if settings.direction == TransformDirection.CART_TO_CYL:
                nodal_data.coordinate_system = CoordinateSystem.CARTESIAN
            else:
                nodal_data.coordinate_system = CoordinateSystem.CYLINDRICAL
            
            transformed = CoordinateTransformer.transform(nodal_data, settings)
            self.transform_requested.emit(transformed, settings)
            
        except Exception as e:
            QMessageBox.critical(
                self, "Transform Error",
                f"Failed to transform data:\n{str(e)}"
            )
    
    def _on_reset_clicked(self):
        """Handle reset button click."""
        self.origin_x_spin.setValue(0.0)
        self.origin_y_spin.setValue(0.0)
        self.origin_z_spin.setValue(0.0)
        self.axis_z_radio.setChecked(True)
        self.cart_to_cyl_radio.setChecked(True)
        self.reset_requested.emit()
    
    def _on_export_clicked(self):
        """Handle export button click."""
        self.export_requested.emit()


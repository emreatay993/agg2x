"""
Coordinate transformation between Cartesian and Cylindrical systems.

Mathematical Reference:
=======================

CARTESIAN TO CYLINDRICAL (axis along Z):
----------------------------------------
Position:
    r = sqrt(x² + y²)
    θ = atan2(y, x)
    z_cyl = z

Vector components (force/displacement):
    F_r = F_x * cos(θ) + F_y * sin(θ)
    F_θ = -F_x * sin(θ) + F_y * cos(θ)
    F_z = F_z

CYLINDRICAL TO CARTESIAN (axis along Z):
----------------------------------------
Position:
    x = r * cos(θ)
    y = r * sin(θ)
    z = z_cyl

Vector components:
    F_x = F_r * cos(θ) - F_θ * sin(θ)
    F_y = F_r * sin(θ) + F_θ * cos(θ)
    F_z = F_z

AXIS PERMUTATION:
-----------------
For cylindrical axis along X: permute (x,y,z) -> (y,z,x) before transform
For cylindrical axis along Y: permute (x,y,z) -> (z,x,y) before transform
For cylindrical axis along Z: no permutation needed
"""

import numpy as np
from typing import Tuple

from data.nodal_data import (
    NodalData, DataType, CoordinateSystem, 
    CylindricalAxis, TransformDirection, TransformSettings
)


class CoordinateTransformer:
    """Handles coordinate system transformations for nodal data."""
    
    @staticmethod
    def _get_axis_permutation(axis: CylindricalAxis) -> Tuple[int, int, int]:
        """
        Get the permutation indices for the given cylindrical axis.
        
        The permutation transforms coordinates so that the cylindrical axis
        becomes the Z axis for standard transformation formulas.
        
        Returns:
            Tuple of (idx1, idx2, idx3) for permuting (x, y, z)
        """
        if axis == CylindricalAxis.Z:
            # Z axis: no permutation needed
            # Radial plane is X-Y
            return (0, 1, 2)
        elif axis == CylindricalAxis.X:
            # X axis: radial plane is Y-Z
            # Transform: original (x,y,z) -> (y,z,x) so that X becomes the axial direction
            return (1, 2, 0)
        else:  # Y axis
            # Y axis: radial plane is Z-X
            # Transform: original (x,y,z) -> (z,x,y) so that Y becomes the axial direction
            return (2, 0, 1)
    
    @staticmethod
    def _get_inverse_permutation(axis: CylindricalAxis) -> Tuple[int, int, int]:
        """
        Get the inverse permutation to restore original coordinate order.
        """
        if axis == CylindricalAxis.Z:
            return (0, 1, 2)
        elif axis == CylindricalAxis.X:
            # Inverse of (1,2,0) is (2,0,1)
            return (2, 0, 1)
        else:  # Y axis
            # Inverse of (2,0,1) is (1,2,0)
            return (1, 2, 0)
    
    @classmethod
    def _apply_permutation(cls, data: np.ndarray, perm: Tuple[int, int, int]) -> np.ndarray:
        """Apply column permutation to Nx3 array."""
        return data[:, perm]
    
    @classmethod
    def cartesian_to_cylindrical_positions(cls, positions: np.ndarray, 
                                            origin: np.ndarray,
                                            axis: CylindricalAxis) -> np.ndarray:
        """
        Convert Cartesian positions to Cylindrical.
        
        Args:
            positions: Nx3 array of (x, y, z) coordinates
            origin: Origin point for the cylindrical system
            axis: Which axis is the cylindrical axis
            
        Returns:
            Nx3 array of (r, theta, z_cyl) coordinates
        """
        # Translate to origin
        translated = positions - origin
        
        # Apply axis permutation
        perm = cls._get_axis_permutation(axis)
        permuted = cls._apply_permutation(translated, perm)
        
        # Now permuted[:, 0:2] is the radial plane, permuted[:, 2] is axial
        x_local = permuted[:, 0]
        y_local = permuted[:, 1]
        z_local = permuted[:, 2]
        
        # Convert to cylindrical
        r = np.sqrt(x_local**2 + y_local**2)
        theta = np.arctan2(y_local, x_local)  # Returns radians in [-pi, pi]
        z_cyl = z_local
        
        return np.column_stack([r, theta, z_cyl])
    
    @classmethod
    def cylindrical_to_cartesian_positions(cls, positions: np.ndarray,
                                            origin: np.ndarray,
                                            axis: CylindricalAxis) -> np.ndarray:
        """
        Convert Cylindrical positions to Cartesian.
        
        Args:
            positions: Nx3 array of (r, theta, z_cyl) coordinates
            origin: Origin point for the cylindrical system
            axis: Which axis is the cylindrical axis
            
        Returns:
            Nx3 array of (x, y, z) coordinates
        """
        r = positions[:, 0]
        theta = positions[:, 1]
        z_cyl = positions[:, 2]
        
        # Convert to local Cartesian (in the permuted frame)
        x_local = r * np.cos(theta)
        y_local = r * np.sin(theta)
        z_local = z_cyl
        
        local_cart = np.column_stack([x_local, y_local, z_local])
        
        # Apply inverse permutation
        inv_perm = cls._get_inverse_permutation(axis)
        global_cart = cls._apply_permutation(local_cart, inv_perm)
        
        # Translate back from origin
        return global_cart + origin
    
    @classmethod
    def cartesian_to_cylindrical_vectors(cls, vectors: np.ndarray,
                                          positions: np.ndarray,
                                          origin: np.ndarray,
                                          axis: CylindricalAxis) -> np.ndarray:
        """
        Convert Cartesian vector components to Cylindrical at given positions.
        
        The transformation depends on the position (theta angle) of each point.
        
        Args:
            vectors: Nx3 array of (Fx, Fy, Fz) vector components
            positions: Nx3 array of Cartesian positions where vectors are defined
            origin: Origin point for the cylindrical system
            axis: Which axis is the cylindrical axis
            
        Returns:
            Nx3 array of (Fr, Ftheta, Fz) vector components
        """
        # Translate positions to origin
        translated = positions - origin
        
        # Apply axis permutation to both positions and vectors
        perm = cls._get_axis_permutation(axis)
        pos_permuted = cls._apply_permutation(translated, perm)
        vec_permuted = cls._apply_permutation(vectors, perm)
        
        # Calculate theta at each point
        x_local = pos_permuted[:, 0]
        y_local = pos_permuted[:, 1]
        theta = np.arctan2(y_local, x_local)
        
        # Get vector components in local frame
        Fx_local = vec_permuted[:, 0]
        Fy_local = vec_permuted[:, 1]
        Fz_local = vec_permuted[:, 2]
        
        # Transform vector components
        # F_r = F_x * cos(θ) + F_y * sin(θ)
        # F_θ = -F_x * sin(θ) + F_y * cos(θ)
        # F_z = F_z
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        
        Fr = Fx_local * cos_theta + Fy_local * sin_theta
        Ftheta = -Fx_local * sin_theta + Fy_local * cos_theta
        Fz = Fz_local
        
        return np.column_stack([Fr, Ftheta, Fz])
    
    @classmethod
    def cylindrical_to_cartesian_vectors(cls, vectors: np.ndarray,
                                          positions_cyl: np.ndarray,
                                          origin: np.ndarray,
                                          axis: CylindricalAxis) -> np.ndarray:
        """
        Convert Cylindrical vector components to Cartesian.
        
        Args:
            vectors: Nx3 array of (Fr, Ftheta, Fz) vector components
            positions_cyl: Nx3 array of cylindrical positions (r, theta, z)
            origin: Origin point for the cylindrical system
            axis: Which axis is the cylindrical axis
            
        Returns:
            Nx3 array of (Fx, Fy, Fz) vector components
        """
        # Get theta from cylindrical positions
        theta = positions_cyl[:, 1]
        
        # Get vector components
        Fr = vectors[:, 0]
        Ftheta = vectors[:, 1]
        Fz_cyl = vectors[:, 2]
        
        # Transform vector components
        # F_x = F_r * cos(θ) - F_θ * sin(θ)
        # F_y = F_r * sin(θ) + F_θ * cos(θ)
        # F_z = F_z
        cos_theta = np.cos(theta)
        sin_theta = np.sin(theta)
        
        Fx_local = Fr * cos_theta - Ftheta * sin_theta
        Fy_local = Fr * sin_theta + Ftheta * cos_theta
        Fz_local = Fz_cyl
        
        local_vectors = np.column_stack([Fx_local, Fy_local, Fz_local])
        
        # Apply inverse permutation
        inv_perm = cls._get_inverse_permutation(axis)
        return cls._apply_permutation(local_vectors, inv_perm)
    
    @classmethod
    def transform(cls, nodal_data: NodalData, 
                  settings: TransformSettings) -> NodalData:
        """
        Transform nodal data values between coordinate systems.
        
        NOTE: Only the DATA VALUES (vectors) are transformed, not the positions!
        Positions remain in Cartesian (X, Y, Z) as they represent physical node locations.
        
        Args:
            nodal_data: Source nodal data
            settings: Transformation settings
            
        Returns:
            Transformed NodalData with updated vector values (positions unchanged)
        """
        result = nodal_data.copy()
        origin = settings.origin
        axis = settings.cylindrical_axis
        
        if settings.direction == TransformDirection.CART_TO_CYL:
            # Cartesian to Cylindrical - transform only vector data
            if nodal_data.coordinate_system != CoordinateSystem.CARTESIAN:
                raise ValueError("Source data must be in Cartesian coordinates for Cart->Cyl transform")
            
            # Positions stay in Cartesian (X, Y, Z) - they are physical locations!
            # Only transform vector values if present
            if nodal_data.data_type == DataType.VECTOR:
                result.vector_values = cls.cartesian_to_cylindrical_vectors(
                    nodal_data.vector_values,
                    nodal_data.positions,  # Use Cartesian positions for theta calculation
                    origin, axis
                )
            
            result.coordinate_system = CoordinateSystem.CYLINDRICAL
            
        else:
            # Cylindrical to Cartesian - transform only vector data
            if nodal_data.coordinate_system != CoordinateSystem.CYLINDRICAL:
                raise ValueError("Source data must be in Cylindrical coordinates for Cyl->Cart transform")
            
            # Positions stay in Cartesian - they were never changed
            # Transform vector values if present
            if nodal_data.data_type == DataType.VECTOR:
                # Need cylindrical positions (r, theta, z) for the inverse transform
                cyl_positions = cls.cartesian_to_cylindrical_positions(
                    nodal_data.positions, origin, axis
                )
                result.vector_values = cls.cylindrical_to_cartesian_vectors(
                    nodal_data.vector_values,
                    cyl_positions,  # Cylindrical positions for theta
                    origin, axis
                )
            
            result.coordinate_system = CoordinateSystem.CARTESIAN
        
        return result


def verify_transformations():
    """
    Verification function to test transformation correctness.
    Run this to validate the mathematical implementation.
    """
    print("=" * 60)
    print("COORDINATE TRANSFORMATION VERIFICATION")
    print("=" * 60)
    
    # Test case 1: Simple point on X axis
    print("\nTest 1: Point at (1, 0, 0) - should give r=1, theta=0")
    pos = np.array([[1.0, 0.0, 0.0]])
    origin = np.array([0.0, 0.0, 0.0])
    
    cyl = CoordinateTransformer.cartesian_to_cylindrical_positions(
        pos, origin, CylindricalAxis.Z
    )
    print(f"  Cartesian: {pos[0]}")
    print(f"  Cylindrical (r, theta, z): {cyl[0]} (theta in radians)")
    
    # Verify round-trip
    back = CoordinateTransformer.cylindrical_to_cartesian_positions(
        cyl, origin, CylindricalAxis.Z
    )
    print(f"  Back to Cartesian: {back[0]}")
    print(f"  Round-trip error: {np.linalg.norm(pos - back):.2e}")
    
    # Test case 2: Point at 45 degrees
    print("\nTest 2: Point at (1, 1, 2) - should give r=sqrt(2), theta=pi/4")
    pos = np.array([[1.0, 1.0, 2.0]])
    cyl = CoordinateTransformer.cartesian_to_cylindrical_positions(
        pos, origin, CylindricalAxis.Z
    )
    print(f"  Cartesian: {pos[0]}")
    print(f"  Cylindrical (r, theta, z): {cyl[0]}")
    print(f"  Expected r: {np.sqrt(2):.6f}, theta: {np.pi/4:.6f}")
    
    # Test case 3: Vector transformation
    print("\nTest 3: Radial force at (1, 0, 0) pointing outward (+X)")
    pos = np.array([[1.0, 0.0, 0.0]])
    vec = np.array([[10.0, 0.0, 0.0]])  # Force in +X direction
    
    vec_cyl = CoordinateTransformer.cartesian_to_cylindrical_vectors(
        vec, pos, origin, CylindricalAxis.Z
    )
    print(f"  Cartesian vector: {vec[0]}")
    print(f"  Cylindrical vector (Fr, Ftheta, Fz): {vec_cyl[0]}")
    print(f"  Expected: Fr=10, Ftheta=0, Fz=0 (purely radial)")
    
    # Test case 4: Tangential force
    print("\nTest 4: Tangential force at (1, 0, 0) pointing in +Y")
    vec = np.array([[0.0, 5.0, 0.0]])  # Force in +Y direction (tangential at this point)
    
    vec_cyl = CoordinateTransformer.cartesian_to_cylindrical_vectors(
        vec, pos, origin, CylindricalAxis.Z
    )
    print(f"  Cartesian vector: {vec[0]}")
    print(f"  Cylindrical vector (Fr, Ftheta, Fz): {vec_cyl[0]}")
    print(f"  Expected: Fr=0, Ftheta=5, Fz=0 (purely tangential)")
    
    # Test case 5: Different axis (X as cylindrical axis)
    print("\nTest 5: Cylindrical axis along X")
    pos = np.array([[3.0, 0.0, 1.0]])  # Y=0, Z=1 -> r=1, axial=X=3
    cyl = CoordinateTransformer.cartesian_to_cylindrical_positions(
        pos, origin, CylindricalAxis.X
    )
    print(f"  Cartesian: {pos[0]}")
    print(f"  Cylindrical (r, theta, z_axial): {cyl[0]}")
    print(f"  Expected: r=1 (from Y-Z plane), z_axial=3")
    
    back = CoordinateTransformer.cylindrical_to_cartesian_positions(
        cyl, origin, CylindricalAxis.X
    )
    print(f"  Back to Cartesian: {back[0]}")
    print(f"  Round-trip error: {np.linalg.norm(pos - back):.2e}")
    
    print("\n" + "=" * 60)
    print("VERIFICATION COMPLETE")
    print("=" * 60)


if __name__ == "__main__":
    verify_transformations()


"""
3D visualization module using PyVista.
"""

from typing import Optional
import numpy as np
import pyvista as pv

from data.nodal_data import NodalData, DataType, CoordinateSystem, CylindricalAxis


class Visualizer:
    """Handles 3D visualization of nodal data."""
    
    # Color schemes
    POINT_COLORMAP = 'jet'
    VECTOR_COLOR = '#ff6b6b'  # Coral red
    AXIS_COLORS = {
        'x': '#e74c3c',  # Red
        'y': '#2ecc71',  # Green
        'z': '#3498db'   # Blue
    }
    CYLINDRICAL_AXIS_COLOR = '#f39c12'  # Orange
    
    def __init__(self, plotter):
        """
        Initialize the visualizer.
        
        Args:
            plotter: PyVista QtInteractor instance
        """
        self.plotter = plotter
        self.current_actors = []
        self.show_coordinate_axes = True
        
    def clear(self):
        """Clear all actors from the scene."""
        self.plotter.clear()
        self.plotter.add_axes()
        self.current_actors = []
    
    def show_nodal_data(self, data: NodalData, 
                        show_vectors: bool = True,
                        original_data: Optional[NodalData] = None,
                        cylindrical_axis: Optional[CylindricalAxis] = None,
                        axis_origin: Optional[np.ndarray] = None,
                        point_size_factor: float = 1.0,
                        color_vectors_by_magnitude: bool = False):
        """
        Display nodal data in the 3D viewport.
        
        Args:
            data: NodalData to visualize
            show_vectors: Whether to show vector arrows for vector data
            original_data: Original Cartesian data (for displaying cylindrical data)
            cylindrical_axis: If set, show the cylindrical coordinate system indicator
            axis_origin: Origin of the cylindrical coordinate system
            point_size_factor: Multiplier for point size (default 1.0)
            color_vectors_by_magnitude: If True, color vectors by magnitude using jet colormap
        """
        self.clear()
        
        # Positions are always in Cartesian (X, Y, Z)
        display_positions = data.positions
        
        # For vectors: if data is in cylindrical representation, convert back to Cartesian for 3D display
        if data.data_type == DataType.VECTOR:
            if data.coordinate_system == CoordinateSystem.CYLINDRICAL:
                # Convert Fr, Ftheta, Fz back to Fx, Fy, Fz for arrow display
                display_vectors = self._convert_cylindrical_vectors_for_display(
                    data.vector_values, data.positions, 
                    axis_origin if axis_origin is not None else np.zeros(3),
                    cylindrical_axis if cylindrical_axis else CylindricalAxis.Z
                )
            else:
                display_vectors = data.vector_values
        else:
            display_vectors = None
        
        # Create point cloud
        points = pv.PolyData(display_positions)
        
        # Add scalar data for coloring
        magnitudes = data.data_magnitude
        points['magnitude'] = magnitudes
        
        # Calculate appropriate point size based on data extent
        extent = np.ptp(display_positions, axis=0)
        max_extent = max(extent) if max(extent) > 0 else 1.0
        point_size = max_extent * 0.02 * point_size_factor
        
        # Add points as spheres
        glyphs = points.glyph(
            geom=pv.Sphere(radius=point_size),
            scale=False,
            orient=False
        )
        
        self.plotter.add_mesh(
            glyphs,
            scalars='magnitude',
            cmap=self.POINT_COLORMAP,
            show_scalar_bar=True,
            scalar_bar_args={
                'title': 'Magnitude',
                'vertical': True,
                'position_x': 0.85,
                'position_y': 0.1,
                'width': 0.1,
                'height': 0.8
            }
        )
        
        # Add vector arrows if applicable
        if show_vectors and data.data_type == DataType.VECTOR and display_vectors is not None:
            self._add_vector_arrows(display_positions, display_vectors, max_extent, 
                                     color_by_magnitude=color_vectors_by_magnitude)
        
        # Add coordinate system visualization
        self._add_coordinate_axes(display_positions, max_extent * 0.3)
        
        # Add cylindrical coordinate system visualization if transformed
        if cylindrical_axis is not None and data.coordinate_system == CoordinateSystem.CYLINDRICAL:
            origin = axis_origin if axis_origin is not None else np.zeros(3)
            self.show_cylindrical_axis(cylindrical_axis, origin, max_extent * 0.8)
    
    def _convert_cylindrical_vectors_for_display(self, cyl_vectors: np.ndarray,
                                                   cart_positions: np.ndarray,
                                                   origin: np.ndarray,
                                                   axis: CylindricalAxis) -> np.ndarray:
        """
        Convert cylindrical vector components (Fr, Ftheta, Fz) back to Cartesian (Fx, Fy, Fz)
        for 3D arrow display.
        
        Args:
            cyl_vectors: Nx3 array of (Fr, Ftheta, Fz) components
            cart_positions: Nx3 array of Cartesian positions (X, Y, Z)
            origin: Origin of the cylindrical coordinate system
            axis: Which axis is the cylindrical axis
            
        Returns:
            Nx3 array of (Fx, Fy, Fz) components for display
        """
        from core.coordinate_transformer import CoordinateTransformer
        
        # Get cylindrical positions for theta values needed for inverse transform
        cyl_positions = CoordinateTransformer.cartesian_to_cylindrical_positions(
            cart_positions, origin, axis
        )
        
        # Convert vectors back to Cartesian for display
        return CoordinateTransformer.cylindrical_to_cartesian_vectors(
            cyl_vectors, cyl_positions, origin, axis
        )
    
    def _add_vector_arrows(self, positions: np.ndarray, 
                           vectors: np.ndarray, 
                           scale_ref: float,
                           color_by_magnitude: bool = False):
        """Add vector arrows at node positions."""
        # Calculate magnitudes
        magnitudes = np.linalg.norm(vectors, axis=1)
        max_mag = np.max(magnitudes)
        
        if max_mag == 0:
            return
        
        # Scale arrows relative to the model extent
        arrow_scale = scale_ref * 0.15 / max_mag
        scaled_vectors = vectors * arrow_scale
        
        if color_by_magnitude:
            # Use jet colormap for magnitude-based coloring
            import matplotlib.pyplot as plt
            cmap = plt.cm.jet
            # Normalize magnitudes to 0-1 range
            norm_mags = magnitudes / max_mag
            
            for i in range(len(positions)):
                if magnitudes[i] > 1e-10:
                    start = positions[i]
                    direction = scaled_vectors[i]
                    
                    arrow = pv.Arrow(
                        start=start,
                        direction=direction,
                        tip_length=0.25,
                        tip_radius=0.1,
                        shaft_radius=0.03,
                        scale='auto'
                    )
                    
                    # Get color from jet colormap
                    rgba = cmap(norm_mags[i])
                    color = [int(rgba[0]*255), int(rgba[1]*255), int(rgba[2]*255)]
                    
                    self.plotter.add_mesh(
                        arrow,
                        color=color,
                        opacity=0.9
                    )
        else:
            # Single color for all arrows
            for i in range(len(positions)):
                if magnitudes[i] > 1e-10:
                    start = positions[i]
                    direction = scaled_vectors[i]
                    
                    arrow = pv.Arrow(
                        start=start,
                        direction=direction,
                        tip_length=0.25,
                        tip_radius=0.1,
                        shaft_radius=0.03,
                        scale='auto'
                    )
                    
                    self.plotter.add_mesh(
                        arrow,
                        color=self.VECTOR_COLOR,
                        opacity=0.8
                    )
    
    def _add_coordinate_axes(self, positions: np.ndarray, size: float):
        """Add coordinate system axes at the origin or centroid."""
        # Use origin (0, 0, 0) for axis display
        origin = np.array([0.0, 0.0, 0.0])
        
        # Create axis arrows
        for axis, color in self.AXIS_COLORS.items():
            direction = np.zeros(3)
            if axis == 'x':
                direction[0] = size
            elif axis == 'y':
                direction[1] = size
            else:
                direction[2] = size
            
            arrow = pv.Arrow(
                start=origin,
                direction=direction,
                tip_length=0.2,
                tip_radius=0.08,
                shaft_radius=0.025,
                scale='auto'
            )
            
            self.plotter.add_mesh(
                arrow,
                color=color,
                opacity=1.0
            )
            
            # Add axis label
            label_pos = origin + direction * 1.15
            self.plotter.add_point_labels(
                [label_pos],
                [axis.upper()],
                font_size=16,
                text_color=color,
                point_size=0,
                shape=None,
                fill_shape=False
            )
    
    def show_cylindrical_axis(self, axis: CylindricalAxis, 
                               origin: np.ndarray, 
                               extent: float):
        """
        Visualize the cylindrical coordinate system with:
        - Axial direction (thick orange line with arrow)
        - Radial plane indicator (ring/disc)
        - Radial direction indicator (R arrow)
        - Theta direction indicator (arc with arrow)
        - Labels for R, Theta, Z_cyl
        
        Args:
            axis: Which axis is the cylindrical axis
            origin: Origin point of the cylindrical system
            extent: Length of the axis visualization
        """
        # Determine axis direction and radial plane basis
        if axis == CylindricalAxis.Z:
            axial_dir = np.array([0.0, 0.0, 1.0])
            radial_dir = np.array([1.0, 0.0, 0.0])  # R direction (at theta=0)
            theta_dir = np.array([0.0, 1.0, 0.0])   # Theta direction (at theta=0)
            normal = [0, 0, 1]
        elif axis == CylindricalAxis.X:
            axial_dir = np.array([1.0, 0.0, 0.0])
            radial_dir = np.array([0.0, 1.0, 0.0])  # R direction in Y-Z plane
            theta_dir = np.array([0.0, 0.0, 1.0])
            normal = [1, 0, 0]
        else:  # Y axis
            axial_dir = np.array([0.0, 1.0, 0.0])
            radial_dir = np.array([0.0, 0.0, 1.0])  # R direction in Z-X plane
            theta_dir = np.array([1.0, 0.0, 0.0])
            normal = [0, 1, 0]
        
        # 1. Cylindrical axis (Z_cyl) - thick orange line
        start = origin - axial_dir * extent * 0.6
        end = origin + axial_dir * extent * 0.6
        
        line = pv.Line(start, end)
        tube = line.tube(radius=extent * 0.015)
        
        self.plotter.add_mesh(
            tube,
            color=self.CYLINDRICAL_AXIS_COLOR,
            opacity=0.9
        )
        
        # Add arrow at the end of axial direction
        axial_arrow = pv.Arrow(
            start=origin + axial_dir * extent * 0.5,
            direction=axial_dir * extent * 0.15,
            tip_length=0.3,
            tip_radius=0.12,
            shaft_radius=0.04,
            scale='auto'
        )
        self.plotter.add_mesh(axial_arrow, color=self.CYLINDRICAL_AXIS_COLOR, opacity=1.0)
        
        # Label for Z_cyl (axial)
        label_pos = origin + axial_dir * extent * 0.75
        self.plotter.add_point_labels(
            [label_pos],
            ["Z_cyl"],
            font_size=14,
            text_color=self.CYLINDRICAL_AXIS_COLOR,
            point_size=0,
            shape=None,
            fill_shape=False
        )
        
        # 2. Radial direction indicator (R) - purple arrow
        r_color = '#9b59b6'  # Purple for radial
        r_arrow = pv.Arrow(
            start=origin,
            direction=radial_dir * extent * 0.4,
            tip_length=0.25,
            tip_radius=0.1,
            shaft_radius=0.03,
            scale='auto'
        )
        self.plotter.add_mesh(r_arrow, color=r_color, opacity=1.0)
        
        # Label for R
        r_label_pos = origin + radial_dir * extent * 0.5
        self.plotter.add_point_labels(
            [r_label_pos],
            ["R"],
            font_size=14,
            text_color=r_color,
            point_size=0,
            shape=None,
            fill_shape=False
        )
        
        # 3. Theta direction indicator - arc with arrow (cyan)
        theta_color = '#1abc9c'  # Teal/cyan for theta
        
        # Create arc to show theta direction
        arc_radius = extent * 0.35
        n_arc_points = 20
        angles = np.linspace(0, np.pi/3, n_arc_points)  # 60 degree arc
        
        arc_points = []
        for angle in angles:
            if axis == CylindricalAxis.Z:
                point = origin + arc_radius * np.array([np.cos(angle), np.sin(angle), 0])
            elif axis == CylindricalAxis.X:
                point = origin + arc_radius * np.array([0, np.cos(angle), np.sin(angle)])
            else:  # Y
                point = origin + arc_radius * np.array([np.sin(angle), 0, np.cos(angle)])
            arc_points.append(point)
        
        arc_points = np.array(arc_points)
        arc_line = pv.Spline(arc_points, n_arc_points * 3)
        arc_tube = arc_line.tube(radius=extent * 0.008)
        self.plotter.add_mesh(arc_tube, color=theta_color, opacity=1.0)
        
        # Add small arrow at arc end for theta direction
        arc_end = arc_points[-1]
        theta_tangent = np.cross(normal, arc_end - origin)
        theta_tangent = theta_tangent / np.linalg.norm(theta_tangent) * extent * 0.08
        
        theta_arrow = pv.Arrow(
            start=arc_end,
            direction=theta_tangent,
            tip_length=0.4,
            tip_radius=0.15,
            shaft_radius=0.05,
            scale='auto'
        )
        self.plotter.add_mesh(theta_arrow, color=theta_color, opacity=1.0)
        
        # Label for Theta
        theta_label_pos = arc_end + theta_tangent * 0.5
        self.plotter.add_point_labels(
            [theta_label_pos],
            ["Theta"],
            font_size=14,
            text_color=theta_color,
            point_size=0,
            shape=None,
            fill_shape=False
        )
        
        # 4. Radial plane indicator ring
        ring = pv.Disc(center=origin, inner=extent * 0.42, outer=extent * 0.45, normal=normal)
        self.plotter.add_mesh(
            ring,
            color=self.CYLINDRICAL_AXIS_COLOR,
            opacity=0.3
        )
        
        # 5. Origin marker (sphere at cylindrical origin)
        origin_sphere = pv.Sphere(radius=extent * 0.03, center=origin)
        self.plotter.add_mesh(origin_sphere, color='white', opacity=1.0)


def create_sample_data() -> NodalData:
    """Create sample data for testing visualization."""
    from data.nodal_data import NodalData, DataType, CoordinateSystem
    
    # Create a grid of points
    n = 10
    x = np.linspace(-5, 5, n)
    y = np.linspace(-5, 5, n)
    z = np.linspace(0, 10, n)
    
    xx, yy, zz = np.meshgrid(x, y, z)
    positions = np.column_stack([xx.ravel(), yy.ravel(), zz.ravel()])
    
    node_ids = np.arange(1, len(positions) + 1)
    
    # Create radial force field
    r = np.sqrt(positions[:, 0]**2 + positions[:, 1]**2)
    r[r == 0] = 1e-10
    
    fx = positions[:, 0] / r * 10
    fy = positions[:, 1] / r * 10
    fz = np.zeros(len(positions))
    
    vectors = np.column_stack([fx, fy, fz])
    
    return NodalData(
        node_ids=node_ids,
        positions=positions,
        data_type=DataType.VECTOR,
        vector_values=vectors,
        coordinate_system=CoordinateSystem.CARTESIAN
    )


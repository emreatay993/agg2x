"""
Application stylesheet for modern, minimalistic appearance.
"""


def get_stylesheet() -> str:
    """Return the application stylesheet."""
    return """
/* Main Window */
QMainWindow {
    background-color: #f5f6fa;
}

/* Menu Bar */
QMenuBar {
    background-color: #2c3e50;
    color: #ecf0f1;
    padding: 4px;
    font-size: 13px;
}

QMenuBar::item {
    padding: 6px 12px;
    border-radius: 4px;
}

QMenuBar::item:selected {
    background-color: #34495e;
}

QMenu {
    background-color: #2c3e50;
    color: #ecf0f1;
    border: 1px solid #34495e;
    padding: 4px;
}

QMenu::item {
    padding: 8px 24px;
    border-radius: 4px;
}

QMenu::item:selected {
    background-color: #3498db;
}

QMenu::separator {
    height: 1px;
    background-color: #34495e;
    margin: 4px 8px;
}

/* Group Boxes */
QGroupBox {
    background-color: #ffffff;
    border: 1px solid #dcdde1;
    border-radius: 8px;
    margin-top: 12px;
    padding: 16px 12px 12px 12px;
    font-weight: bold;
    font-size: 13px;
}

QGroupBox::title {
    subcontrol-origin: margin;
    subcontrol-position: top left;
    left: 12px;
    padding: 0 8px;
    background-color: #ffffff;
    color: #2c3e50;
}

/* Labels */
QLabel {
    color: #2c3e50;
    font-size: 12px;
}

/* Push Buttons */
QPushButton {
    background-color: #3498db;
    color: white;
    border: none;
    border-radius: 6px;
    padding: 8px 16px;
    font-size: 12px;
    font-weight: bold;
    min-height: 20px;
}

QPushButton:hover {
    background-color: #2980b9;
}

QPushButton:pressed {
    background-color: #1f618d;
}

QPushButton:disabled {
    background-color: #bdc3c7;
    color: #7f8c8d;
}

QPushButton:checked {
    background-color: #1a5276;
    border: 2px solid #f1c40f;
}

QPushButton:checked:hover {
    background-color: #1f618d;
}

/* Secondary Buttons (in visualization area) */
QPushButton[flat="true"] {
    background-color: transparent;
    color: #3498db;
    border: 1px solid #3498db;
}

QPushButton[flat="true"]:hover {
    background-color: rgba(52, 152, 219, 0.1);
}

/* Line Edits */
QLineEdit {
    background-color: #ffffff;
    border: 1px solid #dcdde1;
    border-radius: 6px;
    padding: 8px 12px;
    font-size: 12px;
    color: #2c3e50;
}

QLineEdit:focus {
    border-color: #3498db;
}

QLineEdit:read-only {
    background-color: #f8f9fa;
    color: #7f8c8d;
}

/* Combo Boxes */
QComboBox {
    background-color: #ffffff;
    border: 1px solid #dcdde1;
    border-radius: 6px;
    padding: 6px 12px;
    padding-right: 28px;
    font-size: 12px;
    color: #2c3e50;
    min-height: 20px;
}

QComboBox:hover {
    border-color: #3498db;
}

QComboBox::drop-down {
    border: none;
    width: 28px;
    subcontrol-origin: padding;
    subcontrol-position: right center;
}

QComboBox::down-arrow {
    image: none;
    border-left: 5px solid transparent;
    border-right: 5px solid transparent;
    border-top: 6px solid #7f8c8d;
    margin-right: 10px;
}

QComboBox QAbstractItemView {
    background-color: #ffffff;
    border: 1px solid #dcdde1;
    border-radius: 4px;
    selection-background-color: #3498db;
    selection-color: white;
    padding: 4px;
    min-width: 200px;
}

/* Radio Buttons */
QRadioButton {
    color: #2c3e50;
    font-size: 12px;
    spacing: 8px;
}

QRadioButton::indicator {
    width: 16px;
    height: 16px;
    border-radius: 9px;
    border: 2px solid #bdc3c7;
    background-color: #ffffff;
}

QRadioButton::indicator:checked {
    border-color: #3498db;
    background-color: #3498db;
}

QRadioButton::indicator:hover {
    border-color: #3498db;
}

/* Check Boxes */
QCheckBox {
    color: #2c3e50;
    font-size: 12px;
    spacing: 8px;
}

QCheckBox::indicator {
    width: 16px;
    height: 16px;
    border-radius: 4px;
    border: 2px solid #bdc3c7;
    background-color: #ffffff;
}

QCheckBox::indicator:checked {
    border-color: #3498db;
    background-color: #3498db;
}

QCheckBox::indicator:hover {
    border-color: #3498db;
}

/* Spin Boxes */
QDoubleSpinBox, QSpinBox {
    background-color: #ffffff;
    border: 1px solid #dcdde1;
    border-radius: 6px;
    padding: 6px 8px;
    font-size: 12px;
    color: #2c3e50;
}

QDoubleSpinBox:focus, QSpinBox:focus {
    border-color: #3498db;
}

QDoubleSpinBox::up-button, QSpinBox::up-button,
QDoubleSpinBox::down-button, QSpinBox::down-button {
    width: 20px;
    border: none;
}

/* Tab Widget */
QTabWidget::pane {
    background-color: #ffffff;
    border: 1px solid #dcdde1;
    border-radius: 0 8px 8px 8px;
    padding: 4px;
}

QTabBar::tab {
    background-color: #ecf0f1;
    color: #7f8c8d;
    border: 1px solid #dcdde1;
    border-bottom: none;
    border-radius: 6px 6px 0 0;
    padding: 10px 24px;
    margin-right: 2px;
    font-size: 12px;
    min-width: 120px;
}

QTabBar::tab:selected {
    background-color: #ffffff;
    color: #2c3e50;
    font-weight: bold;
}

QTabBar::tab:hover:!selected {
    background-color: #d5d8dc;
}

/* Table Widget */
QTableWidget {
    background-color: #ffffff;
    alternate-background-color: #f8f9fa;
    gridline-color: #ecf0f1;
    border: none;
    font-size: 11px;
}

QTableWidget::item {
    padding: 6px 8px;
    color: #2c3e50;
}

QTableWidget::item:selected {
    background-color: #3498db;
    color: white;
}

QHeaderView::section {
    background-color: #ecf0f1;
    color: #2c3e50;
    font-weight: bold;
    font-size: 11px;
    padding: 8px 6px;
    border: none;
    border-right: 1px solid #dcdde1;
    border-bottom: 1px solid #dcdde1;
}

/* Splitter */
QSplitter::handle {
    background-color: #dcdde1;
}

QSplitter::handle:horizontal {
    width: 4px;
}

QSplitter::handle:vertical {
    height: 4px;
}

QSplitter::handle:hover {
    background-color: #3498db;
}

/* Scroll Bars */
QScrollBar:vertical {
    background-color: #f5f6fa;
    width: 12px;
    margin: 0;
    border-radius: 6px;
}

QScrollBar::handle:vertical {
    background-color: #bdc3c7;
    min-height: 30px;
    border-radius: 5px;
    margin: 2px;
}

QScrollBar::handle:vertical:hover {
    background-color: #95a5a6;
}

QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
    height: 0;
}

QScrollBar:horizontal {
    background-color: #f5f6fa;
    height: 12px;
    margin: 0;
    border-radius: 6px;
}

QScrollBar::handle:horizontal {
    background-color: #bdc3c7;
    min-width: 30px;
    border-radius: 5px;
    margin: 2px;
}

QScrollBar::handle:horizontal:hover {
    background-color: #95a5a6;
}

QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
    width: 0;
}

/* Status Bar */
QStatusBar {
    background-color: #2c3e50;
    color: #ecf0f1;
    font-size: 11px;
    padding: 4px 8px;
}

QStatusBar::item {
    border: none;
}

/* Frame Separators */
QFrame[frameShape="4"] {  /* HLine */
    background-color: #dcdde1;
    max-height: 1px;
}

QFrame[frameShape="5"] {  /* VLine */
    background-color: #dcdde1;
    max-width: 1px;
}

/* Tool Tips */
QToolTip {
    background-color: #2c3e50;
    color: #ecf0f1;
    border: 1px solid #34495e;
    border-radius: 4px;
    padding: 6px 10px;
    font-size: 11px;
}
"""


# Continued Rotation Analysis Report — Transcript

Markdown transcription of the draft
`Compressor Stator Parts Continued Rotation Analysis Report.docx`, reconstructed from 19
photographs of the document on screen captured 2026-08-01.

| File | Contains |
|---|---|
| `compressor-stator-parts-continued-rotation-analysis-report.md` | Full transcription, section by section |
| `flight-risk-and-mitigation-report.md` | **Internal** risk assessment — the unvarnished engineering position, including source-document defects |
| `customer-risk-and-mitigation-report.md` | **Customer-facing, technical edition** — for the Platform Owner's airworthiness function |
| `customer-risk-and-mitigation-report-programme-office.md` | **Customer-facing, programme office edition** — same risks, led by risk position, schedule and required inputs |
| `customer-risk-and-mitigation-report-tr.md` | Turkish translation of the technical edition |
| `customer-risk-and-mitigation-report-programme-office-tr.md` | Turkish translation of the programme office edition |

## Word editions

Each of the four customer markdown files has a generated `.docx` sibling, built by
`build_risk_reports_docx.py` using the house styling from
`../../tools/cs-e-substantiation-templates/_style_docx.py`.

```bash
C:/Users/emre_/PycharmProjects/EA_Node_Editor/venv/Scripts/python.exe build_risk_reports_docx.py
```

**The markdown is the source. The `.docx` files are generated artifacts — edit the markdown and
regenerate, never edit the Word file directly.**

What the generator renders: cover with metadata table, field-driven table of contents, navy section
headings with page breaks, repeating table header rows, alternating row shading, `▣` placement
markers as orange notice boxes, other block quotes as navy notes, and checkbox lists. Turkish files
get `tr-TR` proofing language so Word spell-checks them correctly.

Two deliberate touches: the `██` redaction blocks render grey rather than black, and **§5.4
"Items to resolve internally before issue" renders in red with a red margin bar** so it cannot be
missed when preparing the document for issue.

The table of contents is baked in, but page numbers go stale if you edit in Word — `Ctrl+A`, `F9`
refreshes it, same as the other generators in this workspace.

## Language

English versions are canonical, per the repository's English-documentation rule. The `-tr.md` files
are the issue-ready Turkish deliverables for the Platform Owner. **Any change to a risk, limitation,
action or date must be applied to both languages** — the pre-issue checklist in each Turkish edition
carries the consistency check.

Section headings are bilingual (`1 AMAÇ — *OBJECTIVE*`) in all four, matching the house style of the
source Continued Rotation Analysis Report.

## Internal vs. customer versions

The two risk reports cover the same engineering ground and neither conceals a safety-relevant item.
They differ in what else they carry:

- The **internal** version keeps source-document defects in the risk register (broken cross-references,
  duplicate sections, an inverted margin-of-safety formula, draft placeholders) because those are the
  team's actions to close.
- The **customer** version moves those to a pre-issue checklist (§5.4) that is deleted before issue,
  and adds what an external deliverable needs: input requests to the Platform Owner, closure-action
  targets, and a figure/table build plan.

Two items in the customer versions are marked **blocking**: the margin-of-safety formula convention
and the windmilling life-result contradiction. Neither is a safety finding, but no margin figure
should leave the building until both are resolved.

## The two customer editions

The programme office edition was produced by copying the technical edition and editing only the
sections whose treatment changes with audience. Substance is identical — same ten risks, same six
limitations, same six maintenance actions, same ten closure actions, same three required inputs.

What differs:

| | Technical edition | Programme office edition |
|---|---|---|
| Opening | Straight to §1 | §0 executive summary, six questions answered |
| Lead graphics | Hardware and results | Risk matrix and closure timeline, repeated up front |
| §3.1 | Narrative position | Adds risk counts by severity, flags customer-dependent risks |
| §4 | Limitations and actions | Adds §4.4 critical path and dependencies |
| §5.1 | Input request | Adds needed-by dates, critical-path flags, escalation route |
| Load and assumption detail | Main body | Appendix A |
| Orientation figure | Module cross-section | Whole-engine cross-section |

**If both editions are issued, they must never disagree on a risk, a limitation or a date.** An
edition consistency check is included in the programme office pre-issue checklist.

## What this is

The subject part is the **High-Pressure Compressor Casing (HPCC)**. The report substantiates its
structural integrity under two sustained vibratory load cases — Limit Out-of-Balance and
post-shutdown Windmilling after a Core Blade Off event — against **CS-E 650** (Vibration Surveys)
and **CS-E 525** (Continued Rotation), consuming engine-level loads validated under
**AMC E 520(c)(2)**. Both cases pass.

## What this is not

- **Not the source of truth.** The `.docx` is. This is a reading copy for search and reference.
- **Not complete.** Programme, company and engine identifiers are redacted in the source images.
  Front matter, glossary, the opening of the engine description, and Exhibit A were not captured.
- **Not an issued report.** The source is a working draft carrying `XXX` placeholders, Turkish
  `[_… buraya gelecek_]` notes, and broken Word cross-references. These are preserved verbatim; the
  transcript's closing appendix lists them as open items.

Conventions used for redactions, gaps and placeholders are stated at the top of the transcript.

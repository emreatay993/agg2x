# Compressor Stator Parts — Continued Rotation Analysis Report

**Transcription of a draft report, reconstructed from screen photographs.**

| Field | Value |
|---|---|
| Source document | `Compressor Stator Parts Continued Rotation Analysis Report.docx` (opened Read-Only in Word) |
| Source medium | 19 photographs of the document on screen |
| Capture date | 2026-08-01, 14:47 |
| Document length | 46 screens in Word's two-page view (~16 pages) |
| Screens captured | 5–22 (partial), plus later result and conclusion pages |
| Languages | Bilingual Turkish / English headings; body text in English |
| Part of interest | High-Pressure Compressor Casing (**HPCC**) |

## How to read this transcription

- Text is transcribed **verbatim**, including the source document's own typos
  (e.g. "geometrix", "continious", "asessments", "realiable", "fulll", "contaiment"). These are
  not transcription errors.
- `██` marks content **redacted in the source images** (painted over in red or white before
  the photographs were shared). Programme, company and engine names are redacted throughout.
- `[NOT CAPTURED]` marks chapters and pages **deliberately skipped** — not photographed, so
  no content exists for them here.
- Draft placeholders in the original are preserved as written: `XXX`, `[_PART_NO_]`,
  `[_..._ buraya gelecek_]` (Turkish for "…will come here"), and
  `Hata! Başvuru kaynağı bulunamadı.` (Word's "Error! Reference source not found." — broken
  cross-reference fields).
- Figures are photographs of plots and FE contour images; they are described, not reproduced.

---

## Front matter

**[NOT CAPTURED]** — Screens 1–4: cover page, ONAYLAR / *APPROVALS*, DAĞITIM LİSTESİ /
*DISTRIBUTION LIST*, REVİZYON LİSTESİ / *REVISION LIST*.

---

## İÇİNDEKİLER — *CONTENTS*

```
ONAYLAR
APPROVALS
DAĞITIM LİSTESİ
DISTRIBUTION LIST
REVİZYON LİSTESİ
REVISION LIST
İÇİNDEKİLER
CONTENTS
ŞEKİLLER LİSTESİ
LIST OF FIGURES
TABLOLAR LİSTESİ
LIST OF TABLES
TANIMLAR
GLOSSARY
KISALTMALAR
ABBREVIATIONS
    AMAÇ – OBJECTIVE
1.2 DOKÜMAN AMACI – OBJECTIVE OF DOCUMENT
1.3 PROJE AMACI – OBJECTIVE OF PROJECT
2   KAPSAM – SCOPE
2.1 DOKÜMAN KAPSAMI – SCOPE OF DOCUMENT
2.2 PROJE KAPSAMI – SCOPE OF PROJECT
3   REFERANS DOKÜMANLAR – REFERENCED DOCUMENTS
3.1 SÖZLEŞMELER – CONTRACTS
3.2 STANDARTLAR – STANDARDS
3.3 PROSEDÜRLER – PROCEDURES
3.4 DAHİLİ DOKÜMANLAR – INTERNAL DOCUMENTS
3.5 HARİCİ DOKÜMANLAR – EXTERNAL DOCUMENTS
4   SİSTEM TANIMI VE MİMARİ – SYSTEM DESCRIPTION AND ARCHITECTURE
4.1   Engine Description
4.2   Engine Operation
4.2.1 Compressor
5   UYUM VE SERTİFİKASYON GEREKSİNİMLERİ – COMPLIANCE AND CERTIFICATION REQUIREMENTS
5.1 Overview
5.2 Compliance Strategy
5.3 Means of Compliance Matrix
6   ANALİZ – ANALYSIS
6.1   ANALİZ ARAÇLARI – ANALYSIS TOOLS
6.2   ANALİZ SPESİFİKAYONLARI – ANALYSIS SPECIFICATIONS
6.2.1 ANALİZİN AMACI VE KAPSAMI – ANALYSIS PURPOSE AND SCOPE
6.2.2 ANALİZ METODU – ANALYSIS METHOD
6.2.3 VARSAYIMLAR – ASSUMPTIONS
6.2.4 LIMITLER – LIMITATIONS
6.2.5 KOŞULLAR – CONDITIONS
6.2.6 KOŞULLAR – CONDITIONS
6.2.7 ANALİZ SENARYOLARI – ANALYSIS SCENARIOS
6.2.8 MALZEME VERİLERİ – MATERIAL DATA
6.3   GEÇERLİ KILMA – VALIDATION
6.3.1 ANALİZ ARAÇLARININ GEÇERLİ KILINMASI – VALIDATION OF ANALYSIS TOOLS
6.3.2 ANALİZ METODUNUN GEÇERLİ KILINMASI – VALIDATION OF ANALYSIS METHOD
6.4   SONUÇLAR – RESULTS
6.4.1 Limit Out of Balance
6.4.2 Windmilling due to CBO
7   ÇIKARIMLAR VE ÖZET – CONCLUSIONS AND SUMMARY
    EKLER – EXHIBITS
    EK A – EXHIBIT A
```

> **Note on the contents list.** Section 1 is titled `AMAÇ – OBJECTIVE` but its first numbered
> subsection is `1.2`; there is no `1.1` in the contents. Sections `6.2.5` and `6.2.6` carry the
> identical title `KOŞULLAR – CONDITIONS`.

---

## ŞEKİLLER LİSTESİ — *LIST OF FIGURES*

The Turkish page renders empty:

> Şekil tablosu öğesi bulunamadı.
> *(No table-of-figures entry found.)*

The English list is populated:

| # | Figure caption |
|---|---|
| 1 | 3D View of ██ Engine |
| 2 | Engine Cross-Section |
| 3 | Compressor Module, Cross Section View |
| 4 | Details of Compressor Module, Dynamic Analysis Model, Part Names and Interfaces |
| 5 | Input Loads in Frequency Domain [Hz], LOoB, LC: COG |
| 6 | Von Mises Stress Field, Mean Stress (Hot Day) |
| 7 | Von Mises Stress Field, Alternating Stress, LC: LOoB, CoG |
| 8 | Fatigue Assessment (Goodman), LC: LOoB, CoG |
| 9 | Input Loads in Frequency Domain [Hz], Windmilling due to CBO, LC: LPT1 |
| 10 | Von Mises Stress Field, Mean Stress (Residual Stress After CBO Run-Down) |
| 11 | Von Mises Stress Field, Alternating Stress, LC: Windmilling, LPT1 |
| 12 | Fatigue Assessment (Goodman), LC: Windmilling, LPT1 |

---

## TABLOLAR LİSTESİ — *LIST OF TABLES*

**[NOT CAPTURED]** as a list. The tables that appear in the captured body are:

| # | Table caption | Captured |
|---|---|---|
| 1 | Responsibility Assignment Matrix | yes |
| 2 | MoC Matrix – Quick Reference | yes |
| 3 | MoC Matrix – Detailed | partial |
| 4 | Analysis Tools Used | yes |
| 5 | Analysis Assumptions | yes |
| 6 | Details of Each Analysis Load Case, Summary | yes |
| 7 | Material Limits Used for Strength Assessments - HPCC | yes |
| 8 | Summary of Minimum Margins of Safety and Pass Criteria | yes |

---

## TANIMLAR — *GLOSSARY* / KISALTMALAR — *ABBREVIATIONS*

**[NOT CAPTURED]** — Screens 10–13. Only the final line of the abbreviations list was captured:

> **α, β**: Rayleigh mass/stiffness proportional damping coefficients

Abbreviations used throughout the captured text, for reference:

| Abbrev. | Meaning (as used in the document) |
|---|---|
| HPCC | High-Pressure Compressor Casing |
| OoB / LOoB | Out of Balance / Limit Out of Balance |
| CBO | Core Blade Off |
| CoG | Centre of Gravity |
| DSW | Deswirler |
| PVA | (compressor bleed valve/port at the 6 o'clock position on the compressor midcase) |
| RBS | Rear Bearing Support (cooling ports) |
| MoS | Margin of Safety |
| MSUP | Mode Superposition |
| HCF | High Cycle Fatigue |
| IGV | Inlet Guide Vane |
| LPT1 | Low-Pressure Turbine, stage 1 |
| IR | Inertia Relief |

---

## 1 AMAÇ — *OBJECTIVE*

### 1.2 DOKÜMAN AMACI — *OBJECTIVE OF DOCUMENT*

Within the scope of the ██ Turboshaft Engine Development Project, this report demonstrates the
structural integrity of the High-Pressure Compressor Casing (HPCC) under sustained out of balance
loading, including maximum permitted service vibration and post-CBO event windmilling to support
CS-E certification. It consumes validated engine-level inputs and shows that the HPCC meets
fatigue requirements.

### 1.3 PROJE AMACI — *OBJECTIVE OF PROJECT*

The aim of the Project is to develop an indigenous turboshaft engine within the scope of
"TEI-██" suitable for light utility general-purpose helicopter.

---

## 2 KAPSAM — *SCOPE*

The scope of this document, which contains technical information about the project and the
analyses that are part of the project, is explained in the sections below.

### 2.1 DOKÜMAN KAPSAMI — *SCOPE OF DOCUMENT*

The scope is limited to a specific static compressor hardware, the HPCC, as defined by
`[_PART_NO_]` / `[_DRW_NO_]` / `[_REV_]`. The analysis covers:

- Windmilling after shutdown,
- Limit OoB 1× envelope

██ Engine Dynamics team provides validated engine-level forces/moments/accelerations, 1x
envelopes for OoB conditions, speeds, and alert thresholds. The derivation and validation of these
engine-level loads are outside the scope of this report. This division of responsibility is
formally established under the "validated data" concept defined in AMC 520(c)(2). This regulatory
framework allows for the certification of a based on validated inputs from the engine system level,
ensuring that the loads applied herein are representative of the conditions established through
engine-level testing and analysis, including the blade failure conditions described by CS-E 810.

Table 1 details the organizational interfaces and responsibilities between the Module Design Team,
which is responsible for structural analyses of parts, and the Engine Dynamics Team.

**Table 1: Responsibility Assignment Matrix**

| Task / Deliverable | Module Design Team | Engine Dynamics Team |
|---|---|---|
| Derive & Validate CBO & other OoB loads | C (Consulted) | A (Accountable), R (Responsible) |
| Validate Engine-Level Dynamic Model | I (Informed) | A, R |
| Develop & Validate HPCC Component FEM | A, R | I |
| Perform HPCC Structural Analysis | A, R | C |
| Report HPCC Structural Compliance | A, R | I |

### 2.2 PROJE KAPSAMI — *SCOPE OF PROJECT*

The scope of the ██ includes Product, Documentation of design studies, Test infrastructure and
Materials database. The design, development, production and testing of the product and
certification of the engine will be carried out.

The infrastructures of Engine and rig test facilities will be commissioned and calibrated.
Engineering tools will be developed according to test results. A Material Database will be
generated for the necessary materials to be used in the Product.

---

## 3 REFERANS DOKÜMANLAR — *REFERENCED DOCUMENTS*

The reference documents used for the analyses performed are listed in the relevant subsections
below.

### 3.1 SÖZLEŞMELER — *CONTRACTS*

| # | Description | Document Name | Revision |
|---|---|---|---|
| 1 | – | ██ | Söz. Değ.3 |
| 2 | AGR2400128 | ██ | ██ |

### 3.2 STANDARTLAR — *STANDARDS*

- **#3:** EASA CS-E Amendment 7

### 3.3 PROSEDÜRLER — *PROCEDURES*

*(No entries listed.)*

### 3.4 DAHİLİ DOKÜMANLAR — *INTERNAL DOCUMENTS*

- **#4:** `[_Buraya "TLIFE" aracı için TG9 vs numaraları gelecek_]`
- **#5:** `[_Buraya bizim "WE Mechload Viewer" aracı için TG9 vs numaraları gelecek_]`
- **#6:** `[_Buraya bizim "MSUP Transient-Post" aracı için TG9 vs numaraları gelecek_]`
- **#7:** TG-00033058, TS1400 GEO7 C108 Compressor Module – Analysis of Dynamic Loading Conditions
- **#8:** `[_Faz-2 statik test vs. analiz modeli karşılaştırması ŞMO sunumu buraya gelecek_]`
- **#9:** `[_Faz-2 PVA cyclic test (yaparsak) test vs. analiz modeli sonucu buraya gelecek_`
- **#10:** `[_GEO7 Manevra modeli TG'si yapılınca buraya gelecek_]`
- **#11:** `[_MB'nin Seeded Unbalance Testi sonuçlarının değerlendirmesi buraya gelecek_]`
- **#12:** `[_Cem'in yapacağı titreşim (mode shape, çekiç testi vs. buraya gelecek_]`
- **#13:** `[_Cem'in yapacağı titreşim analiz raporu_]`
- **#14:** TR-096915, ██ C108 Geo7 WEMM Loads, Displacements and Accelerations due to Limit Level
  Imbalance
- **#15:** TR-097174, ██ C108 Geo7 WEMM Loads, Displacements and Accelerations due to Windmilling
  after Core Blade Off Events
- **#16:** TR-144357, Compressor Stator Parts Containment Analysis Report
- **#17:** `[_Compressor Stator Parts Strength Analysis Report numarası buraya gelecek_]`
- **#18:** 000523-Ti6242 TMS01-030887 Forging Solution and Precipitation Heat Treated
- **#19:** 000094/03;1-Ti6242 TMS616 Forging Solution and Precipitation Heat Treated

### 3.5 HARİCİ DOKÜMANLAR — *EXTERNAL DOCUMENTS*

- **#20:** TG-00005675 Whole Engine DDR Presentation
- **#21:** MTR-027056 ENSIP, ██
- **#22:** EASA Certification Memorandum CM-S-014 (Proposed) "Modelling & Simulation," Issue 01,
  14 July 2020 (for consultation).
- **#23:** FAA Advisory Circular 33.74/92-1b, "Turbine Engine Continued Rotation and Rotor
  Locking," issued 23 June 2016
- **#24:** Nasa Technical Memorandum NASA/TM-2005-213886/REV2, "NASALIFE - Component Fatigue and
  Creep Life Prediction Program," May 2014.
- **#25:** `[_Firmadan gelen test sonucu raporu da buraya gelecek_]`

---

## 4 SİSTEM TANIMI VE MİMARİ — *SYSTEM DESCRIPTION AND ARCHITECTURE*

**[NOT CAPTURED]** — 4.1 Engine Description, and the opening of 4.2 Engine Operation, including
Figure 1 (3D View of ██ Engine) and Figure 2 (Engine Cross-Section).

### 4.2.1 Compressor *(captured from mid-section)*

> …the external systems. Anti-Ice air and acceleration bleed air passes through PVA and three RBS
> cooling ports provide cooling air to rear section of the engine.

**Figure 3: Compressor Module, Cross Section View**

The compressor system does not have variable geometry such as IGV. Annular slots are incorporated
into the first-stage shroud aft of the impeller blade leading edge to provide a passive compressor
bleed system. These slots communicate with the atmosphere through a port in the outer wall of the
front frame housing. The inducer bleed air either flows out of the slot to the atmosphere or vice
versa, depending on the pressure balance between the slot and the atmosphere. This system improves
the compressor operability margin and performance.

Compressor bleed air mainly is used for four functions: acceleration bleed, platform bleed, engine
anti-ice and sump buffer air/turbine cooling. The acceleration bleed is provided from PVA, which is
located at 6 clock position on compressor midcase. LP interstage compressor air is used for
acceleration bleed and scheduled by engine control system during the acceleration and deceleration
as a function of acceleration rate and flight condition to provide trouble free transient
performance. Acceleration bleed does not function during the steady state operation. Platform bleed
provided from LP compressor interstage ports, which are located at 3 and 9 clock positions and
unused ports for each engine shall be capped. Engine anti-ice air is provided by LP compressor
discharge from PVA. Rear sump buffer and turbine cooling air is provided from interstage LP
compressor and bleed air transmitted to the turbine side via three separate lines connected to
compressor midcase.

---

## 5 UYUM VE SERTİFİKASYON GEREKSİNİMLERİ — *COMPLIANCE AND CERTIFICATION REQUIREMENTS*

### 5.1 Overview

The certification basis for this analysis is EASA CS-E, Amendment 7 [3]. Compliance is mainly
demonstrated by Analysis, and supported by model validation against engine and rig test data.
The key regulations addressed by this report are:

- **CS-E 650 (Vibration Surveys):** Showing compliances requires demonstrating that vibratory
  stresses, have suitable margins against the material's endurance limit. This report supports this
  claim by using the out-of-balance loads validated by engine testing as per AMC E 520(c)(2) [3],
  CS-E 650(a) and performing harmonic response analyses and subsequent Goodman diagram assessments
  for Limit OoB and Windmilling condition. Further details of the system which demonstrates
  compliance with CS-E 650 vibratory requirements, especially for overall vibration levels, will be
  presented in a different structural analysis report for vibration [13].
- **CS-E 525 (Continued Rotation):** Addressed by assessing the effects of vibratory loads due to
  unbalance from a CBO event for the maximum expected flight diversion time. This report addresses
  this by assessing the peak stresses and performing a fatigue analysis for the sustained
  windmilling case following an in-flight shutdown, using the validated unbalance loads due to CBO
  events, as per AMC E 520(c)(2) [3].

### 5.2 Compliance Strategy

The compliance strategy is to demonstrate by analysis that the HPCC meets all applicable strength
and fatigue requirements when subjected to the validated OoB load cases defined in Section .
The credibility of analytical models and by extension, the results, is established through a formal
validation process (refer to Section 6.3.2), where the model's predicted dynamic behavior is
correlated against engine/rig test data.

The credibility of this "analysis-led, test-validated" approach is established though rigorious
validation of the finite element model. The FEM's static and dynamic characteristics are correlated
against component-level modal test data [8,9] and engine level ground vibration survey data.

A foundational element of this strategy is the consumption of validated loads provided by the
Engine Dynamics team, in accordance with AMC E 520(c)(2). This regulation permits the use of
validated data from analysis or test to define the forces imposed on the engine structure following
an out-of-balance event. By using these pre-validated loads, this report can focus exclusively on
the structural response and integrity of the part(s) of interest due to these unbalance effects.

### 5.3 Means of Compliance Matrix

The compliance argument is structured to follow the logical sequence of potential in-service
events: from normal (but extreme) vibration, to vibration events after a blade failure, and finally
to the continued rotation vibration condition post-shutdown. Table 2 provides a summary of the
compliance approach for the applicable regulations.

**Table 2: MoC Matrix – Quick Reference**

| Requirement ID | Title | Applicability | MoC Owner | Means of Compliance Level |
|---|---|---|---|---|
| CS-E 650 | Vibration Surveys | HCF from limit OoB conditions | Fan & Compressor Casing Team | 2, XXX |
| CSE-525 | Continued Rotation | HCF from Windmilling Loads | Fan & Compressor Casing Team | 2, XXX |

Table 3 presents the detailed Means of Compliance matrix. This matrix breaks down each applicable
regulation into its constituent requirements, provides an interpretation specific to the HPCC,
defines the acceptance criterion, and provides a traceable link to the section in this report
containing the compliance evidence. A full version of this matrix is provided in Appendix XXX.

**Table 3: MoC Matrix – Detailed**

| Requirement ID | Requirement Text (Summary) | Interpretation | Acceptance Criterion | Evidence Link to the Document |
|---|---|---|---|---|
| CS-E 650(f) | Vibratory stresses combined with steady stresses must provide suitable margins to the endurance limit. | The combined steady and alternate stresses from Limit OoB operation must not cause HCF failure. | Goodman, Infinite Life<br>If not, Life ≥ XXX cycles | §Hata! Başvuru kaynağı bulunamadı., Hata! Başvuru kaynağı bulunamadı., Hata! Başvuru kaynağı bulunamadı.<br>§Hata! Başvuru kaynağı bulunamadı., Table 8. |
| CS-E 525 | Continued rotation after shutdown must not result in any unacceptable effect. | HPCC must withstand fatigue loading from windmilling for the max diversion time (XXX hr). | Goodman, Infinite Life<br>If not, Life ≥ XXX cycles | §XXX.XXX, Fig XXX,<br>§XXX.XXX, Table XXX |

---

## 6 ANALİZ — *ANALYSIS*

For this analysis report, a total of 2 different scenarios are analyzed and their results are
presented. Further details how these analyses are performed can be found in the related subsections
of this chapter.

### 6.1 ANALİZ ARAÇLARI — *ANALYSIS TOOLS*

The analyses documented in this report were performed using industry-accepted solvers such as ANSYS
and internal tools developed within the company. The versions used are maintained under an
extensive quality assurance and version control system and various benchmarks. Table 4 provides a
summary of the software/tools employed for the analyses detailed in this report.

**Table 4: Analysis Tools Used**

| Software | Version | Application |
|---|---|---|
| Ansys Mechanical | 19.2 | Pre-processing, Meshing, Solving |
| MSUP Transient Post-Processor (Internal Tool by TEI) | 1.0 | Post-processing |
| Excel Spreadsheets (TEI) | – | Post-processing (Fatigue - Goodman) |
| TLIFE (Internal Tool by TEI) | 4.0 | Post-processing (Fatigue – Finite Life) |
| Ansys Mechanical | 2023R2 | Post-processing & Results Review |

### 6.2 ANALİZ SPESİFİKAYONLARI — *ANALYSIS SPECIFICATIONS*

The specifications of analyses are explained in the related sub-sections under this section.

#### 6.2.1 ANALİZİN AMACI VE KAPSAMI — *ANALYSIS PURPOSE AND SCOPE*

The analysis substantiates the structural adequacy of the HPCC for specified OoB events, including
service/manufacturing related limit unbalance conditions and post-shutdown condition after a blade
failure. The analysis will determine the Margins of Safety (MoS) for strength and -if applicable-
fatigue life against certified material allowables and regulatory requirements. The objective is to
demonstrate that the part(s) of interest, in this case HPCC, maintains its structural integrity and
that no hazardous engine effects arise from its response to these dynamic loads. Therefore the
scope is limited to the HPCC structure and its immediate interfaces.

#### 6.2.2 ANALİZ METODU — *ANALYSIS METHOD*

The main analysis method is based on FEA for this analysis and it is performed using the FE model
called "██ GEO7, C108 Compressor Module, Maneuver Model" [10]. In this model, the main part of
interest is High Pressure Compressor Casing (HPCC) and therefore, many of the static parts inside
the Compressor Module are not considered in this model, as they are not on the main load path and
are evaluated to have a much less chance of causing a possible hazardous engine effect compared to
HPCC part. Parts such as Stage-1 Deswirler (DSW) and Mounting Lugs are included in the model for
the sole purpose of being able to correctly apply the interface loads on the HPCC part and simulate
the interface stiffnesses of them adequately. Overall view of FE model and related interfaces
(shown in red) of HPCC which are used for loading the part are shown Figure 4.

**Figure 4: Details of Compressor Module, Dynamic Analysis Model, Part Names and Interfaces**

*Annotated FE model view. Labelled parts and interfaces include: `DSW`, `FBS Dummy`, `HPC`,
`CC Dummy`, `STG2Diff Dummy`, `STG2Shroud Dummy`, `Rear Mount Brackets`, and numbered interfaces
`I1`, `I2`, `I3`, `I4`, `I5`, `I6`, `I12`, `I13`, `I309`.*

The model largely consists of predominantly hexahedral elements to ensure accuracy in stress
prediction, with second-order tetrahedral elements used in areas of high geometrix complexity
wherever required. Loads and boundary conditions are applied to FEM to simulate its interfaces with
adjacent structures. Flange connections are modeled using appropriate constraints for dynamic
analyses to represent the load transfer and stiffness coupling through bolted joint regions.

A critical aspect of the methodology is the application of the dynamic loads from the rotating
components. These loads, which include forces and moments at the bearing locations, are transferred
to the flexible casing structure using Remote Point Connections with Distributed formulation in
ANSYS. This formulation distributes the applied point load to a set of nodes based on a weighting
function, without adding any non-physical stiffness to the model. This ensures that the local
flexibility of the casing is accurately represented, preventing the artificial stiffness
concentrations that would result from a rigid connection.

All dynamic analyses (transient and harmonic) are performed using the Mode Superposition (MSUP)
method within the ANSYS Mechanical solver. This method provides a much computationally efficient
solution compared to a fulll transient solution for dynamic systems. The response of the structure
is calculated by projecting full system's equation of onto a truncated set of its dominant natural
mode shapes, which are pre-calculated in a model analysis. The number of modes included in the
solution is sufficient to capture the dynamic response well beyond the highest frequency of
interest for each load case. In cases where stresses exceed the linear assumptions (e.g. local
stresses > material yield stress), critical time/frequency points are analysed using nonlinear
inertia relief method to be able to determine local plasticity effects and strains.

For fatigue life asessments, a two-tiered strategy is employed for CBO Run-On:

1. **Infinite-Life Screening (Goodman):** First, a conservative screening for infinite life is
   performed. The calculated alternating and mean stresses at every node are plotted on a a Goodman
   diagram constructed using the material's life curve for different temperatures. If all points
   fall within the infinite life boundary, the component is considered to have passed, and no
   further analysis is deemed to be required for that load case.
2. **Finite Life Calculation (TLIFE):** If cyclic stress states fall outside the Goodman
   infinite-life boundary, a detailed fatigue analysis is performed. This analysis uses a
   methodology mainly based on the principles of the NASALIFE code, which accounts for means stress
   effects using a Walker model [24]. Cumulative damage from different stress levels is summed
   using Miner's rule, where failure is predicted when the cumulative damage fraction reaches 1.

For further details about modelling and analyses performed, see again Reference 3 and related
subsections below in this section.

#### 6.2.3 VARSAYIMLAR — *ASSUMPTIONS*

The analysis incorporates the following key modeling assumptions. These assumptions are standard
practice throughout the organization for such analyses and are chosen to ensure a representative
and appropriately conservative prediction of a model's structural response. Further details
regarding these assumptions are specified in Table 5.

**Table 5: Analysis Assumptions**

| Item | Assumption | Rationale / Additional Notes |
|---|---|---|
| Temperature | The temperature conditions are assumed to be of Steady-State | *Rationale:* The load cases either occur at small timeframes and/or at specific temperature/ambient conditions |
| Interface Connections | Loads are applied to the system via Remote Coupling:<br>RBE3 for circular flange interfaces<br>RBE2 for interfaces with bulky parts | *Rationale:* RBE3 connection method applies loads without adding non-physical stiffness to part-to-part interfaces, allowing for accurate prediction of local stresses without inducing artificial stresses due to otherwise rigid connections. |
| Damping | Rayleigh Damping (α: mass damping, β: stiffness damping) is used | *Rationale:* Values are consistent with the validated engine-level model, ensuring representative energy dissipation |
| Contacts | Bonded around bolted joint frustrum, Frictional for rest of the flanges | *Rationale:* To accurately capture load transfer and flange stiffnesses under vibrational loads for linear dynamic analyses |
| Linearity | Homogeneous, isotropic, linearly elastic for dynamic analyses. Plasticity is included for final checks at specific timepoints, where linear stresses are found to be higher than yield stress. | *Rationale:* For almost all of the specified loading conditions or scenarios, stresses are found to be well below the yield stresses of specified parts and their materials. |
| Units | SI units (mm.kg.N) are used for all the analyses performed. | *Note:* Unless otherwise stated, all input load graphs that are shown in this report are shown in [kN] for force and [kN.m] for moment components, for both frequency-domain [Hz] and time-domain [seconds] data |

#### 6.2.4 LIMITLER — *LIMITATIONS*

This analysis does not consider non-linear phenomena such as plasticity (except as accounted for in
material allowables), large deformations, or contact effects (e.g. part-to-part rub), unless
explicitly stated. Therefore, the analyses performed in this report for CBO events are primarily
focused on out-of-balance effects, which are considered secondary in terms of causing a potentially
hazardous engine effects. Primary effects such as endangerment of the contaiment capability of the
system due to full or partial blade release is (which is a nonlinear and transient event) is
considered in a separate report for containment assessment [16].

This analysis does not assess the integrity of bolts or other connecting hardware; as these are
covered in separate reports for strength assessment [17].

#### 6.2.5 KOŞULLAR — *CONDITIONS*

The analyses are performed under a conservative set of operating conditions and load cases selected
to produce the most adverse effects with respect to the applicable acceptance criteria. For details
on how these critical load cases and time/frequency points are selected, one can refer to reference
[7].

For each load case, this involves identifying the combination of parameters (e.g. RPM, temperature,
pressure) from the engine operating envelope and specific failure scenarios that results in the
maximum stress or minimum fatigue life for the part(s) of interest. This approach ensures that the
demonstrated margins of safety are representative of the most severe conditions the component is
predicted to experience in service.

#### 6.2.6 KOŞULLAR — *CONDITIONS*

> **Note.** In the source document, section 6.2.6 repeats section 6.2.5 verbatim — same heading and
> same body text. Reproduced here as it appears.

The analyses are performed under a conservative set of operating conditions and load cases selected
to produce the most adverse effects with respect to the applicable acceptance criteria. For details
on how these critical load cases and time/frequency points are selected, one can refer to reference
[7].

For each load case, this involves identifying the combination of parameters (e.g. RPM, temperature,
pressure) from the engine operating envelope and specific failure scenarios that results in the
maximum stress or minimum fatigue life for the part(s) of interest. This approach ensures that the
demonstrated margins of safety are representative of the most severe conditions the component is
predicted to experience in service.

#### 6.2.7 ANALİZ SENARYOLARI — *ANALYSIS SCENARIOS*

2 primary load senarios are analyzed to demonstrate the structural integrity of the HPCC under
sustained vibratory conditions. These cases cover the spectrum from the highest permissible normal
operating vibration (Limit OoB) to post-shutdown continued vibration (Windmilling) and are defined
in Table 6. The loads, frequencies, and durations used are again summarized in reference [7] and
are based on validated engine system models and regulatory requirements for event duration.

**Table 6: Details of Each Analysis Load Case, Summary**

| Load Case | Description | Analysis Type | Inputs (Ref Doc) | Duration / Frequency | Acceptance Criteria |
|---|---|---|---|---|---|
| Limit OoB | Highest permissible vibration level during normal engine operation, representing the worst case balanced rotor condition. | Harmonic Response (MSUP) | Frequency-domain OoB forces/moments at part interfaces | 1XN1 sweep over full operating range | Inifinite fatigue life required (stress below material endurance limits) |
| Windmilling | Continued rotation of the rotor due to aerodynamic forces after an in-flight shutdown. | Harmonic Response (MSUP), Nonlinear IR if local stress>yield | Frequency-domain OoB forces/moments at part interfaces | 1XN1 sweep over XXX operating range | Calculated life must exceed required life. Positive MoS on life. |

#### 6.2.8 MALZEME VERİLERİ — *MATERIAL DATA*

Material properties are sourced from the approved ██ Database v33 and are detailed in documents
TMS01-030887 [XXX] and TMS616 [XXX]. Table 7 summarizes the temperature-dependent material strength
criteria used in the analysis for the main part of interest on the load path, HPCC. These values are
used for evaluating the margins of safety for these parts wherever they are necessary.

**Table 7: Material Limits Used for Strength Assessments - HPCC**

*Ti6242 TMS01-030887 Forging Solution and Precipitation Heat Treated*

| Temperature °C | %0.2 Yield Stress - A Basis MPa | Tensile Stress - A Basis MPa | Elongation - A Basis % |
|---|---|---|---|
| 25 | 826.4 | 895.5 | 10.00318839 |
| 100 | 704.2 | 794.6 | 10.77902999 |
| 150 | 635.9 | 746.4 | 11.31042835 |
| 200 | 581.3 | 711.3 | 11.84182671 |
| 250 | 539.8 | 685.8 | 12.37322507 |
| 300 | 510.2 | 666.5 | 12.90462342 |
| 350 | 489.8 | 649.8 | 13.43602178 |
| 400 | 475.2 | 632.5 | 13.96742014 |
| 450 | 461.7 | 611 | 14.4988185 |
| 482 | 451.1 | 593.5 | 14.83891345 |
| 500 | 443.7 | 581.9 | 15.03021685 |

As the full fatigue related properties (e.g. Goodman curves for initial checks and Walker
coefficients for detailed assessments) of "TMS01-030887" are not yet available in the approved
material database, the fatigue properties of a chemically and mechanically similar nickel-based
superalloy, "TMS616 (Ti6242 Forging Solution and Precipitation Heat Treated)" have been used for
all fatigue assessments. This substitution is considered as this substitute material is generally
evaluated to have more limiting characteristics by the TEI Material Team, compared to
TMS01-030887.

> **Note.** The source text describes TMS616 as a "nickel-based superalloy" while the material
> designation given in the same sentence — and in reference #19 — is Ti6242, a titanium alloy.
> Transcribed as written.

### 6.3 GEÇERLİ KILMA — *VALIDATION*

#### 6.3.1 ANALİZ ARAÇLARININ GEÇERLİ KILINMASI — *VALIDATION OF ANALYSIS TOOLS*

The Ansys software suite is a widely accepted, commercially available tool for finite element
analysis in the aerospace industry. Its solvers and element formulations are extensively verified
and validated against a large suite of benchmark problems and field data and case studies. Its use
for certification analysis is an established industry practice [22].

In addition to commercial software, ██ utilizes proprietary in-house analysis tools for specific
routines, such as various post-processing, data mapping or life-assessment operations. These tools
are developed under TEI's AS9100 certified quality management system. Any in-house tool that
automates reduces or replaces a process required for certification, and whose output is not
independently verified, undergoes a formal tool qualification process. This process is conducted in
accordance with the principles outlined in RTCA DO-178C and its supplement, DO-330, "Software Tool
Qualification Considerations". The qualification activities include documenting the tool's
requirements, performing comprehensive verification and validation, and generating the
qualification data package to demonstrate that the tool provides realiable and correct results for
its intended use in the certification environment. This dual approach ensures that all software
tools used in this analyses meet the standards required for airworthiness certification.

#### 6.3.2 ANALİZ METODUNUN GEÇERLİ KILINMASI — *VALIDATION OF ANALYSIS METHOD*

The credibility of the specific FEM used for this study is established by demonstrating its ability
to predict the known dynamic behavior of the system. The models's dynamic behavior is validated by
comparing its predicted natural frequencies and mode shapes against empirical data from a
component, subassembly and ground engine test level tests performed mainly on the HPCC and
neighboring parts, respectively, as documented in References [12]. Additionally, modal/global
damping measurements of the system are also measured with a system level test described in
reference [11] and are found to correlate adequately with FEM. The close agreement between the FEA
predictions and the test results provides high confidence that the model can accurately predict the
component's response to forced dynamic loading for OoB vibration conditions.

### 6.4 SONUÇLAR — *RESULTS*

This section presents the results of the structural analyses for the four primary load cases. The
Margin of Safety (MoS) is calculated as:

$$\mathrm{MoS}_{Strength,\%} = \left(1 - \frac{\text{Calculated Stress}}{\text{Allowable Stress}}\right) \times 100
\quad\text{or}\quad
\mathrm{MoS}_{Life,\%} = \left(1 - \frac{\text{Calculated Life}}{\text{Allowed Life}}\right) \times 100$$

A positive margin of safety or infinite life indicates that the component meets the requirement.

> **Note.** Section 6.4 says "four primary load cases", while section 6.2.7 defines and Table 6
> lists only two (Limit OoB and Windmilling). Transcribed as written.

#### 6.4.1 Limit Out of Balance

This analysis assesses the HPCC's durability under the highest level of vibration permitted during
its normal operation. The requirement is for infinite life, meaning the component must withstand
this vibration level for its entire service life without the fatigue damage. To achieve this, a
harmonic response analysis was performed across the full engine operating speed range using the
critical load set given in Reference [14] and shown in Figure 5 for all interfaces of HPCC [7].
The mean (steady-state) stress and the alternating stress results are shown in Figure 6 and
Figure 7.

**Figure 5: Input Loads in Frequency Domain [Hz], LOoB, LC: CoG**

*Two stacked frequency-response plots over roughly 0–700 Hz.*
*Upper — "Translational Components [kN]", peaking around 1.5 kN. Lower — "Rotational Components*
*[kN.m]", peaking around 0.4 kN.m. Series are per-interface and per-direction, labelled in the*
*form `I1-STBD REAR MOUNT - HPCC Side (CS-8012) T1`, `I2-PORT REAR MOUNT - HPCC Side (CS-8013) T1`,*
*`I4-FBS/DSW/INDC/HPCC - HPCC Side (CS-8001) T1` and `T2/T3`, `I5-HPCC/CC`, `I6-HPCC/CDP`,*
*`I12-HPCC/STG2Diff`, `I13-HPCC/DSW/STG2Shroud`, `I309-HPCC/PVA`, with rotational counterparts*
*`R1` and `R2/R3`.*

**Figure 6: Von Mises Stress Field, Mean Stress (Hot Day)**

*ANSYS contour plot on a section of the casing. Legend: "V: Steady-State Condition - Hot Day,*
*Equivalent Stress 2, Type: Equivalent (von-Mises) Stress, Unit: MPa, Time: 4 s,*
*Max: 976.62, Min: 0.25656". Contour bands: 976.62 / 360.91 / 315.83 / 270.75 / 225.67 / 180.58 /*
*135.5 / 90.421 / 45.339 / 0.25656.*

**Figure 7: Von Mises Stress Field, Alternating Stress, LC: LOoB, CoG**

*ANSYS contour plot. Legend: "R: HR - LOoB - CoG, Equivalent Stress 2 - 475.58 Hz - Amplitude,*
*Type: Equivalent (von-Mises) Stress, Frequency: 475.58 Hz, Sweeping Phase: 313°, Unit: MPa,*
*Custom, Max: 83.134, Min: 0.00207, Deformation Scale Factor 109.61". Contour bands run from*
*83.134 down to 0.01700.*

Since these loads and the resulting stresses are much lower compared to other type of out-of-balance
loads such as the ones due to CBO events, overall stress contour or MoS for strength is not
presented in this report for LOoB condition.

The resulting alternating and mean stresses at all locations on the HPCC were plotted on the
material's Goodman diagram, as shown in Figure 8 [7]. To account for various fatigue life
modification factors in actual operational and design conditions, a knockdown factor of 0.6 is
applied to all Goodman curves as described in Reference [21].

**Figure 8: Fatigue Assessment (Goodman), LC: LOoB, CoG**

*Goodman diagram titled "Goodman Diagram (Minimum, Corrected) - Ti 6242 TMS616 Forging".*
*X-axis: Mean Stress [MPa]. Y-axis: Alternating Stress [MPa]. Several downward-sloping limit curves*
*(one per material temperature) sit well above a dense scatter cloud of nodal data points, which*
*is concentrated at low alternating stress across the mean-stress range.*

Each limit curve in Figure 8 indicates Goodman limits for different material temperatures (from
room temperature up to max allowable service temperature of the material). From this analysis, it
was observed that the HPCC has infinite fatigue life under the specified Limit OoB conditions,
which satisfies the CS-E 650 requirement for freedom from harmful vibration in terms of these OoB
loads.

#### 6.4.2 Windmilling due to CBO

This analysis assesses the fatigue durability of the HPCC during a prolonged period of windmilling
after an in-flight shutdown with a blade-out unbalance [7]. This scenario is governed by CS-E 525
and its associated guidance, which specifies a conservative duration to cover diversion scenarios.
The harmonic response analysis was performed over the windmilling speed range, using the
out-of-balance loads calculated from the validated engine dynamics model, as per AMC E 520(c)(2)
[15]. These loads calculated from validated engine model are summarized in Figure 9 for loads
applied on HPCC.

**Figure 9: Input Loads in Frequency Domain [Hz], Windmilling due to CBO, LC: LPT1**

*Two stacked frequency-response plots, "Translational Components [kN]" and "Rotational Components*
*[kN.m]", against frequency [Hz]. Compared with Figure 5 the traces are smooth with a small number*
*of well-separated resonant peaks rather than a dense forest of them.*

The stresses were assessed for fatigue, and a life calculation was required. The mean (steady-state)
stress and the alternating stress results used as input for these life calculations are shown in
Figure 10 and Figure 11. The Goodman diagram of the calculated fatigue life is shown in Figure 12.

**Figure 10: Von Mises Stress Field, Mean Stress (Residual Stress After CBO Run-Down)**

*ANSYS contour plot of the casing with an inset time-history curve (stress vs. time [s], 0–10 s,*
*rising to a plateau). Legend: "A: IR (NL) - CBO Rundown HPC1 w Stress Relief, Equivalent Stress,*
*Type: Equivalent (von-Mises) Stress, Unit: MPa, Time: 10 s, Custom, Max: 675.18, Min: 0.00054186".*
*Contour bands: 675.18 / 600.16 / 525.14 / 450.12 / 375.1 / 300.08 / 225.06 / 150.04 / 75.021 /*
*0.00054186.*

**Figure 11: Von Mises Stress Field, Alternating Stress, LC: Windmilling, LPT1**

*ANSYS contour plot of the same casing section and legend family as Figure 10.*

**Figure 12: Fatigue Assessment (Goodman), LC: Windmilling, LPT1**

*Goodman diagram titled "Goodman Diagram (Minimum, Corrected) - Ti 6242 TMS616 Forging",*
*Series 1–6 plus a "Data" scatter. X-axis: Mean Stress [MPa], 0–500. Y-axis: Alternating Stress*
*[MPa], 0–200. The nodal scatter cloud lies below all limit curves, concentrated below roughly*
*60 MPa alternating stress and 250 MPa mean stress.*

The minimum margin of safety on life is positive, indicating that the HPCC can endure the most
demanding regulatory windmilling scenario, which is due to core blade loss (CBO), without fatigue
failure within the required hours.

---

## 7 ÇIKARIMLAR VE ÖZET — *CONCLUSIONS AND SUMMARY*

For all the scenarios and load cases that were assessed, the summary of minimum margins of safety
or life predictions are given in Table 8.

**Table 8: Summary of Minimum Margins of Safety and Pass Criteria**

| Load Case | Acceptance Criteria | Minimum Margin of Safety | Conclusion |
|---|---|---|---|
| Limit Out-of-Balance | Fatigue Life | Infinite Life Predicted | Pass |
| Windmilling | Fatigue Life | Infinite Life Predicted | Pass |

The structural integrity of the High-Pressure Compressor Casing (HPCC), has been substantiated by
analysis for critical out-of-balance and continious vibration load cases. The finite element model
used for the analysis was validated against component and ground vibration test data (again see
ref. [12] and [11]), ensuring its response adequately represents the actual hardware.

The analyses demonstrate the following:

1. The HPCC exhibits infinite fatigue life Limit Out-of-Balance (LooB) vibration conditions,
   meeting the requirement for freedom from harmful vibration in limit service conditions.
2. The HPCC maintains a positive margin of safety on fatigue life for the required duration of
   post-failure Windmilling, satisfying continued rotation requirements.

All calculated margins of safety and pass criteria are positive. The analysis was conducted in
accordance with approved procedures and validated engine-level dynamic loads which are consistent
with the principles of model validation in AMC E 520(c)(2).

> **Note.** Table 8 records "Infinite Life Predicted" for the Windmilling case, whereas §6.4.2 and
> conclusion item 2 describe that case as a finite-life calculation with a positive margin of safety
> on life, and Table 6 sets its acceptance criterion as "Calculated life must exceed required life".
> Transcribed as written.

---

## EKLER — *EXHIBITS*

### EK A — *EXHIBIT A*

**[NOT CAPTURED]**

---

## Appendix: capture coverage

Screen counters visible in the photographs, in capture order:

| Photo | Word screen counter | Content |
|---|---|---|
| 01 | Screens 5–6 of 46 | İÇİNDEKİLER / CONTENTS |
| 02 | Screens 6–7 of 46 | CONTENTS (end) |
| 03 | — | CONTENTS (end), ŞEKİLLER LİSTESİ (empty) |
| 04 | Screens 8–9 of 46 | LIST OF FIGURES |
| 05 | Screens 14–15 of 46 | Abbreviations (final line only) |
| 06 | Screens 16–17 of 46 | §1 Objective, §2.1 Scope of Document |
| 07 | Screens 18–19 of 46 | Table 1, §2.2, §3 References 3.1–3.4 |
| 08 | Screens 20–21 of 46 | §3.4 (cont.), §3.5 External Documents |
| 09 | — | §4.2.1 Compressor (tail), Figure 3, §5.1 |
| 10–11 | — | §5.2, §5.3, Tables 2 and 3 |
| 12 | — | §6, §6.1 Table 4, §6.2.1, §6.2.2 |
| 13 | — | Figure 4, §6.2.2 (cont.), §6.2.3 |
| 14 | — | Table 5, §6.2.4, §6.2.5, §6.2.6 |
| 15 | — | §6.2.7 Table 6, §6.2.8 Table 7, §6.3.1 |
| 16 | — | §6.3.1 (cont.), §6.3.2, §6.4, §6.4.1 |
| 17 | — | Figure 5, Figure 6, Figure 7 |
| 18 | — | Figure 8, §6.4.2, Figure 9, Figure 10 |
| 19 | — | Figure 11, Figure 12, §7 Table 8 |

**Gaps:** screens 1–4 (cover and front matter), screens 10–13 (glossary and abbreviations), the
opening of §4 (Engine Description, Engine Operation, Figures 1–2), the List of Tables page, and
Exhibit A.

## Appendix: open items visible in the draft

Carried over from the source document, not added by this transcription:

- Broken cross-references (`Hata! Başvuru kaynağı bulunamadı.`) in the Table 3 evidence-link column.
- `XXX` placeholders for: MoC compliance levels, cycle-count criteria, max diversion time, appendix
  and figure/table numbers in evidence links, the windmilling operating range in Table 6, and the
  material-document references in §6.2.8.
- Section 5.2 references "the validated OoB load cases defined in Section ." — section number
  missing.
- Reference entries #4, #5, #6, #8, #9, #10, #11, #12, #13, #17 and #25 are Turkish placeholders
  awaiting document numbers.
- Section 3.3 (Procedures) has no entries.
- Duplicate section 6.2.5 / 6.2.6.
- Contents jumps from section 1 to subsection 1.2 with no 1.1.

# HPCC Devam Eden Dönüş — Risk ve Azaltıcı Önlem Raporu

**Program Ofisi baskısı.**
**Tasarım Kuruluşu tarafından Platform Sahibi Program Ofisi'ne sunulmak üzere hazırlanmıştır.**

| Alan | Değer |
|---|---|
| Konu parça | Yüksek Basınçlı Kompresör Gövdesi (HPCC), Kompresör Modülü |
| Platform | Hafif sınıf, genel maksat yardımcı helikopter |
| Motor | ██ turboşaft |
| Konu | Sürekli balanssızlık ve devam eden dönüş koşullarında yapısal risk |
| Sertifikasyon esası | EASA CS-E Değ. 7 — CS-E 650, CS-E 525, AMC E 520(c)(2) |
| Dayanak analiz | Compressor Stator Parts Continued Rotation Analysis Report |
| Program dönüm noktası | *(doldurulacak — ör. ilk uçuş hazırlık gözden geçirmesi)* |
| Sonraki gözden geçirme tarihi | *(doldurulacak)* |
| Doküman durumu | *(yayım aşamasında doldurulacak)* |
| Gizlilik / dağıtım sınıfı | *(doldurulacak — bkz. §5.5)* |
| Tarih | 2026-08-02 |

> **Eşlenik doküman.** Bu raporun teknik baskısı, Platform Sahibi'nin uçuşa elverişlilik birimi için
> mevcuttur. Aynı risk kaydını ve aynı sonuçları taşır; analiz yöntemi ve sonuçları daha ayrıntılı
> işler. Bu baskı ise risk pozisyonunu, kapatma takvimini ve gereken girdileri önceliklendirir.

---

## 0 ÖZET — *EXECUTIVE SUMMARY*

| Soru | Yanıt |
|---|---|
| **Parça geçiyor mu?** | Evet. Değerlendirilen her iki yük durumu da CS-E 650 ve CS-E 525'e karşı pozitif paylarla geçmektedir. |
| **Uçuş için müsaadeli mi?** | Evet; altı adet geçici operasyonel limitasyon (§4.1) ve §4.2'deki bakım rejimi koşuluyla. |
| **Artık risk nedir?** | Kabul edilebilir. Açık risklerin hiçbiri uçuşa engel değerlendirilmemiştir. Dört risk Orta, altı risk Düşük sınıfındadır. |
| **Artık riski ne yönlendiriyor?** | Fiziksel sonuç değil, kanıt olgunluğu. Doğrulama testleri sürmektedir ve iki analiz parametresinin resmen sınırlandırılabilmesi için Platform Sahibi girdisi gerekmektedir. |
| **Bizden ne isteniyor?** | Üç girdi — bkz. §5.1. Bunlardan ikisi (**azami yönlendirme süresi**, **uçuş zarfı**) L-3 ve L-4 limitasyonlarının kaldırılması için kritik yol üzerindedir. |
| **Ne zaman kapanıyor?** | §4.3'te takip edilen on aksiyon. Nihai sayısallaştırılmış pay (A-3), A-1 ve A-2'nin tamamlanmasına bağlıdır. |

> **▣ ŞEKİL C-9'U BURAYA YERLEŞTİR (§3.1'den tekrar)**
> **İçerik:** Risk matrisi — mevcut ve azaltma sonrası pozisyon.
> **Neden burada:** Program ofisi okuyucuları risk pozisyonunu ilk sayfada görmeyi bekler. İkinci bir sürüm üretmek yerine aynı görseli §3.1'de tekrarlayın.

> **▣ ŞEKİL C-11'İ BURAYA YERLEŞTİR (§4.3'ten tekrar)**
> **İçerik:** Program dönüm noktalarına karşı risk kapatma zaman çizelgesi.
> **Neden burada:** Risk matrisi ile birlikte, teknik içeriğe girmeden önce "neredeyiz ve ne zaman kapanıyor" sorusunu yanıtlar. Tekrarlayın, çoğaltmayın.

---

### Bu dokümandaki yerleşim işaretleri hakkında

**`▣ YERLEŞTİR …`** ile işaretli bloklar, dokümanı yayıma hazırlayacak kişiye hangi görselin veya
tablonun o noktaya geleceğini, kaynağını ve kullanılacak açıklama metnini bildirir. Toplu liste
**§5.6 Şekil ve Tablo Planı** bölümündedir. Görseller yerleştirildikten sonra tüm `▣` blokları
silinmelidir.

---

## 1 AMAÇ — *OBJECTIVE*

Bu rapor, Yüksek Basınçlı Kompresör Gövdesi'nin (HPCC) sürekli titreşimli yükleme altındaki yapısal
risklerini tanımlar, alınan azaltıcı önlemleri ortaya koyar ve platform için önerilen operasyonel
limitasyonlar ile bakım aksiyonlarını belirler.

İki adet mevzuat koşulunu kapsar:

- **CS-E 650 (Titreşim Taramaları)** — Limit Balanssızlık (Limit OoB) olarak adlandırılan, izin
  verilen en yüksek servis titreşim seviyesinde zararlı titreşimden bağışıklık.
- **CS-E 525 (Devam Eden Dönüş)** — Çekirdek Kanat Kopması (CBO) olayını takip eden uçuş içi
  kapatma sonrasında rotorun dönmeye devam etmesinden kaynaklanan kabul edilemez bir etkinin
  oluşmaması.

Her iki koşul da analiz ile değerlendirilmiş ve her ikisi de pozitif paylarla geçmiştir. Bu rapor,
artık riskleri, bunları kapatacak aksiyonları ve kapanışa kadar geçerli olacak geçici tedbirleri
ortaya koyar. Ayrıca **Platform Sahibi'nden girdi gerektiren üç husus** tanımlanmıştır (bkz. §5.1).

Bu baskı, program karar alma sürecini desteklemek üzere yazılmıştır: risk pozisyonu, kapatma
takvimi, sorumluluk ve gereken girdiler. Analiz yöntemi ve sonuçları, risk pozisyonunu gerekçelendirmek
için gereken düzeyde özetlenmiştir; ayrıntılı işleyiş teknik baskıdadır.

> **▣ ŞEKİL C-1'İ BURAYA YERLEŞTİR**
> **Kaynak:** Continued Rotation Analysis Report, Şekil 2 — *Engine Cross-Section*.
> **Açıklama:** *Şekil C-1: Motor kesit görünüşü; Yüksek Basınçlı Kompresör Gövdesi'nin konumu gösterilmiştir.*
> **Neden burada:** Uzman olmayan okuyucuyu, konu donanımın motor içindeki yerine yönlendirir. HPCC'yi kontrast bir renkle işaretleyin.
> **Not — teknik baskıdan farklıdır;** teknik baskı Şekil 3'ü (Kompresör Modülü kesiti) kullanır. Tüm motor görünüşü bu kitleye daha uygundur; modül seviyesi ayrıntı burada değer katmaz.

---

## 2 YAPILAN ÇALIŞMANIN ÖZETİ — *SUMMARY OF WORK PERFORMED*

### 2.1 Yaklaşım

HPCC, **AMC E 520(c)(2) kapsamında doğrulanmış veri** olarak sağlanan motor seviyesi dinamik yüklere
karşı sonlu elemanlar analizi ile substantiye edilmiştir. Bu mevzuat hükmü, bir balanssızlık olayı
sonrasında motor yapısına etkiyen kuvvetlerin tanımlanmasında analiz veya testten elde edilen
doğrulanmış verinin kullanılmasına izin vererek, komponent değerlendirmesinin yapısal tepkiye
odaklanmasını mümkün kılar.

Uyum yaklaşımı *analiz öncülüğünde, test ile doğrulanmış* niteliktedir: sonlu elemanlar modelinin
öngördüğü doğal frekanslar, mod şekilleri ve sönümleme değerleri; komponent seviyesi modal test ve
motor seviyesi yer titreşim taraması (GVS) verileri ile korele edilir. Bu korelasyonun durumu §3.2,
**CR-01** riskinde ele alınmıştır.

### 2.2 Analiz modeli

| Husus | İçerik |
|---|---|
| Model | Kompresör Modülü dinamik analiz modeli; ilgilenilen parça HPCC |
| Model kapsamı | Kademe-1 Deswirler ve bağlantı kulakları, arayüz yüklerinin doğru uygulanması ve arayüz rijitliğinin doğru temsili amacıyla modelde tutulmuştur; ana yük yolu üzerinde olmayan diğer iç statik parçalar modele dâhil edilmemiştir |
| Elemanlar | Ağırlıklı olarak altıyüzlü (heksahedral); geometrik olarak karmaşık bölgelerde ikinci mertebe dörtyüzlü (tetrahedral) |
| Yük aktarımı | Dağıtılmış (Distributed) formülasyonlu Uzak Nokta Bağlantıları; yapay yerel rijitlik oluşturmaz |
| Bağlantılar | Cıvatalı bağlantı konisi çevresinde bonded; flanşların geri kalanında sürtünmeli (frictional) |
| Sönümleme | Rayleigh (kütle ve rijitlik orantılı); doğrulanmış motor seviyesi model ile tutarlı |
| Çözüm | Mod Süperpozisyonu (MSUP) harmonik tepki; yerel gerilmenin akmayı aştığı kritik noktalarda doğrusal olmayan atalet rahatlatma (inertia relief) uygulanmıştır |

> **▣ ŞEKİL C-2'Yİ BURAYA YERLEŞTİR**
> **Kaynak:** Continued Rotation Analysis Report, Şekil 4 — *Details of Compressor Module, Dynamic Analysis Model, Part Names and Interfaces*.
> **Açıklama:** *Şekil C-2: Kompresör Modülü sonlu elemanlar modeli; modellenen parçalar ve HPCC yük arayüzleri.*
> **Neden burada:** Kurum dışı okuyucu için raporun en önemli tek şeklidir; neyin modellendiğini ve yükün gövdeye nereden girdiğini gösterir; sonraki tüm sonuçların dayanağıdır. Model tablosunun hemen ardına yerleştirin.
> **Not:** Kaynak şekil kurum içi parça etiketleri taşımaktadır (`FBS Dummy`, `CC Dummy`, `STG2Diff Dummy`, `I1`–`I309` arayüz kodları). Yayımdan önce müşteri adlandırması ve fikrî mülkiyet taraması açısından gözden geçirin.

### 2.3 Değerlendirilen yük durumları

İzin verilen en yüksek normal işletme titreşiminden kapatma sonrası devam eden dönüşe kadar uzanan
sürekli titreşim spektrumunu iki yük durumu sınırlandırmaktadır.

> **▣ TABLO C-1'İ BURAYA YERLEŞTİR**
> **Kaynak:** Continued Rotation Analysis Report, Tablo 6 — *Details of Each Analysis Load Case, Summary*.
> **Açıklama:** *Tablo C-1: Analiz yük durumları, girdiler ve kabul kriterleri.*
> **Neden burada:** Sonuçlar sunulmadan önce yük durumlarını tanımlar.
> **Gerekli düzenleme:** Kaynak tablodaki Windmilling süre/frekans hücresinde `XXX` bulunmaktadır. Teyit edilen yönlendirme süresi ile doldurun (risk **CR-02**) veya açıkça "teyit edilecek" yazın — `XXX` görünür hâlde yayımlamayın.

İki durumun özeti:

| Yük durumu | Koşul | Kabul kriteri |
|---|---|---|
| **Limit OoB** | Normal motor işletiminde izin verilen en yüksek titreşim seviyesi; en olumsuz balanslı rotor koşulunu temsil eder. Tüm işletme aralığı boyunca 1×N1 taraması. | Sonsuz yorulma ömrü — gerilme, malzeme dayanım limitlerinin altında |
| **Windmilling** | Kanat kopmalı balanssızlık ile uçuş içi kapatma sonrasında rotorun aerodinamik kuvvetlerle dönmeye devam etmesi. Windmilling hız aralığında 1×N1 taraması. | Hesaplanan ömür, gerekli ömrü aşmalıdır; ömür üzerinden pozitif emniyet payı |

> **▣ ŞEKİL C-3 VE C-4'Ü EK A'YA YERLEŞTİR — ana gövdeye *değil***
> **Kaynak:** Şekil 5 — *Input Loads in Frequency Domain [Hz], LOoB, LC: CoG* ve Şekil 9 — *Input Loads in Frequency Domain [Hz], Windmilling due to CBO, LC: LPT1*.
> **Açıklamalar:** *Şekil C-3: HPCC arayüzlerindeki Limit Balanssızlık girdi yükleri, frekans domeni.* / *Şekil C-4: Çekirdek Kanat Kopması sonrası windmilling girdi yükleri, frekans domeni.*
> **Neden ekte:** Bu şekiller, analizin varsayılan değerlerle değil doğrulanmış motor seviyesi yüklerle sürüldüğünü kanıtlar — önemlidir, ancak bu kitle için argüman metinde yeterince taşınmaktadır. Karşılaştırma için ekte yan yana yerleştirin.
> **Not — teknik baskıdan farklıdır;** orada her ikisi de ana gövdededir.

### 2.4 Yorulma değerlendirme yöntemi

İki kademeli bir strateji kullanılmaktadır:

1. **Sonsuz ömür taraması (Goodman).** Her düğüm noktasındaki değişken ve ortalama gerilmeler,
   ilgili her sıcaklıktaki malzeme ömür eğrisinden oluşturulan Goodman eğrileri üzerine işlenir.
   Gerçek operasyonel ve tasarım koşullarındaki yorulma ömrü düzeltme faktörlerini hesaba katmak
   üzere **tüm Goodman eğrilerine 0,6 azaltma katsayısı uygulanır.** Tüm noktalar sonsuz ömür
   sınırının içinde kalıyorsa durum geçer ve ileri analiz gerekmez.
2. **Sonlu ömür hesabı.** Çevrimsel gerilme durumlarının sonsuz ömür sınırının dışına çıktığı
   hâllerde, NASALIFE kodunun prensiplerine dayanan bir metodoloji ile ayrıntılı değerlendirme
   yapılır; ortalama gerilme etkileri Walker modeli ile hesaba katılır ve kümülatif hasar Miner
   kuralı ile toplanır.

> **▣ TABLO C-2'Yİ EK A'YA YERLEŞTİR — ana gövdeye *değil***
> **Kaynak:** Tablo 5 — *Analysis Assumptions*.
> **Açıklama:** *Tablo C-2: Temel modelleme varsayımları ve gerekçeleri.*
> **Neden ekte:** Bilinçli muhafazakârlığı ortaya koyar; ancak bu kitlenin baştan sona incelemesi beklenmeyecek bir ayrıntı düzeyindedir. Referans için ve müşterinin uçuşa elverişlilik birimine iletilmek üzere erişilebilir tutun.
> **Not — teknik baskıdan farklıdır;** orada ana gövde için önerilmektedir.

### 2.5 Sonuçlar

> **▣ ŞEKİL C-5 VE C-6'YI BURAYA YERLEŞTİR (Limit OoB)**
> **Kaynak:** Şekil 7 — *Von Mises Stress Field, Alternating Stress, LC: LOoB, CoG*, ardından Şekil 8 — *Fatigue Assessment (Goodman), LC: LOoB, CoG*.
> **Açıklamalar:** *Şekil C-5: Değişken gerilme alanı, Limit Balanssızlık koşulu.* / *Şekil C-6: Goodman değerlendirmesi, Limit Balanssızlık koşulu — tüm düğüm verileri sonsuz ömür sınırı içinde.*
> **Neden burada:** Önce gerilme alanı, sonra kabul grafiği — okuyucu önce fiziksel sonucu, ardından bu sonucun karşılaştırıldığı kriteri görür.
> **Gerekli düzenleme:** Kaynak kontur lejantları kurum içi çözücü meta verisi taşımaktadır (yük adımı adları, tarama fazı, deformasyon ölçeği). Yayımdan önce kırpın veya temiz lejant ile yeniden üretin.

Limit OoB altında, değerlendirilen tüm sıcaklık aralığında bütün düğüm noktalarındaki
değişken/ortalama gerilme durumları sonsuz ömür sınırı içinde kalmaktadır. **HPCC, Limit OoB
koşullarında sonsuz yorulma ömrüne sahiptir**; bu, söz konusu yükler bakımından CS-E 650'nin zararlı
titreşimden bağışıklık gereksinimini karşılamaktadır.

Limit OoB gerilmeleri, CBO olaylarından doğan gerilmelerden belirgin biçimde düşüktür. Bu nedenle
Limit OoB koşulu için genel gerilme konturu ve dayanım payı ayrıca sunulmamıştır; CBO kaynaklı
durumlar bu koşulu sınırlandırmaktadır.

> **▣ ŞEKİL C-7 VE C-8'İ BURAYA YERLEŞTİR (Windmilling)**
> **Kaynak:** Şekil 11 — *Von Mises Stress Field, Alternating Stress, LC: Windmilling, LPT1*, ardından Şekil 12 — *Fatigue Assessment (Goodman), LC: Windmilling, LPT1*.
> **Açıklamalar:** *Şekil C-7: Değişken gerilme alanı, Çekirdek Kanat Kopması sonrası windmilling.* / *Şekil C-8: Goodman değerlendirmesi, windmilling koşulu.*
> **Neden burada:** Limit OoB sunumunu birebir yansıtır; böylece iki durum paralel okunur.
> **Opsiyonel ilave:** Artık gerilme durumunun açıklanması gerekiyorsa Şekil 10 (*Mean Stress, Residual Stress After CBO Run-Down*) — 675 MPa tepe değeri taşır ve **M-5** bakım aksiyonunun dayanağıdır.

CBO olayı sonrası windmilling altında, ömür üzerinden minimum emniyet payı pozitiftir. **HPCC,
mevzuatın öngördüğü en zorlayıcı windmilling senaryosuna, gerekli süre boyunca yorulma hasarı
oluşmaksızın dayanabilmektedir**; bu, CS-E 525 devam eden dönüş gereksinimlerini karşılamaktadır.

> **▣ TABLO C-3'Ü BURAYA YERLEŞTİR**
> **Kaynak:** Tablo 8 — *Summary of Minimum Margins of Safety and Pass Criteria*.
> **Açıklama:** *Tablo C-3: Minimum emniyet payları ve geçme kriterleri özeti.*
> **Neden burada:** §3'teki risk tartışmasının hemen öncesinde, §2'yi ana sonuçla kapatır.
> **Gerekli düzenleme — bkz. §5.4.** Windmilling satırı, yukarıda tarif edilen sonlu ömür sonucu ile yayımdan önce mutabakata alınmalıdır. Kayıt teyit edilmeden bu tabloyu yayımlamayın.

### 2.6 Sorumluluk paylaşımı

CBO yükleri, hızlar ve alarm eşikleri dâhil olmak üzere motor seviyesi balanssızlık yükleri, Motor
Dinamiği organizasyonu tarafından türetilir ve doğrulanır. HPCC komponent modeli, yapısal analiz ve
bu değerlendirme Modül Tasarım organizasyonunun sorumluluğundadır. Bu paylaşım, AMC E 520(c)(2)
kapsamında doğrulanmış verinin kullanılmasının dayanağıdır.

> **▣ TABLO C-4'Ü BURAYA YERLEŞTİR (OPSİYONEL)**
> **Kaynak:** Tablo 1 — *Responsibility Assignment Matrix*.
> **Açıklama:** *Tablo C-4: Yük türetimi, model doğrulama ve yapısal substantiyasyon için sorumluluk dağılımı.*
> **Neden burada:** Müşterinin hangi kanıtın hangi organizasyona ait olduğunu anlaması gerekiyorsa faydalıdır. Müşterinin her iki organizasyonla da temas edeceği durumlarda **dâhil edilmesi önerilir.**

---

## 3 SONUÇ VE DEĞERLENDİRME — *CONCLUSION AND ASSESSMENT*

### 3.1 Genel durum

Değerlendirilen her iki yük durumu da pozitif paylarla geçmektedir. Analiz yöntemi koşula uygundur,
çeşitli noktalarda bilinçli muhafazakârlık uygular — 0,6 Goodman azaltması, muhafazakâr ikame
yorulma malzemesi, en olumsuz yük durumu seçimi — ve devam eden dönüş substantiyasyonu için kabul
görmüş mevzuat yolu ile tutarlıdır.

**Artık risk, §4.1'deki operasyonel limitasyonlar ve §4.3'teki kapatma aksiyonları koşuluyla uçuş
için kabul edilebilir değerlendirilmektedir.** Baskın artık riskler fiziksel sonuçtan çok kanıt
olgunluğuna ilişkindir: doğrulama testleri devam etmektedir ve analiz zarfının platform işletimini
sınırlandırdığının resmen gösterilebilmesi için iki parametrenin Platform Sahibi tarafından teyidi
gerekmektedir.

**Bir bakışta risk pozisyonu:**

| | Adet | Risk numaraları | Niteliği |
|---|---|---|---|
| **Orta** | 4 | CR-01, CR-02, CR-03, CR-04 | Kanıt olgunluğu ve bekleyen girdiler. Tümünün tanımlı kapatma aksiyonu vardır. |
| **Düşük** | 6 | CR-05 ilâ CR-10 | Arayüz teyitleri ve kayıt ekleme. Bu süre zarfında muayene rejimi ile kontrol altındadır. |
| **Yüksek** | 0 | — | — |
| **Uçuşa engel** | 0 | — | — |

**Dört Orta riskten ikisi (CR-02, CR-04) Platform Sahibi girdisi olmadan kapatılamaz.** Bunlar
kritik yol üzerindeki hususlardır — bkz. §5.1.

> **▣ ŞEKİL C-9'U BURAYA YERLEŞTİR (YENİ GÖRSEL GEREKLİ — ayrıca §0'da tekrarlanır)**
> **İçerik:** Risk matrisi — CR-01 ilâ CR-10 risklerinin işlendiği 5×5 şiddet/olasılık ısı haritası; hem mevcut hem azaltma sonrası pozisyon gösterilir (mevcuttan artığa oklar).
> **Açıklama:** *Şekil C-9: Azaltıcı önlem öncesi ve sonrası risk pozisyonu.*
> **Neden burada:** Risk kaydının hemen öncesinde ve yönetici özetinde tekrar. Her riskin kabul edilebilir bölgeye taşındığını gösteren tek bir görsel, genel durumu aktarmanın en etkili yoludur.
> **Üretim notu:** Programın standart risk matrisi formatı varsa onu kullanın; yoksa basit bir 5×5 ızgara. Şiddet tanımlarını kendiniz uydurmayın — müşterinin veya programın mevcut ölçeğine hizalayın.
> **Bu baskı için önerilen işaretleme:** Platform Sahibi'ne bağlı iki riski (CR-02, CR-04) ayırt edici renk veya çerçeve ile belirtin; böylece müşteri hangi risklerin kendisinde olduğunu bir bakışta görür.

### 3.2 Risk kaydı

| No | Risk | Önlem alınmazsa etki | Mevcut / planlanan azaltıcı önlem | Artık | Sorumlu |
|---|---|---|---|---|---|
| **CR-01** | **Model doğrulama testleri henüz tamamlanmadı.** Komponent seviyesi modal test ve motor seviyesi yer titreşim taraması korelasyonu planlanmış ancak henüz raporlanmamıştır. Analiz öncülüğünde, test ile doğrulanmış argüman bunlara bağlıdır. | Öngörülen doğal frekanslar ve sönümleme donanımdan farklı çıkabilir; bu, rezonans tepkisini ve dolayısıyla değişken gerilmeleri kaydırır. | Sönümleme değerleri hâlihazırda doğrulanmış motor seviyesi model ile hizalıdır. Muhafazakâr 0,6 Goodman azaltması, ılımlı frekans kaymasına karşı pay sağlar. Testler planlanmıştır — bkz. §4.3 A-1. Geçici limitasyonlar L-1, L-2 geçerlidir. M-1 uyarınca titreşim izleme, işletme içi teyit sağlar. | Orta | Tasarım Kuruluşu |
| **CR-02** | **Azami uçuş yönlendirme süresi henüz sabitlenmedi.** CS-E 525 substantiyasyon süresi, platform harekât konseptinden türeyen azami beklenen yönlendirme süresinin bir fonksiyonudur. | Gösterilen windmilling süresi, öngörülen platform işletimini sınırlandırmayabilir. | **Platform Sahibi girdisi gereklidir** — bkz. §5.1. Analiz taramasının, mutabık kalınan süreyi payla birlikte kapsadığı teyit edilecektir. Geçici limitasyon L-3 geçerlidir. | Orta | Platform Sahibi / Tasarım Kuruluşu |
| **CR-03** | **Windmilling yorulma ömrü payı nihai hâline getirilecek.** Sayısal ömür ve pay, doğrulama testlerinin tamamlanması ve yönlendirme süresinin teyidi üzerine yeniden beyan edilecektir. | Bağımsız inceleme için sayısallaştırılmış pay mevcut değildir. | Sonuç mevcut girdilerle pozitiftir ve geçmektedir. Nihai değer, doğrulanmış analiz ile birlikte yayımlanacaktır — bkz. §4.3 A-2. | Orta | Tasarım Kuruluşu |
| **CR-04** | **Platform uçuş zarfı kapsaması.** Yük durumu kapsamının, manevra koşulları dâhil olmak üzere öngörülen platform uçuş zarfına karşı teyit edilmesi gerekmektedir. | Değerlendirilen kümenin dışındaki zarf koşulları substantiye edilmemiş olur. | **Platform Sahibi girdisi gereklidir** — bkz. §5.1. Geçici limitasyon L-4 geçerlidir. | Orta | Platform Sahibi / Tasarım Kuruluşu |
| **CR-05** | **Konfigürasyon uygulanabilirliği.** Analiz, tanımlı bir parça, resim ve revizyon standardı için geçerlidir; uçuş donanımının bu standarda uygunluğu teyit edilmelidir. | Analiz, imal edilmiş donanımı temsil etmiyor olabilir. | Resmî kapanışa kadar her sorti öncesi L-5 uyarınca konfigürasyon doğrulaması. HPCC veya flanş arayüzlerinde herhangi bir konsesyon ya da sapma yeniden değerlendirmeyi tetikler. | Düşük | Tasarım Kuruluşu / Konfigürasyon Yönetimi |
| **CR-06** | **Bağlantı elemanı ve cıvatalı bağlantı bütünlüğü bu değerlendirmenin dışındadır;** ayrı bir dayanım değerlendirme raporunda ele alınmaktadır. Modellenen yük yolunu flanş bağlantıları taşımaktadır. | Bu yük durumları için bağlantı bütünlüğü teyit edilmemiştir. | Ayrı raporun mevcut olduğu ve aynı yük durumları ile arayüzleri kapsadığı teyit edilecektir — bkz. §4.3 A-4. Bu süre zarfında M-3 muayene aksiyonu geçerlidir. | Düşük | Tasarım Kuruluşu |
| **CR-07** | **Kanat ucu sürtmesi ve parça-parça temas etkileri,** doğrusal olmayan ve geçici nitelikte olmaları nedeniyle bu analizin dışında bırakılmıştır. Sürtme, CBO olayının beklenen bir sonucudur. | Sürtmenin gövde üzerindeki yapısal geri etkisi yakalanmamıştır. | Kanat kopması ve muhafaza davranışı, ayrı Compressor Stator Parts Containment Analysis Report kapsamında değerlendirilmektedir. Sürtme etkilerinin orada sınırlandırıldığı teyit edilecektir — bkz. §4.3 A-5. | Düşük | Tasarım Kuruluşu |
| **CR-08** | **İkame yorulma malzeme verisi.** Birincil gövde malzemesinin tam yorulma özellikleri onaylı veri tabanında henüz mevcut değildir; Malzeme organizasyonunca daha kısıtlayıcı olduğu değerlendirilen, kimyasal ve mekanik olarak benzer bir alaşımın özellikleri tüm yorulma değerlendirmelerinde kullanılmıştır. | İkame malzeme tüm sıcaklıklarda muhafazakâr değilse yorulma payları olduğundan yüksek görünür. | İkame, Malzeme organizasyonunca muhafazakâr değerlendirilmiştir. Karşılaştırma resmen referanslanacaktır — bkz. §4.3 A-6. | Düşük | Malzeme / Tasarım Kuruluşu |
| **CR-09** | **Yerel tepe gerilme teyidi.** Kararlı hal sıcak gün gerilme alanında yüksek bir yerel tepe mevcuttur. Bunun geometrik tekillik mi yoksa gerçek yerel akma mı olduğu teyit edilecektir. | Gerçek ise, doğrusal elastik varsayım yerel olarak ihlal edilmiş olur. | Yöntem, yerel gerilmenin akmayı aştığı noktalarda doğrusal olmayan atalet rahatlatma uygulanmasını hâlihazırda öngörmektedir. Teyit sürmektedir — bkz. §4.3 A-7. | Düşük | Tasarım Kuruluşu |
| **CR-10** | **Analiz aracı kalifikasyon kayıtlarının** (kurum içi son işlem ve ömür değerlendirme araçları) eklenmesi gerekmektedir. | Araç çıktısı bağımsız olarak kanıtlanmamıştır. | Araçlar AS9100 sertifikalı kalite yönetim sistemi altında geliştirilmiştir; kalifikasyon RTCA DO-178C / DO-330 prensiplerine göre yürütülmüştür. Kayıtlar eklenecektir — bkz. §4.3 A-8. | Düşük | Analiz Metotları |

### 3.3 Değerlendirme

**CR-01 ilâ CR-04** riskleri önemli kümeyi oluşturur ve ortak bir niteliği paylaşır: fiziksel sonuç
olumludur, ancak bu sonucu resmen sınırlandıran kanıt hâlâ derlenmektedir. Dördün ikisi
(**CR-02**, **CR-04**) Tasarım Kuruluşu tarafından tek başına kapatılamaz ve Platform Sahibi girdisi
gerektirir.

**CR-05 ilâ CR-10**, §4.3'teki aksiyonlarla ve bu süre zarfında §4.2'deki muayene rejimi ile kontrol
altında tutulabilir.

Bu kayıttaki hiçbir risk, §4.1'deki limitasyonlar altında uçuşa engel olarak değerlendirilmemiştir.

---

## 4 LİMİTASYON VE BAKIM AKSİYONLARI — *LIMITATIONS AND MAINTENANCE ACTIONS*

### 4.1 Operasyonel limitasyonlar

Uçuş müsaadesi koşullarına dâhil edilmesi önerilir. Her limitasyon geçicidir ve ilişkili riski
kapandığında kalkar.

| No | Limitasyon | İlgili risk | Kalkış koşulu |
|---|---|---|---|
| **L-1** | İşletim, balanssızlık yüklerinin doğrulandığı titreşim zarfı ile sınırlıdır. Limit OoB 1× zarfının üzerinde işletim yapılmayacaktır. | CR-01 | A-1 |
| **L-2** | Motor titreşim alarm eşikleri uçuş boyunca aktif olacak ve izlenecektir. Herhangi bir aşım sortiyi sonlandırır ve M-5'i tetikler. | CR-01 | Kalıcı |
| **L-3** | Azami yönlendirme süresi mutabakata bağlanana kadar, sorti profilleri kapatma sonrası windmilling süresinin analiz edilen taramayı aşamayacağı şekilde planlanacaktır — pratikte, uygun bir iniş sahasına tanımlı bir yarıçap içinde işletim. | CR-02, CR-03 | A-2, A-3 |
| **L-4** | Yük durumu kapsamının platform zarfına karşı teyidi beklenirken, hâlihazırda müsaade edilmiş koşulların ötesinde kasıtlı manevra yüklemesi yapılmayacaktır. | CR-04 | A-9 |
| **L-5** | Uçuş donanımı HPCC konfigürasyonu, uçuştan önce analiz edilen imalat standardına karşı doğrulanacaktır. HPCC veya flanş arayüzlerinde herhangi bir konsesyon ya da sapma, uçuş öncesi yeniden değerlendirme gerektirir. | CR-05 | A-10 |
| **L-6** | Motor buz önleme ve hızlanma boşaltması normal kontrol programı içinde işletilecektir. Kullanılmayan LP kademeler arası boşaltma portlarının kapatıldığı teyit edilecektir. | CR-09 | Kalıcı |

> **▣ TABLO C-5'İ BURAYA YERLEŞTİR**
> **İçerik:** Yukarıdaki limitasyon tablosu; müşterinin uçuş limitasyonu doküman formatı varsa ona uygun biçimlendirilmiş hâli.
> **Açıklama:** *Tablo C-5: Önerilen operasyonel limitasyonlar.*
> **Not:** Platform Sahibi bir ana limitasyon kaydı tutuyorsa, bağımsız numaralandırma yayımlamak yerine onların numaralarını ilave bir sütunda çapraz referanslayın.

### 4.2 Bakım ve muayene aksiyonları

| No | Aksiyon | Periyot / tetikleyici | Gerekçe |
|---|---|---|---|
| **M-1** | Her sortide motor titreşim seviyesini (1×N1) kaydedin ve trendini izleyin. Her kademeli değişimi araştırın. | Her uçuş | Yorulma durumu balanssızlık seviyesi tarafından yönetilir. Kayma, rotor balanssızlığının analiz edilen zarfın ötesinde büyüdüğüne işaret eder. Ayrıca CR-01'in kapatılmasını destekleyen işletme içi kanıt biriktirir. |
| **M-2** | Kompresör modülünün boreskop muayenesi; HPCC deliği, flanş radyusları ve orta gövdedeki boşaltma portu bölgesine dikkat edilerek. | Motor bakım el kitabına göre ve her titreşim aşımından sonra | Yorulma açısından kritik bölgeler. Boşaltma portu, yük yolunda geometrik bir süreksizliktir. |
| **M-3** | HPCC flanş cıvatalı bağlantılarının ve arka bağlantı braketi tespitlerinin görsel ve tork kontrolü. | Bakım el kitabına göre ve her balanssızlık ya da sert iniş olayından sonra | Bağlantı bütünlüğü, modellenen yük yolunu taşımakla birlikte ayrı bir değerlendirmede ele alınmaktadır (CR-06). |
| **M-4** | Birikimli windmilling süresini motor çalışma süresinden ayrı olarak takip edin. | Sürekli | Windmilling maruziyeti, CS-E 525 durumu altında ömür tüketen bir parametredir. |
| **M-5** | **Herhangi bir CBO, kanat kopması veya balanssızlık alarm aşımı sonrasında: motoru yer görevine alın.** Bu analize dayanarak servise geri dönmeyin. Tam söküm, HPCC boyutsal ve tahribatsız muayenesi (NDT) ile mühendislik değerlendirmesi gereklidir. | Böyle bir olay olduğunda | Analiz, *bir yönlendirme süresi boyunca* hayatta kalmayı gösterir; sonrasında uçuşa elverişliliğin devamını değil. CBO yavaşlaması sonrasında kayda değer bir artık gerilme alanı mevcuttur. |
| **M-6** | Yer çalıştırması titreşim tarama verilerini saklayın ve öngörülen doğal frekanslara karşı inceleyin. | Her yer çalıştırması | CR-01'i kapatan kanıtı doğrudan biriktirir. |

> **▣ ŞEKİL C-10'U BURAYA YERLEŞTİR (YENİ GÖRSEL — OPSİYONEL)**
> **İçerik:** M-2 ve M-3'te atıf yapılan muayene bölgelerini işaretleyen açıklamalı HPCC görünüşü — delik, flanş radyusları, boşaltma portu bölgesi, arka bağlantı braketleri.
> **Açıklama:** *Şekil C-10: HPCC muayene bölgeleri.*
> **Neden burada:** Metin listesini uygulanabilir bir bakım yardımcısına dönüştürür. Şekil C-2 geometrisi veya kaynak Şekil 10 kontur görünüşünün konturu kaldırılarak işaretlenmesiyle üretilebilir.

### 4.3 Risk kapatma aksiyonları

| No | Aksiyon | Kapattığı | Hedef |
|---|---|---|---|
| **A-1** | Komponent modal testini ve motor seviyesi yer titreşim taraması korelasyonunu tamamlayın ve yayımlayın. | CR-01 | *(tarih girilecek)* |
| **A-2** | Azami yönlendirme süresini teyit edin ve analiz edilen windmilling taramasının bunu payla birlikte sınırlandırdığını doğrulayın. | CR-02 | *(tarih girilecek — §5.1 girdisine bağlı)* |
| **A-3** | Nihai sayısallaştırılmış windmilling yorulma ömrünü ve payını yayımlayın. | CR-03 | *(tarih girilecek — A-1, A-2 sonrası)* |
| **A-4** | Bağlantı elemanı dayanım değerlendirmesinin bu yük durumlarını ve arayüzleri kapsadığını teyit edin. | CR-06 | *(tarih girilecek)* |
| **A-5** | Sürtme etkilerinin muhafaza değerlendirmesi ile sınırlandırıldığını teyit edin. | CR-07 | *(tarih girilecek)* |
| **A-6** | Yorulma verisi ikamesini destekleyen resmî malzeme karşılaştırmasını referanslayın. | CR-08 | *(tarih girilecek)* |
| **A-7** | Kararlı hal sıcak gün alanındaki yerel tepe gerilmenin ele alınış biçimini teyit edin. | CR-09 | *(tarih girilecek)* |
| **A-8** | Analiz aracı kalifikasyon kayıtlarını ekleyin. | CR-10 | *(tarih girilecek)* |
| **A-9** | Yük durumu kapsamını, mutabık kalınan platform uçuş zarfına karşı teyit edin. | CR-04 | *(tarih girilecek — §5.1 girdisine bağlı)* |
| **A-10** | Uçuş donanımı konfigürasyonunu, analiz edilen imalat standardına karşı teyit edin. | CR-05 | *(tarih girilecek)* |

### 4.4 Kritik yol ve bağımlılıklar

| Aksiyon | Bağlı olduğu | Blokladığı | Sorumlu |
|---|---|---|---|
| **A-1** Doğrulama testleri tamam | Test slotu müsaitliği | A-3; L-1 ve L-2'nin kaldırılması | Tasarım Kuruluşu |
| **A-2** Yönlendirme süresi teyitli | **Platform Sahibi'nden I-1 girdisi** | A-3; L-3'ün kaldırılması | Ortak |
| **A-3** Nihai sayısal ömür ve pay | A-1 **ve** A-2 | CR-03'ün resmî kapanışı | Tasarım Kuruluşu |
| **A-9** Zarf kapsaması teyitli | **Platform Sahibi'nden I-2 girdisi** | L-4'ün kaldırılması | Ortak |
| A-4 ilâ A-8, A-10 | Yok — bağımsız | Yalnızca ilgili riskin kapanışı | Tasarım Kuruluşu |

**Kritik yol:** I-1 → A-2 → A-3; A-1 ile paralel yürür. Nihai sayısallaştırılmış pay, hem doğrulama
testleri hem de yönlendirme süresi tamamlanmadan yayımlanamaz. A-4 ilâ A-8 ve A-10 bağımsız yürür
ve uçuşu geciktirmez.

> **▣ ŞEKİL C-11'İ BURAYA YERLEŞTİR (YENİ GÖRSEL GEREKLİ — ayrıca §0'da tekrarlanır)**
> **İçerik:** Risk kapatma zaman çizelgesi — A-1 ilâ A-10 için program takvimine karşı yatay çubuklar; uçuş tarihi işaretli, kritik yol vurgulanmış ve bağımlılıklar gösterilmiş (A-3, A-1 ve A-2'yi takip eder).
> **Açıklama:** *Şekil C-11: Program dönüm noktalarına karşı risk kapatma takvimi.*
> **Neden burada:** §4'ü kapatır ve yönetici özetinde tekrarlanır. Açık risk pozisyonunu tarihli ve yönetilen bir plana dönüştürür; program ofisinin genellikle ilk aradığı şey budur.
> **Bu baskı için önerilen işaretleme:** Platform Sahibi'nin iki girdi kapısını (I-1, I-2) zaman çizelgesinde ayrı dönüm noktası olarak işaretleyin; böylece müşteri kendi yanıt tarihinin kapatma takvimine etkisini görebilir. Ayrıca her aksiyonun tamamlanmasıyla hangi limitasyonun kalktığını belirtin.

---

## 5 DİĞER — *OTHER*

### 5.1 Platform Sahibi'nden gereken girdiler

**Program Ofisi için aksiyon bölümü burasıdır.** Üç husus Tasarım Kuruluşu tarafından tek başına
kapatılamaz. Bunlardan ikisi §4.4'te tanımlanan kritik yol üzerindedir.

| No | Gereken girdi | Son tarih | Beslediği | Kritik yol | Sağlanmazsa sonucu |
|---|---|---|---|---|---|
| **I-1** | Platform harekât konseptinden türetilen **azami beklenen uçuş yönlendirme süresi.** | *(tarih girilecek — A-2, A-3'ü yönetir)* | CR-02, aksiyon A-2 | **Evet** | L-3 limitasyonu yürürlükte kalır; sorti planlaması uygun bir iniş sahasından belirli bir yarıçapla kısıtlanır. Nihai sayısallaştırılmış pay (A-3) yayımlanamaz. |
| **I-2** | Manevra koşulları dâhil **öngörülen platform uçuş zarfı.** | *(tarih girilecek — A-9'u yönetir)* | CR-04, aksiyon A-9 | **Evet** | L-4 limitasyonu yürürlükte kalır; kasıtlı manevra yüklemesi kısıtlanır. |
| **I-3** | **Geçerli limitasyon kaydı formatının teyidi** ve varsa mevcut platform seviyesi limitasyon numaraları. | *(tarih girilecek)* | §4.1'in entegrasyonu | Hayır | Limitasyonlar Tasarım Kuruluşu numaralandırması ile yayımlanır ve sonradan mutabakat gerektirir. |

**Eskalasyon / irtibat noktası:** *(doldurulacak — Tasarım Kuruluşu odak noktası ile bir girdi
tarihinin kaçırılması hâlinde uygulanacak eskalasyon yolu belirtilecek.)*

**I-1**'deki her haftalık gecikme, A-3'ün tamamlanma tarihini ve dolayısıyla L-3 limitasyonunun
kaldırılabileceği noktayı öteler. Kesin bir yönlendirme süresi zamanında sağlanamıyorsa, mutabık
kalınan bir geçici değer kullanılabilir ve analiz sonradan yeniden teyit edilebilir; lütfen girdiyi
açık bırakmak yerine bu seçeneği gündeme getirin.

### 5.2 Dayanak ve geçerlilik

Bu değerlendirme, Compressor Stator Parts Continued Rotation Analysis Report ve onun dayanak
referanslarına dayanmaktadır. Yalnızca HPCC'yi ele alır. Aşağıdakileri kapsamaz:

- Kanat kopması ve muhafaza — ayrı muhafaza analiz raporu.
- Bağlantı elemanı ve bağlayıcı donanım dayanımı — ayrı dayanım değerlendirme raporu.
- CS-E 650 için genel motor titreşim seviyeleri — ayrı titreşim analiz raporu.

### 5.3 Tanımlar

| Terim | Anlamı |
|---|---|
| HPCC | Yüksek Basınçlı Kompresör Gövdesi (High-Pressure Compressor Casing) |
| OoB / Limit OoB | Balanssızlık / Limit Balanssızlık — izin verilen en yüksek servis titreşim seviyesi |
| CBO | Çekirdek Kanat Kopması (Core Blade Off) |
| MoS | Emniyet Payı (Margin of Safety) |
| MSUP | Mod Süperpozisyonu (Mode Superposition) |
| HCF | Yüksek Çevrimli Yorulma (High Cycle Fatigue) |
| Goodman diyagramı | Yorulma dayanım sınırını tanımlayan değişken gerilme–ortalama gerilme grafiği |
| Windmilling | Kapatma sonrası rotorun aerodinamik kuvvetlerle dönmeye devam etmesi |

### 5.4 Yayımdan önce kurum içinde çözülecek hususlar

**Bunlar müşteriye gitmez.** Bu bölümü yayımdan önce silin.

| No | Husus | Aksiyon |
|---|---|---|
| **X-1** | Kaynak raporun §6.4 bölümündeki ömür emniyet payı formülü MoS = (1 − Hesaplanan Ömür / İzin Verilen Ömür) × 100 şeklinde yazılmıştır; bu, hesaplanan ömür gerekenden *az* olduğunda pozitif değer verir — beyan edilen amacın tersi. | **Bloke edici.** Ömür değerlendirme aracı çıktısının hangi konvansiyonu kullandığını **kurum dışına herhangi bir pay rakamı verilmeden önce** çözün ve teyit edin. |
| **X-2** | Kaynak raporun Tablo 8'i Windmilling durumu için "Infinite Life Predicted" kaydeder; §6.4.2 ve sonuçlar ise pozitif paylı bir sonlu ömür hesabı tarif eder. | **Tablo C-3 için bloke edici.** Yayımdan önce mutabakata alın. |
| **X-3** | Kaynak §6.4, "dört birincil yük durumu"na atıf yapar; tanımlı olan iki tanedir. | Daha önceki bir kapsamdan durum çıkarılıp çıkarılmadığını teyit edin. CR-04'ü besler. |
| **X-4** | Kaynak raporun 6.2.5 ve 6.2.6 bölümleri başlık ve gövde olarak aynıdır. | 6.2.6'nın amaçlanan içeriğini belirleyin. |
| **X-5** | Kaynak rapor; çözülmemiş çapraz referanslar, `XXX` yer tutucuları ve boş referans kayıtları içeren, onaylanmamış bir taslaktır. | Bu rapor kaynağı kanıt dayanağı olarak göstermeden önce kontrollü bir revizyon yayımlayın. |
| **X-6** | Kaynak, ikame yorulma alaşımını "nikel esaslı süperalaşım" olarak tarif ederken bir titanyum tanımı adlandırmaktadır. | A-6 kapanmadan önce kaynakta düzeltin. |
| **X-7** | Analiz bir ANSYS sürümünde çözülmüş, başka bir sürümde son işlemden geçirilmiştir. | Sonuç yorumlama tutarlılığını teyit edin; kasıtlı ise analiz raporunda belirtin. |

### 5.5 Yayım öncesi kontrol listesi

- [ ] **X-1 ve X-2 çözüldü** — teyit edilmeden hiçbir pay rakamı veya özet tablo yayımlanmayacak.
- [ ] **5.4 bölümü silindi.**
- [ ] Tüm `▣ YERLEŞTİR` blokları kaldırıldı ve görseller gömüldü.
- [ ] Tüm `XXX` ve `*(tarih girilecek)*` yer tutucuları dolduruldu.
- [ ] Kontur grafik lejantları, kurum içi çözücü meta verisi olmadan yeniden üretildi.
- [ ] Şekil C-2'deki kurum içi parça adları ve arayüz kodları, fikrî mülkiyet ve müşteri adlandırma
      uyumu açısından tarandı.
- [ ] Karartılmış tanımlayıcılar (`██`) gözden geçirildi — Platform Sahibi, çalışma kopyasında
      karartılmış motor ve program adlandırmalarına erişim hakkına sahip olabilir.
- [ ] İhracat kontrolü ve ticari gizlilik sınıfı başlığa işlendi.
- [ ] Teknik kontrol ve bağımsız inceleme tamamlandı ve kayda geçirildi.
- [ ] Doküman numarası, revizyonu ve onay imzaları uygulandı.
- [ ] **Baskılar arası tutarlılık kontrolü** — risk kaydı (§3.2), limitasyonlar (§4.1), bakım
      aksiyonları (§4.2), kapatma aksiyonları (§4.3) ve gereken girdilerin (§5.1) teknik baskı ile
      esas bakımından birebir aynı olduğu doğrulandı. Bu iki doküman hiçbir risk, limitasyon veya
      tarih konusunda birbiriyle çelişmemelidir.
- [ ] Program dönüm noktası ve sonraki gözden geçirme tarihi başlığa işlendi.
- [ ] §5.1'de eskalasyon irtibat noktası belirtildi.

### 5.6 Şekil ve Tablo Planı

Toplu üretim listesi. **Mevcut** = Continued Rotation Analysis Report'taki hâlihazırdaki görsel.
**Yeni** = üretilecek görsel.

Bu baskıdaki yerleşim, belirtilen yerlerde teknik baskıdan farklıdır. **Öncelik**, görsel üretim
eforu kısıtlıysa önce neyin hazırlanacağını gösterir.

| Ref | Bölüm | Tür | Kaynak | Durum | Öncelik | Notlar |
|---|---|---|---|---|---|---|
| Şekil C-9 | **§0** ve §3.1 | **Yeni** | Risk matrisi, mevcut vs. artık | Üretilecek | **1** | Aynı görseli her iki yerde tekrarla. CR-02, CR-04'ü müşteriye bağlı olarak vurgula |
| Şekil C-11 | **§0** ve §4.3 | **Yeni** | Risk kapatma zaman çizelgesi | Üretilecek | **2** | Her iki yerde tekrarla. Kritik yolu, I-1/I-2 girdi kapılarını ve limitasyon kalkış noktalarını işaretle |
| Tablo C-5 | §4.1 | Yeni format | Limitasyon tablosu | Hazır | **3** | Müşteri kayıt formatına hizala; I-3 uyarınca onların numaralarını ekle |
| Tablo C-3 | §2.5 | Mevcut | Tablo 8 — Pay özeti | **Bloke** | 4 | X-2 çözülene kadar beklet |
| Şekil C-1 | §1 | Mevcut | **Şekil 2 — Motor kesiti** | Hazır | 5 | *Farklı:* teknik baskı Şekil 3'ü (modül görünüşü) kullanır |
| Şekil C-2 | §2.2 | Mevcut | Şekil 4 — SE modeli, parça adları ve arayüzler | Önce tara | 6 | Kurum içi etiketlerde fikrî mülkiyet taraması |
| Tablo C-1 | §2.3 | Mevcut | Tablo 6 — Yük durumu özeti | Önce düzenle | 7 | Süre hücresindeki `XXX` kaldırılacak |
| Şekil C-6 | §2.5 | Mevcut | Şekil 8 — LOoB Goodman | Hazır | 8 | |
| Şekil C-8 | §2.5 | Mevcut | Şekil 12 — Windmilling Goodman | Hazır | 8 | |
| Tablo C-4 | §2.6 | Mevcut | Tablo 1 — Sorumluluk matrisi | Hazır | 9 | **Bu baskı için önerilir** — hangi organizasyonun hangi aksiyondan sorumlu olduğunu netleştirir |
| Şekil C-5 | §2.5 | Mevcut | Şekil 7 — LOoB değişken gerilme | Yeniden üret | 10 | Temiz lejant |
| Şekil C-7 | §2.5 | Mevcut | Şekil 11 — Windmilling değişken gerilme | Yeniden üret | 10 | Temiz lejant |
| Şekil C-10 | §4.2 | **Yeni** | HPCC muayene bölgeleri, açıklamalı | Opsiyonel | 11 | C-2 geometrisinden üret |
| Şekil C-3 | **Ek A** | Mevcut | Şekil 5 — LOoB girdi yükleri | Hazır | 12 | *Farklı:* teknik baskıda ana gövdede |
| Şekil C-4 | **Ek A** | Mevcut | Şekil 9 — Windmilling girdi yükleri | Hazır | 12 | *Farklı:* teknik baskıda ana gövdede |
| Tablo C-2 | **Ek A** | Mevcut | Tablo 5 — Analiz varsayımları | Hazır | 12 | *Farklı:* teknik baskıda ana gövdede |
| — | §2.5 | Mevcut | Şekil 10 — CBO yavaşlaması sonrası artık gerilme | Opsiyonel | 13 | Yalnızca M-5 gerekçelendirilecekse dâhil et |

**Kaynak rapordan aktarılmayanlar:** Şekil 1 (3B motor görünüşü — karartılmış ve bu argüman için
gerekli değil), Şekil 6 (sıcak gün ortalama gerilmesi — CR-09 tartışmasını destekler ancak tepe
değeri, A-7 kapandıktan sonra daha iyi yanıtlanacak sorulara davetiye çıkarır), Tablo 2, Tablo 3
(Uyum Yöntemi matrisleri — kurum içi sertifikasyon planlaması ve Tablo 3 çözülmemiş çapraz
referanslar içeriyor), Tablo 4 (analiz araçları — kurum içi), Tablo 7 (malzeme müsaade değerleri —
tescilli; müşterinin veri hakları malzeme özellik verisini açıkça kapsamıyorsa paylaşılmamalı).

### 5.7 İnceleme kaydı

| Husus | Durum |
|---|---|
| Hazırlayan | 2026-08-02 |
| Teknik kontrol | *(tamamlanacak)* |
| Bağımsız inceleme | *(tamamlanacak)* |
| Tasarım Kuruluşu onayı | *(tamamlanacak)* |
| Platform Sahibi'ne yayım | *(tamamlanacak)* |

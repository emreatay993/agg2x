# HPCC Continued Rotation — Risk and Mitigation Report

**Prepared by the Design Organisation for issue to the Platform Owner.**

| Field | Value |
|---|---|
| Subject part | High-Pressure Compressor Casing (HPCC), Compressor Module |
| Platform | Light utility general-purpose helicopter |
| Engine | ██ turboshaft |
| Subject | Structural risk under sustained out-of-balance and continued-rotation conditions |
| Certification basis | EASA CS-E Amdt. 7 — CS-E 650, CS-E 525, AMC E 520(c)(2) |
| Supporting analysis | Compressor Stator Parts Continued Rotation Analysis Report |
| Document status | *(to be completed on issue)* |
| Classification / handling | *(to be completed — see §5.5)* |
| Date | 2026-08-02 |

---

### How to use the placement markers in this document

Blocks marked **`▣ PLACE …`** tell whoever assembles the issued document what artwork or table
belongs at that point, where it comes from, and what caption to use. A consolidated list is given
in **§5.6 Figure and Table Plan**. Remove all `▣` blocks once the artwork is embedded.

---

## 1 AMAÇ — *OBJECTIVE*

This report identifies the structural risks associated with the High-Pressure Compressor Casing
(HPCC) under sustained vibratory loading, states the mitigations in place, and defines the
operating limitations and maintenance actions recommended for the platform.

It covers two regulatory conditions:

- **CS-E 650 (Vibration Surveys)** — freedom from harmful vibration at the highest permissible
  service vibration level, referred to as Limit Out-of-Balance (Limit OoB).
- **CS-E 525 (Continued Rotation)** — no unacceptable effect arising from continued rotation of the
  rotor after an in-flight shutdown following a Core Blade Off (CBO) event.

Both conditions have been assessed by analysis and both pass with positive margins. This report
sets out the residual risks, the actions that close them, and the interim measures that apply until
they are closed. It also identifies **three items requiring Platform Owner input** (see §5.1).

> **▣ PLACE FIGURE C-1 HERE**
> **Source:** Figure 3 of the Continued Rotation Analysis Report — *Compressor Module, Cross Section View*.
> **Caption:** *Figure C-1: Compressor Module cross-section, showing the High-Pressure Compressor Casing.*
> **Why here:** Orients the reader to the subject hardware before any discussion of loads. Annotate the HPCC in a contrasting colour; the source figure is unannotated.
> **Alternative:** Figure 2 (Engine Cross-Section) if a whole-engine view is preferred for the customer audience.

---

## 2 YAPILAN ÇALIŞMANIN ÖZETİ — *SUMMARY OF WORK PERFORMED*

### 2.1 Approach

The HPCC has been substantiated by finite element analysis against engine-level dynamic loads
supplied as **validated data under AMC E 520(c)(2)**. This regulatory provision permits the use of
validated analysis or test data to define the forces imposed on the engine structure following an
out-of-balance event, allowing the component assessment to focus on structural response.

The compliance approach is *analysis-led and test-validated*: the finite element model's predicted
natural frequencies, mode shapes and damping are correlated against component-level modal testing
and engine-level ground vibration survey data. The status of that correlation is addressed in
§3.2, risk **CR-01**.

### 2.2 Analysis model

| Aspect | Content |
|---|---|
| Model | Compressor Module dynamic analysis model; HPCC as the part of interest |
| Scope of model | Stage-1 Deswirler and mounting lugs retained to apply interface loads and represent interface stiffness correctly; other internal static parts omitted as not on the primary load path |
| Elements | Predominantly hexahedral; second-order tetrahedra in geometrically complex regions |
| Load introduction | Remote Point Connections with Distributed formulation, avoiding artificial local stiffness |
| Joints | Bonded around the bolted-joint frustum; frictional elsewhere on flanges |
| Damping | Rayleigh (mass- and stiffness-proportional), consistent with the validated engine-level model |
| Solution | Mode Superposition (MSUP) harmonic response; nonlinear inertia relief applied at critical points where local stress exceeds yield |

> **▣ PLACE FIGURE C-2 HERE**
> **Source:** Figure 4 of the Continued Rotation Analysis Report — *Details of Compressor Module, Dynamic Analysis Model, Part Names and Interfaces*.
> **Caption:** *Figure C-2: Finite element model of the Compressor Module, showing modelled parts and the HPCC load interfaces.*
> **Why here:** This is the single most important figure in the report for an external reader — it shows exactly what was modelled and where load enters the casing, which underpins every result that follows. Place immediately after the model table.
> **Note:** Source figure carries internal part labels (`FBS Dummy`, `CC Dummy`, `STG2Diff Dummy`, interface IDs `I1`–`I309`). Review these against the customer's naming and IP screening before issue.

### 2.3 Load cases assessed

Two load cases bound the sustained vibratory spectrum, from the highest permissible normal
operating vibration through to post-shutdown continued rotation.

> **▣ PLACE TABLE C-1 HERE**
> **Source:** Table 6 of the Continued Rotation Analysis Report — *Details of Each Analysis Load Case, Summary*.
> **Caption:** *Table C-1: Analysis load cases, inputs and acceptance criteria.*
> **Why here:** Defines the load cases before results are presented.
> **Edit required:** The source table contains `XXX` in the Windmilling duration/frequency cell. Populate with the confirmed diversion time (risk **CR-02**) or state "to be confirmed" explicitly — do not issue with `XXX` visible.

Summary of the two cases:

| Load case | Condition | Acceptance criterion |
|---|---|---|
| **Limit OoB** | Highest permissible vibration level in normal engine operation, representing the worst-case balanced rotor condition. 1×N1 sweep over the full operating range. | Infinite fatigue life — stress below material endurance limits |
| **Windmilling** | Continued rotation of the rotor on aerodynamic forces after an in-flight shutdown with blade-out unbalance. 1×N1 sweep over the windmilling speed range. | Calculated life must exceed required life; positive margin of safety on life |

> **▣ PLACE FIGURE C-3 HERE**
> **Source:** Figure 5 — *Input Loads in Frequency Domain [Hz], LOoB, LC: CoG*.
> **Caption:** *Figure C-3: Limit Out-of-Balance input loads at the HPCC interfaces, frequency domain.*
> **Why here:** Evidences that the analysis is driven by validated engine-level loads rather than assumed values — the core of the AMC E 520(c)(2) argument.
> **Layout:** Two stacked plots (translational [kN], rotational [kN.m]). Consider placing side by side with Figure C-4 for direct comparison of the two load cases.

> **▣ PLACE FIGURE C-4 HERE**
> **Source:** Figure 9 — *Input Loads in Frequency Domain [Hz], Windmilling due to CBO, LC: LPT1*.
> **Caption:** *Figure C-4: Windmilling input loads following a Core Blade Off event, frequency domain.*
> **Why here:** Pairs with Figure C-3. The visual contrast is informative — the windmilling response shows a small number of well-separated resonant peaks against the dense forest of the LOoB case.

### 2.4 Fatigue assessment method

A two-tier strategy is used:

1. **Infinite-life screening (Goodman).** Alternating and mean stresses at every node are plotted
   against Goodman curves constructed from the material life curve at each relevant temperature. A
   **knockdown factor of 0.6 is applied to all Goodman curves** to account for fatigue life
   modification factors in actual operational and design conditions. If all points fall inside the
   infinite-life boundary, the case passes with no further analysis.
2. **Finite-life calculation.** Where cyclic stress states fall outside the infinite-life boundary,
   a detailed assessment is performed using a methodology based on the principles of the NASALIFE
   code, accounting for mean-stress effects through a Walker model, with cumulative damage summed
   by Miner's rule.

> **▣ PLACE TABLE C-2 HERE (OPTIONAL)**
> **Source:** Table 5 — *Analysis Assumptions*.
> **Caption:** *Table C-2: Principal modelling assumptions and rationale.*
> **Why here:** Supports the transparency of the method. **Recommend including** — it demonstrates deliberate conservatism, which strengthens the customer's confidence in the residual risk position.
> **Placement alternative:** Move to an appendix if the main body is running long.

### 2.5 Results

> **▣ PLACE FIGURE C-5 AND C-6 HERE (Limit OoB)**
> **Source:** Figure 7 — *Von Mises Stress Field, Alternating Stress, LC: LOoB, CoG*, followed by Figure 8 — *Fatigue Assessment (Goodman), LC: LOoB, CoG*.
> **Captions:** *Figure C-5: Alternating stress field, Limit Out-of-Balance condition.* / *Figure C-6: Goodman assessment, Limit Out-of-Balance condition — all nodal data within the infinite-life boundary.*
> **Why here:** Stress field then acceptance plot, in that order — the reader sees the physical result, then the criterion it is judged against.
> **Edit required:** Source contour legends carry internal solver metadata (load-step names, sweep phase, deformation scale). Crop or re-render with a clean legend before issue.

Under Limit OoB, all nodal alternating/mean stress states fall within the infinite-life boundary
across the full temperature range assessed. **The HPCC has infinite fatigue life under Limit OoB
conditions**, satisfying the CS-E 650 requirement for freedom from harmful vibration in respect of
these loads.

Limit OoB stresses are substantially lower than those arising from CBO events. Overall stress
contour and strength margin for the Limit OoB condition are therefore not presented separately;
the CBO-derived cases bound them.

> **▣ PLACE FIGURE C-7 AND C-8 HERE (Windmilling)**
> **Source:** Figure 11 — *Von Mises Stress Field, Alternating Stress, LC: Windmilling, LPT1*, followed by Figure 12 — *Fatigue Assessment (Goodman), LC: Windmilling, LPT1*.
> **Captions:** *Figure C-7: Alternating stress field, windmilling following Core Blade Off.* / *Figure C-8: Goodman assessment, windmilling condition.*
> **Why here:** Mirrors the Limit OoB presentation so the two cases read in parallel.
> **Optional addition:** Figure 10 (*Mean Stress, Residual Stress After CBO Run-Down*) if the residual stress state warrants explanation — it peaks at 675 MPa and is the basis for maintenance action **M-5**.

Under windmilling following a CBO event, the minimum margin of safety on life is positive. **The
HPCC can endure the most demanding regulatory windmilling scenario without fatigue failure within
the required duration**, satisfying CS-E 525 continued-rotation requirements.

> **▣ PLACE TABLE C-3 HERE**
> **Source:** Table 8 — *Summary of Minimum Margins of Safety and Pass Criteria*.
> **Caption:** *Table C-3: Summary of minimum margins of safety and pass criteria.*
> **Why here:** Closes §2 with the headline result immediately before the risk discussion in §3.
> **Edit required — see §5.4.** The Windmilling row must be reconciled with the finite-life result described above before issue. Do not issue this table until the entry is confirmed.

### 2.6 Division of responsibility

Engine-level out-of-balance loads, including CBO loads, speeds and alert thresholds, are derived
and validated by the Engine Dynamics organisation. The Module Design organisation owns the HPCC
component model, the structural analysis and this assessment. This division is the basis on which
validated data is consumed under AMC E 520(c)(2).

> **▣ PLACE TABLE C-4 HERE (OPTIONAL)**
> **Source:** Table 1 — *Responsibility Assignment Matrix*.
> **Caption:** *Table C-4: Responsibility assignment for load derivation, model validation and structural substantiation.*
> **Why here:** Useful if the customer needs to understand which organisation owns which evidence. **Recommend including** where the customer will interface with both organisations.

---

## 3 SONUÇ VE DEĞERLENDİRME — *CONCLUSION AND ASSESSMENT*

### 3.1 Overall position

Both assessed load cases pass with positive margins. The analysis method is appropriate to the
condition, applies deliberate conservatism at several points — a 0.6 Goodman knockdown, a
conservative substitute fatigue material, worst-case load case selection — and is consistent with
the accepted regulatory route for continued-rotation substantiation.

**Residual risk is assessed as acceptable for flight, subject to the operating limitations in §4.1
and the closure actions in §4.3.** The dominant residual risks concern evidence maturity rather
than the physical result: validation testing is in progress, and two parameters require Platform
Owner confirmation before the analysis envelope can be formally shown to bound platform operation.

> **▣ PLACE FIGURE C-9 HERE (NEW ARTWORK REQUIRED)**
> **Content:** Risk matrix — 5×5 severity/likelihood heat map with risks CR-01 to CR-10 plotted, showing both current position and post-mitigation position (arrows from current to residual).
> **Caption:** *Figure C-9: Risk position before and after mitigation.*
> **Why here:** Immediately before the register. A single graphic that shows every risk moving into the acceptable region is the most effective way to communicate the overall position to a non-specialist reader at the customer.
> **Build note:** Use the programme's standard risk matrix format if one exists; otherwise a simple 5×5 grid. Do not invent severity definitions — align to the customer's or programme's existing scale.

### 3.2 Risk register

| ID | Risk | Impact if unmitigated | Mitigation in place / planned | Residual | Owner |
|---|---|---|---|---|---|
| **CR-01** | **Model validation testing not yet complete.** Component-level modal testing and engine-level ground vibration survey correlation are planned but not yet reported. The analysis-led, test-validated argument depends on them. | Predicted natural frequencies and damping could differ from hardware, shifting resonant response and the resulting alternating stresses. | Damping values already aligned to the validated engine-level model. Conservative 0.6 Goodman knockdown provides margin against modest frequency shift. Testing scheduled — see §4.3 A-1. Interim limitations L-1, L-2 apply. Vibration monitoring per M-1 provides in-service confirmation. | Medium | Design Organisation |
| **CR-02** | **Maximum flight diversion time not yet fixed.** CS-E 525 substantiation duration is a function of the maximum expected diversion time, which derives from platform concept of operations. | The demonstrated windmilling duration may not bound intended platform operation. | **Requires Platform Owner input** — see §5.1. Analysis sweep to be confirmed as covering the agreed time with margin. Interim limitation L-3 applies. | Medium | Platform Owner / Design Organisation |
| **CR-03** | **Windmilling fatigue life margin to be finalised.** The numeric life and margin will be restated on completion of validation testing and confirmation of diversion time. | Quantified margin unavailable for independent review. | Result is positive and passes on current inputs. Final figure to be issued with the validated analysis — see §4.3 A-2. | Medium | Design Organisation |
| **CR-04** | **Platform flight envelope coverage.** Load case coverage is to be confirmed against the intended platform flight envelope, including manoeuvre conditions. | Envelope conditions outside the assessed set would be unsubstantiated. | **Requires Platform Owner input** — see §5.1. Interim limitation L-4 applies. | Medium | Platform Owner / Design Organisation |
| **CR-05** | **Configuration applicability.** The analysis applies to a defined part, drawing and revision standard; the flight article must be confirmed against it. | Analysis may not represent the as-built article. | Configuration verification per L-5 before each sortie until formally closed. Any concession or deviation on the HPCC or its flange interfaces triggers re-assessment. | Low | Design Organisation / Configuration Management |
| **CR-06** | **Fastener and bolted-joint integrity is outside this assessment,** covered in a separate strength assessment report. Flange joints carry the modelled load path. | Joint integrity unconfirmed for these load cases. | Confirm the separate report exists and covers the same load cases and interfaces — see §4.3 A-4. Inspection action M-3 applies in the interim. | Low | Design Organisation |
| **CR-07** | **Blade-tip rub and part-to-part contact effects are excluded** from this analysis, being nonlinear and transient. Rub is an expected consequence of a CBO event. | Structural feedback of rub on the casing not captured. | Blade-release and containment behaviour is assessed in the separate Compressor Stator Parts Containment Analysis Report. Confirm rub effects are bounded there — see §4.3 A-5. | Low | Design Organisation |
| **CR-08** | **Substitute fatigue material data.** Full fatigue properties for the primary casing material are not yet in the approved database; properties of a chemically and mechanically similar alloy, assessed by the Materials organisation as more limiting, are used for all fatigue assessments. | If the substitute is not conservative at all temperatures, fatigue margins would be overstated. | Substitution assessed as conservative by the Materials organisation. Comparison to be formally cited — see §4.3 A-6. | Low | Materials / Design Organisation |
| **CR-09** | **Local peak stress confirmation.** A high local peak is present in the steady-state hot-day stress field. Its treatment — geometric singularity versus genuine local yield — is to be confirmed. | If genuine, the linear-elastic assumption would be locally violated. | Method already provides for nonlinear inertia relief at points where local stress exceeds yield. Confirmation in progress — see §4.3 A-7. | Low | Design Organisation |
| **CR-10** | **Analysis tool qualification records** for in-house post-processing and life-assessment tools to be attached. | Tool output not independently evidenced. | Tools developed under an AS9100-certified quality management system; qualification conducted per RTCA DO-178C / DO-330 principles. Records to be attached — see §4.3 A-8. | Low | Analysis Methods |

### 3.3 Assessment

Risks **CR-01 to CR-04** are the significant set and share a common character: the physical result
is favourable, but the evidence that formally bounds it is still being assembled. Two of the four
(**CR-02**, **CR-04**) cannot be closed by the Design Organisation alone and require Platform Owner
input.

**CR-05 to CR-10** are containable through the actions in §4.3 and, in the interim, the inspection
regime in §4.2.

No risk in this register is assessed as precluding flight under the limitations in §4.1.

---

## 4 LİMİTASYON VE BAKIM AKSİYONLARI — *LIMITATIONS AND MAINTENANCE ACTIONS*

### 4.1 Operating limitations

Recommended for incorporation into the flight clearance conditions. Each limitation is interim and
lifts when its associated risk closes.

| # | Limitation | Addresses | Lifts on closure of |
|---|---|---|---|
| **L-1** | Operation restricted to the vibration envelope for which out-of-balance loads have been validated. No operation above the Limit OoB 1× envelope. | CR-01 | A-1 |
| **L-2** | Engine vibration alert thresholds to be active and monitored throughout flight. Any exceedance terminates the sortie and triggers M-5. | CR-01 | Permanent |
| **L-3** | Until the maximum diversion time is agreed, sortie profiles to be planned such that post-shutdown windmilling duration cannot exceed the analysed sweep — in practice, operation within a defined radius of a suitable landing site. | CR-02, CR-03 | A-2, A-3 |
| **L-4** | No deliberate manoeuvre loading beyond conditions already cleared, pending confirmation of load case coverage against the platform envelope. | CR-04 | A-9 |
| **L-5** | Flight article HPCC configuration to be verified against the analysed build standard prior to flight. Any concession or deviation on the HPCC or its flange interfaces requires re-assessment before flight. | CR-05 | A-10 |
| **L-6** | Engine anti-ice and acceleration bleed to be operated within the normal control schedule. Unused LP interstage bleed ports to be confirmed capped. | CR-09 | Permanent |

> **▣ PLACE TABLE C-5 HERE**
> **Content:** The limitations table above, formatted to the customer's flight-limitation document convention if one exists.
> **Caption:** *Table C-5: Recommended operating limitations.*
> **Note:** If the Platform Owner maintains a master limitations register, cross-reference their IDs in an added column rather than issuing standalone numbering.

### 4.2 Maintenance and inspection actions

| # | Action | Interval / trigger | Rationale |
|---|---|---|---|
| **M-1** | Record and trend engine vibration level (1×N1) each sortie. Investigate any step change. | Every flight | The fatigue case is driven by out-of-balance level. Drift indicates rotor unbalance growth beyond the analysed envelope. Also accumulates in-service evidence supporting CR-01 closure. |
| **M-2** | Borescope inspection of the compressor module, with attention to the HPCC bore, flange radii and the bleed port region on the midcase. | Per engine maintenance manual, and after any vibration exceedance | Fatigue-critical regions. The bleed port is a geometric discontinuity in the load path. |
| **M-3** | Visual and torque check of HPCC flange bolted joints and rear mount bracket attachments. | Per maintenance manual, and after any out-of-balance or hard-landing event | Joint integrity is covered by a separate assessment (CR-06) while carrying the modelled load path. |
| **M-4** | Track accumulated windmilling time separately from engine running time. | Continuous | Windmilling exposure is a life-consuming parameter under the CS-E 525 case. |
| **M-5** | **Following any CBO, blade release, or unbalance alert exceedance: ground the engine.** Do not return to service on the basis of this analysis. Full strip, HPCC dimensional and NDT inspection, and engineering disposition required. | Any such event | The analysis demonstrates survival *for the duration of a diversion*, not continued airworthiness afterwards. A significant residual stress field is present after CBO run-down. |
| **M-6** | Retain ground-run vibration survey data and review against predicted natural frequencies. | Each ground run | Directly accumulates evidence retiring CR-01. |

> **▣ PLACE FIGURE C-10 HERE (NEW ARTWORK — OPTIONAL)**
> **Content:** Annotated HPCC view marking the inspection zones referenced in M-2 and M-3 — bore, flange radii, bleed port region, rear mount brackets.
> **Caption:** *Figure C-10: HPCC inspection zones.*
> **Why here:** Turns a text list into an actionable maintenance aid. Can be built by annotating the geometry from Figure C-2 or the source Figure 10 contour view with the contour removed.

### 4.3 Risk closure actions

| # | Action | Closes | Target |
|---|---|---|---|
| **A-1** | Complete and issue component modal testing and engine-level ground vibration survey correlation. | CR-01 | *(insert date)* |
| **A-2** | Confirm maximum diversion time and verify the analysed windmilling sweep bounds it with margin. | CR-02 | *(insert date — dependent on §5.1 input)* |
| **A-3** | Issue final quantified windmilling fatigue life and margin. | CR-03 | *(insert date — follows A-1, A-2)* |
| **A-4** | Confirm the fastener strength assessment covers these load cases and interfaces. | CR-06 | *(insert date)* |
| **A-5** | Confirm rub effects are bounded by the containment assessment. | CR-07 | *(insert date)* |
| **A-6** | Cite the formal materials comparison supporting the fatigue data substitution. | CR-08 | *(insert date)* |
| **A-7** | Confirm treatment of the local peak stress in the steady-state hot-day field. | CR-09 | *(insert date)* |
| **A-8** | Attach analysis tool qualification records. | CR-10 | *(insert date)* |
| **A-9** | Confirm load case coverage against the agreed platform flight envelope. | CR-04 | *(insert date — dependent on §5.1 input)* |
| **A-10** | Confirm flight article configuration against the analysed build standard. | CR-05 | *(insert date)* |

> **▣ PLACE FIGURE C-11 HERE (NEW ARTWORK RECOMMENDED)**
> **Content:** Risk closure timeline — horizontal bars for A-1 to A-10 against the programme schedule, with the flight date marked and dependencies shown (A-3 follows A-1 and A-2).
> **Caption:** *Figure C-11: Risk closure schedule against programme milestones.*
> **Why here:** Closes §4. This is typically the figure a customer programme office looks at first; it converts an open-risk position into a managed plan with dates.

---

## 5 DİĞER — *OTHER*

### 5.1 Input required from the Platform Owner

Three items cannot be closed by the Design Organisation alone:

| # | Input required | Needed for | Consequence if not provided |
|---|---|---|---|
| **I-1** | **Maximum expected flight diversion time**, derived from the platform concept of operations. | CS-E 525 windmilling duration (CR-02, action A-2) | Limitation L-3 remains in force, constraining sortie planning to a radius from a suitable landing site. |
| **I-2** | **Intended platform flight envelope**, including manoeuvre conditions. | Load case coverage confirmation (CR-04, action A-9) | Limitation L-4 remains in force, restricting deliberate manoeuvre loading. |
| **I-3** | **Confirmation of the applicable limitations register format** and any existing platform-level limitation IDs. | Integration of §4.1 into platform documentation | Limitations issued under Design Organisation numbering, requiring later reconciliation. |

### 5.2 Basis and validity

This assessment is based on the Compressor Stator Parts Continued Rotation Analysis Report and its
supporting references. It addresses the HPCC only. It does not cover:

- Blade release and containment — separate containment analysis report.
- Fastener and connecting hardware strength — separate strength assessment report.
- Overall engine vibration levels for CS-E 650 — separate vibration analysis report.

### 5.3 Definitions

| Term | Meaning |
|---|---|
| HPCC | High-Pressure Compressor Casing |
| OoB / Limit OoB | Out of Balance / Limit Out of Balance — highest permissible service vibration level |
| CBO | Core Blade Off |
| MoS | Margin of Safety |
| MSUP | Mode Superposition |
| HCF | High Cycle Fatigue |
| Goodman diagram | Alternating-versus-mean-stress plot defining the fatigue endurance boundary |

### 5.4 Items to resolve internally before issue

**These are not for the customer.** Remove this section before issue.

| # | Item | Action |
|---|---|---|
| **X-1** | The margin-of-safety formula for life in §6.4 of the source report is written as MoS = (1 − Calculated Life / Allowed Life) × 100, which is positive when calculated life is *less* than required — the inverse of the stated intent. | **Blocking.** Resolve and confirm which convention the life-assessment tool output uses **before any margin figure is quoted externally**. |
| **X-2** | Table 8 of the source records "Infinite Life Predicted" for the Windmilling case; §6.4.2 and the conclusions describe a finite-life calculation with positive margin. | **Blocking for Table C-3.** Reconcile before issue. |
| **X-3** | Source §6.4 refers to "four primary load cases"; two are defined. | Confirm whether cases were removed from an earlier scope. Feeds CR-04. |
| **X-4** | Source sections 6.2.5 and 6.2.6 are identical in heading and body. | Determine intended content of 6.2.6. |
| **X-5** | Source report is an unapproved draft with unresolved cross-references, `XXX` placeholders and empty reference entries. | Issue a controlled revision before this report cites it as its evidence base. |
| **X-6** | Source describes the substitute fatigue alloy as "nickel-based superalloy" while naming a titanium designation. | Correct in the source before A-6 closes. |
| **X-7** | Analysis solved in one ANSYS version and post-processed in another. | Confirm result interpretation consistency; note in the analysis report if intentional. |

### 5.5 Pre-issue checklist

- [ ] **X-1 and X-2 resolved** — no margin figure or summary table issued until confirmed.
- [ ] Section **5.4 removed**.
- [ ] All `▣ PLACE` blocks removed and artwork embedded.
- [ ] All `XXX` and `*(insert date)*` placeholders populated.
- [ ] Contour plot legends re-rendered without internal solver metadata.
- [ ] Internal part names and interface IDs in Figure C-2 screened for IP and customer naming alignment.
- [ ] Redacted identifiers (`██`) reviewed — the Platform Owner may be entitled to engine and programme designations that were redacted in the working copy.
- [ ] Export control and commercial classification applied to the header.
- [ ] Technical check and independent review completed and recorded.
- [ ] Document number, revision and approval signatures applied.

### 5.6 Figure and Table Plan

Consolidated build list. **Reuse** = existing artwork from the Continued Rotation Analysis Report.
**New** = artwork to be created.

| Ref | Section | Type | Source | Status | Notes |
|---|---|---|---|---|---|
| Figure C-1 | §1 | Reuse | Figure 3 — Compressor Module cross-section | Ready | Annotate HPCC. Alternative: Figure 2 |
| Figure C-2 | §2.2 | Reuse | Figure 4 — FE model, part names and interfaces | Screen first | IP screening on internal labels |
| Table C-1 | §2.3 | Reuse | Table 6 — Load case summary | Edit first | Remove `XXX` in duration cell |
| Figure C-3 | §2.3 | Reuse | Figure 5 — LOoB input loads | Ready | Pair with C-4 |
| Figure C-4 | §2.3 | Reuse | Figure 9 — Windmilling input loads | Ready | Pair with C-3 |
| Table C-2 | §2.4 | Reuse | Table 5 — Analysis assumptions | Ready | Optional; recommended |
| Figure C-5 | §2.5 | Reuse | Figure 7 — LOoB alternating stress | Re-render | Clean legend |
| Figure C-6 | §2.5 | Reuse | Figure 8 — LOoB Goodman | Ready | |
| Figure C-7 | §2.5 | Reuse | Figure 11 — Windmilling alternating stress | Re-render | Clean legend |
| Figure C-8 | §2.5 | Reuse | Figure 12 — Windmilling Goodman | Ready | |
| — | §2.5 | Reuse | Figure 10 — Residual stress after CBO run-down | Optional | Include if explaining M-5 |
| Table C-3 | §2.5 | Reuse | Table 8 — Summary of margins | **Blocked** | Hold pending X-2 |
| Table C-4 | §2.6 | Reuse | Table 1 — Responsibility matrix | Ready | Optional; recommended |
| Figure C-9 | §3.1 | **New** | Risk matrix, current vs. residual | To create | Use programme standard scale |
| Table C-5 | §4.1 | New format | Limitations table | Ready | Align to customer register format |
| Figure C-10 | §4.2 | **New** | HPCC inspection zones, annotated | Optional | Build from C-2 geometry |
| Figure C-11 | §4.3 | **New** | Risk closure timeline | Recommended | Show A-3 dependency on A-1, A-2 |

**Not carried across from the source report:** Figure 1 (3D engine view — redacted, and not needed
for this argument), Figure 6 (hot-day mean stress — supports CR-09 discussion but the peak value
invites questions better answered once A-7 closes), Table 2, Table 3 (Means of Compliance matrices
— internal certification planning, and Table 3 contains unresolved cross-references), Table 4
(analysis tools — internal), Table 7 (material allowables — proprietary; withhold unless the
customer's data rights explicitly cover material property data).

### 5.7 Review record

| Item | Status |
|---|---|
| Prepared | 2026-08-02 |
| Technical check | *(to be completed)* |
| Independent review | *(to be completed)* |
| Design Organisation approval | *(to be completed)* |
| Issued to Platform Owner | *(to be completed)* |

# HPCC Continued Rotation — Risk and Mitigation Report for Flight Clearance

**Status: working draft — engineering support material, not a compliance statement.**

| Field | Value |
|---|---|
| Subject part | High-Pressure Compressor Casing (HPCC) |
| Subject platform | Light utility general-purpose helicopter, ██ turboshaft engine |
| Purpose | Risk and mitigation assessment supporting flight clearance / Permit to Fly |
| Evidence base | `Compressor Stator Parts Continued Rotation Analysis Report.docx` (draft) |
| Evidence route | [Transcript](compressor-stator-parts-continued-rotation-analysis-report.md) reconstructed from screen photographs, 2026-08-01 |
| Certification basis referenced | EASA CS-E Amdt. 7 — CS-E 650, CS-E 525, AMC E 520(c)(2) |
| Date | 2026-08-02 |

> **Scope of validity.** Every statement below is derived from the transcribed draft only. The
> source document is unissued and unapproved, carries unresolved placeholders, and was read from
> photographs with programme identifiers redacted. Nothing here has been checked against the
> native `.docx`, the FE model, or the referenced test reports. Confirm against source before any
> use in a clearance package.

---

## 1 AMAÇ — *OBJECTIVE*

To assess whether the structural evidence available for the HPCC under sustained out-of-balance
and continued-rotation conditions is sufficient to support flight of the platform, and to define
the risks, mitigations and operating limitations that apply if flight proceeds on the current
evidence base.

The underlying analysis substantiates the HPCC against two regulatory requirements:

- **CS-E 650 (Vibration Surveys)** — freedom from harmful vibration at the highest permissible
  service vibration level (Limit Out-of-Balance).
- **CS-E 525 (Continued Rotation)** — no unacceptable effect from continued rotation after an
  in-flight shutdown following a Core Blade Off (CBO) event.

This report does **not** re-perform or re-validate that analysis. It takes the analysis at face
value and asks a narrower question: *what could make its conclusions wrong or inapplicable to the
platform that is about to fly, and what do we do about it?*

---

## 2 YAPILAN ÇALIŞMANIN ÖZETİ — *SUMMARY OF WORK PERFORMED*

### 2.1 Analysis performed in the source report

| Aspect | Content |
|---|---|
| Method | Linear FEA, Mode Superposition (MSUP) harmonic response, ANSYS Mechanical 19.2 (solve) / 2023R2 (post) |
| Model | "██ GEO7, C108 Compressor Module, Maneuver Model" — HPCC as part of interest; DSW and mounting lugs retained only to apply interface loads and represent interface stiffness |
| Mesh | Predominantly hexahedral; second-order tetrahedra in geometrically complex regions |
| Load application | Remote Point Connections, Distributed formulation, at bearing/interface locations — avoids artificial stiffness |
| Joints | Bonded around bolted-joint frustum; frictional elsewhere on flanges |
| Damping | Rayleigh (α mass, β stiffness), values consistent with the validated engine-level model |
| Nonlinearity | Nonlinear inertia relief applied only at critical time/frequency points where local stress exceeds yield |
| Fatigue | Two-tier: (1) Goodman infinite-life screening with a 0.6 knockdown on all curves; (2) TLIFE finite-life, NASALIFE principles, Walker mean-stress model, Miner's rule |
| Material | Ti6242 TMS01-030887 for strength; **TMS616 substituted for all fatigue properties** |
| Load source | Engine-level forces/moments/accelerations supplied by Engine Dynamics as *validated data* under AMC E 520(c)(2); their derivation is explicitly out of scope |

### 2.2 Load cases and results claimed

| Load case | Condition | Analysis | Result claimed |
|---|---|---|---|
| Limit OoB | Highest permissible vibration in normal operation, worst-case balanced rotor | Harmonic response, 1×N1 sweep over full operating range | Infinite fatigue life — Pass |
| Windmilling | Continued rotation on aerodynamic forces after in-flight shutdown with blade-out unbalance | Harmonic response + nonlinear IR where local stress > yield, 1×N1 sweep over `XXX` operating range | Positive MoS on life — Pass |

Reported peak stresses: **976.62 MPa** von Mises mean stress (Hot Day steady state, Figure 6) and
**675.18 MPa** mean stress residual after CBO run-down (Figure 10). Alternating stress under LOoB
peaks at **83.13 MPa** at 475.58 Hz (Figure 7).

### 2.3 Division of responsibility

Per Table 1 of the source, the **Engine Dynamics Team** is Accountable and Responsible for deriving
and validating CBO and other OoB loads and for validating the engine-level dynamic model. The
**Module Design Team** owns the HPCC component FEM, the structural analysis and the compliance
report. This split is the mechanism by which the report relies on AMC E 520(c)(2) validated data —
and it is therefore the mechanism by which upstream load errors would propagate into the HPCC
conclusions unchecked.

### 2.4 Work performed for this assessment

The transcript was reviewed line by line against the two regulatory claims, and every placeholder,
internal inconsistency, scope exclusion and unevidenced assertion was extracted and classified by
its effect on flight risk. Fourteen items were retained. No new analysis was performed.

---

## 3 SONUÇ VE DEĞERLENDİRME — *CONCLUSION AND ASSESSMENT*

### 3.1 Headline assessment

**The technical result is favourable; the evidence chain supporting it is not yet closed.**

Both load cases pass with positive margins, the method is appropriate and conservatively framed,
and the load path reasoning is sound. However, the report's own compliance strategy is described as
*"analysis-led, test-validated"* — and the test half of that pair is not yet in place. The
references that carry model validation (`[11]`, `[12]`, internal refs #12 and #13) are Turkish
placeholders for vibration and modal testing still to be performed. Until those exist, the pass
results rest on an unvalidated model.

Accordingly: **flight is supportable on a risk-managed basis with the limitations in §4**, but the
current evidence should not be cited as showing compliance with CS-E 650 or CS-E 525.

### 3.2 Risk register

Classification is a working engineering judgement for this assessment, not a formal programme risk
score. *Impact* is the consequence if the risk is real; *confidence* is how sure we are that the
evidence gap exists.

| ID | Risk | Impact | Confidence | Mitigation | Owner |
|---|---|---|---|---|---|
| **R-01** | **Model validation evidence does not yet exist.** Refs [11]/[12] (modal, mode shape, hammer test, ground vibration survey) are placeholders. The AMC E 520(c)(2) validated-data claim and the entire compliance strategy depend on them. | High | High | Complete and issue component modal + engine-level GVS correlation before flight. If not achievable, fly under R-01 restrictions in §4.1 and treat all margins as provisional. | Module Design / Engine Dynamics |
| **R-02** | **Windmilling life result is self-contradictory.** Table 8 records "Infinite Life Predicted"; §6.4.2 and conclusion item 2 describe a finite-life calculation with positive MoS on life; Table 6 sets the criterion as "calculated life must exceed required life". The actual CS-E 525 margin is therefore unquantified. | High | High | Resolve which result is correct and state the numeric life and margin. If finite, the margin is duration-dependent and R-03 becomes binding. | Module Design |
| **R-03** | **Maximum diversion time is undefined** (`XXX hr` in Table 3; `XXX operating range` in Table 6). CS-E 525 compliance is a function of windmilling duration, so the demonstrated envelope cannot be compared to the intended operation. | High | High | Fix the diversion time from the platform CONOPS and confirm the analysed sweep covers it with margin. Until fixed, impose the diversion limitation in §4.1. | Certification / Module Design |
| **R-04** | **Margin-of-safety formula for life is inverted.** §6.4 defines MoS<sub>Life</sub> = (1 − Calculated Life / Allowed Life) × 100, which is positive when calculated life is *less* than allowed. The intent (Table 6) is the opposite. A "positive MoS on life" quoted against this formula is unconservative if taken literally. | High | High | Correct to MoS<sub>Life</sub> = (Calculated Life / Required Life − 1) × 100 and re-state the reported margin. Verify which convention the TLIFE output actually uses. | Module Design |
| **R-05** | **Hardware configuration is not pinned.** Scope is defined as `[_PART_NO_] / [_DRW_NO_] / [_REV_]`. The clearance cannot be tied to a build standard, so applicability to the as-built flight article is unverifiable. | High | High | Populate part/drawing/revision and confirm against the flight-article build record and any concessions. | Configuration Management |
| **R-06** | **Report is an unapproved draft.** Broken Word cross-references (`Hata! Başvuru kaynağı bulunamadı.`), `XXX` placeholders throughout Table 3 evidence links, §5.2 references "Section ." with no number, §3.3 Procedures empty. | High | High | Do not cite as compliance evidence. Issue a controlled revision with cross-references resolved before any certification submittal. | Module Design |
| **R-07** | **Fatigue material substitution is unevidenced.** TMS616 fatigue properties used in place of TMS01-030887; the "more limiting" justification is attributed to the TEI Material Team but no reference is cited. The same sentence calls TMS616 a "nickel-based superalloy" while naming it Ti6242, indicating the material basis text is unreviewed. | Medium | High | Obtain and cite the Material Team comparison. Confirm the substitution is conservative across the full temperature range in Table 7, not only at room temperature. | Materials / Module Design |
| **R-08** | **Hot Day steady-state peak exceeds A-basis yield at every tabulated temperature.** Figure 6 reports Max 976.62 MPa against a Table 7 yield of 826.4 MPa at 25 °C falling to 443.7 MPa at 500 °C — yet §6.2.3 asserts stresses are "well below the yield stresses". If this peak is not a discounted singularity, the linear-elastic assumption is violated where it matters. | Medium | Medium | Confirm the peak location, whether it is a mesh/contact singularity, and whether the §6.2.2 nonlinear inertia-relief trigger was applied there. Report the assessed (de-singularised) value. | Module Design |
| **R-09** | **In-house tool qualification is not evidenced.** TLIFE, MSUP Transient-Post and WE Mechload Viewer are cited via placeholder TG numbers (#4–#6). DO-178C / DO-330 qualification is claimed in §6.3.1 but not demonstrated. | Medium | High | Attach tool qualification records, or independently verify a sample of TLIFE life results by hand calculation. | Analysis Methods |
| **R-10** | **Load-case count discrepancy.** §6.4 states "four primary load cases"; §6.2.7 and Table 6 define two. The FE model is named "**Maneuver** Model" but no manoeuvre load case is reported. Cases may have been dropped from an earlier scope without the text being updated. | Medium | High | Confirm whether manoeuvre and any other OoB cases were assessed elsewhere, or are genuinely absent. If absent, assess coverage against the platform flight envelope. | Module Design |
| **R-11** | **Bolted joints and fasteners are out of scope** (§6.2.4), deferred to a strength report whose number is still a placeholder (#17). Flange joints carry the OoB load path modelled here. | Medium | High | Confirm the fastener strength report exists and covers the same load cases and interfaces before flight. | Module Design |
| **R-12** | **Contact effects, part-to-part rub and large deformation are excluded.** Blade-tip rub during CBO run-down and windmilling is a physically expected consequence of the very event being analysed. | Medium | High | Confirm rub is bounded by the containment assessment (TR-144357, ref #16) and that its structural feed-back on the casing is either negligible or covered. | Module Design |
| **R-13** | **No strength margin is presented for Limit OoB.** §6.4.1 omits stress contour and strength MoS on the grounds that LOoB stresses are much lower than CBO stresses — a comparative argument, not a demonstrated margin. | Low–Medium | High | Add the LOoB strength MoS, or record the comparative argument formally with the supporting numbers. | Module Design |
| **R-14** | **Duplicate section 6.2.5 / 6.2.6**, identical heading and body. Symptomatic of incomplete review; one of the two may have been intended to hold different conditions that are now missing. | Low | High | Determine what §6.2.6 was intended to contain. | Module Design |

### 3.3 Aggregate judgement

Risks **R-01 through R-06** are the flight-critical set. R-01, R-02 and R-03 together mean the
CS-E 525 continued-rotation margin is currently *unquantified against an undefined duration using
an unvalidated model*. That is the controlling concern. R-04 compounds it, because the one number
that would resolve R-02 may have been computed with an inverted sign convention.

R-05 and R-06 are administrative rather than physical, but they are the reason this evidence cannot
be presented as compliance regardless of how favourable the physics turns out to be.

The remaining items are containable through the limitations and actions in §4.

---

## 4 LİMİTASYON VE BAKIM AKSİYONLARI — *LIMITATIONS AND MAINTENANCE ACTIONS*

### 4.1 Operating limitations proposed for flight

Proposed for incorporation into the flight clearance / Permit to Fly conditions. Each traces to a
risk in §3.2.

| # | Limitation | Traces to |
|---|---|---|
| L-1 | Flight only within the vibration envelope for which OoB loads were validated. No operation above the Limit OoB 1× envelope of Table 6. | R-01 |
| L-2 | Vibration alert thresholds supplied by Engine Dynamics to be active and monitored for the whole flight. Any exceedance terminates the sortie. | R-01, R-10 |
| L-3 | Until the diversion time is fixed (R-03), restrict sorties to a profile in which post-shutdown windmilling duration cannot exceed the analysed sweep. Practically: remain within a defined radius of a suitable landing site. | R-03, R-02 |
| L-4 | No deliberate manoeuvre loading beyond that already cleared elsewhere, pending resolution of the manoeuvre load-case gap. | R-10 |
| L-5 | Flight article configuration to be verified against the analysed standard before each sortie until R-05 is closed. Any concession or deviation on the HPCC or its flange interfaces requires re-assessment. | R-05 |
| L-6 | Engine anti-ice and acceleration bleed operated within normal schedule; unused LP interstage bleed ports confirmed capped per §4.2.1. | R-08 |

### 4.2 Maintenance and inspection actions

| # | Action | Interval / trigger | Rationale |
|---|---|---|---|
| M-1 | Record and trend engine vibration levels (1×N1) each sortie. Investigate any step change. | Every flight | The whole fatigue case is driven by OoB level; drift indicates rotor unbalance growth beyond the analysed envelope. |
| M-2 | Borescope inspection of the compressor module, with attention to the HPCC bore, flange radii and PVA port region. | Per engine maintenance manual, plus after any vibration exceedance | Fatigue-critical regions; PVA port at 6 o'clock on the midcase is a geometric discontinuity in the load path. |
| M-3 | Visual and torque check of HPCC flange bolted joints and rear mount bracket attachments. | Per manual, plus after any OoB or hard-landing event | Joint integrity is explicitly out of the analysis scope (R-11) while carrying the modelled load path. |
| M-4 | Track accumulated windmilling time separately from engine running time. | Continuous | If R-02 resolves as finite life, accumulated windmilling exposure becomes a life-limiting parameter. |
| M-5 | **Post-CBO or post-unbalance-event action:** ground the engine. Do not return to service on the strength of this analysis. Full strip, HPCC dimensional and NDT inspection, and engineering disposition. | Any CBO, blade release, or unbalance alert exceedance | The residual stress field after CBO run-down peaks at 675 MPa (Figure 10); the analysis demonstrates survival for a diversion, not continued airworthiness afterwards. |
| M-6 | Retain and review vibration survey data against the FE-predicted natural frequencies as validation evidence accumulates. | Each ground run | Directly retires R-01 through accumulated in-service correlation. |

### 4.3 Analysis-side actions to retire risk

| # | Action | Closes | Priority |
|---|---|---|---|
| A-1 | Complete and issue component modal / hammer testing and engine-level GVS correlation reports (refs [11], [12]). | R-01 | Before flight if achievable |
| A-2 | Resolve the windmilling life contradiction and publish the numeric life and margin. | R-02 | Before flight |
| A-3 | Fix maximum diversion time from platform CONOPS; confirm the analysed sweep covers it. | R-03 | Before flight |
| A-4 | Correct the MoS<sub>Life</sub> formula and re-state the margin against the corrected convention. | R-04 | Before flight |
| A-5 | Populate part number / drawing / revision and reconcile with the flight-article build record. | R-05 | Before flight |
| A-6 | Issue a controlled revision with all cross-references and `XXX` placeholders resolved. | R-06 | Before certification submittal |
| A-7 | Obtain and cite the TMS616 / TMS01-030887 conservatism comparison; correct the alloy-family description. | R-07 | Before certification submittal |
| A-8 | Confirm treatment of the 976.62 MPa Hot Day peak — singularity or genuine yield exceedance. | R-08 | Before flight |
| A-9 | Attach tool qualification records for TLIFE and MSUP Transient-Post, or hand-verify a sample. | R-09 | Before certification submittal |
| A-10 | Confirm status of manoeuvre and any other omitted load cases. | R-10 | Before flight |
| A-11 | Confirm the fastener strength report exists and covers these load cases. | R-11 | Before flight |
| A-12 | Confirm rub effects are bounded by TR-144357. | R-12 | Before certification submittal |

---

## 5 DİĞER — *OTHER*

### 5.1 Assumptions made in producing this report

1. **Flight clearance context assumed.** The request specified a platform going to flight; this is
   written for a Permit to Fly / flight-test clearance rather than full type certification. If the
   target is type certification, the "before certification submittal" items in §4.3 become
   blocking rather than deferrable.
2. **Transcript treated as faithful.** Where the source is internally inconsistent, both readings
   are carried rather than one being chosen.
3. **No access to referenced documents.** Refs [7], [11], [12], [14], [15], [16], [17] and
   TR-144357 were not available. Several risks would likely downgrade if those documents close the
   gaps.
4. **Redacted identifiers.** Programme, company and engine names are `██` throughout; the report
   cannot confirm the analysed engine is the flight engine.

### 5.2 What would most change this assessment

Sight of the **validation reports (refs [11], [12])** and a **single numeric windmilling life
margin against a defined diversion time**. Those two items alone retire R-01, R-02 and R-03 — the
entire flight-critical set except configuration control.

### 5.3 Related documents

| Document | Relationship |
|---|---|
| [Continued Rotation Analysis Report transcript](compressor-stator-parts-continued-rotation-analysis-report.md) | Sole evidence base for this assessment |
| TR-144357, Compressor Stator Parts Containment Analysis Report | Covers blade-release containment, excluded from the source analysis |
| `[#17]` Compressor Stator Parts Strength Analysis Report | Covers bolts and connecting hardware — number not yet assigned |
| `[#13]` Vibration analysis report | Carries CS-E 650 overall vibration levels — not yet written |
| FAA AC 33.74/92-1b | Continued rotation and rotor locking guidance, cited as ref #23 |
| EASA CM-S-014 (Proposed), Modelling & Simulation | Relevant to R-01 and R-09 — model credibility and tool qualification |

### 5.4 Review record

| Item | Status |
|---|---|
| Prepared | 2026-08-02, from transcript only |
| Technical check against source `.docx` | **Not performed** |
| Independent review | **Not performed** |
| Approval | **Not approved** |

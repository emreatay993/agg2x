# Compressor Mid-Case Static Loading Validation — Risk and Mitigation Report

**Programme Office edition.**
**Prepared by the Design Organisation for issue to the Platform Owner Programme Office.**

| Field | Value |
|---|---|
| Subject part | Compressor Mid-Case (TS9 Midcase, GM-3.1 standard), Compressor Module |
| Platform | Light utility general-purpose helicopter |
| Engine | ██ turboshaft |
| Subject | Structural risk arising from the maturity and domain of the validated finite element model used for compressor mid-case substantiation |
| Certification basis | EASA CS-E Amdt. 7 — CS-E 100, CS-E 640 |
| Supporting evidence | EX100 Compressor Midcase — Static Loading Test Report (TR-068830/02); Static Loading Test vs FEA correlation presentation |
| Validation roadmap | TG-00004984 — Compressor Case Validation, Static Loading Tests |
| Test phase | **Phase-I of a three-phase validation roadmap** (Phase-0 complete; Phase-II certification testing not yet performed) |
| Programme milestone | *(to be completed — e.g. first flight readiness review)* |
| Next review date | *(to be completed)* |
| Document status | *(to be completed on issue)* |
| Classification / handling | *(to be completed — see §5.5)* |
| Date | 2026-08-03 |

> **Companion document.** A technical edition of this report is available for the Platform Owner's
> airworthiness function. It carries the same risk register and the same conclusions, with fuller
> treatment of test method, model detail and results. This edition prioritises risk position,
> closure schedule and required inputs.

---

## 0 ÖZET — *EXECUTIVE SUMMARY*

| Question | Answer |
|---|---|
| **What was tested?** | A full-scale compressor mid-case in a static loading rig, under five load cases up to and including scaled blade-out, with 168 strain channels and 9 displacement transducers. |
| **Did the part pass?** | **Yes, physically.** One mid-case survived the entire campaign — limit, ultimate, 32 bar overpressure and two blade-out cases, one reaching **142 % of raw WE blade-out load** — with **no permanent deformation**. |
| **What was this test actually for?** | To demonstrate that the finite element method used for structural substantiation predicts this structure correctly. The flight clearance rests on that model; this campaign establishes how far it can be relied upon. |
| **How accurate is the model?** | Displacement within **13.1 %** at ultimate load (criterion: 20 %). Plain-wall stress within approximately **±14 %**. Twenty gauges in one block agreed within ±13.9 %; eighteen in another within ±13.2 %. |
| **How confident should we be in that?** | **The ultimate case was an independent re-test** — rig fully rebuilt, new dummy legs, repaired instrumentation, model parameters fixed beforehand and not re-tuned. The correlation *improved*. That is blind-prediction evidence, not curve-fitting. |
| **Is it cleared for flight?** | Yes, subject to four interim limitations (§4.1) and the maintenance regime in §4.2. |
| **What is the residual risk?** | Acceptable. No open risk is assessed as precluding flight. Four risks are Medium; one is Low; none is High. |
| **What drives the residual risk?** | **Coverage of the evidence, not the quality of the correlation or the integrity of the part.** Both of the latter were demonstrated directly. |
| **Anything we should know?** | Yes, and it is disclosed openly in §2.9. Phase-2 modelling found interfaces missing from the Phase-I model which **relocate the critical region to the PVA boss radii**. The Phase-I load set is superseded. This report therefore presents Phase-I as **method validation, not load-case substantiation**. |
| **What do you need from us?** | Three inputs — see §5.1. Two of them (**operating envelope**, **knockdown convention**) sit on the critical path. |
| **When does it close?** | Five actions tracked in §4.3, with dependencies in §4.4. Phase-II certification testing (A-5) is the terminal milestone. |

> **▣ PLACE FIGURE S-10 HERE (repeated from §3.1)**
> **Content:** Validated domain diagram — what this campaign proved, and what remains.
> **Why here:** For a programme office reader this is the whole report in one picture. It answers "what did we buy with this test campaign, and what is still outstanding" before any technical content. Repeat the same graphic in §3.1 rather than creating a second version.

> **▣ PLACE FIGURE S-11 HERE (repeated from §3.1)**
> **Content:** Risk matrix — current versus post-mitigation position.
> **Why here:** Programme office readers expect the risk position on the first page. Repeat, do not duplicate.

> **▣ PLACE FIGURE S-13 HERE (repeated from §4.4)**
> **Content:** Risk closure timeline against programme milestones.
> **Why here:** Completes the "where are we, and when does it close" pairing. Repeat, do not duplicate.

---

### How to use the placement markers in this document

Blocks marked **`▣ PLACE …`** tell whoever assembles the issued document what artwork or table
belongs at that point, where it comes from, and what caption to use. Sources are cited by **frame
number and filename** from the transcription (`presentation-transcription.md`) so the original
artwork can be located directly. A consolidated list is given in **§5.6 Figure and Table Plan**.
Remove all `▣` blocks once the artwork is embedded.

---

## 1 AMAÇ — *OBJECTIVE*

This report states the structural risk position arising from the **Phase-I static loading validation
campaign** on the compressor mid-case, identifies the mitigations in place, and defines the operating
limitations and maintenance actions recommended for the platform.

**What this report is about.** The flight clearance for the compressor mid-case rests on finite
element structural substantiation. A finite element model is admissible evidence only to the extent
that its predictive accuracy has been demonstrated against measurement. This campaign is that
demonstration. Accordingly, this report addresses a specific question:

> **To what extent, and within what domain, may the compressor mid-case finite element model be
> relied upon as substantiation evidence for flight?**

The campaign **demonstrated the physical robustness of the mid-case** and **established a quantified
accuracy for the finite element method**, confirmed under an independent rig rebuild. Both results
are favourable. The residual risks concern **what the evidence covers** — not the integrity of the
part, and not the quality of the correlation.

**What this report is not.** This is not itself a compliance demonstration against CS-E. It is the
validation evidence that licenses the substantiation reports which make those demonstrations. It
does not cover blade containment, fastener strength, or the thermal and pressure-loaded operating
condition, each addressed separately — see §5.2.

**One point of scope is stated up front.** Phase-2 modelling has since identified interfaces absent
from the Phase-I model which relocate the critical region of the mid-case. The Phase-I load set is
therefore superseded, and this report presents the campaign as **validation of the method**, not as
substantiation of the load cases it happened to apply. §2.9 sets this out in full.

This report identifies **three items requiring Platform Owner input** (see §5.1).

> **▣ PLACE FIGURE S-1 HERE**
> **Source:** Frame 003 / `20260802_205442.jpg` — the paired rig images at the top right of the *Test Plan – Phase 1* slide (grey CAD render of the full rig, plus the colour photograph of the installed rig in the test cell).
> **Caption:** *Figure S-1: Compressor mid-case static loading test rig — analysis model and installed hardware.*
> **Why here:** Orients the reader to the physical campaign before any discussion of method. The CAD/photograph pair immediately communicates that this is a full-scale physical test, not a paper exercise — which is the single most reassuring thing a non-specialist reader can be shown on page one.
> **Layout:** Side by side, CAD left, photograph right. Crop the photograph to remove the safety fencing and adjacent test-cell equipment.

---

## 2 YAPILAN ÇALIŞMANIN ÖZETİ — *SUMMARY OF WORK PERFORMED*

### 2.1 How this campaign supports the flight clearance

The compliance argument for the compressor mid-case is *analysis-led and test-validated*. The chain
of reasoning is:

| Step | Statement |
|---|---|
| 1 | Structural substantiation of the mid-case is performed by finite element analysis. |
| 2 | Finite element results are admissible as substantiation evidence only where predictive accuracy has been demonstrated by measurement. |
| 3 | This campaign measures displacement and strain on the physical article under controlled applied loads, and compares them against the same model used for substantiation. |
| 4 | The comparison establishes **(a)** a quantified accuracy band, and **(b)** the domain over which that band applies. |
| 5 | Within the domain, the model carries substantiation with the stated accuracy. Outside it, other means of compliance apply. |

**The purpose of this report is to state (a) and (b) precisely, and to identify the risks attaching
to each.**

The campaign follows the validation roadmap in **TG-00004984**, which defines three phases:

| Phase | Geometry | Material | Loads | Status |
|---|---|---|---|---|
| **Phase-0** | GM-2.1 | Inco-718 | C107 | **Complete.** Established test/analysis compatibility and surfaced test application difficulties. |
| **Phase-I** | **GM-3.1** | **Ti 6.2-4.2** | **C108** | **Complete — this report.** Static loading for strength evaluation and analysis validation. |
| **Phase-II** | Final | Ti 6.2-4.2 | — | **Not yet performed.** Engine certification testing. |

> **▣ PLACE FIGURE S-2 HERE**
> **Source:** Frame 003 / `20260802_205442.jpg` — the campaign flowchart in the lower right of the *Test Plan – Phase 1* slide.
> **Caption:** *Figure S-2: Validation campaign logic — parallel static and thermal correlation branches converging on a validated analysis model.*
> **Why here:** **This is the most important figure in the report.** It shows the reader that the campaign is a structured validation process with defined pass gates and explicit iterate-or-accept decisions, not a one-off test. It also makes visible that this report covers only the *left branch* (Static Test vs FEA); the thermal branch (TS9/2) is separate and outstanding — which is the honest framing of §3.2 risk **SL-01**.
> **Annotation required:** Mark the "Static Test vs FEA" branch as the scope of this report, and shade the "TS9/2 Test vs FEA" branch as outside it. The source figure does not distinguish them.

### 2.2 Analysis model

The model is a full representation of the test rig, not the mid-case in isolation, so that the
measured response includes the real stiffness of every load-path element.

| Aspect | Content |
|---|---|
| Scope | Complete rig assembly: ground block, front gimbal and pedestal, piston load adapter, mount legs with pins and spherical bearings, combustor casing dummy, torque tube / FBS dummy and intermediate flanges, and the mid-case |
| Mid-case model | 171 bodies, **325,239 nodes, 236,084 elements**, first-order hexahedral mesh, mass 5.1095 kg |
| Mid-case material | **Ti6242 TMS01-030887 forging, solution and precipitation heat treated**, non-linear (elastic-plastic) definition |
| Strain gauges | Modelled as **discrete meshed bodies with their own material**, capturing the local stiffening and strain-averaging effect of the gauge backing |
| Fixture idealisation | Welded fabrications converted to midsurface shell with node-merged weld lines; connectivity verified by edge/body connectivity plots |
| Joints | Gimbal represented by four revolute joints (2 rotational DOF); spherical plain bearings modelled explicitly with separate inner and outer races and frictional contact |
| Friction | **COF = 0.2 throughout**, except the rear-mount ball bearings, calibrated against measurement — see §2.5 |
| Load introduction | Seven rigid remote points, one per actuator, each with its own local coordinate system |

> **▣ PLACE FIGURE S-3 HERE**
> **Source:** Frame 029 / `20260802_205715.jpg` — the shaded CAD assembly render on the *Model Details – Subassemblies* slide, with the twelve-entry colour legend at the left.
> **Caption:** *Figure S-3: Finite element model of the test rig, showing all modelled subassemblies.*
> **Why here:** Establishes that the whole load path is modelled. A reader who has just been told the result depends on the model needs to see what "the model" means.
> **Edit required:** The source legend carries internal body-prefix codes (`AA3`, `AE3`, `BM4`, `CI4`…). Replace with plain part names before issue.
> **Optional addition:** Frame 030 / `20260802_205719.jpg` (materials view) if the customer requires evidence of material assignment.

### 2.3 Acceptance criteria

The campaign was judged against criteria fixed in advance. These are the criteria against which
every result in §2.6 is assessed.

| Measurement | Successful | Acceptable |
|---|---|---|
| **Displacement (LVDT)** | error < 10 % | error < 20 % |
| **Stress — low-stress region (< 20 MPa)** | error < 20 % | error < 30 % |
| **Stress — medium and high-stress region (> 20 MPa)** | error < 10 % | error < 20 % |
| **Absolute stress tolerance band** | **2–5 MPa**, depending on load case | |

> **▣ PLACE TABLE S-1 HERE**
> **Source:** Frame 003 / `20260802_205442.jpg` — the numbered acceptance criteria list in the left half of the *Test Plan – Phase 1* slide.
> **Caption:** *Table S-1: Test success criteria, fixed before test.*
> **Why here:** Criteria must be visible before results. That they were set in advance, and are two-tier rather than pass/fail, evidences a considered validation strategy.
> **Edit required:** The source slide prints the medium/high-stress category bound as "< 20 MPa", which given the preceding low-stress category is a typo for "> 20 MPa". Correct before issue.

### 2.4 Load cases

Five load cases were applied to a single physical mid-case, in sequence, with **fluorescent penetrant
inspection (FPI) between every case**.

| LC | Case | Applied Fy (N) | Character |
|---|---|---|---|
| **1** | Maneuver Limit | 4 528.6 | Limit manoeuvre external loads |
| **2** | Maneuver Ultimate | 10 189.5 | Ultimate manoeuvre external loads |
| **3** | Overpressure (PVA port) | **32 Bar** | Deliberate run-to-failure to locate the pressure-critical feature |
| **4** | Blade-out | 53 358.8 | Scaled blade-out, vertical |
| **5** | Blade-out horizontal | 75 460.8 | Scaled blade-out, horizontal — highest load of the campaign |

**Load scaling and its limits.** Applied loads incorporate a compensation factor (**CF = 1.71** for
manoeuvre, **CF = 1.58** for blade-out) derived per **TG-00005107**, which scales room-temperature
load so that the room-temperature reserve factor matches the hot reserve factor.

> **This is a material limitation and is stated plainly:** the compensation factor is used to obtain
> a usable signal-to-noise ratio with a defensible physical basis for the scaling magnitude. **It is
> not a demonstration of hot operating equivalence.** External piston loads cannot reproduce the
> internal pressure staging or the thermally-driven radial growth and local thermal constraint around
> the mounts that characterise the operating condition. This bounds the validation domain — see risk
> **SL-01**.

> **▣ PLACE TABLE S-2 HERE**
> **Source:** Frame 025 / `20260802_205652.jpg` — the applied load table (Load Case No / Name / Fy / Mx1 / Mx2 / My1 / My2 / Mz1 / Mz2).
> **Caption:** *Table S-2: Applied piston loads by load case.*
> **Why here:** Quantifies the test envelope. Include the full seven-actuator breakdown, not just Fy — it evidences that a multi-axis load state was applied, not a single-axis pull.
> **Optional addition:** the LC1→LC5 sequence flow with FPI between each case, from the lower right of the same frame. **Recommend including** — inspection between load cases is a strong process point.

> **▣ PLACE FIGURE S-4 HERE**
> **Source:** Frame 025 / `20260802_205652.jpg` — the ANSYS Mechanical view showing the seven red remote-point "spiders" on the rig model with their local coordinate triads.
> **Caption:** *Figure S-4: Load introduction via seven rigid remote points, each with a local coordinate system.*
> **Why here:** Evidences that loads were applied through defined, controlled interfaces rather than idealised point forces.
> **Edit required:** Source view carries the internal analysis name in its header block. Crop or re-render.

### 2.5 Instrumentation and model calibration

**Instrumentation.** 56 three-element 45° rectangular rosettes (**168 strain channels**) on the
mid-case, plus 6 gauges on the mount legs, and **9 LVDT displacement transducers** mounted on a
reference frame decoupled from the loaded structure. Gauge positions were determined per
**TG-00021914** and modelled per **TBP-110351**.

**Calibration.** Two parameters were calibrated against measurement rather than assumed:

| Parameter | Treatment | Basis |
|---|---|---|
| Ball-joint friction coefficient | **COF = 0.05** selected for manoeuvre cases (from a 0.05–0.15 trial range); **COF = 0.1** used for blade-out | Selected on best displacement agreement, then cross-checked against strain sign-agreement and R² linearity — both metrics independently favoured 0.05 |
| Gimbal bolt-to-hole clearance | **50 microns**, applied as a ramped contact offset | Represents real assembly tolerance |

> **This is declared, not concealed.** Two model parameters were tuned to the displacement data. The
> stress correlation in §2.6 is therefore **not fully independent** of the test it is compared
> against. The mitigation is that the tuned parameters are few, physically meaningful, and bounded by
> a narrow range — and that the stress agreement holds across gauges and load cases that played no
> part in the tuning. See risk **SL-04**.

> **▣ PLACE FIGURE S-5 HERE**
> **Source:** Two-part composite. Left: frame 017 / `20260802_205600.jpg` — the CAD layout with LVDT positions 1–9. Right: frame 011 / `20260802_205535.jpg` or frame 014 / `20260802_205547.jpg` — a photograph of the instrumented mid-case showing bonded rosettes with hand-numbered positions.
> **Caption:** *Figure S-5: Instrumentation — LVDT displacement transducer layout (left) and strain-gauge installation on the mid-case (right).*
> **Why here:** Shows instrumentation density. 168 strain channels on one part is a substantial measurement campaign and the figure should convey that.
> **Note:** The photographs carry hand-written gauge numbers in marker pen. This is normal test practice but may read as informal to a customer audience — consider the cleaner CAD gauge-map view from frame 080 / `20260802_210954.jpg` as an alternative or companion.

### 2.6 Results

Stress results are extracted as **`SEQV_at_max_external_load − SEQV_assembly`**, isolating the
increment due to external load. This matches what the gauges measure, since they were zeroed after
assembly.

#### Displacement — the primary structural response

| Load case | Result against criteria |
|---|---|
| **Maneuver Ultimate** | **All eight LVDT channels correlate within 13.1 %.** Five are "successful" (< 10 %): LVDT 1 (−0.4 %), 2 (+0.6 %), 3 (−8.5 %), 5 (+9.8 %), 6 (+9.6 %). Three are "acceptable" (< 20 %): LVDT 4 (+10.8 %), 7 (+13.1 %), 8 (+10.4 %). **No channel fails.** |
| **Maneuver Limit** | Mixed. Four of eight channels exceed the 20 % acceptable band. Absolute displacements are 0.056–0.910 mm, so large percentages correspond to small absolute differences. |
| **Blade-out** | Correlation is good up to the hardware failure events, then diverges — see §2.8. |

**The maneuver ultimate displacement result is the strongest single piece of validation evidence in
the campaign**, and the reason is not only the numbers.

**It is an independent re-test, not a repeat measurement.** Between the manoeuvre limit and manoeuvre
ultimate cases the rig was **completely disassembled and rebuilt**: new dummy mount legs were
fitted, damaged strain gauges were repaired or replaced, and the test was executed at a different
time, by a fresh setup, in different ambient conditions. Nothing was carried over except the
mid-case itself and the analysis model.

The model parameters had already been fixed on the manoeuvre limit data (§2.5). They were **not
re-tuned** for the ultimate case. Against that independently rebuilt configuration the model
predicted **all eight channels within 13.1 %** — a *better* result than the case it was calibrated
on.

> **This is blind-prediction evidence.** A model that is merely fitted to its calibration data does
> not improve when the hardware is rebuilt around it. That the correlation improved under an
> independent build is the strongest available indication that the model represents the structure
> rather than the particular test article assembly.

> **▣ PLACE TABLE S-3 HERE**
> **Source:** Frame 105 / `20260802_211309.jpg` — the maneuver ultimate LVDT table (Direction / LVDT No / Disp Test / Disp FEA COF .05 / Error %).
> **Caption:** *Table S-3: Displacement correlation, maneuver ultimate condition.*
> **Why here:** The headline validation result. Place it before the stress results — displacement is the more fundamental check of global model correctness.
> **Recommend:** add a colour band or tick column showing each channel against the < 10 % / < 20 % criteria. Every row passes; make that visible.

#### Stress — plain-wall response

| Evidence | Result |
|---|---|
| **Maneuver ultimate, 20-gauge circumferential block** | All twenty gauges (18.6–25.6 MPa) correlate within **±13.92 %**, with a tight and consistent bias near −10 % |
| **Blade-out horizontal, 18-gauge block** | Eighteen gauges spanning 54–250 MPa correlate within **±13.2 %**; **eleven within ±7 %**, including SG_23 at +0.18 %, SG_4 at −1.1 %, SG_14 at +2.03 % |
| **Maneuver limit, residual strain** | Maximum residual (FEA − test) across all 168 channels within **±40 µε**, equivalent to approximately **4 MPa** — inside the declared 2–5 MPa tolerance band |
| **Maneuver limit, threshold screening** | Applying a dual filter of peak error ≥ 30 % **and** absolute error ≥ 20 µε, only **8 of 168 channels (4.8 %)** fail both |
| **Highest measured stress** | SG_2 at **250.43 MPa** under blade-out horizontal, correlating at **−13.11 %** |

**Where the model correlates well, it does so consistently and across load cases.** The plain-wall
membrane response — which is what directly evidences the load path, applied load magnitudes and
overall stiffness — agrees to roughly ±14 % or better at every load level assessed.

> **▣ PLACE FIGURE S-6 HERE**
> **Source:** Frame 117 / `20260802_211427.jpg` or the magnified frame 118 / `20260802_211431.jpg` — the maneuver ultimate wide-sector contour with twenty labelled gauges.
> **Caption:** *Figure S-6: Stress correlation, maneuver ultimate — twenty gauges across a circumferential sector, all within ±13.9 %.*
> **Why here:** **The single most persuasive results figure available.** Twenty measurement points on one image, every one agreeing, is far more convincing than a table of the same numbers.
> **Edit required:** Source labels show test value and % difference in separate tags. Consider consolidating to one tag per gauge for legibility at print size. Re-render the legend without internal analysis metadata.

> **▣ PLACE FIGURE S-7 HERE**
> **Source:** Frame 155 / `20260802_212748.jpg` or the magnified frame 156 / `20260802_212756.jpg` — the blade-out horizontal view with eighteen labelled gauges.
> **Caption:** *Figure S-7: Stress correlation, blade-out horizontal — eighteen gauges from 54 to 250 MPa, sixteen within ±13.2 %.*
> **Why here:** Pairs with Figure S-6 to show correlation holding at the highest load of the campaign, across a wide stress range.
> **Note on rendering:** the stress contour for this case was lost to a data-handling fault, so the view is rendered on plain CAD. **The gauge annotations and the correlation percentages on it are unaffected** — they were extracted from the contour data before it was lost, and the underlying numerical results are retained. Present it as an annotated results view, not as a contour plot.

> **▣ PLACE TABLE S-4 HERE**
> **Source:** Appendix A of `presentation-transcription.md` — consolidated strain-gauge results, all 56 gauges × 4 load cases.
> **Caption:** *Table S-4: Consolidated strain-gauge correlation across all load cases.*
> **Why here:** Closes the results section with the complete data set, so the customer can see nothing has been selected out. **Recommend including as an appendix rather than in the body** — it is a large table and its value is completeness, not readability.
> **Edit required:** Mark the SG_14 blade-out entry as invalid (faulty gauge) and flag the blade-out horizontal columns as not assembly-subtracted.

### 2.7 Stress levels under the scaled test loads

**The applied loads are deliberately artificial and do not represent any operating condition.** As
stated in §2.4, the compensation factor (**CF 1.71** manoeuvre, **CF 1.58** blade-out) exists to lift
measured strain clear of the instrumentation noise floor, with a secondary allowance for the
stiffness difference between room and operating temperature. It carries no other physical meaning.

**It follows that reserve factors computed under these loads are not margins against anything.**
They cannot be read as strength margins for a real blade-out event, because no real blade-out event
applies these loads. Within the model they serve one purpose only: as a **diagnostic that locates
where stress concentrates**, so that instrumentation and future modelling effort can be directed
correctly.

Read strictly on that basis, the scaled blade-out case indicates local concentration at a mount-pad
hole edge and a rib/flange corner, against **B-basis** allowables for Ti6242 TMS01-030887 forging at
25 °C (yield 868.4 MPa, ultimate 953.5 MPa). Surrounding material sits two to fifteen times below
those levels, and the analysis characterises the indication as **local only**.

Two further points bound how much weight these indications carry:

1. The Phase-I model **does not include peripheral radii around boss regions** and uses a
   **first-order hexahedral mesh**. Both sharpen predicted peak stress at precisely the hole-edge and
   corner geometry where the indications appear, so the local values are expected to be pessimistic.
2. **Phase-2 analysis has since relocated the critical region entirely** — see §2.9. The Phase-I
   indications are superseded and are not the locations that will govern.

**The physically meaningful strength statement from this campaign is the observed one:** a single
mid-case carried limit and ultimate manoeuvre loading, a 32 bar overpressure excursion and two
blade-out cases — one reaching 142 % of raw WE blade-out load — with **no permanent deformation**
(§2.8).

> **▣ PLACE FIGURE S-8 HERE (OPTIONAL — see note)**
> **Source:** Frames 128 / `20260802_211626.jpg` (yield basis) and 129 / `20260802_211631.jpg` (ultimate basis) — the reserve factor contour views with their magnified detail and the "Local yield only" callouts.
> **Caption:** *Figure S-8: Stress concentration indicated under the artificially scaled blade-out load. Diagnostic only — the scaled load does not represent an operating condition.*
> **Why optional:** These plots invite a margin reading that the scaled loads cannot support, and the locations they highlight are superseded by the Phase-2 findings in §2.9. **Recommendation: omit from the issued document**, or include only if the customer's reviewer has specifically asked to see the Phase-I strength screening.
> **If included:** show the full-part view, never the detail crop alone, and carry the "diagnostic only" wording into the caption itself rather than relying on the body text.

### 2.8 Physical outcome and observed failures

**The mid-case.** A **single physical mid-case** was used for the entire campaign. It was not
replaced between load cases. It was subjected to limit and ultimate manoeuvre loading, a 32 bar
overpressure excursion, and two blade-out cases — one of which reached **142 % of raw WE blade-out
load** before a rig failure terminated it.

> **No permanent deformation was observed on the mid-case in any test.**

**Three failures occurred, all in rig hardware, and the model predicted each location:**

| Event | Load case | What happened | Model prediction |
|---|---|---|---|
| **PVA port gasket rupture** | LC3, 32 Bar | Gasket failed as intended. Root cause: spacing-to-diameter (S/D) ratio not met at the failed land. | Failure mode reproduced by the model. Test was a **deliberate run-to-failure** to locate the pressure-critical feature. |
| **Mount-leg ball joints seized** | LC4 Blade-out | Local plasticity at ≈ 450 s (95 % of raw WE load), major transient at ≈ 578.8 s (**142 % of raw WE load**). Post-test inspection confirmed seizure; bearing pins found bent with large runout. | Model independently predicted **7071.4 MPa** peak stress and **3.64 % plastic strain** in the bearing races — far beyond yield. |
| **Front dummy weld failure** | LC5 Blade-out horizontal | Flange-to-cone weld tore at ≈ 484.5 s, terminating the test. Root cause: **improper welding and missing weld calculations at DDR**. | Model predicted peak maximum principal stress at the same location and instant. |

**This is a favourable outcome, correctly stated.** The article under test survived every condition
applied to it. Every failure was in a sacrificial or fixture component, and in each case the model
identified the failure location — which is itself validation evidence, obtained the hard way.

**On the extent of usable blade-out data.** The mount-leg joints seized at approximately **142 % of
raw WE blade-out load**, so correlation is available **through and beyond 100 % of the unscaled
load** before the load path changed. Three points bound the significance of the divergence after
that instant:

- The seizure occurred under a **1.58-scaled** load. The joint would not be expected to encounter
  that level in service.
- The blade-out condition is a **dynamic** load applied here **statically**, and held. Under real
  dynamic magnitudes and durations the joint loading would be substantially less severe.
- The joints are **rig hardware**, not engine hardware. Their behaviour is not a characteristic of
  the mid-case or of its engine installation.

The data beyond seizure is therefore set aside as not representative, rather than treated as a
correlation shortfall. The same applies to the blade-out horizontal case after the dummy weld
failure.

> **▣ PLACE FIGURE S-9 HERE**
> **Source:** Composite of two. Left: frame 125 / `20260802_211541.jpg` — the post-test bearing inspection photographs (dye-penetrant marked races, bent pins). Right: frame 145 / `20260802_212023.jpg` — the front dummy weld failure photograph with its magnified crack detail and the adjacent FE maximum-principal-stress plot.
> **Caption:** *Figure S-9: Observed rig hardware failures and the corresponding finite element predictions.*
> **Why here:** Closes §2. Pairing each physical failure with the model's prediction of the same location is the most compelling demonstration of predictive capability in the entire data set. Present the photograph and the prediction side by side.
> **Presentation note:** Frame the caption around prediction, not failure — "the model identified these locations" rather than "these components failed". Both statements are true; the first is the one this section is evidencing.

### 2.9 Standing of this evidence in light of Phase-2 analysis

**This section defines what the Phase-I campaign should and should not be relied upon for.**

Subsequent Phase-2 modelling identified **interfaces not represented in the Phase-I model** which
have a **substantial effect on the mid-case stress field and on where the critical region falls**.
The consequence is significant and is stated plainly:

- Under **dynamic conditions** (blade-out and related), the critical location now falls
  predominantly around the **PVA boss radii** — the compressor bleed valve port on the mid-case.
- The same region is identified as critical under **windmilling** and certain **limit
  out-of-balance** conditions in the separate continued-rotation assessment, so the finding is
  corroborated from an independent analysis stream.
- The Phase-I load set is consequently **superseded**. The Phase-II load cases will differ
  substantially, and the Phase-I critical locations (mount-pad and rib/flange, §2.7) are not the
  locations that will govern.

**What this campaign therefore establishes:**

| Phase-I evidence supports | Phase-I evidence does not establish |
|---|---|
| That the modelling approach — rig representation, joint idealisation, contact treatment, gauge modelling — reproduces measured behaviour to a quantified accuracy | Substantiation of the current (Phase-II) load set |
| That the correlation process itself is sound, repeatable, and survives an independent rig rebuild (§2.6) | The stress field at the PVA boss radii, which the Phase-I model does not resolve |
| That the mid-case is physically robust well beyond limit and ultimate manoeuvre loading | Critical-location margins, which have moved |
| **Confidence that the organisation's finite element method predicts this structure correctly** | A decisive strength demonstration for certification |

**Read correctly, this is a capability demonstration.** Known loads were applied to both the physical
article and the model, and the two agreed to within a stated band across four load cases, two rig
builds and a 250 MPa stress range. That is what licenses the method to be relied upon when it is
applied to the revised Phase-II load set — which is exactly how validation evidence is intended to
function.

---

## 3 SONUÇ VE DEĞERLENDİRME — *CONCLUSION AND ASSESSMENT*

### 3.1 Overall position

**Three results, all favourable:**

1. **The mid-case is physically robust.** One article survived the full campaign — limit, ultimate,
   32 bar overpressure, and two blade-out cases including one to 142 % of raw WE load — with no
   permanent deformation.
2. **The finite element model reproduces measured behaviour to a quantified accuracy**, within
   approximately **±14 % on plain-wall stress** and **within 13.1 % on displacement at ultimate
   load**, against criteria of 20 % in both cases.
3. **That accuracy survived an independent rig rebuild.** The manoeuvre ultimate case was measured on
   a completely reassembled rig with new dummy legs and repaired instrumentation, using model
   parameters fixed beforehand on the earlier case. The correlation improved (§2.6).

**The validated domain is bounded as follows:**

| Dimension | Validated | Not established by this campaign |
|---|---|---|
| **Loading** | External mechanical loads applied through the mount and flange interfaces | Internal pressure staging; thermally-driven radial growth; local thermal constraint at mounts |
| **Temperature** | Room temperature | Operating temperature |
| **Stress field** | Plain-wall membrane response, moderate gradients | Steep local gradients at boss radii — including the PVA boss now identified as critical (§2.9) |
| **Load set** | The Phase-I (C108) load cases | The revised Phase-II load set, which differs substantially |

**Residual risk is assessed as acceptable for flight, subject to the operating limitations in §4.1
and the closure actions in §4.3.** The residual risks concern **what the evidence covers**, not the
integrity of the part or the quality of the correlation. Both of the latter were demonstrated
directly.

**Risk position at a glance:**

| | Count | Risk IDs | Character |
|---|---|---|---|
| **High** | 0 | — | — |
| **Medium** | 4 | SL-01 to SL-04 | Evidence coverage: thermal condition, revised load set, local geometry, quantified bias. All have defined closure actions. |
| **Low** | 1 | SL-05 | Phase-II sequencing. |
| **Precluding flight** | 0 | — | — |

**Of the four Medium risks, two (SL-01, SL-04) depend on Platform Owner input to close.** These are
the critical-path items — see §4.4 and §5.1.

**What the Programme Office should take from this section:** the campaign delivered what it was
commissioned to deliver, and it did so under an independent rig rebuild. **None of the five risks
arises from a failed test or a poor correlation.** Four concern the scope of what was covered; one
is the planned next roadmap phase. The most consequential — the Phase-2 interface finding (SL-02) —
was identified by our own analysis and is disclosed here deliberately.

> **▣ PLACE FIGURE S-10 HERE (NEW ARTWORK REQUIRED — HIGH VALUE — also repeated in §0)**
> **Content:** Validated domain diagram. A two-axis plot: horizontal axis "external mechanical load", vertical axis "thermal and pressure loading". Shade the region validated by this campaign (mechanical axis, room temperature) in green. Mark the operating condition as a point in the upper right, outside the shaded region, and label it "addressed by TS9/2 thermal correlation — outstanding". Overlay the tested load cases as points.
> **Caption:** *Figure S-10: Validation domain established by the Phase-I static loading campaign, and the conditions remaining to be addressed.*
> **Why here:** **This is the most valuable new artwork in the report and should be created even if nothing else is.** It converts the campaign's principal boundary — that the rig cannot reproduce operating thermal and pressure conditions — into a clear, deliberate statement of scope. Reviewers respond far better to a bounded domain stated up front than to a limitation discovered later in a risk register.
> **Build note:** Keep it schematic. Do not attempt quantitative axes — the point is the boundary, not the coordinates.

> **▣ PLACE FIGURE S-11 HERE (NEW ARTWORK REQUIRED — also repeated in §0)**
> **Content:** Risk matrix — 5×5 severity/likelihood heat map with risks SL-01 to SL-05 plotted, showing both current and post-mitigation position (arrows from current to residual).
> **Caption:** *Figure S-11: Risk position before and after mitigation.*
> **Why here:** Immediately before the register, and repeated in the executive summary.
> **Build note:** Use the programme's standard risk matrix format if one exists. Do not invent severity definitions — align to the customer's or programme's existing scale.
> **Recommended annotation for this edition:** colour or outline the two Platform-Owner-dependent risks (**SL-01**, **SL-04**) distinctly, so the customer can see at a glance which risks sit with them. With only five risks the matrix will be sparse — that is the message, and it should not be padded.

### 3.2 Risk register

| ID | Risk | Impact if unmitigated | Mitigation in place / planned | Residual | Owner |
|---|---|---|---|---|---|
| **SL-01** | **Validation domain does not include the thermal and pressure operating condition.** The rig applies external mechanical loads at room temperature. It cannot reproduce internal pressure staging, nor thermally-driven radial growth and local thermal constraint around the mounts. | Substantiation of the operating condition would rest on a model whose accuracy is demonstrated only for mechanical loading at room temperature. | The boundary is explicit in the campaign definition, not discovered after the fact. The parallel **TS9/2 thermal stress correlation branch** of the validation roadmap addresses this condition — see Figure S-2. Mechanical validation remains valid for the mechanical load path. Closure action **A-1**. Interim limitation **L-1** applies. | **Medium** | Design Organisation |
| **SL-02** | **Phase-I load set is superseded.** Phase-2 modelling identified interfaces not represented in the Phase-I model which materially change the mid-case stress field and relocate the critical region to the **PVA boss radii** (§2.9). | Phase-I correlation could be relied upon as substantiation of load cases and critical locations that no longer govern. | Identified by the Design Organisation's own Phase-2 analysis, and independently corroborated by the continued-rotation assessment which flags the same region under windmilling and limit out-of-balance conditions. Phase-I evidence is presented in this report as **method validation, not load-case substantiation** (§2.9). Re-baselining against the Phase-2 interface definition is action **A-2**. | **Medium** | Design Organisation |
| **SL-03** | **Boss peripheral radii are not modelled in the Phase-I model,** and the Phase-2 critical location falls at exactly such a feature (PVA boss radii). | The model as validated does not resolve the geometry that now governs, so the correlation band established here does not transfer to the critical location. | The omission is a documented, deliberate global-model simplification with submodelling identified from the outset as the remedy. Modelling the boss radii and submodelling the critical location is action **A-4**, and is required input to Phase-II regardless of this report. | **Medium** | Design Organisation |
| **SL-04** | **Systematic under-prediction.** FEA under-predicts measured plain-wall stress by approximately **10 %**, consistently across gauges and manoeuvre load cases. | Substantiation using this model would be non-conservative by that margin unless accounted for. | The bias is consistent, well characterised, and of known probable origin (first-order hexahedral mesh; modelled gauge backing stiffness). A **quantified knockdown factor** is to be established and applied to substantiation results — action **A-3**. Until then, limitation **L-2** applies. | **Medium** | Design Organisation |
| **SL-05** | **Phase-II certification testing not yet performed.** Current evidence is Phase-I only, on the GM-3.1 geometry standard and the superseded C108 load set. | Validation applies to the Phase-I article and load set, not the certification standard. | Phase-I is an explicit, planned stage of the roadmap in TG-00004984, not an incomplete substitute for Phase-II. Configuration applicability is controlled by limitation **L-3**. Phase-II execution is action **A-5**, and its scope already incorporates the Phase-2 interface findings and the pressure-stiffened configuration described in §4.3. | Low | Design Organisation |

### 3.3 Assessment

All five risks concern **the coverage of the evidence**, not the quality of the correlation or the
integrity of the part. This distinction is the substance of the assessment:

- **What was measured, correlated well.** Four load cases, two independent rig builds, a 250 MPa
  stress range, and displacement agreement inside 13.1 % at ultimate load.
- **What the part experienced, it survived.** No permanent deformation under any applied condition,
  including 142 % of raw WE blade-out load.
- **What remains is scope.** The thermal and pressure condition (SL-01), the revised load set
  (SL-02), the geometry at the new critical location (SL-03), a quantified bias correction (SL-04),
  and the Phase-II campaign itself (SL-05).

**No risk in this register is assessed as precluding flight under the limitations in §4.1.**

Risks **SL-02** and **SL-03** are linked and are best read together: the critical region has moved to
a feature the Phase-I model did not resolve. Both are addressed by the same Phase-II modelling work
(**A-2**, **A-4**), and neither reflects an error in the Phase-I correlation — which remains valid
for what it measured.

---

## 4 LİMİTASYON VE BAKIM AKSİYONLARI — *LIMITATIONS AND MAINTENANCE ACTIONS*

### 4.1 Operating limitations

Recommended for incorporation into the flight clearance conditions. Each limitation is interim and
lifts when its associated risk closes.

| # | Limitation | Addresses | Lifts on closure of |
|---|---|---|---|
| **L-1** | Structural substantiation of the compressor mid-case for **thermal and pressure-loaded operating conditions** shall not be based on this validation alone. Mechanical-load substantiation may rely on it within the domain stated in §3.1. | SL-01 | A-1 |
| **L-2** | Substantiation results derived from this model shall carry the **stress knockdown factor** established under A-3. Until A-3 completes, an interim knockdown of not less than **1.15** shall be applied to plain-wall stress results. | SL-04 | A-3 |
| **L-3** | Flight article mid-case configuration to be verified against the **GM-3.1 analysed build standard** prior to flight. Any concession or deviation on the mid-case, its mount pads or its flange interfaces requires re-assessment before flight. | SL-05 | A-5 |
| **L-4** | Engine vibration and out-of-balance alert thresholds to be active and monitored throughout flight. Any exceedance terminates the sortie and triggers M-3. | — | Permanent |

> **▣ PLACE TABLE S-5 HERE**
> **Content:** The limitations table above, formatted to the customer's flight-limitation document convention if one exists.
> **Caption:** *Table S-5: Recommended operating limitations.*
> **Note:** If the Platform Owner maintains a master limitations register, cross-reference their IDs in an added column rather than issuing standalone numbering.

### 4.2 Maintenance and inspection actions

| # | Action | Interval / trigger | Rationale |
|---|---|---|---|
| **M-1** | Borescope inspection of the compressor module, with attention to the **PVA port region** and boss radii, mount pads and flange radii on the mid-case. | Per engine maintenance manual, and after any out-of-balance exceedance | The PVA boss radii are the critical location identified by Phase-2 analysis (§2.9) and are independently flagged in the continued-rotation assessment. They are also the geometry the Phase-I model does not resolve. |
| **M-2** | Visual and torque check of mid-case flange bolted joints and rear mount leg attachments. | Per maintenance manual, and after any out-of-balance or hard-landing event | The mount interfaces carry the modelled load path into the casing. |
| **M-3** | Record and trend engine vibration level each sortie. Investigate any step change. | Every flight | Provides in-service confirmation that operation remains within the mechanically validated envelope. |
| **M-4** | **Following any blade-release, out-of-balance alert exceedance, or hard landing: ground the engine.** Do not return to service on the basis of this validation. Full strip, mid-case dimensional and NDT inspection, and engineering disposition required. | Any such event | This validation demonstrates survival of the article under controlled applied loads. It does not evidence continued airworthiness after an unbalance event. |
| **M-5** | Retain and review any ground-run or engine-test strain and displacement data against the validated model predictions. | Each ground run and engine test | Accumulates in-service evidence that extends the validated domain toward the operating condition, supporting closure of SL-01 and SL-04. |

> **▣ PLACE FIGURE S-12 HERE (NEW ARTWORK — RECOMMENDED)**
> **Content:** Annotated mid-case view marking the inspection zones referenced in M-1 and M-2 — **PVA port and boss radii**, mount pads, flange radii and mount leg attachments.
> **Caption:** *Figure S-12: Mid-case inspection zones.*
> **Why here:** Turns a text list into an actionable maintenance aid, and visually links the inspection regime to the critical location identified in §2.9.
> **Build note:** Can be built by annotating the geometry from frame 076 / `20260802_210927.jpg` (the clean mid-case CAD render) with the contour removed. Mark the PVA boss prominently — it is the location this report most wants the reader to retain.

### 4.3 Risk closure actions

| # | Action | Closes | Target |
|---|---|---|---|
| **A-1** | Complete and issue the **TS9/2 thermal stress correlation** branch of the validation roadmap, extending the validated domain to the thermal condition. | SL-01 | *(insert date)* |
| **A-2** | Re-baseline the validated load set against the **Phase-2 interface definition**, and confirm which Phase-I correlation evidence transfers to the revised load cases. | SL-02 | *(insert date)* |
| **A-3** | Establish and issue the **quantified stress knockdown factor** derived from the observed systematic bias, for application to all substantiation results using this model. | SL-04 | *(insert date)* |
| **A-4** | Model boss peripheral radii — **the PVA boss in particular** — and submodel the Phase-2 critical location with second-order mesh, re-establishing local stress and margins. | SL-03 | *(insert date)* |
| **A-5** | Execute **Phase-II certification testing** on the final geometry standard and the revised load set. Scope to include the pressure-stiffened configuration described below. | SL-05 | *(insert date)* |

**Phase-II pressure testing — planned scope.** The Phase-I overpressure excursion (LC3) was run to
locate the pressure-critical feature and applied pressures well beyond anything the joint would see
in service. Phase-II takes a different and more representative approach: the **static load
configuration will be run with internal pressure applied**, so that the **pressure-stiffened
behaviour of the part** is captured rather than mechanical loading alone. To sustain pressure for
that configuration, the PVA port gasket interface will be **welded shut and/or fitted with
additional leakage-prevention measures**, removing the gasket as a limiting feature of the test
rather than of the design.

### 4.4 Critical path and dependencies

| Action | Depends on | Blocks | Owner |
|---|---|---|---|
| **A-1** TS9/2 thermal correlation | Test slot availability; **Input I-1 from Platform Owner** to scope the condition | Lifting of **L-1**; extension of the validated domain to the operating condition | Joint |
| **A-2** Re-baseline load set to Phase-2 interfaces | Phase-2 model release | A-4, A-5 | Design Organisation |
| **A-3** Establish stress knockdown factor | **Input I-2 from Platform Owner** on the acceptable convention | Lifting of **L-2**; all substantiation results using this model | Joint |
| **A-4** Model boss radii and submodel the critical location | A-2 | A-5 | Design Organisation |
| **A-5** Phase-II certification testing | A-1, A-2, A-4 | Lifting of **L-3**; certification credit | Design Organisation |

**Critical path:** `A-2 → A-4 → A-5`, with `I-1 → A-1` running in parallel and also feeding A-5.
The two Platform Owner inputs sit on the A-1 and A-3 branches.

**What gates flight versus what gates certification:**

| | Actions | Effect if incomplete |
|---|---|---|
| **Does not gate flight** | A-2, A-4 | Interim limitations remain; no operational restriction beyond §4.1 |
| **Gates lifting of limitations** | A-1 (L-1), A-3 (L-2), A-5 (L-3) | Flight proceeds under the limitation; the constraint is on declared margins and substantiation scope, not on airworthiness |
| **Gates certification credit** | A-5, dependent on A-1, A-2, A-4 | Phase-II is a planned roadmap stage, not recovery work |

**The Programme Office should note:** none of the five actions is rework arising from a test failure
of the subject part. Three (A-2, A-4, A-5) are the natural consequence of the Phase-2 interface
finding and would be required regardless of this report. Two (A-1, A-3) extend and calibrate the
validation.

> **▣ PLACE FIGURE S-13 HERE (NEW ARTWORK REQUIRED — also repeated in §0)**
> **Content:** Risk closure timeline — horizontal bars for A-1 to A-5 against the programme schedule, with the flight date and Phase-II certification milestone marked, the critical path highlighted, and dependencies shown (A-4 follows A-2; A-5 follows A-1, A-2 and A-4).
> **Caption:** *Figure S-13: Risk closure schedule against programme milestones.*
> **Why here:** Closes §4, and repeated in the executive summary. This converts an open-risk position into a managed plan with dates, and is typically the first thing a programme office looks for.
> **Recommended annotation for this edition:** mark the two Platform Owner input gates (**I-1**, **I-2**) as distinct milestones, so the customer can see the effect of their response date on the closure schedule. Mark which limitation lifts at each action's completion, and distinguish flight-gating from certification-gating actions per the table above.

---


## 5 DİĞER — *OTHER*

### 5.1 Input required from the Platform Owner

Three items cannot be closed by the Design Organisation alone. **Two of them sit on the critical
path** (§4.4).

| # | Input required | Needed for | Critical path | Consequence if not provided | Response required by |
|---|---|---|---|---|---|
| **I-1** | **Confirmation of the intended operating envelope** — pressure and temperature conditions the mid-case will experience in platform service. | Defining the gap between the validated domain (§3.1) and the operating condition, and scoping the TS9/2 thermal correlation (**A-1**). | **Yes** | The validated domain cannot be shown to bound platform operation. Limitation **L-1** remains in force, restricting the scope of substantiation this model can carry. | *(insert date — drives A-1 start)* |
| **I-2** | **Agreement on the acceptable knockdown convention** for substantiation results derived from a validated-with-bias model. | Establishing the knockdown factor under **A-3** in a form the Platform Owner's airworthiness function will accept. | **Yes** | The interim **1.15** knockdown under **L-2** remains. This is conservative and may constrain declared margins unnecessarily — the cost of not answering falls on the Platform Owner's own margins. | *(insert date — drives A-3 completion)* |
| **I-3** | **Confirmation of the applicable limitations register format** and any existing platform-level limitation IDs. | Integration of §4.1 into platform documentation. | No | Limitations issued under Design Organisation numbering, requiring later reconciliation. | *(insert date)* |

**Effect of delay.** Each week of delay on **I-1** moves the TS9/2 thermal correlation, and therefore
Phase-II certification testing, by the same amount. **I-2** does not delay flight but directly
determines how much declared margin the Platform Owner carries in the interim.

### 5.2 Basis and validity

This assessment is based on the EX100 Compressor Midcase Static Loading Test Report
(**TR-068830/02**) and the Static Loading Test vs FEA correlation presentation, transcribed in full
at `presentation-transcription.md`. It addresses the compressor mid-case only. It does not cover:

- **Thermal and pressure operating conditions** — TS9/2 thermal stress correlation, outstanding.
- **Blade release and containment** — separate containment analysis.
- **Fastener and connecting hardware strength** — separate strength assessment.
- **Continued rotation and sustained out-of-balance** — separate Continued Rotation Analysis Report
  and its associated risk and mitigation report.

### 5.3 Definitions

| Term | Meaning |
|---|---|
| CF | Compensation Factor — scaling applied to room-temperature load so the room-temperature reserve factor matches the hot reserve factor |
| WE | Worst Event — the reference blade-out load condition |
| LVDT | Linear Variable Differential Transformer — displacement transducer |
| SG | Strain Gauge; here, three-element 45° rectangular rosettes (three channels per gauge) |
| SEQV | Equivalent (von Mises) stress |
| FPI | Fluorescent Penetrant Inspection |
| B-basis | Statistical material allowable — 90 % of the population equalled or exceeded, 95 % confidence |
| DDR | Design Definition Review |
| S/D ratio | Spacing-to-diameter ratio of a gasket land around its bolt holes |
| Validated domain | The range of loading, temperature and structural conditions over which model accuracy has been demonstrated by measurement |

### 5.4 Items to resolve internally before issue

**These are not for the customer.** Remove this section before issue.

| # | Item | Action |
|---|---|---|
| **X-1** | The source presentation carries the marking **"ŞİRKET HASSAS"** (company confidential) on multiple slides. | **Blocking.** Confirm the classification that applies to derived material and to any artwork reused from it, before issue. |
| **X-2** | The source uses anonymised placeholders **"CustomerCompany"** and **"MyCompany"**. | Confirm whether real organisation names are to be restored for this customer, or whether the anonymisation is deliberate and must be preserved. |
| **X-3** | Reserve factors below 1.0 under the CF-scaled blade-out load appear in the source presentation. §2.7 now frames these as diagnostic indications under an artificial load, not as margins, and recommends **omitting Figure S-8** from the issued document. | Confirm the Design Organisation agrees with both the framing and the omission. If a reviewer later requests the Phase-I strength screening, it should be supplied with the §2.7 wording attached, not as a standalone plot. |
| **X-4** | The interim knockdown of **1.15** in limitation **L-2** is proposed by this report on the basis of the observed ~10 % bias plus margin. | **Blocking.** Confirm this value is endorsed by the responsible stress authority. Do not issue a numeric knockdown the organisation has not formally adopted. |
| **X-5** | **Strain-gauge positioning accuracy — internal lessons learned, deliberately not raised to the customer.** Positional error was approximately **1–2 mm** in the manoeuvre load cases, where gauges were applied carefully. It grew in the later cases, attributed to **schedule pressure on the test campaign** leading to more hurried application. The `Translate_Orient_SG 56` transform in the blade-out horizontal analysis corrects 50 of 56 positions. | **Not a customer-facing item and not to be carried to the Platform Owner by the Programme Office.** Action is internal: build gauge-position verification and sign-off into the Phase-II test readiness process, and protect gauge application time in the Phase-II schedule. Record in the Phase-I lessons-learned log. |
| **X-6** | Gauge SG_14 blade-out vertical percentage is recorded as **8.45231e+11 %** — a divide-by-zero artefact from a faulty gauge. | Ensure this value is excluded from any table issued. It appears in Appendix A of the transcription and must be flagged there. |
| **X-7** | The presentation's own acceptance-criteria slide contains a typo ("< 20 MPa" for the medium/high stress category). | Correct in the source before this report's Table S-1 cites it. |
| **X-8** | Phase-I test article is GM-3.1; certification standard is "final geometry" per TG-00004984. | Confirm the configuration delta between GM-3.1 and the certification standard. Feeds **SL-05** and **L-3**. |
| **X-9** | §2.9 discloses that Phase-2 analysis found interfaces missing from the Phase-I model, relocating the critical region to the PVA boss radii. | Confirm the Design Organisation is content to disclose this to the Platform Owner. **Recommendation: yes.** It was found by our own analysis, it is corroborated independently by the continued-rotation work, and disclosing it now is far better than the customer discovering later that Phase-I evidence had been superseded. It also sets correct expectations for what Phase-I substantiates. |

### 5.5 Pre-issue checklist

- [ ] **X-1, X-4 resolved** — classification confirmed, knockdown value endorsed by the stress authority.
- [ ] **X-9 confirmed** — disclosure of the Phase-2 interface finding (§2.9) agreed.
- [ ] **X-5 confirmed as withheld** — gauge-positioning lessons learned are internal and must not reach the Platform Owner.
- [ ] Section **5.4 removed**.
- [ ] All `▣ PLACE` blocks removed and artwork embedded.
- [ ] All `*(insert date)*` placeholders populated.
- [ ] Contour plot legends re-rendered without internal analysis names and solver metadata.
- [ ] Internal body-prefix codes (`AA3`, `AE3`, `BM4`…) removed from Figure S-3 legend.
- [ ] Hand-written gauge numbers in instrumentation photographs reviewed for legibility and professionalism at print size.
- [ ] Redacted identifiers (`██`) reviewed — the Platform Owner may be entitled to engine and programme designations redacted in the working copy.
- [ ] Figure S-8 omitted per §2.7 recommendation, or included with the "diagnostic only" caption wording.
- [ ] Export control and commercial classification applied to the header.
- [ ] Technical check and independent review completed and recorded.
- [ ] Document number, revision and approval signatures applied.

### 5.6 Figure and Table Plan

Consolidated build list. **Reuse** = artwork exists in the source presentation, cited by frame.
**New** = artwork to be created.

| Ref | Section | Type | Source | Status | Notes |
|---|---|---|---|---|---|
| Figure S-1 | §1 | Reuse | Frame 003 — rig CAD + installed photograph | Ready | Crop photograph; place side by side |
| Figure S-2 | §2.1 | Reuse | Frame 003 — campaign flowchart | **Annotate first** | Mark static branch as in scope, thermal branch as outstanding |
| Figure S-3 | §2.2 | Reuse | Frame 029 — FE model subassemblies | **Edit first** | Replace internal body-prefix codes with plain part names |
| Table S-1 | §2.3 | Reuse | Frame 003 — acceptance criteria | **Edit first** | Correct "< 20 MPa" typo in medium/high category |
| Table S-2 | §2.4 | Reuse | Frame 025 — applied load table | Ready | Include all seven actuator channels; add LC sequence with FPI |
| Figure S-4 | §2.4 | Reuse | Frame 025 — remote point load introduction | Re-render | Remove internal analysis name from header |
| Figure S-5 | §2.5 | Reuse | Frames 017 + 011/014 — LVDT layout and SG installation | Review | Consider frame 080 CAD gauge map as cleaner alternative |
| Table S-3 | §2.6 | Reuse | Frame 105 — maneuver ultimate LVDT table | Ready | Add pass-criteria column; every row passes |
| Figure S-6 | §2.6 | Reuse | Frame 117 / 118 — 20-gauge correlation | Re-render | **Highest-value results figure.** Consolidate paired labels |
| Figure S-7 | §2.6 | Reuse | Frame 155 / 156 — 18-gauge blade-out horizontal | Ready | Annotated results view, not a contour — see §2.6 note |
| Table S-4 | Appendix | Reuse | Transcription Appendix A | Edit first | Flag SG_14 invalid (faulty gauge) |
| Figure S-8 | §2.7 | Reuse | Frames 128 + 129 — reserve factor screening | **Omit — recommended** | Invites a margin reading the scaled loads cannot support; locations superseded by §2.9 |
| Figure S-9 | §2.8 | Reuse | Frames 125 + 145 — failure photographs with FE predictions | Ready | Caption framed around prediction, not failure |
| Figure S-10 | §0, §3.1 | **New** | `figures/figure-S-10-validated-domain.svg` | **Built** | Update accuracy figures after A-2; edit SVG text directly. **Repeated in §0** |
| Figure S-11 | §0, §3.1 | **New** | Risk matrix, current vs residual | To create | Annotate SL-01/SL-04 as Platform-Owner-dependent. **Repeated in §0** |
| Table S-5 | §4.1 | New format | Limitations table | Ready | Align to customer register format |
| Figure S-12 | §4.2 | **New** | Mid-case inspection zones, annotated | Optional in this edition | Build from frame 076 geometry. **Technical edition priority** — consider omitting here |
| Figure S-13 | §0, §4.4 | **New** | Risk closure timeline with critical path | **Create — programme office priority** | Mark I-1 and I-2 input gates; distinguish flight-gating from certification-gating actions. **Repeated in §0** |

**Edition note.** This edition front-loads three graphics (S-10, S-11, S-13) into §0. They are
repeated, not duplicated — build each once and place it twice. If print length is a constraint,
Figures S-5 (instrumentation) and S-12 (inspection zones) are the ones to drop from this edition;
both are retained in the technical edition for the airworthiness function.

**Not carried across from the source presentation:** the strain-gauge datasheet extracts (frame 009 —
supplier product data, no evidential value to the customer); the ANSYS contact property panels
(frames 039–055, 064–066 — internal modelling detail); the compensation factor Python source code
(frames 023–024 — internal tooling, and the CF contours it produced were lost to data corruption);
the individual per-contact definition slides throughout §Model Details; and the overpressure gasket
failure photographs (frame 005), which are not needed now that §4.3 states the Phase-II pressure-test
plan directly.

### 5.7 Review record

| Item | Status |
|---|---|
| Prepared | 2026-08-03 |
| Technical check | *(to be completed)* |
| Independent review | *(to be completed)* |
| Design Organisation approval | *(to be completed)* |
| Issued to Platform Owner | *(to be completed)* |

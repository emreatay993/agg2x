# OpenCode Office Harness Instructions

## Purpose

This repository builds a portable OpenCode configuration for two Windows office PCs:

- The internet laptop handles Chrome, Classic Outlook, approved report documents, and web work.
- The intranet VDI handles analysis-side files, mapped HPC storage, SSH, and SLURM.

Never transfer raw analysis data, internal paths, HPC metadata, email content, prompts, logs, or machine-local memory from the intranet VDI to the internet laptop.

## Engineering Rules

- Keep all runtime behavior compatible with Windows PowerShell 5.1 unless a file explicitly requires PowerShell 7.
- Use `Set-StrictMode -Version Latest`, terminating errors, `-LiteralPath`, explicit native exit-code checks, and `try/finally` cleanup.
- Return structured JSON from scripts called by OpenCode tools.
- Never store API keys, passwords, browser storage, Outlook message content, or SSH secrets in tracked files.
- Never disable SSH host-key checking or automate password entry.
- Classic Outlook write operations are opt-in through the `write` block in the Outlook settings file. A settings file without that block stays read-only, and the `outlook-reader` agent must never gain a write tool.
- Classic Outlook deletion must move messages to Deleted Items and must refuse items already in Deleted Items. Never add a permanent-delete or empty-folder path.
- Classic Outlook sending must be draft-first. Never add a tool that composes and sends in one call.
- Delete, send, and rule creation must stay two-phase behind a single-use confirmation token that is minted by the script, bound to a fingerprint of the exact targets, and expiring. Never let a caller supply a token that the tooling did not issue.
- Outlook Web may mark a message read when opening it, but must not expose explicit mark-read, send, reply, forward, move, delete, archive, or attachment-download operations.
- Word, Excel, and PowerPoint edits must use a new output file. Never overwrite the source Office file.
- SLURM cancellation must require an explicit numeric job ID.
- Prefer narrow custom tools over unrestricted shell commands.
- Keep prompts short and deterministic for weaker models.

## Changes And Tests

- Prefer the smallest change that solves the problem.
- Do not edit generated files under `local/`, `node_modules/`, or runtime state.
- Parse every changed PowerShell file before considering it valid.
- Run `powershell.exe -NoProfile -File .\tests\Test-Static.ps1` after changes.
- Run live Office, browser, model, and HPC checks only on the appropriate office PC.

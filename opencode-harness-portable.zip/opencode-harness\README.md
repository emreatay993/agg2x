# OpenCode Office Harness

A portable, weak-model-oriented OpenCode setup for a Windows internet laptop and an offline intranet VDI.

The harness provides:

- Explicit internal OpenAI-compatible Qwen configuration.
- Safe and broad office-automation agents.
- Windows PowerShell 5.1 guidance and narrow custom tools.
- Full Chrome automation through pinned Playwright MCP on the internet laptop.
- Read-only Classic Outlook search plus dedicated Outlook Web search and message reading for New-Outlook-only PCs.
- Opt-in Classic Outlook mailbox management: flag, categorize, read state, importance, move, archive, folder creation, attachment saving, and draft writing, with delete, send, and rule creation held behind a two-phase confirmation token. Off until enabled in settings.
- Word and Excel inspection, PDF rendering, and guarded copy editing.
- PowerPoint inspection, rendering, and save-copy editing.
- House-style slide authoring: a captured presentation style plus a deck builder that applies it.
- SSH-backed SLURM status, submission, log tailing, and cancellation on the intranet VDI.
- Reviewed local Markdown memory that never promotes model guesses automatically.

## Start Tomorrow

1. Copy this complete folder to the office PC.
2. Open Windows PowerShell in the copied folder.
3. Run the appropriate installer:

```powershell
.\scripts\install\Install-Harness.ps1 -Machine Internet -UseExistingOpenCode
.\scripts\install\Install-Harness.ps1 -Machine Intranet -UseExistingOpenCode
```

Windows Documents is approved by default. To use another folder, add `-OfficeRoot 'D:\ApprovedReports'`.
Pass multiple trusted folders as `-OfficeRoot 'D:\Reports','E:\SharedDocs'`. Reinstalling with this
parameter updates both the Office allowlist and OpenCode's external-directory permissions; all other
external paths continue to require approval.

4. Run the generated `Test-OfficeHarness.ps1`.
5. Run the generated `Start-WordOpenCode.ps1` for the staged Word workflow. The existing model/provider configuration remains in use.

The installer seeds the complete Word prompt/router/stage folder under persistent state and adds it to the installed tools without copying the surrounding MyLife repository. Reinstalling refreshes runtime tools but preserves the active Word workspace.

Read [docs/start-here-tomorrow.md](docs/start-here-tomorrow.md) for the complete checklist.

## Rebuild The Portable Package

After changing anything in this folder, rebuild the archive in `releases/`:

```powershell
.\scripts\install\New-HarnessPackage.ps1
```

It runs `tests\Test-Static.ps1` first, stages the tree, compresses it, verifies the archive against
the staged file set, and only then overwrites `releases\opencode-harness-portable.zip` and rewrites
its `.sha256`. A failed build leaves the previous package untouched. Pass `-SkipStaticTest` to skip
the test pass, or `-OutputPath` to write elsewhere.

`releases/`, `CONTEXT.md`, `*.local.json`, `local/`, and `.git/` are excluded. `opencode/node_modules`
and `browser-mcp/node_modules` are included on purpose so the office PCs install offline; run
`.\scripts\install\Prepare-Dependencies.ps1` first if they are missing.

## Safety Modes

The default `office-coordinator` agent allows inspection and read-only operations but asks before browser interaction, Word/Excel/PowerPoint copy edits, SLURM submission, and cancellation.

Switch explicitly to `office-auto` for unattended use. It may perform only the selected narrow actions automatically. Outlook Web may mark opened messages read; it still cannot perform any other Outlook mutation, overwrite source Office files, run arbitrary browser JavaScript, extract browser secrets, or execute unrestricted shell commands.

Classic Outlook mailbox changes live in the separate `outlook-operator` agent and are disabled until the `write` block in `outlook.local.json` is enabled. `outlook-reader` stays read-only and has no write tool. Deleting mail moves it to Deleted Items and can be undone; there is no permanent-delete path. Sending is draft-first, and delete, send, and rule creation each require a fresh preview and an explicit user approval before anything happens. See [docs/outlook-manage.md](docs/outlook-manage.md).

## Existing OpenCode Integration

`-UseExistingOpenCode` sets OpenCode's supported `OPENCODE_CONFIG_DIR` to the installed role-specific capability folder. It does not replace the executable, change `PATH`, or replace the existing provider/model configuration. Omit the switch only when a separate isolated harness configuration is required.

## Disconnect Or Uninstall

Run the generated command at any time:

```powershell
& "$env:LOCALAPPDATA\OpenCodeOfficeHarness\Uninstall-Harness.ps1"
```

This disconnects the OpenCode overlay and removes harness runtime and launchers. It preserves settings, Word workflow checkpoints, reviewed memory, browser profiles, and other state so reinstalling reconnects cleanly. It restores only environment values that still equal what this harness installed; later user changes are left alone.

To delete the preserved harness state as well:

```powershell
& "$env:LOCALAPPDATA\OpenCodeOfficeHarness\Uninstall-Harness.ps1" -PurgeState
```

State purge deletes harness settings, Word checkpoints, memory, browser profiles/output, cached sessions, and the protected harness API-key blob. Neither mode removes ordinary OpenCode, its provider/model configuration, Office documents, edited outputs, or files outside the harness install root. Restart OpenCode and open terminals afterward. To reconnect after the default disconnect, rerun `Install-Harness.ps1` from the extracted ZIP.

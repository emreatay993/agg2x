# Transfer Manifest

Prepared: 2026-08-05

Supersedes the 2026-07-28 package. This revision adds the portable staged Word workspace, stricter
Word operation schemas, bounded inspection, guarded document creation and formatting, and the
model-specific execution controls described below. The earlier Outlook verification still stands.

## Portable Word Workflow Update

- The ZIP contains its own Word workspace router and prepare, edit, and verify stage contracts. The installer seeds them under persistent state and adds `Start-WordOpenCode.ps1`; reinstalling refreshes runtime tools without replacing an active run.
- `-UseExistingOpenCode` removes harness model/provider overrides. The installed `word-auto` agent has no model override, so the user's selected provider and model remain authoritative.
- `word-auto` uses Qwen's recommended temperature of 0.6, loads only the current stage contract, exposes scoped workspace file tools plus the four Word tools, makes one document mutation attempt, and stops on error.
- Word edit operations use strict operation-specific schemas with required fields and no extra properties. Backend validation remains the trust boundary for paired ranges, nonempty formatting changes, approved roots, source hashes, and copy-only output.
- The packager keeps nested portable-workspace `CONTEXT.md` files while excluding only the containing MyLife router.
- Installation generates a registered `Uninstall-Harness.ps1`. Default disconnect removes only harness runtime/integration and preserves state; `-PurgeState` explicitly removes persistent harness state. Environment values changed after installation are never overwritten during disconnect.

### Verification Performed

- The portable ZIP was built, inspected, extracted, and installed into a disposable existing-OpenCode layout. Five nested workspace contracts, the Word launcher, agent, scripts, tool dependencies, and persistent workspace were present; the generated existing-OpenCode config contained no model or provider override.
- The exact model `openrouter/qwen/qwen3.5-122b-a10b` completed a supervised report-copy test through persisted preparation, explicit plan approval, edit, and verification handoffs.
- Its audited plan covered one clear typo, one font-size outlier while preserving bold emphasis, one missing Caption style, and one exact paragraph insertion. The edit trace was `read -> one apply_plan -> write`; the verification trace contained two focused inspections, one render, no edit call, and one verification write.
- All four operations applied. The disposable source SHA-256 remained unchanged, the edited document reopened successfully, and Word exported a 23-page PDF.
- The two changed PDF pages were rendered independently and visually inspected. The corrected title, figure caption, normalized text, and inserted paragraph were legible and showed no clipping, overlap, or broken layout. Unchanged pages were not inspected individually in this final run.
- `tests\Test-Static.ps1`, `tests\Test-Word.ps1`, and `git diff --check` passed.
- `tests\Test-Uninstall.ps1` verified default state preservation, exact restoration of an overwritten environment value, preservation of a value changed after install, and explicit state purge of a disposable installation.

## Pinned Components

| Component | Version |
|---|---:|
| OpenCode configuration target | 1.18.4 |
| `@opencode-ai/plugin` | 1.18.4 |
| `@ai-sdk/openai-compatible` | 3.0.14 |
| `@playwright/mcp` | 0.0.78 |

## Included Offline Content

- `opencode/node_modules` is intentionally included for offline custom tools and the internal provider adapter.
- `browser-mcp/node_modules` is intentionally included for the internet-laptop browser profile.
- No browser binaries are bundled; the internet profile uses installed Google Chrome.
- No API key, SSH key, password, Outlook content, browser profile, machine-local settings, or runtime memory is included.

## Verification Performed

- All PowerShell source files parsed with Windows PowerShell 5.1.
- JSON files and generated profile templates parsed.
- Both machine profiles installed into disposable locations.
- OpenCode 1.18.4 resolved both generated configurations and discovered the expected agents and commands.
- External skill discovery and user-global config/data/state/cache inheritance were isolated.
- Internet general-browser and Outlook-Web Playwright MCP instances resolved with separate persistent profiles.
- A mock OpenAI-compatible streamed tool-call loop advertised the required Word, Excel, PowerPoint, SLURM, and memory tools and executed `office_memory_list` successfully.
- A disposable Word document was inspected, rendered to PDF, edited through an atomic output copy, reinspected, and verified to leave its source hash unchanged; six negative cases passed.
- A disposable Excel workbook was inspected, rendered to PDF, edited through `SaveCopyAs`, reinspected, and verified to leave its source hash unchanged; thirteen negative cases passed.
- A disposable PowerPoint deck was created, inspected, rendered, edited through `SaveCopyAs`, reinspected, and verified to leave its source hash unchanged.
- A four-slide house-style deck was built from a spec through `New-PowerPointDeck.ps1`, rendered, and inspected slide by slide. Bullet ladder, panel auto-layout, badges, governing star, callouts, block arrows, superposition plus, verdict groups, and the warning banner all rendered as intended. The bullet-glyph fallback path and the bullet-block overlap warning were both exercised.
- House-style colour tokens are derived from photographs of a rendered deck, not from a source file. Confirm them against a real `.pptx` or the corporate template on the office PC before the first deck that leaves the desk.
- Reviewed-memory draft, hash listing, and hash-bound promotion were smoke-tested.
- Classic Outlook was unavailable on this PC. Outlook Web sign-in/MFA and mailbox interaction remain manual acceptance checks. Live HPC was not tested.

## Classic Outlook Write Support

Added 2026-07-28. Disabled by default: `settings/outlook.example.json` ships with `write.enabled`,
`allowSend`, `allowDelete`, `allowRules`, and `allowAttachmentDownload` all false, and a settings
file with no `write` block behaves exactly as the 2026-07-27 package did.

- Reversible operations (flag, category, read state, importance, move, archive, folder creation, attachment saving, draft creation) apply directly through the `outlook-operator` agent.
- Delete, send, and rule creation are two-phase. The script mints a single-use, expiring confirmation token bound to a SHA-256 fingerprint of the exact targets; the caller must return that token in a second call after the user explicitly approves.
- Deletion moves mail to Deleted Items and refuses items already there. No permanent-delete or empty-folder path exists.
- Sending is draft-first and confined to unsent items in the default Drafts folder. There is no compose-and-send call.
- `outlook-reader` remains read-only and holds no write tool.

### Verification Performed

- All new and modified PowerShell parsed with Windows PowerShell 5.1.
- `tests/Test-Static.ps1` passes, including ten new Outlook guardrail assertions: the reader agent is rejected if it references any write tool, the operator agent is rejected without its `ask` gates, each gated script is rejected unless it both mints and validates a token, the delete script is rejected without its Deleted-Items check or if it gains a permanent-delete path, the draft script is rejected if it calls `Send()`, the send script is rejected unless it confines itself to the Drafts folder, and the example settings are rejected unless every write switch ships false.
- Thirty-six behavioural checks passed against the confirmation and settings layer: legacy settings stay read-only, per-capability switches gate correctly, batch limits and malformed plans are refused, fingerprints are deterministic and collision-resistant across field boundaries, and tokens are rejected when replayed, expired, fabricated, malformed, aimed at a different target, or used for a different operation.
- Attachment file-name sanitization verified against directory traversal, invalid characters, reserved device names, empty names, and over-length names.
- TypeScript tool definitions syntax-checked.

### Not Verified

- No Classic Outlook COM call was exercised, because Classic Outlook is unavailable on the preparation PC. Flag, category, move, delete, draft, send, attachment, folder, and rule behaviour are all manual acceptance checks on the internet laptop.
- `RuleSet.Save()` rewrites the whole client rule set and can be refused by Exchange policy or server-side rule limits. The script reports rule names before and after saving so a loss is visible; compare them on first use.
- `write.allowedFolders` and `write.archiveFolder` must name folders that actually exist in the mailbox. Confirm the archive folder's real name before the first move.

Run the generated diagnostic again on each office PC because installed Office applications, internal model IDs, SSH policy, paths, and network access are machine-specific.

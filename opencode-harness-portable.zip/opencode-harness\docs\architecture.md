# Architecture And Data Boundaries

## Two Independent Installations

The internet laptop and intranet VDI share source code but not runtime state.

| Capability | Internet laptop | Intranet VDI |
|---|---:|---:|
| Internal Qwen API | Yes | Yes |
| PowerShell and reviewed memory | Yes | Yes |
| Word COM | Yes | Yes |
| Excel COM | Yes | Yes |
| PowerPoint COM | Yes | Yes |
| Chrome and Playwright | Yes | No |
| Classic Outlook | Yes | No |
| Outlook Web reader | Yes | No |
| SSH, mapped HPC drive, SLURM | No | Yes |
| Internet web tools | Yes | No |

## Runtime Layout

```text
%LOCALAPPDATA%\OpenCodeOfficeHarness\
├── Start-OfficeOpenCode.ps1
├── Test-OfficeHarness.ps1
├── runtime\                 replaced by reinstall
└── state\                   preserved by reinstall
    ├── opencode.json
    ├── settings\
    ├── memory\
    ├── browser\             internet only
    ├── browser-output\      internet only
    └── xdg\
```

With `-UseExistingOpenCode`, `OPENCODE_CONFIG_DIR` points to the role-specific agents, commands, skills, custom tools, and permission overlay while the existing global provider/model configuration remains active. A separate isolated installation instead uses `OPENCODE_CONFIG` plus dedicated XDG config, data, state, and cache roots. Internet state also contains separate `outlook-web-browser` and `outlook-web-output` directories.

The installer physically removes SLURM tools from the internet runtime and browser/Outlook tools from the intranet runtime. Permissions provide a second boundary rather than being the only boundary.

## Narrow Tools Instead Of Raw Shell

Classic Outlook, Word, Excel, PowerPoint, SLURM, browser opening, and memory use typed OpenCode custom tools. The tools call strict PowerShell scripts with argument arrays and compact JSON results. This reduces quoting errors and prevents weaker models from inventing high-impact commands.

Playwright remains an MCP because persistent browser state and accessibility snapshots are useful for interactive web work. Outlook Web uses a second MCP instance and persistent profile so mailbox authentication is not shared with the general browser.

## Data Rules

- Nothing synchronizes automatically.
- Intranet state, logs, memory, job IDs, paths, and scripts remain on the intranet side.
- Raw analysis data never enters browser, email, or internet-laptop workflows.
- Approved report documents are the only normal outward artifact.
- API secrets, SSH credentials, Outlook content, and browser state are excluded from memory.

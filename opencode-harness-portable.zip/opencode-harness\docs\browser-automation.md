# Chrome And Playwright

Browser capability is installed only in the internet profile.

Outlook Web uses its own Playwright MCP instance, profile, agent, and command. Do not add Outlook aliases to the general browser settings or sign the general profile into Outlook.

## Simple Opening

Edit `sites.local.json` and add aliases and allowed hosts:

```json
{
  "browserExecutable": "",
  "allowUnlistedExplicitUrls": false,
  "aliases": {
    "team-portal": "https://portal.example.com/"
  },
  "allowedHosts": ["portal.example.com"]
}
```

Then ask OpenCode to open `team-portal` or run `/open-site team-portal`.

## Full Automation

The pinned Playwright MCP launches the Chrome channel with a dedicated persistent profile under harness state. Sign in manually the first time. Do not point it at Chrome's normal profile directory.

Node.js 20 or newer is required by the pinned Playwright runtime.

The browser agent should navigate once, use targeted `browser_find` calls or shallow snapshots, interact with exact element references, and verify the final page state.

## Guardrails

- Cookie and local/session-storage tools are denied.
- Arbitrary `browser_run_code_unsafe` is denied.
- File access outside the OpenCode workspace is not enabled.
- Passwords, cookies, and profile databases must not be inspected.
- Authentication failures require user sign-in, not credential extraction.
- Site allowlists are convenience controls and do not make Playwright a security boundary.

If corporate policy blocks automated Chrome or the Playwright extension, retain the simple URL-opening tool and disable the MCP block in the generated config.

# Configure The Internal Qwen Models

## Required Values

Ask the internal API owner for:

- Base URL for the OpenAI-compatible API root.
- Exact IDs returned by `GET /models`.
- Whether authentication uses a bearer API key.
- Whether streaming chat completions and tool calls are supported.
- Context and output-token limits.

Do not append `/chat/completions` to the configured base URL.

If authentication is required, run the installed `Set-OfficeApiKey.ps1`. It protects the value with Windows CurrentUser DPAPI. The launcher decrypts it only for OpenCode, while custom PowerShell and browser MCP child processes receive filtered environments.

## Existing OpenCode

If Qwen already works in ordinary OpenCode, keep that provider configuration:

```powershell
.\scripts\install\Install-Harness.ps1 -Machine Internet -UseExistingOpenCode
```

Use `-Machine Intranet` on the intranet PC. No base URL, model ID, or API key input is required from the harness.

## Initial Routing

The installer defaults are only likely names:

```text
qwen35-122b-a10b
qwen-next-80b-coder
```

Initial routing uses the general model for coordination, Outlook, browser work, exploration, and memory. It uses the coder model for PowerShell, SLURM, and PowerPoint editing.

Override both IDs during installation if `/models` returns different strings.

If Qwen3.5 122B A10B is the only available model, assign its exact `/models` ID to both roles:

```powershell
.\scripts\install\Install-Harness.ps1 -Machine Internet `
    -BaseUrl 'https://internal-api.example/v1' `
    -GeneralModelId 'qwen35-122b-a10b' `
    -CoderModelId 'qwen35-122b-a10b'
```

Use the same command with `-Machine Intranet` on the intranet PC.

## Validation

Run the diagnostic with `-LiveModel`. It checks `/models`, asks the configured model to call the
read-only memory-list tool, then requests one harmless inspection of a deliberately nonexistent Word
file. The second turn must produce exactly one failed tool event, no fallback tool calls, and a terminal
failure report.

The minimum acceptable model behavior is:

1. Produces a valid custom tool call.
2. Accepts the tool result in the next turn.
3. Does not repeat an unchanged failed call.
4. Stops after reporting the requested result.
5. Honors denied tools and agent step limits.

If the general model fails the tool test but the coder succeeds, reinstall with the coder ID for both roles. If neither succeeds, the API server may not expose OpenAI-compatible tool calling even if plain chat works.

## Configuration Characteristics

- Provider allowlist contains only `office-llm`.
- Agent prompts enforce one bounded workflow, one mutation attempt, and an immediate stop on tool, schema, or validation errors.
- Word, Excel, and PowerPoint operation arrays are parsed again inside the custom tool before PowerShell or Office starts; this protects against malformed calls forwarded by the host.
- PowerPoint inspection is paged at 10 slides by default and 25 maximum, with an explicit continuation cursor.
- `office-auto` has a 12-step ceiling; larger jobs must continue in another bounded turn rather than wandering through recovery attempts.
- Sharing and automatic updates are disabled.
- Provider timeout is ten minutes; stream-chunk timeout is one minute.
- Tool output is truncated after 300 lines or 16 KiB.
- Compaction keeps eight recent turns and reserves 12,000 tokens.
- Subagents cannot launch nested subagents.

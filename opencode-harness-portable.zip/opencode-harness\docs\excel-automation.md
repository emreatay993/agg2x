# Excel Inspection And Editing

Excel automation uses desktop Excel COM and can run on either office PC.

## Settings

Excel reuses `settings/powerpoint.local.json` so existing approved roots need no migration. At least one `allowedRoots` entry is required:

```json
{
  "allowedRoots": ["%USERPROFILE%\\Documents\\Reports"],
  "defaultOutputRoot": "%USERPROFILE%\\Documents\\Reports\\Generated"
}
```

Create configured directories before adding them.

## Inspect

`office_excel_inspect` returns bounded workbook and worksheet metadata. Supply `sheetName` and `range` together to inspect one contiguous A1 range of at most 32 cells. The result includes displayed text, literal values, formula indicators, protection state, hashes, and truncation notices.

## Render

`office_excel_render` exports the complete workbook to a new PDF. The output path must not exist.

## Edit Plan

`office_excel_apply_plan` supports at most 100 guarded operations:

- `set_value`: write one JSON string, number, boolean, or null.
- `clear`: clear one cell.

Each operation requires an exact `sheetName`, one A1 `address`, and `expectedText` copied from inspection. Formula targets, protected cells, stale expected text, formula-like strings, ranges, formatting, charts, pivots, macros, and structural changes are rejected.

The output path must not exist and must preserve the source extension. Supported formats are `.xls`, `.xlsx`, `.xlsm`, and `.xlsb`.

## Verification

The backend opens the source read-only with links, events, macros, and automatic calculation disabled. It saves only through `SaveCopyAs` to a temporary sibling and atomically moves that file into place. It verifies the source SHA-256 before and after and returns the output hash and per-operation results.

Re-inspect the output after editing. Successful COM execution does not prove print layout; review the rendered PDF or perform manual review.

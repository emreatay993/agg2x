# Install On The Internet Laptop

## Requirements

- OpenCode 1.18.4 or a schema-compatible newer version.
- Windows PowerShell 5.1.
- Node.js 20 or newer. Node.js 22 or newer is preferred when preparing dependencies.
- Google Chrome.
- New Outlook or Outlook Web access; Classic Outlook is optional for the COM reader.
- Desktop Word, Excel, and PowerPoint.
- Reachability to the internal OpenAI-compatible API.

## Install

```powershell
.\scripts\install\Install-Harness.ps1 -Machine Internet -UseExistingOpenCode
```

Windows Documents is approved by default. If reports live elsewhere, authorize their existing parent
folder during installation, for example `-OfficeRoot 'D:\ApprovedReports'`. Multiple trusted folders
can be supplied as a comma-separated PowerShell array. Rerun the installer with `-OfficeRoot` whenever
the approved folder set should change.

This keeps the provider, credentials, and Qwen model already configured in OpenCode.

The installer copies the runtime into `%LOCALAPPDATA%\OpenCodeOfficeHarness`, preserves existing local settings and memory, writes no API key, and disables SLURM capability in the generated internet profile.

Open a new Command Prompt after installation and type `opencode`.

## Configure

Edit `sites.local.json` and `outlook.local.json` under the installed `state\settings` folder. The installer
keeps the shared Word, Excel, and PowerPoint roots synchronized between `powerpoint.local.json` and
OpenCode. Run the diagnostic without live switches, then with `-LiveOffice` and `-LiveModel`.

Start Classic Outlook normally before its optional live mail test. Sign into the dedicated Outlook Web Playwright profile manually for New Outlook mail; keep the general browser profile signed out of Outlook.

## Disconnect Or Remove

Run `%LOCALAPPDATA%\OpenCodeOfficeHarness\Uninstall-Harness.ps1` to disconnect the overlay while keeping settings, Word checkpoints, memory, and browser sign-in state. Add `-PurgeState` only when those persistent harness files should also be deleted. Ordinary OpenCode, its provider/model, and Office documents are never removed. Restart OpenCode and terminals afterward.

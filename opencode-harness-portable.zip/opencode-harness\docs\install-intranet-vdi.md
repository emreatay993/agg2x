# Install On The Intranet VDI

## Requirements

- OpenCode 1.18.4 or a schema-compatible newer version.
- Windows PowerShell 5.1.
- Reachability to the internal OpenAI-compatible API.
- Windows OpenSSH client.
- An IT-approved noninteractive SSH key or credential agent for automation.
- A mapped drive that corresponds to the configured remote HPC work root.
- Desktop Word, Excel, and PowerPoint when report inspection or editing is required.

No internet access or npm installation is required after transfer because the OpenCode custom-tool dependencies are bundled.

## Install

```powershell
.\scripts\install\Install-Harness.ps1 -Machine Intranet -UseExistingOpenCode
```

The generated profile disables web access, browser tools, Outlook tools, and their specialist agents.

The existing OpenCode provider, credentials, and Qwen model remain in use. Open a new Command Prompt after installation and type `opencode`.

## Configure

Edit `slurm.local.json` and `powerpoint.local.json` under the installed `state\settings` folder. The PowerPoint settings file supplies the shared approved roots for Word, Excel, and PowerPoint. Verify the HPC host fingerprint manually before live tests.

Run the normal diagnostic first. Use `-LiveModel` after API setup and `-LiveHpc` only after `ssh office-hpc` works without a password prompt.

Never copy the generated state folder back to the internet laptop.

## Disconnect Or Remove

Run `%LOCALAPPDATA%\OpenCodeOfficeHarness\Uninstall-Harness.ps1` to disconnect the overlay while keeping settings, Word checkpoints, reviewed memory, and local session state. Add `-PurgeState` only when that persistent harness state should also be deleted. Ordinary OpenCode, its provider/model, Office documents, SSH material, mapped-drive data, and HPC files are never removed. Restart OpenCode and terminals afterward.

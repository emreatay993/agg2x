# Hybrid Reviewed Memory

Memory is local Markdown under the installed `state\memory` directory.

## Trust Levels

- `approved/`: durable instructions that may guide future tasks.
- `inbox/`: untrusted model-drafted candidates.
- `archive/`: superseded entries retained for traceability.
- `index.md`: small map loaded into every session.

## Capture And Promotion

Use `/memory-capture` to draft one atomic candidate. The draft records an ID, topic, machine scope, source, creation date, and proposed text.

Review the exact file and SHA256, then explicitly ask to promote that ID and hash. Promotion fails if the file changed after review and moves an unchanged entry into `approved/notes`. It never happens automatically, including in broad mode.

## Suitable Memory

- Stable user preferences.
- Approved URL aliases and site conventions.
- PowerPoint template and review conventions.
- Outlook folder/search conventions without message content.
- HPC path mappings, partitions, modules, and operating procedures when permitted.

## Prohibited Memory

- Passwords, keys, tokens, or connection secrets.
- Email bodies, attachments, or message identifiers.
- Browser cookies, storage, passwords, or session data.
- Raw analysis data, result values, or confidential project details.
- Current job status and other transient state.
- Model guesses without a verified source.

Internet and intranet memories do not synchronize. A common-looking fact learned on the intranet remains intranet-local unless separately approved for transfer under office policy.

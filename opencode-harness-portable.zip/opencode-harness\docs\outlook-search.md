# Classic Outlook Search And Summarization

The Outlook tools use the signed-in Classic Outlook MAPI profile on the internet laptop. New Outlook is not supported by this COM workflow.

For New Outlook mail, use the separate Outlook Web workflow documented in [outlook-web.md](outlook-web.md).

## Configure Folders

Edit `outlook.local.json`:

```json
{
  "folders": ["Inbox", "Sent Items"],
  "maxItemsScannedPerFolder": 1000,
  "maxSearchResults": 50,
  "maxBodyCharacters": 20000
}
```

Nested folders can be written as configured Outlook folder paths. Keep the set small.

## Workflow

1. Search sender, subject, metadata text, date range, and unread status.
2. Review returned metadata and coverage.
3. Retrieve only relevant messages by `EntryId` and `StoreId`.
4. Summarize facts with sender and date where useful.
5. Report scanned folders, item limits, result limits, and truncation.

The `text` search is metadata-only. It does not scan every message body. Body search would require opening many messages and is deliberately excluded.

## Read-Only Contract

The `outlook-reader` agent has no tool for send, reply, forward, move, archive, delete, attachment
saving, or mark-read, and must not gain one. Do not bypass this through generic PowerShell. Reading
body text may expose sensitive information to the configured internal model endpoint, so keep
searches narrow.

Mailbox changes are a separate capability with its own agent, settings switches, and confirmation
gating. See [outlook-manage.md](outlook-manage.md). Write tools stay inert unless the `write` block
in `outlook.local.json` is present and enabled, so a settings file without it keeps this workflow
read-only end to end.

Message bodies and identifiers must not enter persistent memory.

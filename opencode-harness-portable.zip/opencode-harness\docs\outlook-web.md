# Outlook Web Search And Summarization

Outlook Web support is installed only in the internet profile. It provides bounded mailbox search, folder navigation, and selected-message reading through a dedicated persistent Playwright profile. It does not control the Windows New Outlook application.

Classic Outlook remains available through its separate COM tools when Classic Outlook and a MAPI profile are installed.

## First Use

1. Start the internet harness.
2. Ask the `outlook-web-reader` agent to open Outlook Web.
3. Complete sign-in and MFA manually in the dedicated browser window.
4. Run `/mail-web-summary` with a folder, date range, and search terms.

Authentication state stays in the untracked Outlook Web browser profile. If authentication expires, complete sign-in manually again. Never provide credentials to the agent.

## Workflow

The reader searches one named folder, inspects at most 20 visible result rows, and opens at most 5 relevant messages. Narrow the request further when those limits truncate the result.

Opening a message in Outlook Web may mark it read. Every summary must report how many messages were opened and warn that their read state may have changed.

## Hard Limits

The reader cannot:

- compose, reply, forward, or send;
- move, archive, delete, report, mark as junk, flag, or categorize;
- open or download attachments;
- upload files;
- run arbitrary JavaScript;
- inspect console or network details, cookies, or browser storage; or
- manage generic browser tabs.

The general browser profile is separate and must not be signed into Outlook. Outlook Web is physically absent from intranet installations.

The dedicated profile, permission prompts, and denied tools are convenience guardrails, not a security sandbox. Keep searches narrow because visible message content is sent to the configured model. Do not save message content in durable memory.

## Troubleshooting

- **Sign-in or MFA appears:** complete it manually in the dedicated browser window, then retry.
- **The page layout is ambiguous:** stop instead of guessing a control; refresh the visible snapshot and narrow the request.
- **Results are truncated:** use a smaller date range, one folder, or more specific sender and subject terms.
- **Outlook tools are missing:** confirm that the internet profile was installed. The intranet profile deliberately excludes them.

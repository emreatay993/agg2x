# PowerPoint Inspection And Editing

PowerPoint automation uses desktop PowerPoint COM and can run on either office PC.

## Settings

At least one `allowedRoots` entry is required. The same `powerpoint.local.json` roots protect Word, Excel, and PowerPoint. The installer uses `%USERPROFILE%\MyLife` when that folder exists; otherwise configure an approved root before using Office file tools:

```json
{
  "allowedRoots": ["%USERPROFILE%\\Documents\\Reports"],
  "defaultOutputRoot": "%USERPROFILE%\\Documents\\Reports\\Generated",
  "renderWidth": 1920,
  "renderHeight": 1080
}
```

Create configured directories before adding them.

Authoring new decks in the house slide style is a separate concern. See [presentation-style.md](presentation-style.md).

## Inspect

`office_powerpoint_inspect` returns every slide, top-level and grouped shapes, text, tables, notes, bounds, links, and macro indicators. Use the returned slide indices and shape names or IDs for edits.

## Edit Plan

Supported operations:

- `replace_text`
- `set_text`
- `set_notes`
- `move_resize`
- `replace_image`

These edit an existing deck. To create one, use `office_powerpoint_new_deck`, which builds a new `.pptx` from a deck spec and never opens the output path if it already exists.

The OpenCode tool generates a temporary plan and fixes `allowOverwrite` to false. The output path must not already exist and must preserve the source extension.

## Verification

The backend hashes the source before and after, calls only `SaveCopyAs`, and returns output hash and per-operation details. Re-inspect and render the output after editing.

Successful COM execution does not prove visual quality. Inspect every rendered slide or perform manual review when the model endpoint has no image capability. Image replacement may not preserve crop, effects, animation, or action settings. Text replacement can normalize mixed inline formatting.

# PowerShell Guide For OpenCode

Harness scripts are compatible with Windows PowerShell 5.1. PowerShell 7 can be used interactively, but it is not required.

## Reliable Script Shape

```powershell
#requires -Version 5.1
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$InputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $InputPath -PathType Leaf)) {
    throw "Input file not found: '$InputPath'."
}
```

## Native Programs

Use an executable plus argument array. Never build a command for `Invoke-Expression`.

```powershell
$arguments = @('-o', 'BatchMode=yes', 'office-hpc', 'squeue --me')
& $sshExecutable @arguments
if ($LASTEXITCODE -ne 0) {
    throw "ssh failed with exit code $LASTEXITCODE."
}
```

## Paths

- Derive repository paths from `$PSScriptRoot`.
- Use `Join-Path` and `-LiteralPath`.
- Verify the parent before creating an output.
- Use full paths at application and network boundaries.
- Do not change directory inside an agent command when the tool can supply a working directory.

## Errors And Output

- Emit machine-readable JSON to stdout.
- Emit failure JSON to stderr and exit nonzero.
- Do not suppress exceptions that determine whether an operation succeeded.
- Bound large output before returning it to a model.

## COM

Close documents and applications in `finally`. Release child COM objects before parents. Never rely only on garbage collection to close Office applications.

# House Presentation Style

Slide authorship is separate from slide mechanics.

- `powerpoint-com` owns mechanics: inspect, plan, `SaveCopyAs`, verify.
- `presentation-style` owns authorship: which layout, which words, which colour, and what a colour means.

Editing someone else's deck loads only the first. Writing your own loads both.

## Where The Style Lives

| Layer | File | Job |
|---|---|---|
| Tokens | `settings\presentation-style.local.json` | Fonts, colours, geometry, bullet glyphs. The single source of truth. |
| Rules | `opencode\skills\presentation-style\SKILL.md` | Which pattern to pick, how to name a slide, what a colour means. |
| Detail | `opencode\skills\presentation-style\reference\*.md` | Full visual system, eight layouts, voice, deck-spec schema. |
| Builder | `scripts\powerpoint\New-PowerPointDeck.ps1` | Applies the tokens so the model never has to remember a hex code. |

Tokens are read by the builder at run time. Correcting a colour in the JSON changes every future deck without touching prose or code.

## Style Origin And Confidence

The style was derived from 63 photographs of a rendered 94-slide analysis deck. Colours were sampled from those photographs and white-balanced against the slide background, so they are close but not exact. Fonts, geometry, layout patterns, and voice were read directly and are reliable.

Before the first real deck, open a genuine source `.pptx` or the corporate template, read the true theme colours, and correct `presentation-style.local.json`. Everything else then follows automatically.

## Settings

```json
{
  "slideSize": { "widthPt": 960, "heightPt": 540, "aspect": "16:9" },
  "fonts": { "title": { "name": "Arial", "bold": true, "sizePt": 32, "colour": "#404040" } },
  "colours": { "badgeRed": "#C0504D", "verdictGreen": "#00703C" },
  "bullets": { "level1": { "glyph": "➢", "font": "Wingdings", "indentPt": 18, "hangingPt": 18 } },
  "geometry": { "marginLeftPt": 36, "footerRuleTopPt": 500 },
  "rules": { "maxBodyBulletsPerSlide": 6, "justifyThresholdChars": 220 }
}
```

The installer copies the shipped example to `presentation-style.local.json` on both machines. Missing sections are an error, not a silent default, so a truncated file fails loudly on the first build.

## Building A Deck

`office_powerpoint_new_deck` takes a deck spec and an output path.

- Output must be `.pptx` and must not already exist.
- Output must sit inside a configured `allowedRoots` entry.
- An optional `templatePath` supplies theme and masters and is opened read-only.
- Pass `imageRoot` whenever the spec uses relative image paths. The spec is written to machine-local state, so relative paths have no useful base without it.

The builder writes text, bullets, badges, callouts, banners, arrows, plus marks, governing stars, rules, verdicts, and placed images. It does not write video, animation, transitions, tables, charts, or grouped vector diagrams. Place a rendered image instead and say so.

## Verification

The manifest reports the spec hash, output hash and size, per-slide shape counts, the resolved style path, and warnings.

Warnings are advisory and do not fail the build:

- more body bullets than the house limit
- more than one governing star on a slide
- PowerPoint rejecting a bullet glyph or indent, which means the ladder fell back and the slides must be looked at

Successful COM execution does not prove visual quality. Render the output and inspect every slide before calling a deck finished.

## Reviewing A Deck

Ask for a style review rather than a rewrite when the deck already exists. The skill reports violations against the non-negotiables, title grammar, and colour semantics with slide numbers, and does not restyle unless asked.

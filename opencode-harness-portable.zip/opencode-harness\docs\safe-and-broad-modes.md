# Safe And Broad Modes

## Safe Mode

`office-coordinator` is the default.

Allowed without approval:

- Read-only file discovery.
- Classic Outlook metadata search and selected body retrieval.
- Word and Excel inventory and PDF rendering.
- PowerPoint inventory and rendering.
- SLURM connection, status, accounting, and bounded log tailing.
- Listing approved and draft memory.

Approval required:

- Browser launch or interaction.
- Outlook Web search, folder navigation, and selected-message opening.
- Word and Excel output-copy edits.
- PowerPoint save-copy edits.
- SLURM submission and cancellation.
- Memory drafting and promotion.
- Generic PowerShell commands in the PowerShell specialist.

## Broad Mode

Switch explicitly to the `office-auto` primary agent in the OpenCode TUI. It can automatically perform:

- Configured non-Outlook browser interactions.
- Classic Outlook search and reading.
- Constrained Outlook Web search and reading; opening mail may mark it read.
- Word, Excel, and PowerPoint edits to new, nonexistent output paths.
- Validated SLURM submission.
- Cancellation of an explicit numeric job ID after ownership inspection.

Broad mode still denies generic shell and file editing, Outlook mutation beyond the accepted Outlook Web mark-read side effect, existing-output overwrite through custom tools, unsafe browser JavaScript, cookie/storage tools, implicit job selection, and memory promotion without approval.

Do not pass OpenCode's global `--auto` option to the harness launcher. The launcher rejects it because it would auto-approve unrelated `ask` permissions. Select the `office-auto` agent instead.

Use safe mode when defining a workflow. Use broad mode only after settings, paths, Office-file operations, and SLURM templates are known and tested.

# SLURM And SSH

SLURM tools exist only on the intranet VDI.

## Authentication Requirement

OpenCode tools are noninteractive. Configure an IT-approved OpenSSH key or credential agent and a host alias in `%USERPROFILE%\.ssh\config`:

```sshconfig
Host office-hpc
    HostName 192.168.x.x
    User your-user-name
    IdentityFile ~/.ssh/id_ed25519
```

Do not add `StrictHostKeyChecking no`. Connect manually once and verify the host fingerprint with the HPC administrator.

If policy permits only username/password, use MobaXterm or PuTTY manually. Do not store or automate the password in this harness.

## Local Settings

```json
{
  "hostAlias": "office-hpc",
  "sshExecutable": "ssh.exe",
  "connectTimeoutSeconds": 15,
  "mappedDriveRoot": "H:\\home\\your-user-name",
  "remoteWorkRoot": "/home/your-user-name",
  "allowedPartitions": ["standard"],
  "maxTailLines": 500
}
```

The mapped and remote roots must identify the same directory tree.

## Script Example

```bash
#!/usr/bin/env bash
#SBATCH --job-name=example
#SBATCH --partition=standard
#SBATCH --nodes=1
#SBATCH --ntasks=1
#SBATCH --time=00:10:00
#SBATCH --output=logs/%x-%j.out
#SBATCH --error=logs/%x-%j.err

set -euo pipefail
printf 'job=%s host=%s start=%s\n' "$SLURM_JOB_ID" "$(hostname)" "$(date --iso-8601=seconds)"

# Load only site-approved modules here.
# module load ansys/<approved-version>

printf 'finish=%s\n' "$(date --iso-8601=seconds)"
```

Save with LF line endings.

## Submission Contract

The script must be under `mappedDriveRoot`, contain no carriage returns, use an allowed partition, map below `remoteWorkRoot`, pass remote `bash -n`, and submit through `sbatch --parsable`. The returned numeric job ID is the authoritative identifier.

Cancellation requires an explicit positive numeric ID. The tool checks the job owner before `scancel`.

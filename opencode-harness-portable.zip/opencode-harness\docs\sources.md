# Primary References

- OpenCode configuration schema: <https://opencode.ai/config.json>
- OpenCode configuration: <https://opencode.ai/docs/config/>
- OpenCode agents: <https://opencode.ai/docs/agents/>
- OpenCode permissions: <https://opencode.ai/docs/permissions/>
- OpenCode custom tools: <https://opencode.ai/docs/custom-tools/>
- OpenCode MCP servers: <https://opencode.ai/docs/mcp-servers/>
- Microsoft Playwright MCP: <https://github.com/microsoft/playwright-mcp>
- New Outlook for Windows architecture: <https://learn.microsoft.com/en-us/microsoft-365-apps/outlook/overview-new-outlook-windows>
- Outlook NameSpace object: <https://learn.microsoft.com/en-us/office/vba/api/outlook.namespace>
- Word `Document.ExportAsFixedFormat`: <https://learn.microsoft.com/en-us/office/vba/api/word.document.exportasfixedformat>
- Excel `Workbook.SaveCopyAs`: <https://learn.microsoft.com/en-us/office/vba/api/excel.workbook.savecopyas>
- Excel `Workbook.ExportAsFixedFormat`: <https://learn.microsoft.com/en-us/office/vba/api/excel.workbook.exportasfixedformat>
- PowerPoint `Presentation.SaveCopyAs`: <https://learn.microsoft.com/en-us/office/vba/api/powerpoint.presentation.savecopyas>
- SLURM `sbatch`: <https://slurm.schedmd.com/sbatch.html>
- SLURM `squeue`: <https://slurm.schedmd.com/squeue.html>
- SLURM `sacct`: <https://slurm.schedmd.com/sacct.html>

OpenCode validates configuration strictly. Recheck the live schema when upgrading beyond the bundled version assumptions.

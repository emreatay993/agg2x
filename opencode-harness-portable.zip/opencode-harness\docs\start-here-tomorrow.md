# Start Here Tomorrow

Use this checklist independently on each office PC. Do not copy generated `state` folders between machines.

OpenCode must already be installed and the `opencode` command must be available on `PATH`.

## Before Transfer

The complete harness folder must include these ignored dependency directories:

```text
opencode\node_modules
browser-mcp\node_modules
```

If either is missing, run this on an internet-connected PC before transfer:

```powershell
.\scripts\install\Prepare-Dependencies.ps1
```

## Internet Laptop

```powershell
.\scripts\install\Install-Harness.ps1 `
    -Machine Internet `
    -UseExistingOpenCode
```

Edit:

```text
%LOCALAPPDATA%\OpenCodeOfficeHarness\state\settings\sites.local.json
%LOCALAPPDATA%\OpenCodeOfficeHarness\state\settings\outlook.local.json
%LOCALAPPDATA%\OpenCodeOfficeHarness\state\settings\powerpoint.local.json
```

The PowerPoint settings file supplies the approved roots for Word, Excel, and PowerPoint. After installation, start the harness and complete Outlook Web sign-in/MFA manually in its dedicated browser profile.

## Intranet VDI

```powershell
.\scripts\install\Install-Harness.ps1 `
    -Machine Intranet `
    -UseExistingOpenCode
```

Edit:

```text
%LOCALAPPDATA%\OpenCodeOfficeHarness\state\settings\slurm.local.json
%LOCALAPPDATA%\OpenCodeOfficeHarness\state\settings\powerpoint.local.json
```

The PowerPoint settings file supplies the approved roots for Word, Excel, and PowerPoint. Outlook Web is intentionally absent from this installation.

## API Key

With `-UseExistingOpenCode`, keep using the provider and credentials already configured in OpenCode. The harness does not ask for or copy them.

For a separate isolated installation only, store a required key with Windows CurrentUser DPAPI:

```powershell
& "$env:LOCALAPPDATA\OpenCodeOfficeHarness\Set-OfficeApiKey.ps1"
```

The launcher decrypts it only into the OpenCode process environment. Custom PowerShell and browser MCP processes receive filtered environments without the key.

## Diagnose

```powershell
& "$env:LOCALAPPDATA\OpenCodeOfficeHarness\Test-OfficeHarness.ps1"
```

Optional live checks are intentionally opt-in:

```powershell
& "$env:LOCALAPPDATA\OpenCodeOfficeHarness\runtime\scripts\validation\Test-OfficeHarness.ps1" `
    -Machine Internet `
    -InstallRoot "$env:LOCALAPPDATA\OpenCodeOfficeHarness" `
    -UseExistingOpenCode `
    -LiveModel `
    -LiveOffice
```

Use `-LiveHpc` only on the intranet VDI after SSH settings and keys are ready.

## Start

```powershell
opencode
```

Open a new Command Prompt first so it receives `OPENCODE_CONFIG_DIR`. OpenCode keeps its existing model/provider configuration and loads the installed Office agents, commands, skills, tools, and role restrictions from that directory.

The launcher ignores project `opencode.json` files by default so they cannot broaden the office profile. Add `-AllowProjectConfig` only when you have reviewed the project configuration.

The launcher also rejects OpenCode's `--auto` flag. Use the `office-auto` agent for the bounded broad workflow.

Restart OpenCode after changing configuration, agents, skills, tools, or MCP settings.

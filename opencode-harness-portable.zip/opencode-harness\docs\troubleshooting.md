# Troubleshooting

## OpenCode Rejects The Config

Run the generated diagnostic. Inspect the generated file at `%LOCALAPPDATA%\OpenCodeOfficeHarness\state\opencode.json` for unresolved `__TOKEN__` values.

OpenCode can bypass a broken explicit configuration for repair:

```powershell
$env:OPENCODE_DISABLE_PROJECT_CONFIG = '1'
opencode
```

Do not edit secrets into the generated JSON.

## Custom Tools Do Not Load

Confirm `opencode\node_modules\@opencode-ai\plugin` was transferred. Run `Prepare-Dependencies.ps1` on an internet PC and recopy the complete harness.

Restart OpenCode after changing tools, skills, agents, commands, or config.

## Model Chats But Does Not Call Tools

Run diagnostics with `-LiveModel`. Verify exact `/models` IDs and server support for streamed OpenAI-compatible tool calls. Try the coder model for both roles. Plain chat compatibility does not prove tool compatibility.

## Chrome MCP Fails

Confirm Node 18 or newer, desktop Chrome, and the pinned `browser-mcp\node_modules` folder. Delete only the harness browser profile if it is corrupted; do not inspect or reuse Chrome's normal profile.

## Outlook COM Fails

Confirm Classic Outlook desktop is installed, a profile is configured, and Outlook can open normally. New Outlook does not expose the required COM model; use `/mail-web-summary` through the dedicated Internet-profile browser instead.

## Outlook Web Requires Sign-In

Complete sign-in and MFA manually in the dedicated Outlook Web browser window. Do not enter credentials through an agent. The general browser profile must remain signed out of Outlook.

## Word Or Excel Remains Running

Close visible documents or workbooks and rerun the operation. Inspect leftover `WINWORD.EXE` or `EXCEL.EXE` manually before ending it; the harness never terminates all Office processes because the user may have unsaved work.

## PowerPoint Remains Running

Close visible presentations and rerun the operation. If a previous abnormal termination left `POWERPNT.EXE`, inspect it manually before ending it; never terminate all PowerPoint processes automatically because the user may have unsaved work.

## SSH Requests A Password

The tool uses `BatchMode=yes`, so password prompts fail by design. Configure an approved key or credential agent, or use MobaXterm/PuTTY manually.

## Script Submission Rejects Line Endings

Configure the editor for LF and resave the shell script. Do not silently normalize a production script during submission because that changes the submitted artifact.

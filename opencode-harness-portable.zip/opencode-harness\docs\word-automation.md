# Word Inspection, Editing, And Creation

Word automation uses desktop Word COM on either office PC. Existing-document work supports `.doc`, `.docx`, and `.docm`; new documents are `.docx` only.

Use the generated `Start-WordOpenCode.ps1` launcher for model-driven Word work. It opens the existing OpenCode installation in the persistent staged workspace and selects `word-auto`, which inherits the selected model. The workspace persists visible preparation/plan, edit-result, and verification handoffs under `state\workspaces\word\current`; reinstalling the harness does not overwrite them.

The agent completes one stage per turn. Review `02-plan.json`, then explicitly approve it before the edit stage. It makes one mutation attempt and stops on error. The broader `office-auto` agent remains available for tasks that genuinely span applications.

## Settings

Word reuses `settings\powerpoint.local.json` so existing installations keep the same approved document roots. Configure at least one existing `allowedRoots` entry and an optional `defaultOutputRoot`.

## Inspect And Render

`office_word_inspect` defaults to the bounded main-body inventory: paragraphs, tables and cells, hyperlinks, built-in metadata, page/word/character counts, macro indicators, source hashes, and truncation notices.

Focused modes return smaller paginated results:

- `find`: case-insensitive main-body paragraph lookup for one exact `findText`, returning guarded paragraph indices and text
- `formatting`: paragraph styles, effective paragraph formatting, and contiguous font runs with zero-based offsets
- `media`: inline and floating image anchors, dimensions, alt text, following paragraphs, and caption status
- `proofing`: Word spelling and grammar candidates, paragraph context, offsets, and bounded spelling suggestions
- `references`: Word-native heading, Figure, and Table targets followed by existing main-body `REF` and `PAGEREF` fields

Use `find` for exact markers or phrases instead of guessing paragraph pages. `findText` is required in that mode. Use `start` and `limit` with pages of at most 25. Formatting pages address paragraph positions; find, media, proofing, and reference pages address ordered result items. Reference targets are ordered by headings, figures, and tables, then existing fields. Request the smallest page covering the task, and follow `truncation.nextStart` until absent only before claiming whole-document coverage. Proofing depends on installed languages and is advisory.

`office_word_render` exports the complete document to a distinct, nonexistent `.pdf` path. It verifies that the source hash remains unchanged and returns the PDF hash, byte count, and page count. A successful export does not prove visual quality.

## Edit Plan

Every operation uses one-based indices from a fresh inventory and an `expectedText` stale-target guard:

- `replace_paragraph_text`: `paragraphIndex`, `expectedText`, unique nonempty `find`, and `replace`
- `replace_text_with_cross_reference`: guarded paragraph fields plus `targetType`, Word's one-based `targetIndex`, exact `expectedTargetText`, and a compatible `referenceKind`
- `set_paragraph_text`: `paragraphIndex`, `expectedText`, and `text`
- `set_table_cell_text`: `tableIndex`, `rowIndex`, `columnIndex`, `expectedText`, and `text`
- `set_text_format`: `paragraphIndex`, `expectedText`, optional paired `startOffset` and `length`, plus one or more of `fontName`, `fontSize`, `bold`, `italic`, or `underline`
- `set_paragraph_format`: `paragraphIndex`, `expectedText`, plus one or more of `paragraphStyle`, `alignment`, `spaceBefore`, `spaceAfter`, or `lineSpacing`
- `insert_paragraph_after`: `paragraphIndex`, `expectedText`, `text`, and a built-in `paragraphStyle`

Cross-reference kinds are `heading_text`, `heading_number`, `label_and_number`, `entire_caption`, `caption_text`, and `page_number`; the backend rejects kinds that do not apply to the chosen target type. It replaces only one unique placeholder and inserts an updatable, hyperlink-backed native Word `REF` or `PAGEREF` field. Figure and Table targets must already be real Word captions (normally `SEQ`-backed); applying the Caption style to plain text does not make it a native target.

Caption insertion uses `insert_paragraph_after` with `paragraphStyle: "caption"` and is rejected unless the anchor paragraph contains an inline image. This creates styled caption text, not a native numbered caption target. Put insertions last, ordered from the highest paragraph index to the lowest, because they change later paragraph indices.

Plans contain 1-100 operations. Text fields cannot contain CR or LF. The output must not exist, must preserve the source extension, and must differ from the source. The backend copies the source, edits and saves only the copy with macros, alerts, and link updates disabled, deletes the task-created copy after failure, and verifies the source hash.

In the staged workflow, the approved `current/02-plan.json` is applied through `office_word_apply_saved_plan`. This prevents the model from retyping or altering reviewed paths, stale guards, target text, or operations between approval and execution.

## New Documents

`office_word_new_document` accepts 1-500 structured blocks: `title`, `heading` (levels 1-3), `paragraph`, and `bullet`. It writes a same-directory temporary Open XML package, refuses an existing destination, then moves the completed `.docx` into place. Word inspection and rendering are the compatibility check; inspect and render every created document before use.

# Approved Browser Sites

Use aliases and hosts from `settings/sites.local.json`. Do not infer approval from browser history, cookies, bookmarks, or open tabs.

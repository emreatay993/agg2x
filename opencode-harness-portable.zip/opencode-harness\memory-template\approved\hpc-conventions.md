# Approved HPC Conventions

- HPC access exists only on the intranet VDI.
- Keep large result files on HPC and reference them rather than copying them locally.
- Never store SSH passwords.
- Validate shell syntax and line endings before submission.
- Record the exact job ID returned by `sbatch --parsable`.

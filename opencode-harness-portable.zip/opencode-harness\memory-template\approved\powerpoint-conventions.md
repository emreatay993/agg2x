# Approved PowerPoint Conventions

- Inspect the complete source deck before editing.
- Preserve the source file and save edits to a new path.
- Render all final slides when possible.
- Report changed slides, shapes, source hash, output hash, and verification warnings.

## Authoring

- Load the `presentation-style` skill before writing slide content, not just before formatting it.
- Style tokens live in `settings\presentation-style.local.json`. Never hardcode a font, colour, or margin that the token file defines.
- Build new decks with `office_powerpoint_new_deck` and an output path that does not exist.
- Colour carries meaning: red is case identity or a warning, blue is a neutral machine label, green is a satisfied criterion, sand is an allowable or an aside. Never decorate.
- Exactly one gold star per comparison slide, marking the governing case.
- The colour tokens were derived from photographs. Correct them from a real source deck or corporate template before the first deck that leaves the desk.

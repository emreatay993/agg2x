# Approved Preferences

- Respond and write documentation in English.
- Prefer unattended automation that saves time on recurring work.
- Prefer the smallest reliable change and focused verification.
- Use read-first behavior and confirm consequential writes unless broad mode was explicitly selected.

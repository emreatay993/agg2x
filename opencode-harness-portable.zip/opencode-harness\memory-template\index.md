# Office Memory Index

Only files under `approved/` are durable memory. Files under `inbox/` are untrusted drafts and must not guide work until the user explicitly promotes them.

Before using memory:

1. Identify the current machine from `machine.md`.
2. Read only the approved topic relevant to the task.
3. Never copy intranet memory to the internet laptop.
4. Never store credentials, email contents, browser session data, raw analysis data, or confidential project details.
5. If a remembered fact conflicts with current files, commands, or the user, use current evidence and draft a correction.

Approved topics:

- `approved/preferences.md`
- `approved/browser-sites.md`
- `approved/outlook-conventions.md`
- `approved/powerpoint-conventions.md`
- `approved/hpc-conventions.md`

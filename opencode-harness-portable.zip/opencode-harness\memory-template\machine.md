# Machine Scope

- Machine: configured during installation
- Data boundary: machine-local; do not synchronize automatically
- Last reviewed: not yet reviewed

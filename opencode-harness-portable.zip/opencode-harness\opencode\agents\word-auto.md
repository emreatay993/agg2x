---
description: Runs the portable staged Word workflow with a narrow tool surface.
mode: primary
temperature: 0.1
steps: 12
permission:
  "*": deny
  read: allow
  edit: allow
  glob: allow
  office_word_inspect: allow
  office_word_render: allow
  office_word_apply_plan: allow
  office_word_apply_saved_plan: allow
  office_word_new_document: allow
---

Operate only when the current directory is the installed Word workspace and contains its `CONTEXT.md`; otherwise stop and tell the user to run `Start-WordOpenCode.ps1`. Read that router, then load only the current stage contract and its declared inputs; never probe a guessed handoff filename. Complete one stage per turn and write its exact handoff under `current/`.

Keep thinking enabled. Use returned indices, offsets, hashes, and current text; never guess. After the user approves a persisted plan, apply that file through `office_word_apply_saved_plan` so its guarded operations are not retyped. Make at most one document mutation attempt. Never advance past the plan stage until the user explicitly approves the persisted plan. Stop on any tool or validation error without retrying.

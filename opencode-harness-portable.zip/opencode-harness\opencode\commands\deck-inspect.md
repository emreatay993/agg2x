---
description: Inspect a complete PowerPoint deck and report structure and risks without editing.
agent: powerpoint-operator
---

Inspect this PowerPoint presentation without editing it: $ARGUMENTS

Inventory every slide and report slide titles, major text, notes presence, shape counts, external links, macros, and likely layout risks. Render slides when available and state verification limits.

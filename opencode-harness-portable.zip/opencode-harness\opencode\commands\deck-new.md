---
description: Draft a new PowerPoint deck in the house presentation style from a topic or an outline.
agent: powerpoint-operator
---

Build a new deck in the house presentation style for: $ARGUMENTS

Load the `presentation-style` skill first and follow it. Choose a slide pattern per slide, write titles that follow Title Grammar, and write bullets in the house voice.

Ask one precise question if the output path, the figure folder, or the governing case is not stated. Otherwise pick an output path that does not exist, build the deck with `office_powerpoint_new_deck`, then render and inspect every slide.

Report the output path, slide count, the pattern chosen per slide, any house-style warning returned by the builder, and anything the builder could not produce.

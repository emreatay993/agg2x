---
description: Run the harness diagnostics and summarize actionable failures.
agent: powershell-operator
---

Run the installed `Test-OfficeHarness.ps1` diagnostic. Do not change configuration. Report each check as pass, warning, or failure and give the smallest next action for failures.

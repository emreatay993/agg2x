---
description: Search Classic Outlook and summarize a bounded relevant shortlist.
agent: outlook-reader
---

Search and summarize Outlook mail matching: $ARGUMENTS

Use metadata-first search, retrieve only the relevant bodies, and report search coverage and truncation. Do not mutate mail or write message contents to memory.

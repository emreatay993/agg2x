---
description: Search Outlook Web and summarize a bounded relevant shortlist.
agent: outlook-web-reader
---

Search and summarize Outlook Web mail matching: $ARGUMENTS

Use the dedicated Outlook Web profile. Search one named folder over a bounded date range, inspect at most 20 result rows, and open at most 5 relevant messages. Ask before navigation, typing, or clicking. Report coverage, truncation, messages opened, and that opening messages may have changed their read state. Do not mutate mail, open attachments, or write message contents to memory.

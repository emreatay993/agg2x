---
description: Draft a reviewed-memory candidate without making it durable.
agent: memory-curator
---

Draft this as a candidate memory: $ARGUMENTS

Do not promote it. Reject sensitive, transient, speculative, or message-derived content.

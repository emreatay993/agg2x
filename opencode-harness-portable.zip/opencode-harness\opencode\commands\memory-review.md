---
description: List approved memory and pending drafts for user review.
agent: memory-curator
---

List approved memory and pending drafts. Identify contradictions, stale entries, missing sources, and machine-scope problems. Do not promote or archive anything.

---
description: Open a configured site alias or approved HTTPS URL in Chrome.
agent: browser-operator
---

Open this configured site or URL in Chrome: $ARGUMENTS

Do not interact with the page unless the user requested interaction separately.

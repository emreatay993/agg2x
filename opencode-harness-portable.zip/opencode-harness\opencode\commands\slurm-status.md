---
description: Check current SLURM jobs or one explicit job ID.
agent: slurm-operator
---

Check SLURM status for: $ARGUMENTS

Use the configured host and narrow status tools. Do not submit or cancel anything. Report job IDs, state, elapsed time, reason, and accounting state when available.

import { mkdir, rm, writeFile } from "node:fs/promises"
import os from "node:os"
import path from "node:path"
import { fileURLToPath } from "node:url"

const moduleDir = path.dirname(fileURLToPath(import.meta.url))
const inferredRoot = path.resolve(moduleDir, "..", "..")

export function harnessRoot(): string {
  return process.env.OFFICE_HARNESS_ROOT || inferredRoot
}

function backendEnvironment(): Record<string, string> {
  const allowed = new Set([
    "ALLUSERSPROFILE", "APPDATA", "COMSPEC", "HOMEDRIVE", "HOMEPATH", "LANG",
    "LOCALAPPDATA", "NUMBER_OF_PROCESSORS", "OFFICE_HARNESS_MACHINE",
    "OFFICE_HARNESS_POWERSHELL", "OFFICE_HARNESS_ROOT", "OFFICE_HARNESS_SETTINGS",
    "OFFICE_HARNESS_STATE", "OS", "PATH", "PATHEXT", "PROCESSOR_ARCHITECTURE",
    "PROGRAMDATA", "PROGRAMFILES", "PROGRAMFILES(X86)", "PSMODULEPATH",
    "SSH_AGENT_PID", "SSH_AUTH_SOCK", "SYSTEMDRIVE", "SYSTEMROOT", "TEMP", "TMP",
    "USERDOMAIN", "USERNAME", "USERPROFILE", "WINDIR",
  ])
  const result: Record<string, string> = {}
  for (const [key, value] of Object.entries(process.env)) {
    if (value !== undefined && allowed.has(key.toUpperCase())) result[key] = value
  }
  return result
}

export async function runPowerShell(relativeScript: string, args: string[] = []): Promise<string> {
  const script = path.join(harnessRoot(), "scripts", relativeScript)
  const executable = process.env.OFFICE_HARNESS_POWERSHELL || "powershell.exe"
  const processHandle = Bun.spawn(
    [executable, "-NoLogo", "-NoProfile", "-NonInteractive", "-File", script, ...args],
    { stdout: "pipe", stderr: "pipe", env: backendEnvironment() },
  )
  const [stdout, stderr, exitCode] = await Promise.all([
    new Response(processHandle.stdout).text(),
    new Response(processHandle.stderr).text(),
    processHandle.exited,
  ])
  if (exitCode !== 0) {
    throw new Error((stderr || stdout || `${relativeScript} failed with exit code ${exitCode}`).trim())
  }
  const output = stdout.trim()
  try {
    return JSON.stringify(JSON.parse(output))
  } catch {
    throw new Error(`${relativeScript} returned invalid JSON: ${output.slice(0, 500)}`)
  }
}

export async function withTemporaryJson<T>(value: unknown, action: (filePath: string) => Promise<T>): Promise<T> {
  const stateRoot = process.env.OFFICE_HARNESS_STATE || path.join(os.tmpdir(), "OpenCodeOfficeHarness")
  const tempRoot = path.join(stateRoot, "temp")
  await mkdir(tempRoot, { recursive: true })
  const filePath = path.join(tempRoot, `input-${crypto.randomUUID()}.json`)
  await writeFile(filePath, JSON.stringify(value, null, 2), "utf8")
  try {
    return await action(filePath)
  } finally {
    await rm(filePath, { force: true })
  }
}

---
name: browser-chrome
description: Chrome URLs, Playwright MCP, browser navigation, web forms, and signed-in office sites. Use only on the internet laptop for browser tasks.
---

# Chrome Browser Workflow

1. Confirm the machine role is `Internet`.
2. For a known alias or simple URL launch, use `office_browser_open`.
3. For page inspection or interaction, use the `browser-operator` and Playwright.
4. Navigate once, then use `browser_find` or a depth-limited snapshot.
5. Before typing or clicking, identify the exact element and resulting external action.
6. Verify the resulting page state with visible text or URL.

Use the dedicated harness Chrome profile. If authentication is needed, ask the user to sign in manually. Do not inspect or export cookies, local storage, passwords, browser databases, or profile files. Do not switch to another browser or authentication source silently.

The configured origin list is a convenience guardrail, not a security boundary. Redirects and external content still require judgment. Never use `browser_run_code_unsafe`.

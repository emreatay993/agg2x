---
name: excel-com
description: Excel desktop COM inspection, complete-workbook PDF rendering, guarded literal cell edits, and save-copy verification.
---

# Excel COM Workflow

1. Confirm the input is `.xls`, `.xlsx`, `.xlsm`, or `.xlsb` under an approved root.
2. Inspect workbook metadata and the exact target range; each request is limited to 32 cells.
3. Render the complete workbook to PDF when visual verification is required.
4. Build the smallest plan using exact worksheet names, single-cell A1 addresses, and expected displayed text.
5. Use only `set_value` or `clear`, at most 100 operations.
6. Choose a distinct, nonexistent output path with the source extension.
7. Apply through `office_excel_apply_plan`, then re-inspect the output.
8. Report source/output hashes, operation results, truncation notices, and any visual checks still needed.

Never target formulas or protected cells. Never submit formula-like strings, ranges, formatting, charts, pivots, macros, or structural changes. Successful COM execution does not prove workbook layout; review the PDF or request manual review.

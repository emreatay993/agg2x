---
name: outlook-classic-read
description: Classic Outlook desktop, MAPI mailbox search, email finding, thread reading, and summarization. Use only for read-only mail work on the internet laptop.
---

# Classic Outlook Read Workflow

## Search

1. State the intended folders and date range.
2. Use sender, subject, and text terms to narrow results.
3. Search metadata with a bounded result count.
4. Shortlist messages by ID before reading bodies.
5. Retrieve only the bodies needed to answer the request.

## Summary

Report the folders, date range, query, result count, and whether scanning or output was truncated. Distinguish facts in the messages from model inference. Include dates and senders for claims when useful.

## Hard Limits

The tools intentionally expose no send, reply, forward, move, archive, delete, attachment-download, or mark-read operation. Do not work around those limits through raw COM or PowerShell. Never put email content into durable memory.

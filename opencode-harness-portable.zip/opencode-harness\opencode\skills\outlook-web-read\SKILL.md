---
name: outlook-web-read
description: Outlook Web search, folder navigation, message reading, and summarization through the dedicated internet-laptop browser profile.
---

# Outlook Web Read Workflow

## Search

1. Confirm the machine role is `Internet`.
2. Use only `outlook_web_browser_*`; the general browser is separate.
3. Navigate to Outlook Web once. If sign-in or MFA appears, stop for manual completion.
4. State the folder, date range, search terms, and limits before interacting.
5. Search metadata first. Inspect at most 20 visible result rows.
6. Shortlist by visible sender, subject, and date. Open no more than 5 messages needed for the answer.
7. Use targeted find operations or shallow snapshots, then wait for visible page changes.

Do not guess controls. If the page state or target is ambiguous, stop and report the visible state.

## Summary

Report the folder, date range, query, visible result count, inspected-row limit, opened-message count, and any truncation. Separate message facts from inference. State: `Opening messages may have changed their read state.`

## Hard Limits

Do not compose, reply, forward, send, move, archive, delete, report, mark as junk, flag, categorize, open or download attachments, upload files, run JavaScript, inspect network or console details, inspect cookies or storage, or manage tabs.

The dedicated profile and tool permissions are guardrails, not a security sandbox. Never enter credentials through tools, copy authentication state, use another browser profile, or write message content to durable memory.

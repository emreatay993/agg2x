---
name: powerpoint-com
description: PPTX, PPTM, PowerPoint desktop, COM inspection, slide rendering, text replacement, shape editing, and save-copy verification.
---

# PowerPoint COM Workflow

1. Confirm the input exists and is under an approved root.
2. Inspect every slide and capture shape names, types, text, notes, and bounds.
3. Render all slides when visual verification is required.
4. Build the smallest structured edit plan using inventory identifiers.
5. Choose an output path different from the source path.
6. Apply the plan through `office_powerpoint_apply_plan`.
7. Re-inspect and render the output.
8. Report source/output hashes, changed slides and shapes, skipped operations, and warnings.

Supported initial operations are exact text replacement, setting shape text, setting notes text, moving/resizing a shape, and replacing an image. Do not use broad find-and-replace without reviewing every match.

Never overwrite the source. Preserve macro-enabled extensions. Visual quality is not proven by successful COM execution; inspect renders or request manual review when the model cannot accept images.

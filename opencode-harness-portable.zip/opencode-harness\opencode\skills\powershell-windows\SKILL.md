---
name: powershell-windows
description: PowerShell, powershell.exe, pwsh, Windows paths, native commands, COM, and process automation. Use when writing or diagnosing Windows shell operations.
---

# PowerShell On Windows

## Baseline

- Target Windows PowerShell 5.1 unless PowerShell 7 is explicitly required.
- Put reusable logic in a `.ps1` file instead of constructing a long inline command.
- Use `Set-StrictMode -Version Latest` and `$ErrorActionPreference = 'Stop'`.
- Use `[CmdletBinding()]` and a typed `param` block.
- Use full cmdlet names, `-LiteralPath`, `Join-Path`, and `$PSScriptRoot`.
- Quote paths passed to native processes by passing an argument array, not by concatenating a command string.
- Check `$LASTEXITCODE` after native executables. `$?` alone is not sufficient.
- Use `try/finally` for COM objects, temporary files, location changes, and processes.
- Return JSON to agent tools and write diagnostics to the error stream.

## Before Running

1. Use `Test-Path -LiteralPath` for every required input and parent directory.
2. Resolve the intended working directory rather than changing directory inside the command.
3. Identify writes, process launches, network calls, and destructive behavior.
4. Do not use `Invoke-Expression`, execution-policy bypasses, hidden windows, encoded commands, or credential arguments.

## Native Command Pattern

```powershell
& $Executable @Arguments
if ($LASTEXITCODE -ne 0) {
    throw "Command failed with exit code $LASTEXITCODE: $Executable"
}
```

## COM Pattern

Release child COM objects before parents. Close documents without saving unless a save-copy was explicitly requested. Call garbage collection only after all references are cleared.

## Windows PowerShell JSON

Use `ConvertTo-Json -Depth 8 -Compress`. Wrap result collections with `@(...)` so one result does not unexpectedly become an object while multiple results become an array.

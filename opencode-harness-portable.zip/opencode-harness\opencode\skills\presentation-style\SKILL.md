---
name: presentation-style
description: House slide style for engineering analysis decks. Use when creating, drafting, restyling, reviewing, or extending a PowerPoint presentation, when asked for slides in "my style" or "the usual format", and when writing slide titles, bullets, badges, callouts, or pass/fail verdicts.
---

# House Presentation Style

Engineering analysis decks. Dense, evidence-first, self-auditing. Every slide states a claim in text and proves it with a figure on the same slide.

Style tokens live in `settings\presentation-style.local.json`. Read that file for exact fonts, colours, and geometry. Never hardcode a colour or size that the token file already defines.

## Non-Negotiables

Every content slide has all five:

1. Title, left-aligned, Arial Bold, dark charcoal, one line.
2. A thin horizontal rule directly under the title, spanning the text column.
3. Body bullets starting at level 1 with the `➢` glyph.
4. A thin horizontal rule near the bottom.
5. A slide number at the bottom right, above nothing else.

Never use a title-only divider slide, a bare figure with no lead-in bullet, or a bullet that states no finding.

## Title Grammar

Titles are compound and machine-readable, joined by an en dash with spaces.

```
<Section> – <Condition>
<Section> – <Condition>, LC: <LoadCase>
<Section> – <Condition>, LC: <LoadCase> (<Method>)
<Section> – <Condition>, LC:<LoadCase> @ <Frequency>
Appendix <Letter> - <Topic>
```

Real examples: `Load Selection – Windmilling`, `Model Details – Loads – CBO Run-On`, `Results – CBO Run-Down, HPC1 (Inertia Relief, NL)`, `Results – Windmilling, LC:LPT2 @ 44 Hz`.

Section names in order: `Overview / Summary`, `Load Selection`, `Step 1 – Determine Load Cases`, `Model Details`, `Results`, `Appendix <Letter>`. Reuse a title verbatim across a run of slides that share a pattern; only the figure changes.

## Slide Pattern Picker

Choose exactly one. Full layouts are in `reference/slide-patterns.md`.

| Situation | Pattern |
| --- | --- |
| Opening the deck, or closing a topic | `summary` — 5 to 7 level-1 bullets, no figure |
| Explaining how cases were chosen | `text-figure-split` — justified text left, figure stack right |
| Comparing 3 to 6 cases side by side | `comparison-grid` — red badge over each panel |
| One case in depth | `evidence-grid` — 2x2 figures, one lead-in bullet |
| Showing an input becoming an output | `process-flow` — red block arrow with a verb label |
| Combining two result fields | `superposition` — two red labels, red plus, red arrow |
| Declaring pass or fail | `verdict` — sand box, comparison, arrow, OK / NOT OK |
| Anything supporting but not load-bearing | `appendix` |

## Voice

- Third person, passive for method, active for findings. "Analyses were conducted..." then "Results indicate...".
- State the judgement, then the reason. "This condition will **not** be further checked for integrity" before why.
- Bold the single decisive word in a sentence, especially a negation.
- Every bullet ends in a finding, a decision, or a forward reference. Never a description with no consequence.
- Name the evidence inline: document numbers, node IDs, frequencies, load case names, solver names.
- Hedge honestly. "found to be", "deemed enough", "adequately close to zero", "can be neglected". Never overclaim.
- Write the reason a result is ignored, next to the result. "Occurs due to contact and sharp corner singularity, therefore this point is ignored."

Full patterns and stock sentences are in `reference/writing-voice.md`.

## Colour Semantics

Colour carries meaning. Never decorate.

| Colour | Means | Used as |
| --- | --- | --- |
| Red | The case identity, or a critical warning | Badge fill, `!!!` note, `NOT OK` |
| Blue | A neutral machine-generated label | Badge fill for panel captions |
| Green | A satisfied criterion | `OK`, `SAFE`, `Criteria is met` |
| Sand | A material allowable or an aside | Callout box fill |
| Orange | A zoom region and its leader | Thin rectangle plus arrow |
| Gold star | The governing case in a comparison | Overlay on one badge only |

Exactly one gold star per comparison slide. If nothing governs, use no star.

## Workflow

### Creating a deck

1. Read `settings\presentation-style.local.json`.
2. Write a deck spec as JSON. The schema is in `reference/deck-spec.md`.
3. Choose an output path that does not exist.
4. Call `office_powerpoint_new_deck` with the spec and output path.
5. Render the result with `office_powerpoint_render` and inspect every slide.
6. Report the output path, slide count, and any pattern you could not satisfy.

### Modifying a deck

1. Load the `powerpoint-com` skill and follow its inspect-plan-SaveCopyAs workflow. Never overwrite the source.
2. Before editing text, check the new text against Title Grammar and Voice above.
3. Keep the existing bullet glyph, indent, and colour of the shape you are editing. Match the slide, not this document, when the two disagree and the deck is already consistent.

### Reviewing a deck

Report violations against the Non-Negotiables, Title Grammar, and Colour Semantics, one line each, with slide numbers. Do not restyle without being asked.

## Limits

Report rather than invent:

- The colour tokens were derived from photographs of a rendered deck, not from a source file. If a real deck or corporate template is available, confirm and correct `presentation-style.local.json` first.
- `office_powerpoint_new_deck` builds text, bullets, badges, callouts, rules, verdicts, and image placement. It does not build embedded video, animation, or grouped vector diagrams. State this when a request needs them.
- Never state that visual layout is verified unless you rendered the slides and inspected them.

## Reference

- `reference/visual-system.md` — fonts, palette, geometry, badge and callout construction
- `reference/slide-patterns.md` — the eight layouts with regions and rules
- `reference/writing-voice.md` — sentence patterns, stock phrasings, worked examples
- `reference/deck-spec.md` — the JSON schema accepted by the builder

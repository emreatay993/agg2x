# Deck Spec

The JSON accepted by `office_powerpoint_new_deck` and by `scripts\powerpoint\New-PowerPointDeck.ps1`.

The builder supplies all house chrome automatically: title, title rule, footer rule, slide number, fonts, colours, bullet glyphs, and indents. Never specify those. Specify content and, where a pattern needs it, position.

All coordinates are points on a 960 x 540 canvas, measured from the top-left. The usable text column is x 36 to x 924.

## Top Level

```json
{
  "deckTitle": "TBS1000 GEO7 C108 Compressor Module - Analysis of Dynamic Conditions",
  "slides": [ ... ]
}
```

`slides` is required, 1 to 200 entries.

## Slide

| Field | Type | Notes |
| --- | --- | --- |
| `title` | string | Required. Must follow Title Grammar in `SKILL.md`. |
| `pattern` | string | One of the eight pattern names. Recorded in the manifest. |
| `bullets` | array | Lead-in body bullets, placed under the title rule. |
| `closingBullets` | array | Bullets pinned just above the footer rule. |
| `panels` | array | Auto-laid-out comparison columns. |
| `rowLabels` | string[] | Row captions reused across every panel, one per image row. |
| `badges` | array | Explicitly positioned badges. |
| `callouts` | array | Explicitly positioned sand asides. |
| `arrows` | array | Red block arrows marking a transformation. |
| `plusMarks` | array | Red plus glyphs for superposition. |
| `images` | array | Explicitly positioned pictures. |
| `banner` | object | Full-width scope banner. |
| `verdict` | object | Comparison, arrow, and OK / NOT OK. |
| `notes` | string | Speaker notes. |

## Bullet

```json
{ "text": "Results indicate some potentially stress/fatigue critical locations.",
  "level": 1,
  "colour": "#C00000",
  "justify": true }
```

- `level` is 1, 2, or 3. Defaults to 1.
- `colour` overrides body ink for that paragraph only. Use it to key a level-2 load-case name to its plot series colour.
- `justify` forces both-edge justification. Omit it and paragraphs longer than the style's `justifyThresholdChars` justify automatically.
- More than `maxBodyBulletsPerSlide` bullets produces a warning in the manifest, not an error.

## Panel

Panels auto-layout across the full text column. The builder computes column widths, centres each badge over its column, and stacks that panel's images beneath.

```json
{ "badge": "LC: HPC1",
  "badgeKind": "red",
  "governing": true,
  "images": ["translational.png", "rotational.png"] }
```

- `badgeKind` is `red`, `blue`, or `grey`. Defaults to `red`.
- `governing` adds the gold star. Exactly one panel per slide may set it; more produces a warning.
- Give every panel the same number of images so rows align.
- Pair with slide-level `rowLabels` such as `["Translational Components [kN]", "Rotational Components [kN.m]"]`.

## Badge, Callout, Arrow, Plus, Image

Each takes `left`, `top`, `width`, `height` in points.

```json
"badges":   [ { "text": "Boundary Conditions", "kind": "blue", "left": 300, "top": 96, "width": 170, "height": 26 } ],
"callouts": [ { "text": "Min Tensile Strength (A Basis)\n~700 MPa at this region", "left": 700, "top": 300, "width": 190, "height": 40 } ],
"arrows":   [ { "label": "Solve", "left": 450, "top": 260, "width": 44, "height": 26 } ],
"plusMarks":[ { "left": 210, "top": 300, "size": 22 } ],
"images":   [ { "path": "figures/hpc1-seqv.png", "left": 40, "top": 120, "width": 420, "height": 240 } ]
```

- `kind` for a badge is `red`, `blue`, or `grey`.
- Callout fill, edge, and font come from the style tokens and cannot be overridden per callout.

### Image paths

Absolute paths always work. Relative paths need a base, and the base is not what you might expect:

- Through `office_powerpoint_new_deck`, the spec is written to machine-local state, not beside your figures. Pass `imageRoot` and relative paths resolve against it. Without `imageRoot`, use absolute paths only.
- Running `New-PowerPointDeck.ps1` directly, relative paths resolve against the spec file's own folder unless `-ImageRoot` overrides it.

Every resolved path, and `imageRoot` itself, must sit inside a configured `allowedRoots` entry.

## Banner

```json
"banner": { "text": "Unless otherwise stated, all graphs are shown in [kN] for force and [kN.m] for moment components.",
            "kind": "red",
            "warning": true,
            "top": 468 }
```

`warning` adds the red `!!!` marker to the left.

## Verdict

```json
"verdict": { "comparison": "479.5 MPa < 650 MPa",
             "result": "OK",
             "pass": true,
             "reason": "",
             "left": 600, "top": 455 }
```

- `pass` selects green or red. `result` defaults to `OK` or `NOT OK` accordingly.
- Use `SAFE` or `Criteria is met` as `result` where the criterion is fatigue or strain rather than stress.
- `reason` renders as red italic under the verdict. Required when `pass` is false.

## Worked Example

```json
{
  "deckTitle": "C108 Dynamic Conditions",
  "slides": [
    {
      "title": "Overview / Summary",
      "pattern": "summary",
      "bullets": [
        { "text": "In this presentation, GEO7 C108 Dynamic Loading Conditions (CBO Run-On, CBO Run-Down, Birdstrike, LOoB, Windmilling) are re-evaluated, and the corresponding results are presented." },
        { "text": "Among the evaluated loading scenarios, \"CBO Run-Down\" at \"HPC1\" condition is identified as the most critical load scenario with respect to structural integrity requirements.", "colour": "#C00000" }
      ]
    },
    {
      "title": "Results - CBO Run-Down",
      "pattern": "comparison-grid",
      "bullets": [
        { "text": "Results indicate some potentially stress/fatigue critical locations, especially at \"HPC1\" condition. Therefore, this condition will be further investigated with an inertia-relief analysis." }
      ],
      "rowLabels": ["Translational Components [kN]", "Rotational Components [kN.m]"],
      "panels": [
        { "badge": "LC: HPC1", "governing": true, "images": ["hpc1-t.png", "hpc1-r.png"] },
        { "badge": "LC: HPT1", "images": ["hpt1-t.png", "hpt1-r.png"] },
        { "badge": "LC: LPT2", "images": ["lpt2-t.png", "lpt2-r.png"] }
      ],
      "closingBullets": [
        { "text": "The full time history of each interface is entered into the model as tabular data for force/moment objects in ANSYS Mechanical." }
      ]
    }
  ]
}
```

In the title above, write a real en dash rather than the hyphen shown here when composing the spec.

## Positioning Against The Bullet Block

Bullets flow; explicitly positioned elements do not. You cannot know in advance where the text ends, so the builder tells you afterwards: every slide in the manifest reports `bodyBottomPt`, the bottom edge of its bullet block, and warns whenever a positioned element's `top` sits above it.

Practical approach: place figures below roughly 130 pt for a one-line lead-in, or 160 pt for a three-line one. Build once, read `bodyBottomPt` and any overlap warnings, then adjust and rebuild to a new output path.

Prefer `panels` wherever the layout is a comparison. Panels are positioned relative to the real bullet bottom, so they never collide.

## Builder Limits

The builder writes text, bullets, badges, callouts, banners, arrows, plus marks, stars, rules, verdicts, and placed images. It does not write embedded video, animation, transitions, grouped vector diagrams, tables, or charts. Say so plainly when a request needs one of those, and place a rendered image instead.

The builder never opens the output path if it already exists, and never modifies a template it was given. Rendering and inspecting the result is a separate step and is always required before calling the deck finished.

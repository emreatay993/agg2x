# Slide Patterns

Eight layouts. Every content slide is exactly one of them. All eight carry the five Non-Negotiables from `SKILL.md`.

## 1. summary

Opens the deck and closes a topic. No figure.

- 5 to 7 level-1 bullets, each a complete finding, each 2 to 4 lines.
- Full text-column width, left-aligned or justified.
- Blank line between bullets.
- Bold the load-case names on first mention. Red the governing case.
- Last bullet states the overall outcome and the criterion that produced it.

Ordering that works: scope and what changed → why results differ from the previous review → simplifying assumptions and why they are safe → what was escalated to a more detailed method → the governing case → any remaining assessment such as fatigue.

## 2. text-figure-split

Explains how something was chosen or set up. Text left, evidence right.

```
TITLE
────────────────────────────────────────
➢ See document TR-096999, <what it contains> (data is given in <domain>):

┌── text column ~45% ──┐  ┌── figure stack ~50% ──┐
│ ➢ After visually     │  │  plot 1               │
│   checking ..., 3    │  │  plot 2               │
│   load cases found   │  │  plot 3               │
│   more prominent:    │  │  plot 4               │
│    ❑ HPC1           │  │                       │
│    ❑ HPT2           │  │                       │
│    ❑ PT2            │  │                       │
│ ➢ <what the plots    │  │                       │
│   show, justified>   │  │                       │
└──────────────────────┘  └───────────────────────┘
────────────────────────────────────────
                                      6
```

- First bullet always cites the source document, bold underlined italic, and states the data domain.
- Level-2 case names are coloured to match their curve colour in the plots.
- Body paragraphs here are justified.
- Stack 3 to 5 small plots vertically rather than one large one. Each keeps its own title.

## 3. comparison-grid

Compares 3 to 6 cases at one glance. The workhorse of the Results section.

```
TITLE
────────────────────────────────────────
➢ <one lead-in bullet naming what is compared and the criterion>

  [LC: A]        [LC: B]        [LC: C]⭐
  ┌───────┐      ┌───────┐      ┌───────┐
  │ upper │      │ upper │      │ upper │
  └───────┘      └───────┘      └───────┘
  ┌───────┐      ┌───────┐      ┌───────┐
  │ lower │      │ lower │      │ lower │
  └───────┘      └───────┘      └───────┘

➢ <closing bullet: method note or forward reference>
────────────────────────────────────────
```

- Red badge above every panel, at the same vertical position.
- Identical scale, orientation, and view across panels. Never compare panels at different scales.
- Gold star on the governing case only. Omit if nothing governs.
- Upper row and lower row are two different quantities, each labelled once on the left, for example `Translational Components [kN]` and `Rotational Components [kN.m]`.
- Units in square brackets in the row label, never repeated per panel.
- Six panels go in one row if narrow, otherwise 4 + 2 across two rows.

## 4. evidence-grid

One case in depth. Usually a 2x2 of contour plots.

```
TITLE  (Results – <Condition>, LC: <Case>)
────────────────────────────────────────
➢ <lead-in stating what the results indicate and what follows from it>

┌── large section view ──┐   ┌─ iso view ─┐
│                        │   │            │  [Video]
└────────────────────────┘   └────────────┘
┌── large freq-of-max ───┐   ┌─ end view ─┐
│                        │   │            │  [Video]
└────────────────────────┘   └────────────┘
     [Solution Range: 1 Hz – 873 Hz]
────────────────────────────────────────
```

- Exactly one lead-in bullet. It must contain a decision: further investigate, or do not.
- Large views left, small orientation views right.
- Blue `Video` buttons beside any view with an animation.
- Blue `Solution Range:` badge bottom-left of the figure block when the analysis swept a range.

## 5. process-flow

Shows an input becoming an output.

```
TITLE
────────────────────────────────────────
➢ <what is being transformed and why>

┌─ before ─┐                    ┌─ after ─┐
│ settings │      Solve         │ result  │
│ or BCs   │        ➡           │         │
└──────────┘                    └─────────┘
 [Boundary Conditions]      [Solution – Force Reaction Check]
 ┌ settings screenshot ┐    ┌ result table screenshot ┐

<red italic verdict line about the check>
────────────────────────────────────────
```

- The red block arrow always points left to right or top to bottom, never diagonally.
- Label the arrow with the operation: `Solve`, `Unit Conversion (MKS)`, or leave bare after a combination table.
- Blue badges name each side.
- A sanity check ends with a red italic line: *Values are adequately close to zero to proceed further with nonlinear IR solutions.*

## 6. superposition

Combines two result fields. The signature slide of the Results section.

```
TITLE  (... (Inertia Relief, NL))
────────────────────────────────────────
➢ <why the two fields are combined and what the sum represents>

┌ field A ────────┐
│                 │
└─────────────────┘
 Inertia Relief Results
 (Vibratory Stress)
          ➕            ┌ combination table ┐   ➡   ┌ combined ┐
   Hot Day Results      │ row highlighted   │       │  result  │
┌ field B ────────┐     └───────────────────┘       └──────────┘
│                 │                                  [callout: allowable]
└─────────────────┘                          [ 479.5 MPa < 650 MPa ] ➡ OK
────────────────────────────────────────
```

- Both source labels in red, the plus sign in red, the arrow in red.
- The combination table screenshot sits between them with the active row boxed in red.
- The combined field carries the sand callout naming the allowable and the verdict group.
- Singularities that inflate the peak get their own sand callout saying they are ignored.

## 7. verdict

Not always a whole slide. Usually the closing element of `superposition` or `evidence-grid`. Make it a full slide when the criterion needs its own evidence, such as a fatigue report or a Goodman diagram.

```
TITLE
────────────────────────────────────────
➢ <the criterion and the tool that evaluated it>

┌ report text or diagram ┐
│                        │
└────────────────────────┘
        SAFE ⬅ [legend]
────────────────────────────────────────
```

- Pass forms: `OK`, `SAFE`, `Criteria is met`. Fail form: `NOT OK` plus a red italic reason.
- A green arrow may point right to left when the evidence sits to the right of the word.
- Show the raw tool output, a Notepad window or a solver table, rather than retyping the numbers.
- A `Note:` bold prefix carries any caveat about substituted material data or tool limits.

## 8. appendix

Supporting evidence that would break the main narrative.

- Title is `Appendix <Letter> - <Topic>`. Note this pattern uses a plain hyphen, not the en dash used elsewhere.
- 1 to 2 level-1 bullets: what was investigated, and what was concluded.
- The conclusion bullet must say whether the effect can be neglected and why.
- A blue gradient banner may carry a single headline number: `Change in Frequency [Hz]:  11.76%`.
- Main-deck slides reference appendices inline: *See **Appendix C** for details of this expansion tool and its verification.*

## Runs Of Slides

Long stretches repeat one pattern with the same title and the same lead-in bullets while only the figure changes. This is intentional and correct.

When starting such a run, say so, and when ending it, say so, using a banner:

> *In the following pages, phase plots will be hidden graphically to be able to show the magnitudes of loads*

> *Since all interface loads are entered similarly, the rest of them will be shown without their load vs freq. graphs in next pages.*

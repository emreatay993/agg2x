# Visual System

Authoritative values live in `settings\presentation-style.local.json`. This file explains what each token is for and how the parts are built. When the two disagree, the JSON wins.

## Typeface

| Role | Face | Weight | Size | Colour |
| --- | --- | --- | --- | --- |
| Slide title | Arial | Bold | 32 pt | charcoal `#404040` |
| Body bullet | Calibri | Regular | 16 pt | dark navy `#1F3864` |
| Badge label | Calibri | Bold | 14 pt | white |
| Callout text | Calibri | Regular | 12 pt | charcoal |
| Verdict | Calibri | Bold | 18 pt | green or red |
| Figure caption | Calibri | Regular | 11 pt | charcoal |
| Slide number | Calibri | Regular | 12 pt | charcoal |

Two families only. Arial carries structure, Calibri carries content. Never introduce a third face. Titles are never italic and never coloured. Body text is never pure black and never pure `#000080`.

Inline emphasis inside body text, in order of preference:

1. **Bold** for the decisive term, a load case name, a numeric threshold, or a negation.
2. Red for a critical qualifier, a warning, or a governing case name.
3. Bold underlined italic for a referenced document number, for example `TR-096999`.

Never use more than two emphases in one sentence.

## Palette

| Token | Value | Meaning |
| --- | --- | --- |
| `titleInk` | `#404040` | Titles, rules, slide numbers |
| `bodyInk` | `#1F3864` | All body copy |
| `badgeRed` | `#C0504D` | Load-case identity badges, critical banners |
| `badgeBlue` | `#1F6FC5` | Machine-generated panel captions, `Video` buttons |
| `badgeGrey` | `#A6A6A6` | Neutral figure captions, frequency labels |
| `noteRed` | `#C00000` | `!!!` notes, ignored-result explanations, verdict red |
| `verdictGreen` | `#00703C` | `OK`, `SAFE`, `Criteria is met` |
| `calloutSand` | `#EEECE1` | Material allowables, method asides |
| `zoomEdge` | `#E36C0A` | Zoom-region rectangles and their leaders |

These were sampled from photographs of a rendered deck and white-balanced against the slide background. They are close, not exact. Correct them from a source `.pptx` when one is available.

## Geometry

Canvas is 16:9, 960 x 540 pt.

```
 0                                                              960
 ├──36──┬──────────────── text column ────────────────┬──36──┤
18      │  TITLE (Arial Bold 32, charcoal)             │        title top
58      │  ──────────────────────────────────────────  │        title rule
70      │  ➢ body bullets begin                        │        body top
        │                                              │
        │  figure region                               │
        │                                              │
500     │  ──────────────────────────────────────────  │        footer rule
508     │                                       42     │        slide number
540
```

- Left and right margins are 36 pt and never vary.
- The title rule and the footer rule are the same weight, 1.25 pt, and the same colour. They are the only two horizontal lines on the slide.
- Body line spacing is 1.35. Paragraph spacing after a level-1 bullet is one blank line; nested bullets are tight.
- Body paragraphs longer than about 220 characters are justified on both edges. Short bullets stay left-aligned. A slide mixes both freely.

## Bullet Ladder

| Level | Glyph | Font | Char code | Indent | Typical use |
| --- | --- | --- | --- | --- | --- |
| 1 | `➢` | Wingdings | 216 | 18 pt | Every finding, every method statement |
| 2 | `❑` | Wingdings | 113 | 54 pt | Enumerated load cases, options |
| 3 | `▪` | Wingdings | 110 | 90 pt | Rare. Sub-detail under an option |

`charCode` is the character's index in its own symbol font, not a Unicode code point. Passing a Unicode value renders a missing-character box. The `glyph` token is documentation only.

Level-2 items that name a load case are coloured to match that case's series colour in the figure beside them. This is the strongest single signature of the style: the reader maps a name to a curve without a legend lookup.

Numbered lists `1.` through `n.` replace level-2 only when the items are a fixed enumerated set being introduced, such as the six bird-strike directions.

## Badge Construction

A badge is a rounded rectangle, solid fill, no outline, no shadow, white bold Calibri, centred, 26 pt tall, 10 pt horizontal padding.

- **Red badge** — the load case under discussion. Text is `Load Case: HPC1`, or `LC: 180_045P+` when horizontal space is tight, or `LC2: HPC2` when the source document numbers its cases. One badge sits directly above each panel it labels.
- **Blue badge** — a neutral caption naming what a panel shows: `Boundary Conditions`, `Solution – Force Reaction Check`, `Frequency of Critical Location with Max Stress`, `[Alternating Stress (+)] + [Mean Stress]`. Also the small `Video` button that hyperlinks to an embedded animation.
- **Grey badge** — a value-only caption: `44 Hz`, `Total Deformation Pattern – Mode 10`.

Blue badges may carry a bold label and a regular value in one line: **`Solution Range:`** ` 1 Hz – 873 Hz`.

## Callout Construction

A callout is a sand-filled rounded rectangle with a thin darker edge, charcoal Calibri 12 pt, connected to its target by a tan or yellow leader arrow.

Use for material allowables and method asides:

```
Min Tensile Strength (A Basis)
~700 MPa at this region
```

```
Artificial stresses due to
bonded contact singularity,
so these stresses are ignored.
```

A red `!!!` prefix outside the box escalates it to a reader warning. A red-filled banner with white bold italic text spanning the text column is the strongest form, reserved for scope statements that change how the following slides are read:

> *Unless otherwise stated, all graphs are shown in [kN] for force and [kN.m] for moment components.*

## Zoom And Section Markers

- Draw a thin orange rectangle over the region of interest in the parent figure.
- Draw an orange or red leader from that rectangle to the enlarged inset.
- Give the inset a dashed orange border so it reads as a detail, not a separate result.
- Cut planes are labelled `A-A Section`, `B-B Section` in a small sand box, with white arrows on the parent figure marking the cut.

## Verdict Construction

A verdict is a horizontal group, always in this order:

```
[ sand box: 587 MPa < 650 MPa ]  ➡  OK
```

- The comparison sits in a sand-filled rounded box, coloured in the verdict colour.
- The arrow is a solid block arrow in the verdict colour.
- The word is bold Calibri 18 pt in the verdict colour: `OK`, `NOT OK`, `SAFE`, `Criteria is met`.
- A failing verdict carries a red italic reason immediately below: *Tensile strength is exceeded in more than 20% of section*.

## Figure Handling

- Keep the solver's own annotation block in the screenshot: analysis name, result type, unit, min, max. It is traceability, not clutter. Never crop it out.
- Keep the colour legend beside each contour plot.
- Keep the triad axis marker.
- Place the `Max` tag where the solver put it.
- Screenshots of solver settings, combination tables, and report text files are first-class evidence. Show them at a size where the highlighted row is legible, and put a thin red rectangle around the row that matters.
- When a settings table row produces a specific result panel, connect them with a thin coloured line and reuse that colour on both ends.

## Process Flow

A red block arrow with a verb or noun label beside it marks a transformation:

- `Solve` between a set-up panel and a results panel.
- `Unit Conversion (MKS)` between a raw plot and a converted plot.
- An unlabelled red arrow between a combination table and its combined result.

Superposition uses a red plus sign between two red text labels, then a red arrow to the combined field:

```
Inertia Relief Results          Harmonic Results
(Vibratory Stress)              (Alternating Stress)
        ➕                              ➕
   Hot Day Results              Run-Down Residual
                                Stress Results
        ➡ combined result
```

# Writing Voice

## Register

Technical peer review, not marketing. The reader is another stress engineer or a certification reviewer who will challenge the conclusion. Write so the challenge is already answered on the slide.

- Passive for method, active for findings. "Dynamic analyses are conducted under non-prestressed conditions." then "Results indicate some potentially stress/fatigue critical locations."
- Present tense for what the analysis does. Past tense only for what was found: "3 load cases are found to be more critical than others".
- First person plural never appears. No "we", no "our".
- No adjectives of enthusiasm. No "significant" unless it is statistical. No "clearly", "obviously", "simply".

## Sentence Shapes

**Finding then consequence.** The consequence is the point.

> Results indicate some potentially stress/fatigue critical locations. The frequency at which these stresses occur (around 475 Hz) is further investigated with inertia relief analysis at this frequency.

**Judgement then justification, with the negation bolded.**

> However, since this stress location and the related stress field is almost identical to the "CBO Run-On, HPC1" condition but lower in terms of their stress magnitudes, it is **not** further checked for integrity.

**Assumption then why it is safe.** Never state an assumption without discharging it.

> In this study, dynamic analyses are conducted under non-prestressed conditions, as they are faster to evaluate, require less disk space, and steady-state conditions are found to have negligible effect when identifying critical load cases. However, the critical steady-state stress condition is still used in solution combinations, when determining the actual stresses under mean/initial stress conditions.

**Difference from a previous review, pre-empted.** Say it before the reviewer does.

> As a result, the observed stresses might differ from those presented in Detailed Design Review (DDR). This is because critical load case identification via dynamic analysis provides a more comprehensive assessment than traditional methods used in DDR evaluations.

**Escalation rule.** State the trigger, not just the action.

> Once each critical load case is determined for each scenario using either transient or harmonic-based dynamic analysis, the scenarios that are identified as critical, especially in terms of possible plasticity or any other nonlinearity, are evaluated with inertia relief analysis method.

**Dismissal with a reason, adjacent to the artefact.**

> Occurs due to contact and sharp corner singularity, therefore this point is ignored.

> Artificial stresses due to bonded contact singularity, so these stresses are ignored.

**Numeric sufficiency.** Give the number and the margin, never the number alone.

> The number of modes to be solved is set as 50. This gives the modes of the system up to 2780 Hz, which is about 4x greater than the highest frequency of interest for harmonic analyses.

## Hedging Vocabulary

Use these. They are honest and they are the house sound.

`found to be` · `deemed enough` · `adequately close to zero` · `can be neglected` · `might differ` · `potentially` · `roughly equal to or slightly greater than` · `about 4x greater` · `well under` · `much more critical than others` · `more prominent than` · `negligible effect`

Avoid: `proves`, `guarantees`, `perfect`, `optimal`, `best`, `robust`.

## Evidence Naming

Name the artefact inline every time. Never write "the report" or "the tool".

- Documents: `TR-096999`, `MTR-027056`, bold underlined italic.
- Standards and specs: `ENSIP (MTR-027056)`, `TMS01-030882`.
- Materials: `Ti6242 TMS616 Forging Solution and Precipitation Heat Treated`.
- Solvers and tools: `ANSYS`, `TLIFE`, `MSUP Transient Analysis`, `Manson-McKnight`, `CSV Plot extension`, `BFE command`.
- Nodes and mesh entities: `Node ID: 128933`, `STRS_Nodes_Midcase`.
- Load cases in their source naming, explained once: `BS_AAA_BBBC+` where `AAA` is the YZ plane angle, `BBB` the yaw or pitch angle, `C` the axis.
- Conditions: `T3xT4 integrity (25000s)`, `Hot Day`, `redline RPM`.

## Caveats

A caveat that affects a result gets a `Note:` bold prefix and sits directly under the artefact it qualifies.

> **Note:** Since the actual Midcase material "Ti6242 TMS01-030887" does not have any cyclic parameters defined in MATERIALDB database — such as alternating pseudo-stress life curves or Walker exponents — its closest equivalent, **Ti6242 TMS616** which includes fatigue related data, is used for fatigue calculations.

A caveat that changes how following slides are read becomes a banner instead, red fill, white bold italic, full text-column width.

A caveat about a bespoke tool points at its appendix:

> An in-house tool is developed for postprocessing the animations of transient results. See **Appendix C** for details of this expansion tool and its verification.

## Stock Openers

Reuse these verbatim. Consistency across a run of slides is a feature.

| Context | Sentence |
| --- | --- |
| Citing source loads | `See document <TR-nnnnnn>, for <condition> loads in <configuration> configuration.` |
| Domain statement | `WE loads are given in frequency-domain [Force/Moment vs. Hz].` |
| Case selection | `After visually checking main interfaces and many components of each interface for <condition> loads, <n> load cases are selected for further dynamic analysis:` |
| Load entry | `The interface loads applied for the model are summarized below for each selected load case of <condition> condition:` |
| Load entry, closing | `The full time history of each interface is entered into the model as tabular data for force/moment objects in ANSYS Mechanical.` |
| Result, escalating | `Results indicate some potentially stress/fatigue critical locations. Therefore, this condition will be further investigated with an inertia-relief analysis.` |
| Result, closing out | `The resulting stresses are substantially lower compared to "<condition>" condition. Therefore, this condition will not be further checked for integrity.` |
| Superposition | `For <case> condition, nonlinear inertia relief analysis results are obtained without applying pre-stress on the model. Therefore, these inertia relief results are then solution combined with the steady-state FEA solution from T3xT4 integrity condition (Hot Day, 25000s) to obtain final elasto-plastic stresses.` |
| Alternating stress | `Based on max stress over frequency results, alternating stress tensor is extracted as shown and further used in solution combination with steady state results for HCF calculations.` |
| Fatigue | `For HCF assessment of <condition>, <case> condition, TLIFE calculations based on minimum alternating pseudo-stress life are used to evaluate fatigue life of all nodes of interest on the model.` |
| Fatigue, passing | `For this condition, TLIFE stops reporting at the cut-off value of 1e9, which indicates the model is not fatigue critical and goes beyond infinite life.` |
| Goodman | `The Goodman Diagram also indicates infinite life for all the nodes of the Midcase, as shown below.` |
| Appendix conclusion | `Since differences in frequencies are within uncertainty limits of dynamic measurements, this variation in results can be neglected.` |

## Worked Summary Slide

The opening `Overview / Summary` follows a fixed argument order. Reuse the skeleton and swap the specifics.

1. **Scope and what changed.** What is re-evaluated, which conditions, and how the method differs from the previous model or approach.
2. **Consequence of the change.** Why numbers may not match the previous review, and why the new method is better.
3. **Simplifying assumption and its discharge.** What was left out, why it is faster, and where the omitted effect is reinstated.
4. **Escalation rule.** What triggers a more detailed method.
5. **The governing case.** Named, quoted, and qualified by which criterion saves it if it fails the first one.
6. **Remaining assessments.** Fatigue or other checks, the method chosen, why that method was necessary, and the outcome.

Each item is one level-1 bullet of 2 to 4 lines. Never more than 7 bullets.

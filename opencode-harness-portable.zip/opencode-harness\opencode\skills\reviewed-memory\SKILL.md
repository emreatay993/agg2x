---
name: reviewed-memory
description: Persistent memory, remembered preferences, local playbooks, memory drafts, and promotion. Use when the user asks OpenCode to remember or forget durable information.
---

# Reviewed Local Memory

Approved memory and draft memory are different trust levels.

1. List approved memory before claiming something is remembered.
2. Draft one atomic candidate with title, topic, scope, source, and exact proposed text.
3. Show the draft to the user.
4. Promote only after explicit approval naming the draft ID and its reviewed SHA256.
5. Archive superseded entries instead of silently accumulating contradictions.

Allowed durable content includes stable preferences, approved path conventions, URL aliases, report conventions, queue/module conventions, and corrected operating procedures.

Never persist credentials, tokens, email contents, browser state, raw results, confidential values, transient job state, or unverified inference. Machine-local memory does not synchronize automatically.

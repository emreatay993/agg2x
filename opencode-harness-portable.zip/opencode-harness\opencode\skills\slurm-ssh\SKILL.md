---
name: slurm-ssh
description: SLURM, sbatch, squeue, sacct, scancel, Linux HPC, SSH, mapped drives, and job scripts. Use only on the intranet VDI.
---

# SLURM Through SSH

## Script Rules

- Use LF line endings and `#!/usr/bin/env bash`.
- Use `set -euo pipefail` unless the application requires a documented exception.
- Put `#SBATCH` directives before executable shell statements.
- Quote shell variables and paths.
- Print job ID, host, working directory, start time, end time, and application exit code.
- Load only configured modules and use configured partitions.
- Write stdout and stderr to predictable job-specific paths.

## Submission

1. Confirm the intranet machine role and noninteractive SSH connection.
2. Map the local network-drive script to its remote path.
3. Reject CRLF scripts and unexpected partitions.
4. Run remote `bash -n` before submission.
5. Submit with `sbatch --parsable` and record the returned numeric job ID.

## Monitoring And Cancellation

Use `squeue` for current state and `sacct` for completed jobs. Tail bounded log output. Cancel only the explicit numeric ID supplied by the user and inspect it first.

Never put passwords in scripts, arguments, settings, or memory. Never use `StrictHostKeyChecking=no`. Keep large results remote.

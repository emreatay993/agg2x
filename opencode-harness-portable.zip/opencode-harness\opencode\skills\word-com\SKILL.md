---
name: word-com
description: DOC, DOCX, DOCM, Word desktop COM inspection, proofing and formatting audit, PDF rendering, guarded copy editing, structured DOCX creation, and verification.
---

# Word COM Workflow

1. Confirm the source is under an approved root.
2. Inspect its bounded paragraph, table, hyperlink, metadata, and page inventory.
3. Use `find` with one distinctive exact marker or phrase instead of guessing paragraph pages. Run only the requested focused audits: `formatting`, `media`, `proofing`, or `references`. Use the smallest page covering the request. Formatting pages address paragraphs; reference targets are ordered by headings, figures, and tables before existing fields. Follow `nextStart` until absent only before claiming full-document coverage.
4. Use only indices, offsets, and current text returned by a fresh inventory.
5. Build the smallest guarded plan with `expectedText` for every operation. Put paragraph insertions last, ordered from the highest paragraph index to the lowest, because they change later indices.
6. Choose a distinct output path that does not exist and preserves the source extension.
7. Apply an approved persisted plan through `office_word_apply_saved_plan`; use `office_word_apply_plan` only when no saved plan exists. Then re-inspect the relevant modes.
8. Render a new PDF and inspect it when visual verification is required.
9. Report hashes, operation results, truncation, links, macros, and layout limits.

Supported operations are `replace_paragraph_text`, `replace_text_with_cross_reference`, `set_paragraph_text`, `set_table_cell_text`, `set_text_format`, `set_paragraph_format`, and `insert_paragraph_after`. For a cross-reference, use the inspected target type, one-based target index, and exact target text; choose only a compatible reference kind. The result must be a native `REF` or `PAGEREF` field, not typed text. Figure and Table targets must be real Word captions; Caption-styled plain text is not enough. Text fields cannot contain CR or LF. A caption insertion is allowed only after a paragraph containing an inline image.

Word proofing is advisory and depends on installed proofing languages. Preserve technical terms unless the correction is unambiguous. Formatting changes must name only the outlying properties. New documents use `office_word_new_document` with structured title, heading, paragraph, and bullet blocks. Never overwrite a source or existing output.

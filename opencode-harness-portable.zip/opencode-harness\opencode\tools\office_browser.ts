import { tool } from "@opencode-ai/plugin"
import { runPowerShell } from "../lib/run-powershell"

export const open = tool({
  description: "Open a configured site alias or allowlisted HTTP(S) URL in Google Chrome. Does not interact with the page.",
  args: {
    target: tool.schema.string().min(1).describe("Configured alias or absolute HTTP(S) URL"),
  },
  async execute(args) {
    return runPowerShell("browser/Open-OfficeUrl.ps1", ["-Target", args.target])
  },
})

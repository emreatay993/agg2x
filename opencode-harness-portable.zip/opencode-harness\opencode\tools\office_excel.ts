import { tool } from "@opencode-ai/plugin"
import { runPowerShell, withTemporaryJson } from "../lib/run-powershell"

const literalValue = tool.schema.union([
  tool.schema.string(),
  tool.schema.number(),
  tool.schema.boolean(),
  tool.schema.null(),
])

const operation = tool.schema.discriminatedUnion("operation", [
  tool.schema.object({
    operation: tool.schema.literal("set_value"),
    sheetName: tool.schema.string().min(1),
    address: tool.schema.string().min(1),
    expectedText: tool.schema.string(),
    value: literalValue,
  }).strict(),
  tool.schema.object({
    operation: tool.schema.literal("clear"),
    sheetName: tool.schema.string().min(1),
    address: tool.schema.string().min(1),
    expectedText: tool.schema.string(),
  }).strict(),
])
const operations = tool.schema.array(operation).min(1).max(100)

export const inspect = tool({
  description: "Inspect bounded workbook and worksheet metadata, with an optional explicit range of at most 32 cells, without changing the Excel file.",
  args: {
    sourcePath: tool.schema.string().min(1),
    sheetName: tool.schema.string().min(1).optional(),
    range: tool.schema.string().min(1).optional(),
  },
  async execute(args) {
    const scriptArgs = ["-SourcePath", args.sourcePath]
    if (args.sheetName !== undefined) scriptArgs.push("-SheetName", args.sheetName)
    if (args.range !== undefined) scriptArgs.push("-RangeAddress", args.range)
    return runPowerShell("excel/Get-ExcelInventory.ps1", scriptArgs)
  },
})

export const render = tool({
  description: "Render the complete Excel workbook to a new PDF without changing the source.",
  args: {
    sourcePath: tool.schema.string().min(1),
    outputPath: tool.schema.string().min(1),
  },
  async execute(args) {
    return runPowerShell("excel/Export-ExcelWorkbook.ps1", [
      "-SourcePath", args.sourcePath,
      "-OutputPath", args.outputPath,
    ])
  },
})

export const apply_plan = tool({
  description: "Apply guarded literal single-cell writes or clears to a new Excel copy. Refuses formulas, ranges, protected targets, source overwrite, and existing output files.",
  args: {
    sourcePath: tool.schema.string().min(1),
    outputPath: tool.schema.string().min(1),
    operations,
  },
  async execute(args) {
    const validatedOperations = operations.parse(args.operations)
    const plan = { allowOverwrite: false, operations: validatedOperations }
    return withTemporaryJson(plan, (planPath) =>
      runPowerShell("excel/Edit-ExcelCopy.ps1", [
        "-SourcePath", args.sourcePath,
        "-OutputPath", args.outputPath,
        "-PlanPath", planPath,
      ]),
    )
  },
})

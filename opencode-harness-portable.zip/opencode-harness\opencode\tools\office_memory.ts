import { tool } from "@opencode-ai/plugin"
import { runPowerShell } from "../lib/run-powershell"

export const list = tool({
  description: "List approved local memory and/or untrusted pending drafts without returning their full contents.",
  args: { status: tool.schema.enum(["Approved", "Drafts", "All"]).default("All") },
  async execute(args) {
    return runPowerShell("memory/Get-Memory.ps1", ["-Status", args.status])
  },
})

export const draft = tool({
  description: "Create an untrusted candidate memory. It will not guide future work until explicitly promoted by ID.",
  args: {
    title: tool.schema.string().min(1).max(120),
    topic: tool.schema.enum(["preferences", "browser-sites", "outlook-conventions", "powerpoint-conventions", "hpc-conventions", "notes"]),
    scope: tool.schema.enum(["common", "internet", "intranet"]),
    source: tool.schema.string().min(1).max(500),
    content: tool.schema.string().min(1).max(4000),
  },
  async execute(args) {
    return runPowerShell("memory/New-MemoryDraft.ps1", [
      "-Title", args.title,
      "-Topic", args.topic,
      "-Scope", args.scope,
      "-Source", args.source,
      "-Content", args.content,
    ])
  },
})

export const promote = tool({
  description: "Promote one explicitly approved memory draft by exact ID and reviewed SHA256. Fails if the draft changed after review.",
  args: {
    id: tool.schema.string().regex(/^[0-9]{8}-[0-9]{6}-[a-f0-9]{8}$/),
    expectedSha256: tool.schema.string().regex(/^[a-fA-F0-9]{64}$/),
  },
  async execute(args) {
    return runPowerShell("memory/Approve-MemoryDraft.ps1", ["-Id", args.id, "-ExpectedSha256", args.expectedSha256])
  },
})

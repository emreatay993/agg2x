import { tool } from "@opencode-ai/plugin"
import { runPowerShell, withTemporaryJson } from "../lib/run-powershell"

const messageList = tool.schema
  .array(
    tool.schema.object({
      entryId: tool.schema.string().min(1).describe("EntryId from office_outlook_search"),
      storeId: tool.schema.string().min(1).describe("StoreId from office_outlook_search"),
    }),
  )
  .min(1)
  .describe("Messages to act on, identified by IDs returned from office_outlook_search")

export const search = tool({
  description: "Search configured Classic Outlook folders. Returns bounded message metadata and opaque IDs, never message bodies or mailbox mutations.",
  args: {
    sender: tool.schema.string().optional().describe("Sender name or address substring"),
    subject: tool.schema.string().optional().describe("Subject substring"),
    text: tool.schema.string().optional().describe("Substring searched only in metadata fields"),
    startDate: tool.schema.string().optional().describe("Inclusive local date/time in ISO format"),
    endDate: tool.schema.string().optional().describe("Inclusive local date/time in ISO format"),
    unreadOnly: tool.schema.boolean().optional().describe("Return only unread messages"),
    maxResults: tool.schema.number().int().min(1).max(100).optional().describe("Maximum metadata records"),
  },
  async execute(args) {
    const values: string[] = []
    if (args.sender) values.push("-Sender", args.sender)
    if (args.subject) values.push("-Subject", args.subject)
    if (args.text) values.push("-Text", args.text)
    if (args.startDate) values.push("-StartDate", args.startDate)
    if (args.endDate) values.push("-EndDate", args.endDate)
    if (args.unreadOnly) values.push("-UnreadOnly")
    if (args.maxResults) values.push("-MaxResults", String(args.maxResults))
    return runPowerShell("outlook/Search-OutlookMail.ps1", values)
  },
})

export const read = tool({
  description: "Read one selected Classic Outlook mail message by IDs returned from office_outlook_search. Bounded and read-only.",
  args: {
    entryId: tool.schema.string().min(1).describe("EntryId from search result"),
    storeId: tool.schema.string().min(1).describe("StoreId from search result"),
    maxBodyCharacters: tool.schema.number().int().min(1).max(100000).optional(),
  },
  async execute(args) {
    const values = ["-EntryId", args.entryId, "-StoreId", args.storeId]
    if (args.maxBodyCharacters) values.push("-MaxBodyCharacters", String(args.maxBodyCharacters))
    return runPowerShell("outlook/Read-OutlookMail.ps1", values)
  },
})

export const set_properties = tool({
  description:
    "Flag, categorize, set read state, or set importance on scoped Classic Outlook messages. Reversible, so no confirmation is required.",
  args: {
    messages: messageList,
    readState: tool.schema.enum(["read", "unread"]).optional(),
    importance: tool.schema.enum(["low", "normal", "high"]).optional(),
    flag: tool.schema
      .object({
        action: tool.schema.enum(["followup", "complete", "clear"]),
        interval: tool.schema.enum(["nodate", "today", "tomorrow", "thisweek", "nextweek"]).optional(),
        dueDate: tool.schema.string().optional().describe("Local date/time in ISO format"),
        text: tool.schema.string().optional().describe("Flag text, defaults to 'Follow up'"),
      })
      .optional(),
    categories: tool.schema
      .object({
        mode: tool.schema.enum(["add", "remove", "set", "clear"]),
        names: tool.schema.array(tool.schema.string().min(1)).optional(),
        createMissing: tool.schema.boolean().optional().describe("Add unknown names to the master category list"),
      })
      .optional(),
  },
  async execute(args) {
    return withTemporaryJson(args, (planPath) =>
      runPowerShell("outlook/Set-OutlookMailProperties.ps1", ["-PlanPath", planPath]),
    )
  },
})

export const move = tool({
  description:
    "Move scoped Classic Outlook messages into a configured writable folder, or into the configured archive folder. Deleted Items is refused here; use office_outlook_delete.",
  args: {
    messages: messageList,
    mode: tool.schema.enum(["move", "archive"]).optional().describe("Defaults to move"),
    destinationFolder: tool.schema.string().min(1).optional().describe("Required for mode 'move'"),
  },
  async execute(args) {
    return withTemporaryJson(args, (planPath) => runPowerShell("outlook/Move-OutlookMail.ps1", ["-PlanPath", planPath]))
  },
})

export const delete_messages = tool({
  description:
    "Move scoped Classic Outlook messages to Deleted Items. TWO STEPS: call without confirmationToken to get a preview plus a token, show that preview to the user, and call again with the token only after the user explicitly approves. Never permanently deletes.",
  args: {
    messages: messageList,
    confirmationToken: tool.schema
      .string()
      .regex(/^[0-9a-f]{48}$/)
      .optional()
      .describe("Token from the preview call. Only supply it after the user has explicitly approved the deletion."),
  },
  async execute(args) {
    const { confirmationToken, ...plan } = args
    return withTemporaryJson(plan, (planPath) => {
      const values = ["-PlanPath", planPath]
      if (confirmationToken) values.push("-ConfirmationToken", confirmationToken)
      return runPowerShell("outlook/Remove-OutlookMail.ps1", values)
    })
  },
})

export const create_draft = tool({
  description:
    "Create a plain-text Outlook draft (new, reply, replyAll, or forward) and save it to Drafts. This never sends. Returns the draft IDs for office_outlook_send_draft.",
  args: {
    mode: tool.schema.enum(["new", "reply", "replyAll", "forward"]),
    entryId: tool.schema.string().min(1).optional().describe("Source message, required unless mode is 'new'"),
    storeId: tool.schema.string().min(1).optional().describe("Source message, required unless mode is 'new'"),
    to: tool.schema.array(tool.schema.string().min(1)).optional(),
    cc: tool.schema.array(tool.schema.string().min(1)).optional(),
    subject: tool.schema.string().optional().describe("Required for mode 'new'; otherwise overrides the reply subject"),
    body: tool.schema.string().min(1).describe("Plain text placed above any quoted history"),
  },
  async execute(args) {
    return withTemporaryJson(args, (planPath) => runPowerShell("outlook/New-OutlookDraft.ps1", ["-PlanPath", planPath]))
  },
})

export const send_draft = tool({
  description:
    "Send an existing Outlook draft. TWO STEPS: call without confirmationToken to get the recipients, subject, and body preview plus a token, show that to the user, and call again with the token only after the user explicitly approves. Editing the draft invalidates the token.",
  args: {
    entryId: tool.schema.string().min(1).describe("Draft EntryId from office_outlook_create_draft"),
    storeId: tool.schema.string().min(1).describe("Draft StoreId from office_outlook_create_draft"),
    confirmationToken: tool.schema
      .string()
      .regex(/^[0-9a-f]{48}$/)
      .optional()
      .describe("Token from the preview call. Only supply it after the user has explicitly approved sending."),
  },
  async execute(args) {
    const values = ["-EntryId", args.entryId, "-StoreId", args.storeId]
    if (args.confirmationToken) values.push("-ConfirmationToken", args.confirmationToken)
    return runPowerShell("outlook/Send-OutlookDraft.ps1", values)
  },
})

export const save_attachment = tool({
  description:
    "Save attachments from one scoped Classic Outlook message into the configured attachment directory. Executable and script file types are refused.",
  args: {
    entryId: tool.schema.string().min(1),
    storeId: tool.schema.string().min(1),
    attachmentName: tool.schema.string().min(1).optional().describe("Save only this attachment; omit to save all"),
    outputDirectory: tool.schema.string().min(1).optional().describe("Must be inside the configured attachment root"),
  },
  async execute(args) {
    const values = ["-EntryId", args.entryId, "-StoreId", args.storeId]
    if (args.attachmentName) values.push("-AttachmentName", args.attachmentName)
    if (args.outputDirectory) values.push("-OutputDirectory", args.outputDirectory)
    return runPowerShell("outlook/Save-OutlookAttachment.ps1", values)
  },
})

export const create_folder = tool({
  description: "Create one mail subfolder under a configured writable Outlook folder.",
  args: {
    parentFolder: tool.schema.string().min(1).describe("Must be listed in write.allowedFolders"),
    name: tool.schema.string().min(1).max(64).describe("Single folder name, no path separators"),
  },
  async execute(args) {
    return runPowerShell("outlook/New-OutlookMailFolder.ps1", ["-ParentFolder", args.parentFolder, "-Name", args.name])
  },
})

export const create_rule = tool({
  description:
    "Create one incoming-mail rule that files messages into a folder. TWO STEPS: call without confirmationToken to get a preview plus a token, show it to the user, and call again with the token only after the user explicitly approves. A rule keeps acting on the mailbox after this session.",
  args: {
    name: tool.schema.string().min(1).max(128),
    moveToFolder: tool.schema.string().min(1).describe("Must be listed in write.allowedFolders"),
    fromAddresses: tool.schema.array(tool.schema.string().min(1)).optional(),
    subjectContains: tool.schema.array(tool.schema.string().min(1)).optional(),
    enabled: tool.schema.boolean().optional().describe("Defaults to true"),
    confirmationToken: tool.schema
      .string()
      .regex(/^[0-9a-f]{48}$/)
      .optional()
      .describe("Token from the preview call. Only supply it after the user has explicitly approved the rule."),
  },
  async execute(args) {
    const { confirmationToken, ...plan } = args
    return withTemporaryJson(plan, (planPath) => {
      const values = ["-PlanPath", planPath]
      if (confirmationToken) values.push("-ConfirmationToken", confirmationToken)
      return runPowerShell("outlook/New-OutlookRule.ps1", values)
    })
  },
})

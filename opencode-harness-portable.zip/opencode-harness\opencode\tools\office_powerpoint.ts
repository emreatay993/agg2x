import { tool } from "@opencode-ai/plugin"
import { runPowerShell, withTemporaryJson } from "../lib/run-powershell"

const operation = tool.schema.object({
  operation: tool.schema.enum(["replace_text", "set_text", "set_notes", "move_resize", "replace_image"]),
  slideIndex: tool.schema.number().int().min(1),
  shapeName: tool.schema.string().optional(),
  shapeId: tool.schema.number().int().min(1).optional(),
  shapeIndex: tool.schema.number().int().min(1).optional(),
  find: tool.schema.string().optional(),
  replace: tool.schema.string().optional(),
  text: tool.schema.string().optional(),
  left: tool.schema.number().optional(),
  top: tool.schema.number().optional(),
  width: tool.schema.number().positive().optional(),
  height: tool.schema.number().positive().optional(),
  imagePath: tool.schema.string().optional().describe("Absolute path to a replacement image under an approved root"),
})

export const inspect = tool({
  description: "Inspect every slide, shape, text range, notes area, link, and macro indicator in a PowerPoint file without changing it.",
  args: { sourcePath: tool.schema.string().min(1) },
  async execute(args) {
    return runPowerShell("powerpoint/Get-PowerPointInventory.ps1", ["-SourcePath", args.sourcePath])
  },
})

export const render = tool({
  description: "Render every slide from a PowerPoint file to PNG in an output directory without changing the source.",
  args: {
    sourcePath: tool.schema.string().min(1),
    outputDirectory: tool.schema.string().min(1),
  },
  async execute(args) {
    return runPowerShell("powerpoint/Export-PowerPointSlides.ps1", ["-SourcePath", args.sourcePath, "-OutputFolder", args.outputDirectory])
  },
})

export const new_deck = tool({
  description:
    "Build a new PowerPoint deck in the house presentation style from a JSON deck spec. Writes .pptx only, refuses an existing output path, and never modifies the optional template. Load the presentation-style skill for the spec schema.",
  args: {
    outputPath: tool.schema.string().min(1).describe("Absolute .pptx path that does not yet exist, under an approved root"),
    spec: tool.schema
      .object({
        deckTitle: tool.schema.string().optional(),
        slides: tool.schema.array(tool.schema.any()).min(1).max(200),
      })
      .describe("Deck spec. See the presentation-style skill reference/deck-spec.md for the schema."),
    templatePath: tool.schema.string().optional().describe("Optional existing presentation to inherit theme and masters from. Opened read-only."),
    imageRoot: tool.schema
      .string()
      .optional()
      .describe("Folder that relative image paths in the spec resolve against. Required whenever the spec uses relative image paths, because the spec itself is written to machine-local state."),
  },
  async execute(args) {
    return withTemporaryJson(args.spec, (specPath) => {
      const scriptArgs = ["-SpecPath", specPath, "-OutputPath", args.outputPath]
      if (args.templatePath) scriptArgs.push("-TemplatePath", args.templatePath)
      if (args.imageRoot) scriptArgs.push("-ImageRoot", args.imageRoot)
      return runPowerShell("powerpoint/New-PowerPointDeck.ps1", scriptArgs)
    })
  },
})

export const apply_plan = tool({
  description: "Apply validated structured edits to a new PowerPoint copy. Refuses source overwrite and existing output files.",
  args: {
    sourcePath: tool.schema.string().min(1),
    outputPath: tool.schema.string().min(1),
    operations: tool.schema.array(operation).min(1).max(100),
  },
  async execute(args) {
    const plan = { allowOverwrite: false, operations: args.operations }
    return withTemporaryJson(plan, (planPath) =>
      runPowerShell("powerpoint/Edit-PowerPointCopy.ps1", [
        "-SourcePath", args.sourcePath,
        "-OutputPath", args.outputPath,
        "-PlanPath", planPath,
      ]),
    )
  },
})

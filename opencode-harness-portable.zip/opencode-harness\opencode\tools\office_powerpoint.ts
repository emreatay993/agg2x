import { tool } from "@opencode-ai/plugin"
import { runPowerShell, withTemporaryJson } from "../lib/run-powershell"

const shapeSelector = {
  shapeName: tool.schema.string().min(1).optional(),
  shapeId: tool.schema.number().int().min(1).optional(),
  shapeIndex: tool.schema.number().int().min(1).optional(),
}

const operation = tool.schema.discriminatedUnion("operation", [
  tool.schema.object({
    operation: tool.schema.literal("replace_text"),
    slideIndex: tool.schema.number().int().min(1),
    ...shapeSelector,
    find: tool.schema.string().min(1),
    replace: tool.schema.string(),
  }).strict(),
  tool.schema.object({
    operation: tool.schema.literal("set_text"),
    slideIndex: tool.schema.number().int().min(1),
    ...shapeSelector,
    text: tool.schema.string(),
  }).strict(),
  tool.schema.object({
    operation: tool.schema.literal("set_notes"),
    slideIndex: tool.schema.number().int().min(1),
    text: tool.schema.string(),
  }).strict(),
  tool.schema.object({
    operation: tool.schema.literal("move_resize"),
    slideIndex: tool.schema.number().int().min(1),
    ...shapeSelector,
    left: tool.schema.number().optional(),
    top: tool.schema.number().optional(),
    width: tool.schema.number().positive().optional(),
    height: tool.schema.number().positive().optional(),
  }).strict(),
  tool.schema.object({
    operation: tool.schema.literal("replace_image"),
    slideIndex: tool.schema.number().int().min(1),
    ...shapeSelector,
    imagePath: tool.schema.string().min(1).describe("Absolute path to a replacement image under an approved root"),
  }).strict(),
]).refine(
  (value) => value.operation === "set_notes" || value.shapeName !== undefined || value.shapeId !== undefined || value.shapeIndex !== undefined,
  { message: "Shape operations require shapeName, shapeId, or shapeIndex." },
).refine(
  (value) => value.operation !== "move_resize" || value.left !== undefined || value.top !== undefined || value.width !== undefined || value.height !== undefined,
  { message: "move_resize requires left, top, width, or height." },
)
const operations = tool.schema.array(operation).min(1).max(100)

export const inspect = tool({
  description: "Inspect a bounded page of at most 25 PowerPoint slides, including shapes, text, notes, links, and macro indicators, without changing the file. Follow truncation.nextStart only for a requested whole-deck audit.",
  args: {
    sourcePath: tool.schema.string().min(1),
    startSlide: tool.schema.number().int().min(1).optional(),
    limit: tool.schema.number().int().min(1).max(25).optional(),
  },
  async execute(args) {
    const scriptArgs = ["-SourcePath", args.sourcePath]
    if (args.startSlide !== undefined) scriptArgs.push("-StartSlide", String(args.startSlide))
    if (args.limit !== undefined) scriptArgs.push("-Limit", String(args.limit))
    return runPowerShell("powerpoint/Get-PowerPointInventory.ps1", scriptArgs)
  },
})

export const render = tool({
  description: "Render every slide from a PowerPoint file to PNG in an output directory without changing the source.",
  args: {
    sourcePath: tool.schema.string().min(1),
    outputDirectory: tool.schema.string().min(1),
  },
  async execute(args) {
    return runPowerShell("powerpoint/Export-PowerPointSlides.ps1", ["-SourcePath", args.sourcePath, "-OutputFolder", args.outputDirectory])
  },
})

export const new_deck = tool({
  description:
    "Build a new PowerPoint deck in the house presentation style from a JSON deck spec. Writes .pptx only, refuses an existing output path, and never modifies the optional template. Load the presentation-style skill for the spec schema.",
  args: {
    outputPath: tool.schema.string().min(1).describe("Absolute .pptx path that does not yet exist, under an approved root"),
    spec: tool.schema
      .object({
        deckTitle: tool.schema.string().optional(),
        slides: tool.schema.array(tool.schema.any()).min(1).max(200),
      })
      .describe("Deck spec. See the presentation-style skill reference/deck-spec.md for the schema."),
    templatePath: tool.schema.string().optional().describe("Optional existing presentation to inherit theme and masters from. Opened read-only."),
    imageRoot: tool.schema
      .string()
      .optional()
      .describe("Folder that relative image paths in the spec resolve against. Required whenever the spec uses relative image paths, because the spec itself is written to machine-local state."),
  },
  async execute(args) {
    return withTemporaryJson(args.spec, (specPath) => {
      const scriptArgs = ["-SpecPath", specPath, "-OutputPath", args.outputPath]
      if (args.templatePath) scriptArgs.push("-TemplatePath", args.templatePath)
      if (args.imageRoot) scriptArgs.push("-ImageRoot", args.imageRoot)
      return runPowerShell("powerpoint/New-PowerPointDeck.ps1", scriptArgs)
    })
  },
})

export const apply_plan = tool({
  description: "Apply validated structured edits to a new PowerPoint copy. Refuses source overwrite and existing output files.",
  args: {
    sourcePath: tool.schema.string().min(1),
    outputPath: tool.schema.string().min(1),
    operations,
  },
  async execute(args) {
    const validatedOperations = operations.parse(args.operations)
    const plan = { allowOverwrite: false, operations: validatedOperations }
    return withTemporaryJson(plan, (planPath) =>
      runPowerShell("powerpoint/Edit-PowerPointCopy.ps1", [
        "-SourcePath", args.sourcePath,
        "-OutputPath", args.outputPath,
        "-PlanPath", planPath,
      ]),
    )
  },
})

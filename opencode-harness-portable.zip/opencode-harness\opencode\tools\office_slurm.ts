import { tool } from "@opencode-ai/plugin"
import { runPowerShell } from "../lib/run-powershell"

export const connection = tool({
  description: "Test noninteractive host-verified SSH and basic SLURM command availability on the configured HPC host.",
  args: {},
  async execute() {
    return runPowerShell("slurm/Test-SlurmConnection.ps1")
  },
})

export const status = tool({
  description: "Return current SLURM jobs or current and accounting state for one explicit numeric job ID.",
  args: { jobId: tool.schema.string().regex(/^[1-9][0-9]*$/).optional() },
  async execute(args) {
    return runPowerShell("slurm/Get-SlurmStatus.ps1", args.jobId ? ["-JobId", args.jobId] : [])
  },
})

export const tail = tool({
  description: "Read a bounded tail of a remote SLURM log below the configured remote work root.",
  args: {
    remotePath: tool.schema.string().min(1),
    lines: tool.schema.number().int().min(1).max(10000).optional(),
  },
  async execute(args) {
    const values = ["-RemotePath", args.remotePath]
    if (args.lines) values.push("-Lines", String(args.lines))
    return runPowerShell("slurm/Get-SlurmLog.ps1", values)
  },
})

export const submit = tool({
  description: "Validate and submit one mapped-drive SLURM script through noninteractive SSH and return the sbatch numeric job ID.",
  args: {
    localScriptPath: tool.schema.string().min(1),
    partition: tool.schema.string().regex(/^[A-Za-z0-9][A-Za-z0-9._-]*$/),
  },
  async execute(args) {
    return runPowerShell("slurm/Submit-SlurmJob.ps1", ["-LocalScriptPath", args.localScriptPath, "-Partition", args.partition])
  },
})

export const cancel = tool({
  description: "Inspect ownership and cancel one explicit positive numeric SLURM job ID.",
  args: { jobId: tool.schema.string().regex(/^[1-9][0-9]*$/) },
  async execute(args) {
    return runPowerShell("slurm/Stop-SlurmJob.ps1", ["-JobId", args.jobId])
  },
})

import { tool } from "@opencode-ai/plugin"
import { readFile } from "node:fs/promises"
import { runPowerShell, withTemporaryJson } from "../lib/run-powershell"

const operation = tool.schema.discriminatedUnion("operation", [
  tool.schema.object({
    operation: tool.schema.literal("replace_paragraph_text"),
    paragraphIndex: tool.schema.number().int().min(1),
    expectedText: tool.schema.string(),
    find: tool.schema.string().min(1),
    replace: tool.schema.string(),
  }).strict(),
  tool.schema.object({
    operation: tool.schema.literal("replace_text_with_cross_reference"),
    paragraphIndex: tool.schema.number().int().min(1),
    expectedText: tool.schema.string(),
    find: tool.schema.string().min(1),
    targetType: tool.schema.enum(["heading", "figure", "table"]),
    targetIndex: tool.schema.number().int().min(1),
    expectedTargetText: tool.schema.string().min(1),
    referenceKind: tool.schema.enum(["heading_text", "heading_number", "label_and_number", "entire_caption", "caption_text", "page_number"]),
  }).strict(),
  tool.schema.object({
    operation: tool.schema.literal("set_paragraph_text"),
    paragraphIndex: tool.schema.number().int().min(1),
    expectedText: tool.schema.string(),
    text: tool.schema.string(),
  }).strict(),
  tool.schema.object({
    operation: tool.schema.literal("set_table_cell_text"),
    tableIndex: tool.schema.number().int().min(1),
    rowIndex: tool.schema.number().int().min(1),
    columnIndex: tool.schema.number().int().min(1),
    expectedText: tool.schema.string(),
    text: tool.schema.string(),
  }).strict(),
  tool.schema.object({
    operation: tool.schema.literal("set_text_format"),
    paragraphIndex: tool.schema.number().int().min(1),
    expectedText: tool.schema.string(),
    startOffset: tool.schema.number().int().min(0).optional(),
    length: tool.schema.number().int().min(1).optional(),
    fontName: tool.schema.string().min(1).max(100).optional(),
    fontSize: tool.schema.number().positive().max(200).optional(),
    bold: tool.schema.boolean().optional(),
    italic: tool.schema.boolean().optional(),
    underline: tool.schema.boolean().optional(),
  }).strict(),
  tool.schema.object({
    operation: tool.schema.literal("set_paragraph_format"),
    paragraphIndex: tool.schema.number().int().min(1),
    expectedText: tool.schema.string(),
    paragraphStyle: tool.schema.enum(["normal", "caption", "title", "heading1", "heading2", "heading3", "bullet"]).optional(),
    alignment: tool.schema.enum(["left", "center", "right", "justify"]).optional(),
    spaceBefore: tool.schema.number().min(0).max(200).optional(),
    spaceAfter: tool.schema.number().min(0).max(200).optional(),
    lineSpacing: tool.schema.number().positive().max(200).optional(),
  }).strict(),
  tool.schema.object({
    operation: tool.schema.literal("insert_paragraph_after"),
    paragraphIndex: tool.schema.number().int().min(1),
    expectedText: tool.schema.string(),
    text: tool.schema.string().min(1),
    paragraphStyle: tool.schema.enum(["normal", "caption", "title", "heading1", "heading2", "heading3", "bullet"]),
  }).strict(),
])
const operations = tool.schema.array(operation).min(1).max(100)

const block = tool.schema.object({
  kind: tool.schema.enum(["title", "heading", "paragraph", "bullet"]),
  text: tool.schema.string().min(1).max(10000),
  level: tool.schema.number().int().min(1).max(3).optional(),
})

export const inspect = tool({
  description: "Inspect a Word document without changing it. Inventory is the default. Focused modes use pages of at most 25: find locates exact text without paragraph guessing; formatting addresses paragraphs; media and proofing address ordered result items; references returns native heading/figure/table targets followed by existing REF/PAGEREF fields.",
  args: {
    sourcePath: tool.schema.string().min(1),
    mode: tool.schema.enum(["inventory", "find", "formatting", "media", "proofing", "references"]).optional(),
    findText: tool.schema.string().min(1).optional(),
    start: tool.schema.number().int().min(1).optional(),
    limit: tool.schema.number().int().min(1).max(25).optional(),
  },
  async execute(args) {
    const scriptArgs = ["-SourcePath", args.sourcePath]
    if (args.mode) scriptArgs.push("-Mode", args.mode)
    if (args.findText) scriptArgs.push("-FindText", args.findText)
    if (args.start) scriptArgs.push("-Start", String(args.start))
    if (args.limit) scriptArgs.push("-Limit", String(args.limit))
    return runPowerShell("word/Get-WordInventory.ps1", scriptArgs)
  },
})

export const render = tool({
  description: "Render a Word document to a new PDF without changing the source.",
  args: {
    sourcePath: tool.schema.string().min(1),
    outputPath: tool.schema.string().min(1),
  },
  async execute(args) {
    return runPowerShell("word/Export-WordPdf.ps1", ["-SourcePath", args.sourcePath, "-OutputPath", args.outputPath])
  },
})

export const apply_plan = tool({
  description: "Apply guarded text, formatting, style, native cross-reference, and paragraph-insertion edits to a new Word copy. Refuses source overwrite and existing output files.",
  args: {
    sourcePath: tool.schema.string().min(1),
    outputPath: tool.schema.string().min(1),
    operations,
  },
  async execute(args) {
    const validatedOperations = operations.parse(args.operations)
    return withTemporaryJson({ operations: validatedOperations }, (planPath) =>
      runPowerShell("word/Edit-WordCopy.ps1", [
        "-SourcePath", args.sourcePath,
        "-OutputPath", args.outputPath,
        "-PlanPath", planPath,
      ]),
    )
  },
})

export const apply_saved_plan = tool({
  description: "Apply an approved persisted Word plan without reserializing its guarded operations. The JSON must contain sourceDocument, outputDocument, and operations.",
  args: {
    planPath: tool.schema.string().min(1),
  },
  async execute(args) {
    const plan = JSON.parse(await readFile(args.planPath, "utf8")) as Record<string, unknown>
    if (typeof plan.sourceDocument !== "string" || !plan.sourceDocument.trim()) throw new Error("Saved plan sourceDocument is required.")
    if (typeof plan.outputDocument !== "string" || !plan.outputDocument.trim()) throw new Error("Saved plan outputDocument is required.")
    if (!Array.isArray(plan.operations) || plan.operations.length === 0) throw new Error("Saved plan operations are required.")
    return runPowerShell("word/Edit-WordCopy.ps1", [
      "-SourcePath", plan.sourceDocument,
      "-OutputPath", plan.outputDocument,
      "-PlanPath", args.planPath,
    ])
  },
})

export const new_document = tool({
  description: "Create a new .docx from bounded structured title, heading, paragraph, and bullet blocks. Refuses an existing output path.",
  args: {
    outputPath: tool.schema.string().min(1),
    spec: tool.schema.object({ blocks: tool.schema.array(block).min(1).max(500) }),
  },
  async execute(args) {
    return withTemporaryJson(args.spec, (specPath) =>
      runPowerShell("word/New-WordDocument.ps1", ["-SpecPath", specPath, "-OutputPath", args.outputPath]),
    )
  },
})

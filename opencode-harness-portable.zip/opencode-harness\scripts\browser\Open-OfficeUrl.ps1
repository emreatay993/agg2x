#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$Target
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Write-Result {
    param([Parameter(Mandatory = $true)][object]$Value)
    [Console]::Out.WriteLine(($Value | ConvertTo-Json -Depth 6 -Compress))
}

function Get-ChromePath {
    param([string]$ConfiguredPath)

    if (-not [string]::IsNullOrWhiteSpace($ConfiguredPath)) {
        $expanded = [Environment]::ExpandEnvironmentVariables($ConfiguredPath)
        if (-not (Test-Path -LiteralPath $expanded -PathType Leaf)) {
            throw "Configured browserExecutable does not exist: '$expanded'."
        }
        return (Get-Item -LiteralPath $expanded -ErrorAction Stop).FullName
    }

    $registryPaths = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',
        'HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe',
        'HKLM:\SOFTWARE\WOW6432Node\Microsoft\Windows\CurrentVersion\App Paths\chrome.exe'
    )
    foreach ($registryPath in $registryPaths) {
        try {
            $candidate = (Get-ItemProperty -LiteralPath $registryPath -ErrorAction Stop).'(default)'
            if (-not [string]::IsNullOrWhiteSpace($candidate) -and (Test-Path -LiteralPath $candidate -PathType Leaf)) {
                return (Get-Item -LiteralPath $candidate -ErrorAction Stop).FullName
            }
        }
        catch {}
    }

    $candidates = @()
    if ($env:ProgramFiles) { $candidates += (Join-Path $env:ProgramFiles 'Google\Chrome\Application\chrome.exe') }
    if (${env:ProgramFiles(x86)}) { $candidates += (Join-Path ${env:ProgramFiles(x86)} 'Google\Chrome\Application\chrome.exe') }
    if ($env:LOCALAPPDATA) { $candidates += (Join-Path $env:LOCALAPPDATA 'Google\Chrome\Application\chrome.exe') }
    foreach ($candidate in $candidates) {
        if (Test-Path -LiteralPath $candidate -PathType Leaf) {
            return (Get-Item -LiteralPath $candidate -ErrorAction Stop).FullName
        }
    }

    $command = Get-Command -Name 'chrome.exe' -CommandType Application -ErrorAction SilentlyContinue
    if ($null -ne $command) { return $command.Source }
    throw 'Google Chrome was not found. Set browserExecutable in settings\sites.local.json.'
}

try {
    if (-not [string]::IsNullOrWhiteSpace($env:OFFICE_HARNESS_SETTINGS)) {
        $settingsRoot = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($env:OFFICE_HARNESS_SETTINGS))
    }
    else {
        $settingsRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..\settings'))
    }
    $localPath = Join-Path $settingsRoot 'sites.local.json'
    $examplePath = Join-Path $settingsRoot 'sites.example.json'
    $settingsPath = if (Test-Path -LiteralPath $localPath -PathType Leaf) { $localPath } else { $examplePath }
    if (-not (Test-Path -LiteralPath $settingsPath -PathType Leaf)) {
        throw 'Browser settings were not found.'
    }
    $settings = [IO.File]::ReadAllText($settingsPath) | ConvertFrom-Json -ErrorAction Stop

    if ($null -eq $settings.PSObject.Properties['aliases'] -or $settings.aliases -isnot [pscustomobject]) {
        throw 'Browser settings aliases must be a JSON object.'
    }
    if ($null -eq $settings.PSObject.Properties['allowedHosts'] -or $settings.allowedHosts -is [string]) {
        throw 'Browser settings allowedHosts must be a JSON array.'
    }

    $targetValue = $Target.Trim()
    $aliases = $settings.aliases
    $aliasProperty = $aliases.PSObject.Properties[$targetValue]
    $fromAlias = $null -ne $aliasProperty
    $urlText = if ($fromAlias) { [string]$aliasProperty.Value } else { $targetValue }

    $uri = $null
    if (-not [Uri]::TryCreate($urlText, [UriKind]::Absolute, [ref]$uri)) {
        throw "Target is neither a configured alias nor an absolute URL: '$Target'."
    }
    if ($uri.Scheme -notin @('https', 'http')) { throw 'Only HTTP and HTTPS URLs are allowed.' }
    if (-not [string]::IsNullOrEmpty($uri.UserInfo)) { throw 'URLs containing user information are not allowed.' }

    $allowedHosts = @($settings.allowedHosts | ForEach-Object { ([string]$_).ToLowerInvariant() })
    $hostAllowed = $allowedHosts -contains $uri.DnsSafeHost.ToLowerInvariant()
    $allowUnlisted = $false
    if ($null -ne $settings.PSObject.Properties['allowUnlistedExplicitUrls']) {
        if ($settings.allowUnlistedExplicitUrls -isnot [bool]) {
            throw 'Browser setting allowUnlistedExplicitUrls must be a JSON boolean.'
        }
        $allowUnlisted = [bool]$settings.allowUnlistedExplicitUrls
    }
    if (-not $hostAllowed -and -not ($allowUnlisted -and -not $fromAlias)) {
        throw "Host '$($uri.DnsSafeHost)' is not listed in settings\sites.local.json."
    }

    $chromePath = Get-ChromePath -ConfiguredPath ([string]$settings.browserExecutable)
    $process = Start-Process -FilePath $chromePath -ArgumentList @($uri.AbsoluteUri) -PassThru -ErrorAction Stop
    Write-Result ([ordered]@{
        ok = $true
        alias = if ($fromAlias) { $targetValue } else { $null }
        url = $uri.AbsoluteUri
        host = $uri.DnsSafeHost
        browser = $chromePath
        processId = $process.Id
    })
}
catch {
    [Console]::Error.WriteLine(([ordered]@{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress))
    exit 1
}

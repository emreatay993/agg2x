#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$NodePath,
    [Parameter(Mandatory = $true)][string]$CliPath,
    [Parameter(Mandatory = $true)][string]$BrowserProfile,
    [Parameter(Mandatory = $true)][string]$OutputDirectory
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

if (-not (Test-Path -LiteralPath $NodePath -PathType Leaf)) { throw "Node executable not found: '$NodePath'." }
if (-not (Test-Path -LiteralPath $CliPath -PathType Leaf)) { throw "Playwright MCP CLI not found: '$CliPath'." }
foreach ($variable in @(Get-ChildItem Env: | Where-Object Name -Match '(?i)(API.?KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL)')) {
    Remove-Item -LiteralPath ('Env:' + $variable.Name) -ErrorAction SilentlyContinue
}

$arguments = @(
    $CliPath,
    '--browser', 'chrome',
    '--user-data-dir', $BrowserProfile,
    '--output-dir', $OutputDirectory,
    '--output-max-size', '104857600',
    '--output-mode', 'file',
    '--image-responses', 'omit',
    '--codegen', 'none',
    '--console-level', 'warning'
)
& $NodePath @arguments
exit $LASTEXITCODE

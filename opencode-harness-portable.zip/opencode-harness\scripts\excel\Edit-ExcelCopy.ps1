[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourcePath,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath,

    [Parameter(Mandatory = $true)]
    [string]$PlanPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path -Path $PSScriptRoot -ChildPath 'Excel.Common.ps1')

function Get-RequiredExcelPlanValue {
    param(
        [Parameter(Mandatory = $true)][object]$InputObject,
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$Description
    )

    $property = $InputObject.PSObject.Properties[$Name]
    if ($null -eq $property) {
        throw "Missing $Description ('$Name')."
    }
    return $property.Value
}

function Test-ExcelJsonPrimitive {
    param([AllowNull()][object]$Value)

    return $null -eq $Value -or
        $Value -is [string] -or
        $Value -is [bool] -or
        $Value -is [byte] -or
        $Value -is [sbyte] -or
        $Value -is [int16] -or
        $Value -is [uint16] -or
        $Value -is [int32] -or
        $Value -is [uint32] -or
        $Value -is [int64] -or
        $Value -is [uint64] -or
        $Value -is [single] -or
        $Value -is [double] -or
        $Value -is [decimal]
}

$application = $null
$workbook = $null
$worksheets = $null
$sourceFullPath = $null
$outputFullPath = $null
$planFullPath = $null
$temporaryOutputPath = $null
$sourceHashBefore = $null
$sourceHashAfter = $null
$operationResults = @()
$outputCreated = $false

try {
    $settings = Get-ExcelSettings
    $sourceFullPath = Resolve-ExistingExcelFile -Path $SourcePath -Description 'Source workbook'
    $planFullPath = Resolve-ExistingExcelFile -Path $PlanPath -Description 'Edit plan'
    $outputFullPath = Resolve-ExcelOutputFile -Path $OutputPath
    Assert-ExcelWorkbookExtension -Path $sourceFullPath
    Assert-ExcelInputAllowed -Path $sourceFullPath -Settings $settings -Description 'Source workbook'
    Assert-ExcelOutputAllowed -OutputPath $outputFullPath -SourcePath $sourceFullPath -Settings $settings

    if ($sourceFullPath.Equals($outputFullPath, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'SourcePath and OutputPath must resolve to distinct full paths.'
    }
    $sourceExtension = [IO.Path]::GetExtension($sourceFullPath)
    if (-not $sourceExtension.Equals([IO.Path]::GetExtension($outputFullPath), [StringComparison]::OrdinalIgnoreCase)) {
        throw "OutputPath must preserve the source extension '$sourceExtension'."
    }
    if (Test-Path -LiteralPath $outputFullPath) {
        throw "OutputPath already exists: '$outputFullPath'. Choose a new file."
    }

    try {
        $plan = [IO.File]::ReadAllText($planFullPath) | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "Could not parse edit plan '$planFullPath': $($_.Exception.Message)"
    }

    $allowOverwrite = Get-OfficeFilePropertyValue -InputObject $plan -Name 'allowOverwrite' -DefaultValue $false
    if ($allowOverwrite -isnot [bool]) {
        throw 'Plan allowOverwrite must be a JSON boolean.'
    }
    if ([bool]$allowOverwrite) {
        throw 'Excel copy editing does not allow overwriting an existing output.'
    }

    $operationsProperty = $plan.PSObject.Properties['operations']
    if ($null -eq $operationsProperty -or $null -eq $operationsProperty.Value) {
        throw 'The edit plan must contain an operations array.'
    }
    $operations = @($operationsProperty.Value)
    if ($operations.Count -lt 1 -or $operations.Count -gt 100) {
        throw "The edit plan must contain between 1 and 100 operations; received $($operations.Count)."
    }

    $sourceHashBefore = Get-ExcelFileHash -Path $sourceFullPath
    $planHash = Get-ExcelFileHash -Path $planFullPath
    $excelVersion = ''

    try {
        $application = New-SafeExcelApplication
        $excelVersion = [string]$application.Version
        $workbook = Open-ExcelWorkbookReadOnly -Application $application -Path $sourceFullPath
        $worksheets = $workbook.Worksheets

        for ($operationIndex = 0; $operationIndex -lt $operations.Count; $operationIndex++) {
            $operation = $operations[$operationIndex]
            $operationName = ''
            $worksheet = $null
            $cell = $null
            try {
                if ($null -eq $operation) {
                    throw 'Operation is null.'
                }

                $operationName = ([string](Get-RequiredExcelPlanValue -InputObject $operation -Name 'operation' -Description 'operation name')).ToLowerInvariant()
                if (@('set_value', 'clear') -notcontains $operationName) {
                    throw "Unsupported operation '$operationName'."
                }

                $sheetName = [string](Get-RequiredExcelPlanValue -InputObject $operation -Name 'sheetName' -Description 'worksheet name')
                $address = [string](Get-RequiredExcelPlanValue -InputObject $operation -Name 'address' -Description 'cell address')
                $expectedTextValue = Get-RequiredExcelPlanValue -InputObject $operation -Name 'expectedText' -Description 'expected displayed text'
                if ($null -eq $expectedTextValue -or $expectedTextValue -isnot [string]) {
                    throw 'expectedText must be a JSON string.'
                }
                if ([string]::IsNullOrWhiteSpace($sheetName)) {
                    throw 'sheetName must not be blank.'
                }
                Assert-ExcelRangeAddress -Address $address -SingleCell

                $worksheet = Get-ExcelWorksheetByName -Worksheets $worksheets -Name $sheetName
                $cell = $worksheet.Range($address)
                if ([bool]$cell.HasFormula) {
                    throw "Formula cell '$sheetName!$address' cannot be edited."
                }
                if ([bool]$worksheet.ProtectContents -and [bool]$cell.Locked) {
                    throw "Protected cell '$sheetName!$address' cannot be edited."
                }

                $displayedBefore = [string]$cell.Text
                if (-not $displayedBefore.Equals([string]$expectedTextValue, [StringComparison]::Ordinal)) {
                    throw "Stale target '$sheetName!$address': expected displayed text '$expectedTextValue' but found '$displayedBefore'."
                }

                $valueProperty = $operation.PSObject.Properties['value']
                if ($operationName -eq 'set_value') {
                    if ($null -eq $valueProperty) {
                        throw "set_value requires a 'value' property."
                    }
                    $value = $valueProperty.Value
                    if (-not (Test-ExcelJsonPrimitive -Value $value)) {
                        throw 'set_value accepts only a JSON string, number, boolean, or null.'
                    }
                    if ($value -is [string] -and $value -match '^\s*[=+\-@]') {
                        throw "Formula-like string values are not allowed: '$value'."
                    }
                    $cell.Value2 = $value
                }
                else {
                    if ($null -ne $valueProperty -and $null -ne $valueProperty.Value) {
                        throw 'clear does not accept a non-null value.'
                    }
                    [void]$cell.ClearContents()
                }

                if ([bool]$cell.HasFormula) {
                    throw "Operation unexpectedly created a formula in '$sheetName!$address'."
                }
                $operationResults += [pscustomobject][ordered]@{
                    index          = $operationIndex + 1
                    operation      = $operationName
                    sheetName      = [string]$worksheet.Name
                    address        = [string]$cell.Address($false, $false, 1)
                    expectedText   = [string]$expectedTextValue
                    displayedBefore = $displayedBefore
                    displayedAfter = [string]$cell.Text
                    status         = 'applied'
                }
            }
            catch {
                $operationResults += [pscustomobject][ordered]@{
                    index     = $operationIndex + 1
                    operation = $operationName
                    status    = 'failed'
                    error     = $_.Exception.Message
                }
                throw "Plan operation $($operationIndex + 1) failed: $($_.Exception.Message)"
            }
            finally {
                Release-ExcelComObject -ComObject $cell
                Release-ExcelComObject -ComObject $worksheet
            }
        }

        $outputDirectory = [IO.Path]::GetDirectoryName($outputFullPath)
        $temporaryName = '.' + [IO.Path]::GetFileNameWithoutExtension($outputFullPath) +
            '.opencode-' + [Guid]::NewGuid().ToString('N') + $sourceExtension
        $temporaryOutputPath = Join-Path -Path $outputDirectory -ChildPath $temporaryName
        if (Test-Path -LiteralPath $temporaryOutputPath) {
            throw "Temporary output path unexpectedly exists: '$temporaryOutputPath'."
        }

        $workbook.SaveCopyAs($temporaryOutputPath)
        if (-not (Test-Path -LiteralPath $temporaryOutputPath -PathType Leaf)) {
            throw "Excel did not create the temporary output copy '$temporaryOutputPath'."
        }
    }
    finally {
        Release-ExcelComObject -ComObject $worksheets
        if ($null -ne $workbook) {
            try { $workbook.Close($false) } catch {}
            Release-ExcelComObject -ComObject $workbook
            $workbook = $null
        }
        if ($null -ne $application) {
            try { $application.Quit() } catch {}
            Release-ExcelComObject -ComObject $application
            $application = $null
        }
        Complete-ExcelComCleanup
    }

    $sourceHashAfter = Get-ExcelFileHash -Path $sourceFullPath
    if ($sourceHashBefore -ne $sourceHashAfter) {
        throw 'The source workbook hash changed during editing.'
    }
    if (Test-Path -LiteralPath $outputFullPath) {
        throw "OutputPath appeared before the atomic move: '$outputFullPath'."
    }

    [IO.File]::Move($temporaryOutputPath, $outputFullPath)
    $temporaryOutputPath = $null
    $outputCreated = $true
    $outputFile = Get-Item -LiteralPath $outputFullPath -ErrorAction Stop

    Write-ExcelJson -Value ([pscustomobject][ordered]@{
        success      = $true
        command      = 'Edit-ExcelCopy'
        source       = [pscustomobject][ordered]@{
            path         = $sourceFullPath
            sha256Before = $sourceHashBefore
            sha256After  = $sourceHashAfter
            unchanged    = $true
        }
        plan         = [pscustomobject][ordered]@{
            path           = $planFullPath
            sha256         = $planHash
            allowOverwrite = $false
        }
        output       = [pscustomobject][ordered]@{
            path       = $outputFullPath
            sha256     = Get-ExcelFileHash -Path $outputFullPath
            bytes      = [long]$outputFile.Length
            saveMethod = 'SaveCopyAsThenAtomicMove'
        }
        settingsPath = $settings.SettingsPath
        excelVersion = $excelVersion
        operations   = @($operationResults)
        truncationNotices = @()
    })
}
catch {
    $failureRecord = $_
    $cleanupError = $null
    try {
        if ($null -ne $temporaryOutputPath -and (Test-Path -LiteralPath $temporaryOutputPath -PathType Leaf)) {
            [IO.File]::Delete($temporaryOutputPath)
        }
        if ($outputCreated -and $null -ne $outputFullPath -and (Test-Path -LiteralPath $outputFullPath -PathType Leaf)) {
            [IO.File]::Delete($outputFullPath)
        }
    }
    catch {
        $cleanupError = $_.Exception.Message
    }

    $context = @{
        operations = @($operationResults)
    }
    if ($null -ne $sourceFullPath) { $context['sourcePath'] = $sourceFullPath }
    if ($null -ne $outputFullPath) { $context['outputPath'] = $outputFullPath }
    if ($null -ne $planFullPath) { $context['planPath'] = $planFullPath }
    if ($null -ne $sourceHashBefore) { $context['sourceSha256Before'] = $sourceHashBefore }
    if ($null -ne $sourceFullPath -and (Test-Path -LiteralPath $sourceFullPath -PathType Leaf)) {
        try { $context['sourceSha256After'] = Get-ExcelFileHash -Path $sourceFullPath } catch {}
    }
    if ($null -ne $cleanupError) { $context['cleanupError'] = $cleanupError }
    Write-ExcelFailure -Command 'Edit-ExcelCopy' -ErrorRecord $failureRecord -Context $context
    exit 1
}

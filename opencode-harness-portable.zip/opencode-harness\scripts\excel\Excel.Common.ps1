Set-StrictMode -Version Latest

# Excel keeps tool-specific settings and validation here while reusing the
# Office-wide path, hash, JSON, and COM helpers.
. (Join-Path -Path (Split-Path -Parent $PSScriptRoot) -ChildPath 'office\OfficeFile.Common.ps1')

function Get-ExcelSettings {
    $repositoryRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
    if (-not [string]::IsNullOrWhiteSpace($env:OFFICE_HARNESS_SETTINGS)) {
        $settingsRoot = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($env:OFFICE_HARNESS_SETTINGS))
    }
    else {
        $settingsRoot = Join-Path -Path $repositoryRoot -ChildPath 'settings'
    }

    $localPath = Join-Path -Path $settingsRoot -ChildPath 'powerpoint.local.json'
    $examplePath = Join-Path -Path $settingsRoot -ChildPath 'powerpoint.example.json'
    if (Test-Path -LiteralPath $localPath -PathType Leaf) {
        $settingsPath = $localPath
    }
    elseif (Test-Path -LiteralPath $examplePath -PathType Leaf) {
        $settingsPath = $examplePath
    }
    else {
        throw 'Office file settings were not found. Expected settings\powerpoint.local.json or settings\powerpoint.example.json.'
    }

    try {
        $settings = [IO.File]::ReadAllText($settingsPath) | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "Could not parse Office file settings '$settingsPath': $($_.Exception.Message)"
    }

    $allowedRoots = @()
    $configuredRoots = Get-OfficeFilePropertyValue -InputObject $settings -Name 'allowedRoots' -DefaultValue @()
    foreach ($configuredRoot in @($configuredRoots)) {
        if ($null -eq $configuredRoot -or [string]::IsNullOrWhiteSpace([string]$configuredRoot)) {
            continue
        }
        $rootPath = Resolve-OfficeFileConfiguredPath -Path ([string]$configuredRoot) -RepositoryRoot $repositoryRoot
        if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) {
            throw "Configured Excel allowed root does not exist: '$rootPath'."
        }
        $allowedRoots += (Get-Item -LiteralPath $rootPath -ErrorAction Stop).FullName
    }

    $defaultOutputRoot = [string](Get-OfficeFilePropertyValue -InputObject $settings -Name 'defaultOutputRoot' -DefaultValue '')
    if (-not [string]::IsNullOrWhiteSpace($defaultOutputRoot)) {
        $defaultOutputRoot = Resolve-OfficeFileConfiguredPath -Path $defaultOutputRoot -RepositoryRoot $repositoryRoot
        if (Test-Path -LiteralPath $defaultOutputRoot -PathType Container) {
            $defaultOutputRoot = (Get-Item -LiteralPath $defaultOutputRoot -ErrorAction Stop).FullName
        }
    }

    return [pscustomobject][ordered]@{
        SettingsPath      = $settingsPath
        RepositoryRoot    = $repositoryRoot
        AllowedRoots      = @($allowedRoots)
        DefaultOutputRoot = $defaultOutputRoot
    }
}

function Resolve-ExistingExcelFile {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Description
    )
    return Resolve-OfficeFileExistingFile -Path $Path -Description $Description
}

function Resolve-ExcelOutputFile {
    param([Parameter(Mandatory = $true)][string]$Path)
    return Resolve-OfficeFileOutputFile -Path $Path
}

function Assert-ExcelInputAllowed {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][object]$Settings,
        [Parameter(Mandatory = $true)][string]$Description
    )
    Assert-OfficeFileInputAllowed -Path $Path -Settings $Settings -Description $Description -ToolName 'Excel'
}

function Assert-ExcelOutputAllowed {
    param(
        [Parameter(Mandatory = $true)][string]$OutputPath,
        [Parameter(Mandatory = $true)][string]$SourcePath,
        [Parameter(Mandatory = $true)][object]$Settings
    )
    Assert-OfficeFileOutputAllowed -OutputPath $OutputPath -SourcePath $SourcePath -Settings $Settings -ToolName 'Excel'
}

function Assert-ExcelWorkbookExtension {
    param([Parameter(Mandatory = $true)][string]$Path)

    $extension = [IO.Path]::GetExtension($Path).ToLowerInvariant()
    if (@('.xls', '.xlsx', '.xlsm', '.xlsb') -notcontains $extension) {
        throw "Unsupported Excel workbook extension '$extension'."
    }
}

function Get-ExcelFileHash {
    param([Parameter(Mandatory = $true)][string]$Path)
    return Get-OfficeFileSha256 -Path $Path
}

function Release-ExcelComObject {
    param([AllowNull()][object]$ComObject)
    Release-OfficeFileComObject -ComObject $ComObject
}

function Complete-ExcelComCleanup {
    Complete-OfficeFileComCleanup
}

function Write-ExcelJson {
    param([Parameter(Mandatory = $true)][object]$Value)
    Write-OfficeFileJson -Value $Value
}

function Write-ExcelFailure {
    param(
        [Parameter(Mandatory = $true)][string]$Command,
        [Parameter(Mandatory = $true)][Management.Automation.ErrorRecord]$ErrorRecord,
        [hashtable]$Context = @{}
    )
    Write-OfficeFileFailure -Command $Command -ErrorRecord $ErrorRecord -Context $Context
}

function Assert-ExcelRangeAddress {
    param(
        [Parameter(Mandatory = $true)][string]$Address,
        [switch]$SingleCell
    )

    $cell = '\$?[A-Za-z]{1,3}\$?[1-9][0-9]{0,6}'
    $pattern = if ($SingleCell) { "^$cell$" } else { "^$cell(?::$cell)?$" }
    if ($Address -notmatch $pattern) {
        $kind = if ($SingleCell) { 'single-cell' } else { 'cell or contiguous-range' }
        throw "Address must be a $kind A1 reference: '$Address'."
    }
}

function New-SafeExcelApplication {
    $application = New-Object -ComObject Excel.Application
    try {
        $application.Visible = $false
        $application.DisplayAlerts = $false
        $application.EnableEvents = $false
        $application.AskToUpdateLinks = $false
        $application.AutomationSecurity = 3
        if ([int]$application.AutomationSecurity -ne 3) {
            throw 'Excel macro automation could not be disabled.'
        }
        return $application
    }
    catch {
        try { $application.Quit() } catch {}
        Release-ExcelComObject -ComObject $application
        throw
    }
}

function Open-ExcelWorkbookReadOnly {
    param(
        [Parameter(Mandatory = $true)][object]$Application,
        [Parameter(Mandatory = $true)][string]$Path
    )

    $workbooks = $null
    $blankWorkbook = $null
    $workbook = $null
    try {
        $workbooks = $Application.Workbooks
        # Excel requires an open workbook before Calculation can be changed.
        # Keep this unsaved blank open so the source itself opens in manual mode.
        $blankWorkbook = $workbooks.Add()
        $Application.Calculation = -4135
        $Application.CalculateBeforeSave = $false
        if ([int]$Application.Calculation -ne -4135) {
            throw 'Excel automatic calculation could not be disabled.'
        }
        $workbook = $workbooks.Open($Path, 0, $true)
        if (-not [bool]$workbook.ReadOnly) {
            try { $workbook.Close($false) } catch {}
            Release-ExcelComObject -ComObject $workbook
            $workbook = $null
            throw 'Excel did not open the source workbook read-only.'
        }
        return $workbook
    }
    catch {
        if ($null -ne $workbook) {
            try { $workbook.Close($false) } catch {}
            Release-ExcelComObject -ComObject $workbook
        }
        throw
    }
    finally {
        if ($null -ne $blankWorkbook) {
            try { $blankWorkbook.Close($false) } catch {}
            Release-ExcelComObject -ComObject $blankWorkbook
        }
        Release-ExcelComObject -ComObject $workbooks
    }
}

function Get-ExcelWorksheetByName {
    param(
        [Parameter(Mandatory = $true)][object]$Worksheets,
        [Parameter(Mandatory = $true)][string]$Name
    )

    for ($index = 1; $index -le [int]$Worksheets.Count; $index++) {
        $worksheet = $null
        $isMatch = $false
        try {
            $worksheet = $Worksheets.Item($index)
            $isMatch = ([string]$worksheet.Name -ceq $Name)
            if ($isMatch) {
                return $worksheet
            }
        }
        finally {
            if ($null -ne $worksheet -and -not $isMatch) {
                Release-ExcelComObject -ComObject $worksheet
            }
        }
    }

    throw "Worksheet '$Name' was not found using an exact name match."
}

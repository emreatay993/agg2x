[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourcePath,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path -Path $PSScriptRoot -ChildPath 'Excel.Common.ps1')

$application = $null
$workbook = $null
$sourceFullPath = $null
$outputFullPath = $null
$temporaryOutputPath = $null
$sourceHashBefore = $null
$sourceHashAfter = $null
$outputCreated = $false

try {
    $settings = Get-ExcelSettings
    $sourceFullPath = Resolve-ExistingExcelFile -Path $SourcePath -Description 'Source workbook'
    $outputFullPath = Resolve-ExcelOutputFile -Path $OutputPath
    Assert-ExcelWorkbookExtension -Path $sourceFullPath
    Assert-ExcelInputAllowed -Path $sourceFullPath -Settings $settings -Description 'Source workbook'
    Assert-ExcelOutputAllowed -OutputPath $outputFullPath -SourcePath $sourceFullPath -Settings $settings

    if (-not [IO.Path]::GetExtension($outputFullPath).Equals('.pdf', [StringComparison]::OrdinalIgnoreCase)) {
        throw "OutputPath must use the '.pdf' extension."
    }
    if ($sourceFullPath.Equals($outputFullPath, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'SourcePath and OutputPath must resolve to distinct full paths.'
    }
    if (Test-Path -LiteralPath $outputFullPath) {
        throw "OutputPath already exists: '$outputFullPath'. Choose a new file."
    }

    $sourceHashBefore = Get-ExcelFileHash -Path $sourceFullPath
    $excelVersion = ''
    $worksheetCount = 0

    try {
        $application = New-SafeExcelApplication
        $excelVersion = [string]$application.Version
        $workbook = Open-ExcelWorkbookReadOnly -Application $application -Path $sourceFullPath
        $worksheets = $null
        try {
            $worksheets = $workbook.Worksheets
            $worksheetCount = [int]$worksheets.Count
        }
        finally {
            Release-ExcelComObject -ComObject $worksheets
        }

        $temporaryName = '.' + [IO.Path]::GetFileNameWithoutExtension($outputFullPath) +
            '.opencode-' + [Guid]::NewGuid().ToString('N') + '.pdf'
        $temporaryOutputPath = Join-Path -Path ([IO.Path]::GetDirectoryName($outputFullPath)) -ChildPath $temporaryName
        $workbook.ExportAsFixedFormat(0, $temporaryOutputPath)
        if (-not (Test-Path -LiteralPath $temporaryOutputPath -PathType Leaf)) {
            throw "Excel did not create the expected temporary PDF '$temporaryOutputPath'."
        }
    }
    finally {
        if ($null -ne $workbook) {
            try { $workbook.Close($false) } catch {}
            Release-ExcelComObject -ComObject $workbook
            $workbook = $null
        }
        if ($null -ne $application) {
            try { $application.Quit() } catch {}
            Release-ExcelComObject -ComObject $application
            $application = $null
        }
        Complete-ExcelComCleanup
    }

    $sourceHashAfter = Get-ExcelFileHash -Path $sourceFullPath
    if ($sourceHashBefore -ne $sourceHashAfter) {
        throw 'The source workbook hash changed during PDF export.'
    }
    if (Test-Path -LiteralPath $outputFullPath) {
        throw "OutputPath appeared before the atomic move: '$outputFullPath'."
    }

    [IO.File]::Move($temporaryOutputPath, $outputFullPath)
    $temporaryOutputPath = $null
    $outputCreated = $true
    $outputFile = Get-Item -LiteralPath $outputFullPath -ErrorAction Stop
    Write-ExcelJson -Value ([pscustomobject][ordered]@{
        success      = $true
        command      = 'Export-ExcelWorkbook'
        source       = [pscustomobject][ordered]@{
            path         = $sourceFullPath
            sha256Before = $sourceHashBefore
            sha256After  = $sourceHashAfter
            unchanged    = $true
        }
        settingsPath = $settings.SettingsPath
        excelVersion = $excelVersion
        output       = [pscustomobject][ordered]@{
            path           = $outputFullPath
            sha256         = Get-ExcelFileHash -Path $outputFullPath
            bytes          = [long]$outputFile.Length
            worksheetCount = $worksheetCount
            format         = 'PDF'
        }
        truncationNotices = @()
    })
}
catch {
    if ($null -ne $temporaryOutputPath -and (Test-Path -LiteralPath $temporaryOutputPath -PathType Leaf)) {
        try { [IO.File]::Delete($temporaryOutputPath) } catch {}
    }
    if ($outputCreated -and $null -ne $outputFullPath -and (Test-Path -LiteralPath $outputFullPath -PathType Leaf)) {
        try { [IO.File]::Delete($outputFullPath) } catch {}
    }
    $context = @{}
    if ($null -ne $sourceFullPath) { $context['sourcePath'] = $sourceFullPath }
    if ($null -ne $outputFullPath) { $context['outputPath'] = $outputFullPath }
    if ($null -ne $sourceHashBefore) { $context['sourceSha256Before'] = $sourceHashBefore }
    if ($null -ne $sourceFullPath -and (Test-Path -LiteralPath $sourceFullPath -PathType Leaf)) {
        try { $context['sourceSha256After'] = Get-ExcelFileHash -Path $sourceFullPath } catch {}
    }
    Write-ExcelFailure -Command 'Export-ExcelWorkbook' -ErrorRecord $_ -Context $context
    exit 1
}

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourcePath,

    [string]$SheetName = '',

    [string]$RangeAddress = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path -Path $PSScriptRoot -ChildPath 'Excel.Common.ps1')

$application = $null
$workbook = $null
$worksheets = $null
$sourceFullPath = $null
$sourceHashBefore = $null
$sourceHashAfter = $null

try {
    $hasSheetName = -not [string]::IsNullOrWhiteSpace($SheetName)
    $hasRangeAddress = -not [string]::IsNullOrWhiteSpace($RangeAddress)
    if ($hasSheetName -ne $hasRangeAddress) {
        throw 'SheetName and RangeAddress must be supplied together.'
    }
    if ($hasRangeAddress) {
        Assert-ExcelRangeAddress -Address $RangeAddress
    }

    $settings = Get-ExcelSettings
    $sourceFullPath = Resolve-ExistingExcelFile -Path $SourcePath -Description 'Source workbook'
    Assert-ExcelWorkbookExtension -Path $sourceFullPath
    Assert-ExcelInputAllowed -Path $sourceFullPath -Settings $settings -Description 'Source workbook'
    $sourceHashBefore = Get-ExcelFileHash -Path $sourceFullPath

    $sheetResults = @()
    $rangeResult = $null
    $truncationNotices = @()
    $excelVersion = ''
    $hasVbProject = $null
    $workbookFileFormat = 0
    $maxSheets = 200

    try {
        $application = New-SafeExcelApplication
        $excelVersion = [string]$application.Version
        $workbook = Open-ExcelWorkbookReadOnly -Application $application -Path $sourceFullPath
        $workbookFileFormat = [int]$workbook.FileFormat
        $worksheets = $workbook.Worksheets
        $sheetCount = [int]$worksheets.Count
        $inspectedSheetCount = [Math]::Min($sheetCount, $maxSheets)

        for ($sheetIndex = 1; $sheetIndex -le $inspectedSheetCount; $sheetIndex++) {
            $worksheet = $null
            $usedRange = $null
            $usedCells = $null
            $usedRows = $null
            $usedColumns = $null
            try {
                $worksheet = $worksheets.Item($sheetIndex)
                $usedRange = $worksheet.UsedRange
                $usedCells = $usedRange.Cells
                $usedRows = $usedRange.Rows
                $usedColumns = $usedRange.Columns
                $sheetResults += [pscustomobject][ordered]@{
                    index             = $sheetIndex
                    name              = [string]$worksheet.Name
                    visible           = [int]$worksheet.Visible
                    protectedContents = [bool]$worksheet.ProtectContents
                    usedRange         = [string]$usedRange.Address($false, $false, 1)
                    usedCellCount     = [long]$usedCells.CountLarge
                    usedRowCount      = [int]$usedRows.Count
                    usedColumnCount   = [int]$usedColumns.Count
                }
            }
            finally {
                Release-ExcelComObject -ComObject $usedColumns
                Release-ExcelComObject -ComObject $usedRows
                Release-ExcelComObject -ComObject $usedCells
                Release-ExcelComObject -ComObject $usedRange
                Release-ExcelComObject -ComObject $worksheet
            }
        }

        if ($sheetCount -gt $maxSheets) {
            $truncationNotices += "Worksheet metadata was limited to the first $maxSheets of $sheetCount sheets."
        }

        if ($hasRangeAddress) {
            $worksheet = $null
            $range = $null
            $cells = $null
            $cellResults = @()
            try {
                $worksheet = Get-ExcelWorksheetByName -Worksheets $worksheets -Name $SheetName
                $range = $worksheet.Range($RangeAddress)
                $cells = $range.Cells
                $cellCount = [long]$cells.CountLarge
                if ($cellCount -gt 32) {
                    throw "The requested range contains $cellCount cells; the maximum is 32."
                }

                for ($cellIndex = 1; $cellIndex -le $cellCount; $cellIndex++) {
                    $cell = $null
                    try {
                        $cell = $cells.Item($cellIndex)
                        $hasFormula = [bool]$cell.HasFormula
                        $formula = $null
                        if ($hasFormula) {
                            $formula = [string]$cell.Formula
                        }
                        $cellResults += [pscustomobject][ordered]@{
                            address     = [string]$cell.Address($false, $false, 1)
                            row         = [int]$cell.Row
                            column      = [int]$cell.Column
                            displayedText = [string]$cell.Text
                            value       = $cell.Value2
                            hasFormula  = $hasFormula
                            formula     = $formula
                            locked      = [bool]$cell.Locked
                        }
                    }
                    finally {
                        Release-ExcelComObject -ComObject $cell
                    }
                }

                $rangeResult = [pscustomobject][ordered]@{
                    sheetName = [string]$worksheet.Name
                    address   = [string]$range.Address($false, $false, 1)
                    cellCount = $cellCount
                    cells     = @($cellResults)
                }
            }
            finally {
                Release-ExcelComObject -ComObject $cells
                Release-ExcelComObject -ComObject $range
                Release-ExcelComObject -ComObject $worksheet
            }
        }

        try {
            $hasVbProject = [bool]$workbook.HasVBProject
        }
        catch {
            $hasVbProject = $null
        }
    }
    finally {
        Release-ExcelComObject -ComObject $worksheets
        if ($null -ne $workbook) {
            try { $workbook.Close($false) } catch {}
            Release-ExcelComObject -ComObject $workbook
            $workbook = $null
        }
        if ($null -ne $application) {
            try { $application.Quit() } catch {}
            Release-ExcelComObject -ComObject $application
            $application = $null
        }
        Complete-ExcelComCleanup
    }

    $sourceHashAfter = Get-ExcelFileHash -Path $sourceFullPath
    if ($sourceHashBefore -ne $sourceHashAfter) {
        throw 'The source workbook hash changed during inventory.'
    }

    $extension = [IO.Path]::GetExtension($sourceFullPath).ToLowerInvariant()
    Write-ExcelJson -Value ([pscustomobject][ordered]@{
        success      = $true
        command      = 'Get-ExcelInventory'
        source       = [pscustomobject][ordered]@{
            path         = $sourceFullPath
            sha256Before = $sourceHashBefore
            sha256After  = $sourceHashAfter
            unchanged    = $true
        }
        settingsPath = $settings.SettingsPath
        excelVersion = $excelVersion
        workbook      = [pscustomobject][ordered]@{
            name               = [IO.Path]::GetFileName($sourceFullPath)
            worksheetCount     = $sheetCount
            inspectedSheetCount = @($sheetResults).Count
            fileFormat         = [int]$workbookFileFormat
            macroCapable       = @('.xls', '.xlsm', '.xlsb') -contains $extension
            hasVbProject       = $hasVbProject
        }
        worksheets    = @($sheetResults)
        inspectedRange = $rangeResult
        truncationNotices = @($truncationNotices)
    })
}
catch {
    $context = @{}
    if ($null -ne $sourceFullPath) { $context['sourcePath'] = $sourceFullPath }
    if ($null -ne $sourceHashBefore) { $context['sourceSha256Before'] = $sourceHashBefore }
    if ($null -ne $sourceFullPath -and (Test-Path -LiteralPath $sourceFullPath -PathType Leaf)) {
        try { $context['sourceSha256After'] = Get-ExcelFileHash -Path $sourceFullPath } catch {}
    }
    Write-ExcelFailure -Command 'Get-ExcelInventory' -ErrorRecord $_ -Context $context
    exit 1
}

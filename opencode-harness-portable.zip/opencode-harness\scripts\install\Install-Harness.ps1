#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateSet('Internet', 'Intranet')]
    [string]$Machine,

    [string]$BaseUrl = $env:OFFICE_LLM_BASE_URL,

    [ValidateNotNullOrEmpty()]
    [string]$GeneralModelId = 'qwen35-122b-a10b',

    [ValidateNotNullOrEmpty()]
    [string]$CoderModelId = 'qwen-next-80b-coder',

    [Alias('PowerPointRoot')]
    [string[]]$OfficeRoot = @([Environment]::GetFolderPath([Environment+SpecialFolder]::MyDocuments)),

    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'OpenCodeOfficeHarness'),

    [switch]$DoNotPersistBaseUrl,

    [switch]$UseExistingOpenCode
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function ConvertTo-JsonToken {
    param([Parameter(Mandatory = $true)][string]$Value)
    $json = $Value | ConvertTo-Json -Compress
    return $json.Substring(1, $json.Length - 2)
}

function Copy-DirectoryContents {
    param(
        [Parameter(Mandatory = $true)][string]$Source,
        [Parameter(Mandatory = $true)][string]$Destination
    )
    if (-not (Test-Path -LiteralPath $Source -PathType Container)) { throw "Required source directory is missing: '$Source'." }
    $null = New-Item -ItemType Directory -Path $Destination -Force
    Copy-Item -Path (Join-Path $Source '*') -Destination $Destination -Recurse -Force
}

try {
    $sourceRoot = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
    if (-not (Test-Path -LiteralPath (Join-Path $sourceRoot 'README.md') -PathType Leaf)) {
        throw "Harness source root is invalid: '$sourceRoot'."
    }
    $baseUri = $null
    if (-not $UseExistingOpenCode) {
        if ([string]::IsNullOrWhiteSpace($BaseUrl)) {
            $BaseUrl = Read-Host 'Internal OpenAI-compatible API base URL'
        }
        if (-not [Uri]::TryCreate($BaseUrl, [UriKind]::Absolute, [ref]$baseUri) -or $baseUri.Scheme -notin @('http', 'https')) {
            throw 'BaseUrl must be an absolute HTTP or HTTPS URL.'
        }
        if ($baseUri.AbsolutePath -match '/(chat/completions|responses)/?$') {
            throw 'BaseUrl must be the API root, not the final chat/completions or responses endpoint.'
        }
        if (-not [string]::IsNullOrEmpty($baseUri.UserInfo) -or -not [string]::IsNullOrEmpty($baseUri.Query) -or
            -not [string]::IsNullOrEmpty($baseUri.Fragment)) {
            throw 'BaseUrl must not contain user information, query parameters, or a fragment.'
        }
    }
    if ($GeneralModelId -notmatch '^[A-Za-z0-9._:/-]+$' -or $CoderModelId -notmatch '^[A-Za-z0-9._:/-]+$') {
        throw 'Model IDs may contain only letters, digits, dot, underscore, colon, slash, and hyphen.'
    }

    $officeRootsExplicitlyProvided = $PSBoundParameters.ContainsKey('OfficeRoot')
    $resolvedOfficeRoots = New-Object System.Collections.ArrayList
    foreach ($requestedOfficeRoot in @($OfficeRoot)) {
        if ([string]::IsNullOrWhiteSpace([string]$requestedOfficeRoot)) {
            if ($officeRootsExplicitlyProvided) { throw 'OfficeRoot entries must not be empty.' }
            continue
        }
        $expandedOfficeRoot = [IO.Path]::GetFullPath(
            [Environment]::ExpandEnvironmentVariables([string]$requestedOfficeRoot))
        if (-not (Test-Path -LiteralPath $expandedOfficeRoot -PathType Container)) {
            if ($officeRootsExplicitlyProvided) { throw "OfficeRoot does not exist: '$expandedOfficeRoot'." }
            continue
        }
        $canonicalOfficeRoot = (Get-Item -LiteralPath $expandedOfficeRoot -ErrorAction Stop).FullName
        if (-not @($resolvedOfficeRoots | Where-Object {
            ([string]$_).Equals($canonicalOfficeRoot, [StringComparison]::OrdinalIgnoreCase)
        })) {
            $null = $resolvedOfficeRoots.Add($canonicalOfficeRoot)
        }
    }
    if ($officeRootsExplicitlyProvided -and $resolvedOfficeRoots.Count -eq 0) {
        throw 'At least one existing OfficeRoot is required when the parameter is supplied.'
    }

    $installRootFull = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($InstallRoot))
    $installParent = Split-Path -Parent $installRootFull
    if (-not (Test-Path -LiteralPath $installParent -PathType Container)) {
        throw "InstallRoot parent does not exist: '$installParent'."
    }
    $runtimeRoot = Join-Path $installRootFull 'runtime'
    $stateRoot = Join-Path $installRootFull 'state'
    $settingsRoot = Join-Path $stateRoot 'settings'
    $memoryRoot = Join-Path $stateRoot 'memory'
    $wordWorkspace = Join-Path $stateRoot 'workspaces\word'
    $openCodeConfigRoot = Join-Path $runtimeRoot 'opencode'
    $registrationPath = Join-Path $installRootFull 'install-registration.json'
    $previousRegistration = $null
    if (Test-Path -LiteralPath $registrationPath -PathType Leaf) {
        $previousRegistration = [IO.File]::ReadAllText($registrationPath) | ConvertFrom-Json -ErrorAction Stop
        if ($previousRegistration.schemaVersion -ne 1 -or
            -not ([IO.Path]::GetFullPath([string]$previousRegistration.installRoot)).Equals($installRootFull, [StringComparison]::OrdinalIgnoreCase)) {
            throw "Install registration does not own '$installRootFull'."
        }
        if ($previousRegistration.active -and
            ([bool]$previousRegistration.useExistingOpenCode -ne [bool]$UseExistingOpenCode)) {
            throw 'Install mode cannot change while this harness registration is active. Uninstall first or choose another InstallRoot.'
        }
    }

    if ($UseExistingOpenCode) {
        $existingConfigRoot = [Environment]::GetEnvironmentVariable('OPENCODE_CONFIG_DIR', 'User')
        if (-not [string]::IsNullOrWhiteSpace($existingConfigRoot) -and
            -not [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($existingConfigRoot)).Equals(
                $openCodeConfigRoot,
                [StringComparison]::OrdinalIgnoreCase
            )) {
            throw "OPENCODE_CONFIG_DIR is already set to '$existingConfigRoot'. Remove or merge that custom directory before installing the Office harness."
        }
    }

    $roleMarker = Join-Path $stateRoot 'machine-role.txt'
    if (Test-Path -LiteralPath $roleMarker -PathType Leaf) {
        $installedRole = [IO.File]::ReadAllText($roleMarker).Trim()
        if (-not $installedRole.Equals($Machine, [StringComparison]::OrdinalIgnoreCase)) {
            throw "InstallRoot already contains '$installedRole' state and cannot be changed to '$Machine'. Choose a different InstallRoot."
        }
    }

    if (Test-Path -LiteralPath $runtimeRoot) { Remove-Item -LiteralPath $runtimeRoot -Recurse -Force }
    $null = New-Item -ItemType Directory -Path $runtimeRoot -Force
    $null = New-Item -ItemType Directory -Path $stateRoot -Force
    $null = New-Item -ItemType Directory -Path $settingsRoot -Force
    $null = New-Item -ItemType Directory -Path (Join-Path $stateRoot 'xdg') -Force
    $null = New-Item -ItemType Directory -Path (Join-Path $stateRoot 'xdg-data') -Force
    $null = New-Item -ItemType Directory -Path (Join-Path $stateRoot 'xdg-state') -Force
    $null = New-Item -ItemType Directory -Path (Join-Path $stateRoot 'xdg-cache') -Force

    if (-not (Test-Path -LiteralPath $roleMarker -PathType Leaf)) {
        [IO.File]::WriteAllText($roleMarker, $Machine, (New-Object Text.UTF8Encoding($false)))
    }

    Copy-DirectoryContents -Source (Join-Path $sourceRoot 'opencode') -Destination (Join-Path $runtimeRoot 'opencode')
    Copy-DirectoryContents -Source (Join-Path $sourceRoot 'scripts') -Destination (Join-Path $runtimeRoot 'scripts')
    if (-not (Test-Path -LiteralPath $wordWorkspace -PathType Container)) {
        Copy-Item -LiteralPath (Join-Path $sourceRoot 'workspace-template\word') -Destination $wordWorkspace -Recurse
    }
    if ($Machine -eq 'Internet') {
        Copy-DirectoryContents -Source (Join-Path $sourceRoot 'browser-mcp') -Destination (Join-Path $runtimeRoot 'browser-mcp')
        foreach ($relativePath in @(
            'opencode\tools\office_slurm.ts',
            'opencode\agents\slurm-operator.md',
            'opencode\skills\slurm-ssh',
            'opencode\commands\slurm-status.md',
            'scripts\slurm'
        )) {
            $roleExcludedPath = Join-Path $runtimeRoot $relativePath
            if (Test-Path -LiteralPath $roleExcludedPath) { Remove-Item -LiteralPath $roleExcludedPath -Recurse -Force }
        }
    }
    else {
        foreach ($relativePath in @(
            'opencode\tools\office_browser.ts',
            'opencode\tools\office_outlook.ts',
            'opencode\agents\browser-operator.md',
            'opencode\agents\outlook-reader.md',
            'opencode\agents\outlook-operator.md',
            'opencode\agents\outlook-web-reader.md',
            'opencode\skills\browser-chrome',
            'opencode\skills\outlook-classic-read',
            'opencode\skills\outlook-classic-manage',
            'opencode\skills\outlook-web-read',
            'opencode\commands\open-site.md',
            'opencode\commands\mail-summary.md',
            'opencode\commands\mail-web-summary.md',
            'scripts\browser',
            'scripts\outlook'
        )) {
            $roleExcludedPath = Join-Path $runtimeRoot $relativePath
            if (Test-Path -LiteralPath $roleExcludedPath) { Remove-Item -LiteralPath $roleExcludedPath -Recurse -Force }
        }
    }

    $requiredNodeModule = Join-Path $runtimeRoot 'opencode\node_modules\@opencode-ai\plugin\package.json'
    if (-not (Test-Path -LiteralPath $requiredNodeModule -PathType Leaf)) {
        throw 'Bundled OpenCode tool dependencies are missing. On an internet PC run npm install in the source opencode folder before transfer.'
    }

    $settingNames = if ($Machine -eq 'Internet') { @('sites', 'outlook', 'powerpoint', 'presentation-style') } else { @('powerpoint', 'presentation-style', 'slurm') }
    foreach ($settingName in $settingNames) {
        $destination = Join-Path $settingsRoot ($settingName + '.local.json')
        $createdSetting = $false
        if (-not (Test-Path -LiteralPath $destination -PathType Leaf)) {
            Copy-Item -LiteralPath (Join-Path $sourceRoot ('settings\' + $settingName + '.example.json')) -Destination $destination
            $createdSetting = $true
        }
        if ($settingName -eq 'powerpoint' -and ($createdSetting -or $officeRootsExplicitlyProvided)) {
            $powerPointSettings = [IO.File]::ReadAllText($destination) | ConvertFrom-Json -ErrorAction Stop
            $powerPointSettings.allowedRoots = @($resolvedOfficeRoots)
            [IO.File]::WriteAllText($destination, ($powerPointSettings | ConvertTo-Json -Depth 5), (New-Object Text.UTF8Encoding($false)))
        }
    }

    $powerPointSettingsPath = Join-Path $settingsRoot 'powerpoint.local.json'
    $powerPointSettings = [IO.File]::ReadAllText($powerPointSettingsPath) | ConvertFrom-Json -ErrorAction Stop
    $configuredOfficeRoots = New-Object System.Collections.ArrayList
    foreach ($configuredOfficeRoot in @($powerPointSettings.allowedRoots)) {
        if ([string]::IsNullOrWhiteSpace([string]$configuredOfficeRoot)) { continue }
        $expandedOfficeRoot = [IO.Path]::GetFullPath(
            [Environment]::ExpandEnvironmentVariables([string]$configuredOfficeRoot))
        if (Test-Path -LiteralPath $expandedOfficeRoot -PathType Container) {
            $expandedOfficeRoot = (Get-Item -LiteralPath $expandedOfficeRoot -ErrorAction Stop).FullName
        }
        if (-not @($configuredOfficeRoots | Where-Object {
            ([string]$_).Equals($expandedOfficeRoot, [StringComparison]::OrdinalIgnoreCase)
        })) {
            $null = $configuredOfficeRoots.Add($expandedOfficeRoot)
        }
    }

    $createdMemory = $false
    if (-not (Test-Path -LiteralPath $memoryRoot -PathType Container)) {
        Copy-Item -LiteralPath (Join-Path $sourceRoot 'memory-template') -Destination $memoryRoot -Recurse
        $createdMemory = $true
    }
    if ($createdMemory) {
        $irrelevantMemoryFiles = if ($Machine -eq 'Internet') {
            @('approved\hpc-conventions.md')
        }
        else {
            @('approved\browser-sites.md', 'approved\outlook-conventions.md')
        }
        foreach ($relativeMemoryPath in $irrelevantMemoryFiles) {
            $irrelevantMemoryPath = Join-Path $memoryRoot $relativeMemoryPath
            if (Test-Path -LiteralPath $irrelevantMemoryPath -PathType Leaf) { Remove-Item -LiteralPath $irrelevantMemoryPath -Force }
        }
    }
    [string[]]$machineMemory = @(
        '# Machine Scope'
        ''
        "- Machine: $Machine"
        '- Data boundary: machine-local; do not synchronize automatically'
        "- Installed: $((Get-Date).ToString('o'))"
        ''
    )
    [IO.File]::WriteAllLines((Join-Path $memoryRoot 'machine.md'), $machineMemory, (New-Object Text.UTF8Encoding($false)))
    $topicLines = if ($Machine -eq 'Internet') {
        @('approved/preferences.md', 'approved/browser-sites.md', 'approved/outlook-conventions.md', 'approved/powerpoint-conventions.md', 'approved/notes/*.md')
    }
    else {
        @('approved/preferences.md', 'approved/powerpoint-conventions.md', 'approved/hpc-conventions.md', 'approved/notes/*.md')
    }
    [string[]]$memoryIndex = @(
        '# Office Memory Index'
        ''
        "Machine role: $Machine"
        ''
        'Only files under `approved/` are durable memory. Files under `inbox/` are untrusted drafts and must not guide work until explicitly promoted with their reviewed SHA256.'
        ''
        'Read only the approved topic relevant to the current task. Never store or synchronize credentials, email content, browser state, raw analysis data, confidential values, or transient job state.'
        ''
        'Approved topics:'
        ''
    ) + @($topicLines | ForEach-Object { '- `' + $_ + '`' }) + @('')
    [IO.File]::WriteAllLines((Join-Path $memoryRoot 'index.md'), $memoryIndex, (New-Object Text.UTF8Encoding($false)))

    $profileTemplate = Join-Path $sourceRoot ('profiles\' + $Machine.ToLowerInvariant() + '\opencode.json.template')
    $configText = [IO.File]::ReadAllText($profileTemplate)
    $agentsPath = Join-Path $runtimeRoot 'opencode\AGENTS.md'
    $memoryIndexPath = Join-Path $memoryRoot 'index.md'
    $replacementValues = [ordered]@{
        '__SHELL__' = 'powershell.exe'
        '__GENERAL_MODEL_ID__' = $GeneralModelId
        '__CODER_MODEL_ID__' = $CoderModelId
        '__AGENTS_PATH__' = (ConvertTo-JsonToken -Value $agentsPath)
        '__MEMORY_INDEX_PATH__' = (ConvertTo-JsonToken -Value $memoryIndexPath)
    }
    if ($Machine -eq 'Internet') {
        $node = @(Get-Command node.exe -CommandType Application -ErrorAction Stop)[0]
        $nodeVersionText = (& $node.Path --version).TrimStart('v')
        $nodeVersion = $null
        if (-not [Version]::TryParse($nodeVersionText, [ref]$nodeVersion) -or $nodeVersion.Major -lt 20) {
            throw "Playwright MCP requires Node.js 20 or newer; found '$nodeVersionText'."
        }
        $playwrightCli = Join-Path $runtimeRoot 'browser-mcp\node_modules\@playwright\mcp\cli.js'
        if (-not (Test-Path -LiteralPath $playwrightCli -PathType Leaf)) {
            throw 'Bundled Playwright MCP dependencies are missing. Run npm install in browser-mcp before transfer.'
        }
        $browserState = Join-Path $stateRoot 'browser'
        $browserOutput = Join-Path $stateRoot 'browser-output'
        $outlookWebBrowserState = Join-Path $stateRoot 'outlook-web-browser'
        $outlookWebBrowserOutput = Join-Path $stateRoot 'outlook-web-output'
        $null = New-Item -ItemType Directory -Path $browserState -Force
        $null = New-Item -ItemType Directory -Path $browserOutput -Force
        $null = New-Item -ItemType Directory -Path $outlookWebBrowserState -Force
        $null = New-Item -ItemType Directory -Path $outlookWebBrowserOutput -Force
        $replacementValues['__NODE_CMD__'] = (ConvertTo-JsonToken -Value $node.Path)
        $replacementValues['__PLAYWRIGHT_CLI__'] = (ConvertTo-JsonToken -Value $playwrightCli)
        $replacementValues['__PLAYWRIGHT_WRAPPER__'] = (ConvertTo-JsonToken -Value (Join-Path $runtimeRoot 'scripts\browser\Start-PlaywrightMcp.ps1'))
        $replacementValues['__BROWSER_PROFILE_DIR__'] = (ConvertTo-JsonToken -Value $browserState)
        $replacementValues['__BROWSER_OUTPUT_DIR__'] = (ConvertTo-JsonToken -Value $browserOutput)
        $replacementValues['__OUTLOOK_WEB_BROWSER_PROFILE_DIR__'] = (ConvertTo-JsonToken -Value $outlookWebBrowserState)
        $replacementValues['__OUTLOOK_WEB_BROWSER_OUTPUT_DIR__'] = (ConvertTo-JsonToken -Value $outlookWebBrowserOutput)
    }
    foreach ($entry in $replacementValues.GetEnumerator()) {
        $configText = $configText.Replace([string]$entry.Key, [string]$entry.Value)
    }
    if ($configText -cmatch '__[A-Z0-9_]+__') { throw "Generated config contains unresolved template token '$($Matches[0])'." }
    $configObject = $configText | ConvertFrom-Json -ErrorAction Stop
    $externalDirectoryRules = [ordered]@{ '*' = 'ask' }
    foreach ($configuredOfficeRoot in $configuredOfficeRoots) {
        $rootPattern = ([string]$configuredOfficeRoot).TrimEnd('\', '/')
        if ($rootPattern -match '^[A-Za-z]:$') { $rootPattern += '\' }
        $externalDirectoryRules[$rootPattern] = 'allow'
        $externalDirectoryRules[$rootPattern.TrimEnd('\', '/') + '\**'] = 'allow'
    }
    $configObject.permission.external_directory = [pscustomobject]$externalDirectoryRules
    if ($UseExistingOpenCode) {
        foreach ($propertyName in @('model', 'small_model', 'enabled_providers', 'provider')) {
            $configObject.PSObject.Properties.Remove($propertyName)
        }
        foreach ($agentProperty in @($configObject.agent.PSObject.Properties)) {
            $agentProperty.Value.PSObject.Properties.Remove('model')
        }
    }
    $configText = $configObject | ConvertTo-Json -Depth 20
    $configPath = Join-Path $stateRoot 'opencode.json'
    [IO.File]::WriteAllText($configPath, $configText, (New-Object Text.UTF8Encoding($false)))
    if ($UseExistingOpenCode) {
        [IO.File]::WriteAllText((Join-Path $openCodeConfigRoot 'opencode.json'), $configText, (New-Object Text.UTF8Encoding($false)))
    }

    foreach ($templateName in @('Start-OfficeOpenCode.ps1', 'Start-WordOpenCode.ps1', 'Test-OfficeHarness.ps1', 'Uninstall-Harness.ps1')) {
        $templatePath = Join-Path $sourceRoot ('scripts\install\' + $templateName + '.template')
        $launcherText = [IO.File]::ReadAllText($templatePath)
        $launcherText = $launcherText.Replace('__INSTALL_ROOT_PS__', $installRootFull.Replace("'", "''"))
        $launcherText = $launcherText.Replace('__MACHINE__', $Machine)
        $launcherText = $launcherText.Replace('__USE_EXISTING_OPENCODE__', ([bool]$UseExistingOpenCode).ToString())
        [IO.File]::WriteAllText((Join-Path $installRootFull $templateName), $launcherText, (New-Object Text.UTF8Encoding($false)))
    }
    Copy-Item -LiteralPath (Join-Path $sourceRoot 'scripts\install\Set-OfficeApiKey.ps1') -Destination (Join-Path $installRootFull 'Set-OfficeApiKey.ps1') -Force

    $environmentValues = [ordered]@{}
    if ($UseExistingOpenCode) {
        $powerShellPath = @(Get-Command powershell.exe -CommandType Application -ErrorAction Stop)[0].Path
        $environmentValues['OPENCODE_CONFIG_DIR'] = $openCodeConfigRoot
        $environmentValues['OFFICE_HARNESS_ROOT'] = $runtimeRoot
        $environmentValues['OFFICE_HARNESS_STATE'] = $stateRoot
        $environmentValues['OFFICE_HARNESS_SETTINGS'] = $settingsRoot
        $environmentValues['OFFICE_HARNESS_MACHINE'] = $Machine
        $environmentValues['OFFICE_HARNESS_POWERSHELL'] = $powerShellPath
    }
    else {
        if (-not $DoNotPersistBaseUrl) {
            $environmentValues['OFFICE_LLM_BASE_URL'] = $baseUri.AbsoluteUri.TrimEnd('/')
        }
        $env:OFFICE_LLM_BASE_URL = $baseUri.AbsoluteUri.TrimEnd('/')
    }

    $registeredEnvironment = New-Object System.Collections.ArrayList
    if ($null -ne $previousRegistration -and $previousRegistration.active) {
        foreach ($entry in @($previousRegistration.environment)) {
            $null = $registeredEnvironment.Add([ordered]@{
                name = [string]$entry.name
                previousValue = $entry.previousValue
                installedValue = [string]$entry.installedValue
            })
        }
    }
    foreach ($environmentValue in $environmentValues.GetEnumerator()) {
        $existingEntry = @($registeredEnvironment | Where-Object { $_.name -eq [string]$environmentValue.Key } | Select-Object -First 1)
        if ($existingEntry.Count -eq 1) {
            $existingEntry[0].installedValue = [string]$environmentValue.Value
        }
        else {
            $null = $registeredEnvironment.Add([ordered]@{
                name = [string]$environmentValue.Key
                previousValue = [Environment]::GetEnvironmentVariable([string]$environmentValue.Key, 'User')
                installedValue = [string]$environmentValue.Value
            })
        }
    }
    $registration = [ordered]@{
        schemaVersion = 1
        installRoot = $installRootFull
        machine = $Machine
        useExistingOpenCode = [bool]$UseExistingOpenCode
        active = $true
        environment = @($registeredEnvironment)
    }
    [IO.File]::WriteAllText($registrationPath, ($registration | ConvertTo-Json -Depth 6), (New-Object Text.UTF8Encoding($false)))
    foreach ($environmentValue in $environmentValues.GetEnumerator()) {
        [Environment]::SetEnvironmentVariable([string]$environmentValue.Key, [string]$environmentValue.Value, 'User')
    }

    $nextSteps = @(
        "Edit local settings under $settingsRoot",
        "Run $(Join-Path $installRootFull 'Test-OfficeHarness.ps1')",
        "Disconnect later with $(Join-Path $installRootFull 'Uninstall-Harness.ps1')"
    )
    if ($UseExistingOpenCode) {
        $nextSteps += "Run $(Join-Path $installRootFull 'Start-WordOpenCode.ps1') for the staged Word workflow"
    }
    else {
        $nextSteps += "Run $(Join-Path $installRootFull 'Start-OfficeOpenCode.ps1')"
    }

    [pscustomobject]@{
        Ok = $true
        Machine = $Machine
        InstallRoot = $installRootFull
        Config = $configPath
        Settings = $settingsRoot
        Memory = $memoryRoot
        WordWorkspace = $wordWorkspace
        Uninstaller = (Join-Path $installRootFull 'Uninstall-Harness.ps1')
        StatePreservedOnDefaultUninstall = $true
        GeneralModel = $GeneralModelId
        CoderModel = $CoderModelId
        UsesExistingOpenCodeConfig = [bool]$UseExistingOpenCode
        ApiKeyPresent = (Test-Path -LiteralPath (Join-Path $stateRoot 'secrets\llm-api-key.bin') -PathType Leaf)
        Next = $nextSteps
    } | ConvertTo-Json -Depth 5
}
catch {
    [Console]::Error.WriteLine(([ordered]@{ Ok = $false; Error = $_.Exception.Message } | ConvertTo-Json -Compress))
    exit 1
}

#requires -Version 5.1

<#
    Builds the portable harness archive in releases/.

    The archive is staged, compressed, and fully verified before the existing deliverable is
    replaced, so a failed build can never destroy the previous package. The checksum file is
    rewritten from the bytes that actually landed on disk, not from the staging copy.

    Bundled node_modules are intentional: the office PCs install offline. See TRANSFER-MANIFEST.md.
#>

[CmdletBinding()]
param(
    [Parameter()]
    [ValidateNotNullOrEmpty()]
    [string]$OutputPath,

    [Parameter()]
    [switch]$SkipStaticTest
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

# Excluded from the package. 'releases' keeps the archive out of itself and *.local.json is machine-local.
# Only the source root CONTEXT.md is removed after staging; nested portable-workspace contracts are kept.
$excludedDirectories = @('releases', 'local', '.git')
$excludedFiles = @('*.local.json', '*.log', '*.tmp')

$workRoot = $null

try {
    $root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
    $packageName = 'opencode-harness'

    if ([string]::IsNullOrWhiteSpace($OutputPath)) {
        $resolvedOutput = Join-Path $root ('releases\' + $packageName + '-portable.zip')
    }
    else {
        $resolvedOutput = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($OutputPath))
    }
    if ([IO.Path]::GetExtension($resolvedOutput) -ne '.zip') {
        throw "OutputPath must end in .zip, got '$resolvedOutput'."
    }
    $outputDirectory = Split-Path -Parent $resolvedOutput
    if (-not (Test-Path -LiteralPath $outputDirectory -PathType Container)) {
        $null = New-Item -ItemType Directory -Path $outputDirectory -Force
    }

    if (-not $SkipStaticTest.IsPresent) {
        $staticTest = Join-Path $root 'tests\Test-Static.ps1'
        if (-not (Test-Path -LiteralPath $staticTest -PathType Leaf)) {
            throw "Static test not found at '$staticTest'."
        }
        $powerShell = @(Get-Command powershell.exe -CommandType Application -ErrorAction Stop)[0]
        & $powerShell.Path -NoLogo -NoProfile -NonInteractive -File $staticTest | Out-Null
        if ($LASTEXITCODE -ne 0) {
            throw "Test-Static.ps1 failed with exit code $LASTEXITCODE. The package was not built."
        }
    }

    $workRoot = Join-Path ([IO.Path]::GetTempPath()) ('harness-package-' + [Guid]::NewGuid().ToString('N'))
    $stageRoot = Join-Path $workRoot 'tree'
    $stage = Join-Path $stageRoot $packageName
    $stagingZip = Join-Path $workRoot ($packageName + '-staging.zip')
    $null = New-Item -ItemType Directory -Path $stage -Force

    $robocopyArguments = New-Object System.Collections.ArrayList
    $null = $robocopyArguments.Add($root)
    $null = $robocopyArguments.Add($stage)
    foreach ($switch in @('/E', '/NFL', '/NDL', '/NJH', '/NJS', '/NP', '/R:1', '/W:1')) {
        $null = $robocopyArguments.Add($switch)
    }
    $null = $robocopyArguments.Add('/XD')
    foreach ($directory in $excludedDirectories) {
        $null = $robocopyArguments.Add((Join-Path $root $directory))
    }
    $null = $robocopyArguments.Add('/XF')
    foreach ($file in $excludedFiles) {
        $null = $robocopyArguments.Add($file)
    }

    $robocopy = @(Get-Command robocopy.exe -CommandType Application -ErrorAction Stop)[0]
    & $robocopy.Path @robocopyArguments | Out-Null
    # Robocopy uses exit codes 0-7 for success and 8 or above for failure.
    if ($LASTEXITCODE -ge 8) {
        throw "robocopy failed with exit code $LASTEXITCODE."
    }
    $LASTEXITCODE = 0

    $sourceRouter = Join-Path $stage 'CONTEXT.md'
    if (Test-Path -LiteralPath $sourceRouter -PathType Leaf) {
        Remove-Item -LiteralPath $sourceRouter -Force
    }

    $stagedFiles = @(Get-ChildItem -LiteralPath $stage -Recurse -File)
    if ($stagedFiles.Count -lt 1) {
        throw 'Staging produced no files.'
    }
    $stagedRelativePaths = New-Object System.Collections.Generic.HashSet[string] ([StringComparer]::OrdinalIgnoreCase)
    $stagePrefixLength = $stageRoot.TrimEnd('\').Length + 1
    foreach ($stagedFile in $stagedFiles) {
        $null = $stagedRelativePaths.Add($stagedFile.FullName.Substring($stagePrefixLength).Replace('\', '/'))
    }

    Add-Type -AssemblyName System.IO.Compression.FileSystem
    [IO.Compression.ZipFile]::CreateFromDirectory(
        $stageRoot, $stagingZip, [IO.Compression.CompressionLevel]::Optimal, $false)

    # Verify the staging archive before the existing deliverable is touched.
    $archivedPaths = New-Object System.Collections.Generic.HashSet[string] ([StringComparer]::OrdinalIgnoreCase)
    $bundledModuleCount = 0
    $archive = [IO.Compression.ZipFile]::OpenRead($stagingZip)
    try {
        foreach ($entry in $archive.Entries) {
            $entryPath = $entry.FullName.Replace('\', '/')
            $null = $archivedPaths.Add($entryPath)
            if ($entryPath -match '/node_modules/') { $bundledModuleCount++ }
        }
    }
    finally {
        $archive.Dispose()
    }

    $missingFromArchive = @($stagedRelativePaths | Where-Object { -not $archivedPaths.Contains($_) })
    if ($missingFromArchive.Count -gt 0) {
        throw ("The archive is missing {0} staged file(s), first: {1}" -f $missingFromArchive.Count, $missingFromArchive[0])
    }
    $unexpectedInArchive = @($archivedPaths | Where-Object { -not $stagedRelativePaths.Contains($_) })
    if ($unexpectedInArchive.Count -gt 0) {
        throw ("The archive contains {0} unstaged entr(y/ies), first: {1}" -f $unexpectedInArchive.Count, $unexpectedInArchive[0])
    }

    $leaked = @($archivedPaths | Where-Object {
        ($_ -match '(?i)/releases/') -or
        ($_ -match '(?i)\.local\.json$') -or
        ($_ -match "(?i)^$([regex]::Escape($packageName))/CONTEXT\.md$") -or
        ($_ -match '(?i)/\.git/')
    })
    if ($leaked.Count -gt 0) {
        throw ("The archive contains excluded content, first: {0}" -f $leaked[0])
    }

    if ($bundledModuleCount -lt 1000) {
        throw ("Bundled node_modules look incomplete ({0} entries). Run Prepare-Dependencies.ps1 first." -f $bundledModuleCount)
    }

    $previousBytes = 0
    if (Test-Path -LiteralPath $resolvedOutput -PathType Leaf) {
        $previousBytes = (Get-Item -LiteralPath $resolvedOutput).Length
    }

    Copy-Item -LiteralPath $stagingZip -Destination $resolvedOutput -Force

    $checksumPath = $resolvedOutput + '.sha256'
    $hash = (Get-FileHash -LiteralPath $resolvedOutput -Algorithm SHA256).Hash.ToLowerInvariant()
    $checksumLine = $hash + '  ' + [IO.Path]::GetFileName($resolvedOutput)
    [IO.File]::WriteAllText($checksumPath, $checksumLine + "`n", (New-Object Text.UTF8Encoding($false)))

    [pscustomobject]@{
        Ok            = $true
        Package       = $resolvedOutput
        Checksum      = $checksumPath
        Sha256        = $hash
        Files         = $stagedFiles.Count
        BundledModule = $bundledModuleCount
        Bytes         = (Get-Item -LiteralPath $resolvedOutput).Length
        PreviousBytes = $previousBytes
        StaticTest    = (-not $SkipStaticTest.IsPresent)
    } | ConvertTo-Json
}
catch {
    [Console]::Error.WriteLine(([ordered]@{ Ok = $false; Error = $_.Exception.Message } | ConvertTo-Json -Compress))
    exit 1
}
finally {
    if (($null -ne $workRoot) -and (Test-Path -LiteralPath $workRoot)) {
        Remove-Item -LiteralPath $workRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
}

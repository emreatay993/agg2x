#requires -Version 5.1

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

try {
    $root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..\..'))
    $npm = @(Get-Command npm.cmd -CommandType Application -ErrorAction Stop)[0]
    foreach ($relativeDirectory in @('opencode', 'browser-mcp')) {
        $directory = Join-Path $root $relativeDirectory
        if (-not (Test-Path -LiteralPath (Join-Path $directory 'package-lock.json') -PathType Leaf)) {
            throw "package-lock.json is missing under '$directory'."
        }
        Push-Location -LiteralPath $directory
        try {
            & $npm.Path ci --ignore-scripts
            if ($LASTEXITCODE -ne 0) { throw "npm ci failed under '$directory' with exit code $LASTEXITCODE." }
        }
        finally {
            Pop-Location
        }
    }
    [pscustomobject]@{ Ok = $true; Root = $root; Prepared = @('opencode', 'browser-mcp') } | ConvertTo-Json
}
catch {
    [Console]::Error.WriteLine(([ordered]@{ Ok = $false; Error = $_.Exception.Message } | ConvertTo-Json -Compress))
    exit 1
}

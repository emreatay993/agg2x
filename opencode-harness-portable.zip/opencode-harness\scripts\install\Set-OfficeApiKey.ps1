#requires -Version 5.1

[CmdletBinding()]
param(
    [string]$InstallRoot = (Join-Path $env:LOCALAPPDATA 'OpenCodeOfficeHarness'),
    [Security.SecureString]$ApiKey,
    [switch]$Remove
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
Add-Type -AssemblyName System.Security
$bstr = [IntPtr]::Zero
$plainBytes = $null

try {
    $installRootFull = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($InstallRoot))
    $stateRoot = Join-Path $installRootFull 'state'
    if (-not (Test-Path -LiteralPath $stateRoot -PathType Container)) {
        throw "Harness state was not found: '$stateRoot'. Run Install-Harness.ps1 first."
    }
    $secretsRoot = Join-Path $stateRoot 'secrets'
    $keyPath = Join-Path $secretsRoot 'llm-api-key.bin'
    if ($Remove) {
        if (Test-Path -LiteralPath $keyPath -PathType Leaf) { Remove-Item -LiteralPath $keyPath -Force }
        [pscustomobject]@{ Ok = $true; Removed = $true; Path = $keyPath } | ConvertTo-Json
        exit 0
    }

    $secureValue = if ($null -ne $ApiKey) { $ApiKey } else { Read-Host 'Internal API key' -AsSecureString }
    $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureValue)
    $plainText = [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr)
    if ([string]::IsNullOrWhiteSpace($plainText)) { throw 'API key cannot be empty.' }
    $plainBytes = [Text.Encoding]::UTF8.GetBytes($plainText)
    $protectedBytes = [System.Security.Cryptography.ProtectedData]::Protect(
        $plainBytes,
        $null,
        [System.Security.Cryptography.DataProtectionScope]::CurrentUser
    )
    $null = New-Item -ItemType Directory -Path $secretsRoot -Force
    [IO.File]::WriteAllBytes($keyPath, $protectedBytes)
    [pscustomobject]@{ Ok = $true; Stored = $true; Scope = 'CurrentUserDPAPI'; Path = $keyPath } | ConvertTo-Json
}
catch {
    [Console]::Error.WriteLine(([ordered]@{ Ok = $false; Error = $_.Exception.Message } | ConvertTo-Json -Compress))
    exit 1
}
finally {
    if ($null -ne $plainBytes) { [Array]::Clear($plainBytes, 0, $plainBytes.Length) }
    if ($bstr -ne [IntPtr]::Zero) { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

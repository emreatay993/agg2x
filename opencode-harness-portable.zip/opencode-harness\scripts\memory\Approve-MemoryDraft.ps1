#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][ValidatePattern('^[0-9]{8}-[0-9]{6}-[a-f0-9]{8}$')][string]$Id,
    [Parameter(Mandatory = $true)][ValidatePattern('^[a-fA-F0-9]{64}$')][string]$ExpectedSha256
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Memory.Common.ps1')

try {
    $root = Get-HarnessMemoryRoot
    $source = Join-Path (Join-Path $root 'inbox') ($Id + '.md')
    if (-not (Test-Path -LiteralPath $source -PathType Leaf)) { throw "Memory draft '$Id' was not found." }
    $actualHash = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash.ToLowerInvariant()
    if (-not $actualHash.Equals($ExpectedSha256.ToLowerInvariant(), [StringComparison]::Ordinal)) {
        throw 'The memory draft changed after review; inspect it again and use its new SHA256.'
    }
    $content = [IO.File]::ReadAllText($source)
    if ($content -notmatch '(?m)^- Status: draft\s*$') { throw 'The candidate is not an unapproved draft.' }
    Assert-SafeMemoryText -Value $content -Name 'Draft content' -MaximumLength 10000
    if ($content -match '(?i)(email body|message body|cookie|localstorage|raw result|\.rst\b)') {
        throw 'The candidate contains a prohibited memory category.'
    }
    $scopeMatch = [regex]::Match($content, '(?m)^- Scope:\s*(common|internet|intranet)\s*$')
    if (-not $scopeMatch.Success) { throw 'The candidate has no valid memory scope.' }
    Assert-MemoryScopeForMachine -Scope $scopeMatch.Groups[1].Value
    $destinationRoot = Join-Path (Join-Path $root 'approved') 'notes'
    if (-not (Test-Path -LiteralPath $destinationRoot -PathType Container)) {
        $null = New-Item -ItemType Directory -Path $destinationRoot
    }
    $destination = Join-Path $destinationRoot ($Id + '.md')
    if (Test-Path -LiteralPath $destination) { throw "Approved memory '$Id' already exists." }
    $approvedContent = [regex]::Replace($content, '(?m)^- Status: draft\s*$', '- Status: approved', 1)
    $approvedContent = $approvedContent + "`n- Approved: $((Get-Date).ToString('o'))`n"
    [IO.File]::WriteAllText($destination, $approvedContent, (New-Object Text.UTF8Encoding($false)))
    Remove-Item -LiteralPath $source -Force
    Write-MemoryJson ([ordered]@{ ok = $true; id = $Id; reviewedSha256 = $actualHash; status = 'approved'; path = $destination })
}
catch {
    [Console]::Error.WriteLine(([ordered]@{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress))
    exit 1
}

#requires -Version 5.1

[CmdletBinding()]
param(
    [ValidateSet('Approved', 'Drafts', 'All')]
    [string]$Status = 'All'
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Memory.Common.ps1')

try {
    $root = Get-HarnessMemoryRoot
    $items = @()
    if ($Status -in @('Approved', 'All')) {
        $approvedRoot = Join-Path $root 'approved'
        if (Test-Path -LiteralPath $approvedRoot -PathType Container) {
            $items += @(Get-ChildItem -LiteralPath $approvedRoot -Recurse -File -Filter '*.md' | ForEach-Object {
                [ordered]@{ status = 'approved'; id = $_.BaseName; path = $_.FullName; sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant(); updated = $_.LastWriteTime.ToString('o') }
            })
        }
    }
    if ($Status -in @('Drafts', 'All')) {
        $inboxRoot = Join-Path $root 'inbox'
        if (Test-Path -LiteralPath $inboxRoot -PathType Container) {
            $items += @(Get-ChildItem -LiteralPath $inboxRoot -File -Filter '*.md' | ForEach-Object {
                [ordered]@{ status = 'draft'; id = $_.BaseName; path = $_.FullName; sha256 = (Get-FileHash -LiteralPath $_.FullName -Algorithm SHA256).Hash.ToLowerInvariant(); updated = $_.LastWriteTime.ToString('o') }
            })
        }
    }
    Write-MemoryJson ([ordered]@{ ok = $true; status = $Status.ToLowerInvariant(); count = $items.Count; items = @($items) })
}
catch {
    [Console]::Error.WriteLine(([ordered]@{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress))
    exit 1
}

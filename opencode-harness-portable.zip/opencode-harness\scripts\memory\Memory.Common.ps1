Set-StrictMode -Version Latest

function Get-HarnessMemoryRoot {
    if (-not [string]::IsNullOrWhiteSpace($env:OFFICE_HARNESS_STATE)) {
        $stateRoot = [Environment]::ExpandEnvironmentVariables($env:OFFICE_HARNESS_STATE)
    }
    else {
        $stateRoot = Join-Path $env:LOCALAPPDATA 'OpenCodeOfficeHarness\state'
    }
    $memoryRoot = Join-Path $stateRoot 'memory'
    if (-not (Test-Path -LiteralPath $memoryRoot -PathType Container)) {
        throw "Harness memory is not initialized: '$memoryRoot'. Run Install-Harness.ps1."
    }
    return (Get-Item -LiteralPath $memoryRoot -ErrorAction Stop).FullName
}

function Write-MemoryJson {
    param([Parameter(Mandatory = $true)][object]$Value)
    [Console]::Out.WriteLine(($Value | ConvertTo-Json -Depth 8 -Compress))
}

function Assert-SafeMemoryText {
    param(
        [Parameter(Mandatory = $true)][string]$Value,
        [Parameter(Mandatory = $true)][string]$Name,
        [int]$MaximumLength = 4000
    )
    if ([string]::IsNullOrWhiteSpace($Value)) { throw "$Name cannot be empty." }
    if ($Value.Length -gt $MaximumLength) { throw "$Name exceeds $MaximumLength characters." }
    if ($Value -match '(?i)(api[_ -]?key|password|passwd|secret|bearer\s+[A-Za-z0-9._-]+|BEGIN [A-Z ]*PRIVATE KEY|ghp_[A-Za-z0-9]{20,}|github_pat_[A-Za-z0-9_]{20,}|AKIA[A-Z0-9]{16}|eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,})') {
        throw "$Name appears to contain credential material and cannot be stored in memory."
    }
}

function Assert-MemoryScopeForMachine {
    param([Parameter(Mandatory = $true)][string]$Scope)
    if ($Scope -eq 'common') { return }
    if ([string]::IsNullOrWhiteSpace($env:OFFICE_HARNESS_MACHINE)) {
        throw 'OFFICE_HARNESS_MACHINE is required for machine-scoped memory.'
    }
    if (-not $Scope.Equals($env:OFFICE_HARNESS_MACHINE, [StringComparison]::OrdinalIgnoreCase)) {
        throw "Memory scope '$Scope' does not match machine '$($env:OFFICE_HARNESS_MACHINE)'."
    }
}

#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$Title,
    [Parameter(Mandatory = $true)][ValidateSet('preferences', 'browser-sites', 'outlook-conventions', 'powerpoint-conventions', 'hpc-conventions', 'notes')][string]$Topic,
    [Parameter(Mandatory = $true)][ValidateSet('common', 'internet', 'intranet')][string]$Scope,
    [Parameter(Mandatory = $true)][string]$Source,
    [Parameter(Mandatory = $true)][string]$Content
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
. (Join-Path $PSScriptRoot 'Memory.Common.ps1')

try {
    Assert-SafeMemoryText -Value $Title -Name 'Title' -MaximumLength 120
    Assert-SafeMemoryText -Value $Source -Name 'Source' -MaximumLength 500
    Assert-SafeMemoryText -Value $Content -Name 'Content' -MaximumLength 4000
    Assert-MemoryScopeForMachine -Scope $Scope
    if ($Content -match '(?i)(email body|message body|cookie|localstorage|raw result|\.rst\b)') {
        throw 'Content appears to contain a prohibited memory category.'
    }

    $root = Get-HarnessMemoryRoot
    $inbox = Join-Path $root 'inbox'
    if (-not (Test-Path -LiteralPath $inbox -PathType Container)) {
        $null = New-Item -ItemType Directory -Path $inbox
    }
    $id = (Get-Date -Format 'yyyyMMdd-HHmmss') + '-' + [Guid]::NewGuid().ToString('N').Substring(0, 8)
    $path = Join-Path $inbox ($id + '.md')
    $safeTitle = $Title.Replace("`r", ' ').Replace("`n", ' ')
    $safeSource = $Source.Replace("`r", ' ').Replace("`n", ' ')
    [string[]]$lines = @(
        "# Memory Draft: $safeTitle"
        ''
        "- ID: $id"
        '- Status: draft'
        "- Topic: $Topic"
        "- Scope: $Scope"
        "- Source: $safeSource"
        "- Created: $((Get-Date).ToString('o'))"
        ''
        '## Proposed Memory'
        ''
        $Content.Trim()
        ''
    )
    [IO.File]::WriteAllLines($path, $lines, (New-Object Text.UTF8Encoding($false)))
    Write-MemoryJson ([ordered]@{ ok = $true; id = $id; status = 'draft'; path = $path; title = $safeTitle; topic = $Topic; scope = $Scope })
}
catch {
    [Console]::Error.WriteLine(([ordered]@{ ok = $false; error = $_.Exception.Message } | ConvertTo-Json -Compress))
    exit 1
}

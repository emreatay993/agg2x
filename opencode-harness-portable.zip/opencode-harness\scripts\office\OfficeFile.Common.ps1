Set-StrictMode -Version Latest

function Get-OfficeFilePropertyValue {
    param(
        [Parameter(Mandatory = $true)]
        [object]$InputObject,

        [Parameter(Mandatory = $true)]
        [string]$Name,

        [object]$DefaultValue = $null
    )

    $property = $InputObject.PSObject.Properties[$Name]
    if ($null -eq $property) {
        return $DefaultValue
    }

    return $property.Value
}

function Resolve-OfficeFileConfiguredPath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$RepositoryRoot
    )

    $expandedPath = [Environment]::ExpandEnvironmentVariables($Path)
    if (-not [IO.Path]::IsPathRooted($expandedPath)) {
        $expandedPath = Join-Path -Path $RepositoryRoot -ChildPath $expandedPath
    }

    return [IO.Path]::GetFullPath($expandedPath)
}

function Resolve-OfficeFileExistingFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$Description
    )

    $expandedPath = [Environment]::ExpandEnvironmentVariables($Path)
    $fullPath = [IO.Path]::GetFullPath($expandedPath)
    if (-not (Test-Path -LiteralPath $fullPath -PathType Leaf)) {
        throw "$Description does not exist or is not a file: '$fullPath'."
    }

    return (Get-Item -LiteralPath $fullPath -ErrorAction Stop).FullName
}

function Resolve-OfficeFileOutputFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    $expandedPath = [Environment]::ExpandEnvironmentVariables($Path)
    $fullPath = [IO.Path]::GetFullPath($expandedPath)
    $parentPath = [IO.Path]::GetDirectoryName($fullPath)
    if ([string]::IsNullOrWhiteSpace($parentPath) -or -not (Test-Path -LiteralPath $parentPath -PathType Container)) {
        throw "The output parent folder does not exist: '$parentPath'."
    }

    $resolvedParent = (Get-Item -LiteralPath $parentPath -ErrorAction Stop).FullName
    return Join-Path -Path $resolvedParent -ChildPath ([IO.Path]::GetFileName($fullPath))
}

function Resolve-OfficeFileOutputDirectory {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    $expandedPath = [Environment]::ExpandEnvironmentVariables($Path)
    $fullPath = [IO.Path]::GetFullPath($expandedPath)
    if (Test-Path -LiteralPath $fullPath) {
        if (-not (Test-Path -LiteralPath $fullPath -PathType Container)) {
            throw "The output path exists but is not a folder: '$fullPath'."
        }

        return (Get-Item -LiteralPath $fullPath -ErrorAction Stop).FullName
    }

    $parentPath = [IO.Path]::GetDirectoryName($fullPath)
    if ([string]::IsNullOrWhiteSpace($parentPath) -or -not (Test-Path -LiteralPath $parentPath -PathType Container)) {
        throw "The output folder's parent does not exist: '$parentPath'."
    }

    $resolvedParent = (Get-Item -LiteralPath $parentPath -ErrorAction Stop).FullName
    return Join-Path -Path $resolvedParent -ChildPath ([IO.Path]::GetFileName($fullPath))
}

function Test-OfficeFilePathWithinRoot {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$Root
    )

    $comparison = [StringComparison]::OrdinalIgnoreCase
    $normalizedPath = [IO.Path]::GetFullPath($Path).TrimEnd([char[]]@('\', '/'))
    $normalizedRoot = [IO.Path]::GetFullPath($Root).TrimEnd([char[]]@('\', '/'))
    $withinRoot = $normalizedPath.Equals($normalizedRoot, $comparison) -or
        $normalizedPath.StartsWith($normalizedRoot + [IO.Path]::DirectorySeparatorChar, $comparison)
    if (-not $withinRoot) { return $false }

    $currentPath = if (Test-Path -LiteralPath $normalizedPath) {
        $normalizedPath
    }
    else {
        [IO.Path]::GetDirectoryName($normalizedPath)
    }
    while (-not [string]::IsNullOrWhiteSpace($currentPath) -and
        -not $currentPath.Equals($normalizedRoot, $comparison)) {
        if (Test-Path -LiteralPath $currentPath) {
            $item = Get-Item -LiteralPath $currentPath -Force -ErrorAction Stop
            if (($item.Attributes -band [IO.FileAttributes]::ReparsePoint) -ne 0) { return $false }
        }
        $parentPath = [IO.Path]::GetDirectoryName($currentPath)
        if ($parentPath -eq $currentPath) { break }
        $currentPath = $parentPath
    }
    return $true
}

function Assert-OfficeFileInputAllowed {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [object]$Settings,

        [Parameter(Mandatory = $true)]
        [string]$Description,

        [string]$ToolName = 'Office'
    )

    if (@($Settings.AllowedRoots).Count -eq 0) {
        throw "$ToolName allowedRoots is empty. Configure at least one approved root before using Office tools."
    }

    foreach ($root in @($Settings.AllowedRoots)) {
        if (Test-OfficeFilePathWithinRoot -Path $Path -Root $root) {
            return
        }
    }

    throw "$Description is outside the configured $ToolName allowed roots: '$Path'."
}

function Assert-OfficeFileOutputAllowed {
    param(
        [Parameter(Mandatory = $true)]
        [string]$OutputPath,

        [Parameter(Mandatory = $true)]
        [string]$SourcePath,

        [Parameter(Mandatory = $true)]
        [object]$Settings,

        [switch]$Directory,

        [string]$ToolName = 'Office'
    )

    if (@($Settings.AllowedRoots).Count -gt 0) {
        foreach ($root in @($Settings.AllowedRoots)) {
            if (Test-OfficeFilePathWithinRoot -Path $OutputPath -Root $root) {
                return
            }
        }

        throw "The $ToolName output is outside the configured allowed roots: '$OutputPath'."
    }

    if (-not [string]::IsNullOrWhiteSpace([string]$Settings.DefaultOutputRoot)) {
        if (Test-OfficeFilePathWithinRoot -Path $OutputPath -Root $Settings.DefaultOutputRoot) {
            return
        }
    }

    $sourceDirectory = [IO.Path]::GetDirectoryName($SourcePath)
    $outputContainer = [IO.Path]::GetDirectoryName($OutputPath)
    if ($sourceDirectory.Equals($outputContainer, [StringComparison]::OrdinalIgnoreCase)) {
        return
    }

    $outputKind = if ($Directory) { 'folder' } else { 'file' }
    throw "With no allowedRoots configured, the output $outputKind must be a sibling of the source: '$OutputPath'."
}

function Get-OfficeFileSha256 {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    return (Get-FileHash -LiteralPath $Path -Algorithm SHA256 -ErrorAction Stop).Hash.ToLowerInvariant()
}

function Release-OfficeFileComObject {
    param(
        [AllowNull()]
        [object]$ComObject
    )

    if ($null -ne $ComObject -and [Runtime.InteropServices.Marshal]::IsComObject($ComObject)) {
        [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($ComObject)
    }
}

function Complete-OfficeFileComCleanup {
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
}

function Write-OfficeFileJson {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Value
    )

    Write-Output ($Value | ConvertTo-Json -Depth 100 -Compress)
}

function Write-OfficeFileFailure {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Command,

        [Parameter(Mandatory = $true)]
        [Management.Automation.ErrorRecord]$ErrorRecord,

        [hashtable]$Context = @{}
    )

    $failure = [ordered]@{
        success = $false
        command = $Command
        error   = [ordered]@{
            message = $ErrorRecord.Exception.Message
            type    = $ErrorRecord.Exception.GetType().FullName
        }
    }

    foreach ($key in $Context.Keys) {
        $failure[$key] = $Context[$key]
    }

    Write-OfficeFileJson -Value ([pscustomobject]$failure)
}

#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$PlanPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Outlook.Common.psm1'
try {
    Import-Module -Name $modulePath -Force -DisableNameChecking -ErrorAction Stop
}
catch {
    $failure = [pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = 'Move-OutlookMail.ps1'
            Message = $_.Exception.Message
            Type    = $_.Exception.GetType().FullName
        }
    } | ConvertTo-Json -Depth 4 -Compress
    [Console]::Error.WriteLine($failure)
    exit 1
}

$application = $null
$namespace = $null
$defaultStore = $null
$defaultRoot = $null
$destinationFolder = $null
$outputJson = $null
$errorJson = $null

try {
    $settings = Get-OutlookSettings
    Assert-OutlookWriteEnabled -Settings $settings -Operation 'move'

    if (-not (Test-Path -LiteralPath $PlanPath -PathType Leaf)) {
        throw "The plan file '$PlanPath' was not found."
    }
    $plan = Get-Content -LiteralPath $PlanPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $targets = Get-OutlookMessagePlanTargets -Plan $plan -Settings $settings

    $mode = ([string](Get-OutlookOptionalProperty -Source $plan -Name 'mode' -DefaultValue 'move')).Trim().ToLowerInvariant()
    if (@('move', 'archive') -notcontains $mode) {
        throw "Plan 'mode' must be 'move' or 'archive'."
    }

    if ($mode -eq 'archive') {
        $requestedFolder = $settings.Write.ArchiveFolder
        if ([string]::IsNullOrWhiteSpace($requestedFolder)) {
            throw "Archive mode requires 'write.archiveFolder' in '$($settings.SettingsPath)'."
        }
    }
    else {
        $requestedFolder = ([string](Get-OutlookOptionalProperty -Source $plan -Name 'destinationFolder' -DefaultValue '')).Trim()
        if ([string]::IsNullOrWhiteSpace($requestedFolder)) {
            throw "Plan 'destinationFolder' is required for mode 'move'."
        }
    }

    # Deletion must go through Remove-OutlookMail.ps1 so that it is confirmation-gated.
    $normalizedDestination = $requestedFolder.Replace('/', '\').Trim().ToLowerInvariant()
    if (($normalizedDestination -eq 'deleted items') -or $normalizedDestination.EndsWith('\deleted items')) {
        throw "Moving mail into Deleted Items is not available here. Use the delete operation, which requires explicit confirmation."
    }

    $application = New-Object -ComObject 'Outlook.Application'
    $namespace = $application.GetNamespace('MAPI')
    $defaultStore = $namespace.DefaultStore
    $defaultRoot = $defaultStore.GetRootFolder()

    $destinationFolder = Resolve-OutlookScopedFolder -Namespace $namespace -DefaultRoot $defaultRoot `
        -ScopeFolders $settings.Write.AllowedFolders -FolderPath $requestedFolder
    $destinationName = Get-OutlookStringProperty -ComObject $destinationFolder -PropertyName 'Name'
    $destinationEntryId = Get-OutlookStringProperty -ComObject $destinationFolder -PropertyName 'EntryID'

    $results = New-Object System.Collections.ArrayList
    $movedCount = 0
    $failedCount = 0

    foreach ($target in $targets) {
        $resolved = $null
        $movedItem = $null
        try {
            $resolved = Resolve-OutlookScopedMailItem -Namespace $namespace -DefaultRoot $defaultRoot `
                -ScopeFolders $settings.WriteScopeFolders -EntryId $target.EntryId -StoreId $target.StoreId

            $sourceParent = $null
            $sourceEntryId = ''
            try {
                $sourceParent = $resolved.Item.Parent
                if ($null -ne $sourceParent) {
                    $sourceEntryId = Get-OutlookStringProperty -ComObject $sourceParent -PropertyName 'EntryID'
                }
            }
            finally {
                Release-OutlookComObject -ComObject $sourceParent
            }
            if ($namespace.CompareEntryIDs($sourceEntryId, $destinationEntryId)) {
                throw "The message is already in '$requestedFolder'."
            }

            $movedItem = $resolved.Item.Move($destinationFolder)
            if ($null -eq $movedItem) {
                throw 'Outlook did not return a moved item.'
            }
            $movedCount++
            $null = $results.Add([pscustomobject]@{
                SourceFolder = $resolved.ConfiguredFolder
                Subject      = $resolved.Subject
                SenderName   = $resolved.SenderName
                ReceivedTime = $resolved.ReceivedTime
                Ok           = $true
                NewEntryId   = (Get-OutlookStringProperty -ComObject $movedItem -PropertyName 'EntryID')
                NewStoreId   = (Get-OutlookStringProperty -ComObject $destinationFolder -PropertyName 'StoreID')
                Error        = $null
            })
        }
        catch {
            $failedCount++
            $null = $results.Add([pscustomobject]@{
                SourceFolder = $null
                Subject      = if ($null -ne $resolved) { $resolved.Subject } else { $null }
                SenderName   = if ($null -ne $resolved) { $resolved.SenderName } else { $null }
                ReceivedTime = if ($null -ne $resolved) { $resolved.ReceivedTime } else { $null }
                Ok           = $false
                NewEntryId   = $null
                NewStoreId   = $null
                Error        = $_.Exception.Message
            })
        }
        finally {
            Release-OutlookComObject -ComObject $movedItem
            if ($null -ne $resolved) { Release-OutlookComObject -ComObject $resolved.Item }
        }
    }

    $outputJson = [pscustomobject]@{
        Ok                = ($failedCount -eq 0)
        SettingsPath      = $settings.SettingsPath
        Operation         = $mode
        DestinationFolder = $requestedFolder
        DestinationName   = $destinationName
        Requested         = $targets.Count
        Moved             = $movedCount
        Failed            = $failedCount
        Reversible        = $true
        Results           = @($results)
    } | ConvertTo-Json -Depth 8 -Compress
}
catch {
    $errorJson = ConvertTo-OutlookErrorJson -ErrorRecord $_ -ScriptName 'Move-OutlookMail.ps1'
}
finally {
    Release-OutlookComObject -ComObject $destinationFolder
    Release-OutlookComObject -ComObject $defaultRoot
    Release-OutlookComObject -ComObject $defaultStore
    Release-OutlookComObject -ComObject $namespace
    Release-OutlookComObject -ComObject $application
}

if ($null -ne $errorJson) {
    [Console]::Error.WriteLine($errorJson)
    exit 1
}
[Console]::Out.WriteLine($outputJson)

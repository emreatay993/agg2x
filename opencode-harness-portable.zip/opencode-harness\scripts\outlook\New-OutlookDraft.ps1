#requires -Version 5.1

<#
    Creates a plain-text Outlook draft (new, reply, reply-all, or forward) and saves it to the
    Drafts folder. This script never sends. Sending is a separate, confirmation-gated operation
    in Send-OutlookDraft.ps1, so a draft can always be reviewed or discarded in Outlook first.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$PlanPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Outlook.Common.psm1'
try {
    Import-Module -Name $modulePath -Force -DisableNameChecking -ErrorAction Stop
}
catch {
    $failure = [pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = 'New-OutlookDraft.ps1'
            Message = $_.Exception.Message
            Type    = $_.Exception.GetType().FullName
        }
    } | ConvertTo-Json -Depth 4 -Compress
    [Console]::Error.WriteLine($failure)
    exit 1
}

function Get-OutlookRecipientList {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        [object]$Value,

        [Parameter(Mandatory = $true)]
        [string]$FieldName
    )

    $list = New-Object System.Collections.ArrayList
    foreach ($entry in @($Value)) {
        $address = ([string]$entry).Trim()
        if ([string]::IsNullOrWhiteSpace($address)) { continue }
        if ($address -match '[\r\n]') {
            throw "Recipient '$address' in '$FieldName' contains a line break."
        }
        if ($list.Count -ge 50) {
            throw "Field '$FieldName' exceeds the 50 recipient limit."
        }
        $null = $list.Add($address)
    }
    return @($list)
}

$application = $null
$namespace = $null
$defaultStore = $null
$defaultRoot = $null
$sourceItem = $null
$draft = $null
$draftRecipients = $null
$outputJson = $null
$errorJson = $null

try {
    $settings = Get-OutlookSettings
    Assert-OutlookWriteEnabled -Settings $settings -Operation 'create-draft'
    if (-not $settings.Write.AllowSend) {
        throw "Drafting is disabled. Set 'write.allowSend' to true in '$($settings.SettingsPath)' to allow reply, forward, and new-message drafts."
    }

    if (-not (Test-Path -LiteralPath $PlanPath -PathType Leaf)) {
        throw "The plan file '$PlanPath' was not found."
    }
    $plan = Get-Content -LiteralPath $PlanPath -Raw -Encoding UTF8 | ConvertFrom-Json

    $mode = ([string](Get-OutlookOptionalProperty -Source $plan -Name 'mode' -DefaultValue '')).Trim().ToLowerInvariant()
    if (@('new', 'reply', 'replyall', 'forward') -notcontains $mode) {
        throw "Plan 'mode' must be 'new', 'reply', 'replyAll', or 'forward'."
    }

    $body = [string](Get-OutlookOptionalProperty -Source $plan -Name 'body' -DefaultValue '')
    if ([string]::IsNullOrWhiteSpace($body)) {
        throw "Plan 'body' is required and must not be empty."
    }
    if ($body.Length -gt 100000) {
        throw "Plan 'body' exceeds the 100000 character limit."
    }

    $subject = ([string](Get-OutlookOptionalProperty -Source $plan -Name 'subject' -DefaultValue '')).Trim()
    if ($subject -match '[\r\n]') {
        throw "Plan 'subject' must not contain line breaks."
    }
    if ($subject.Length -gt 255) {
        throw "Plan 'subject' exceeds the 255 character limit."
    }

    $toList = Get-OutlookRecipientList -Value (Get-OutlookOptionalProperty -Source $plan -Name 'to' -DefaultValue @()) -FieldName 'to'
    $ccList = Get-OutlookRecipientList -Value (Get-OutlookOptionalProperty -Source $plan -Name 'cc' -DefaultValue @()) -FieldName 'cc'

    if ($mode -eq 'new') {
        if ($toList.Count -lt 1) {
            throw "Plan 'to' must list at least one recipient for mode 'new'."
        }
        if ([string]::IsNullOrWhiteSpace($subject)) {
            throw "Plan 'subject' is required for mode 'new'."
        }
    }

    $sourceEntryId = ([string](Get-OutlookOptionalProperty -Source $plan -Name 'entryId' -DefaultValue '')).Trim()
    $sourceStoreId = ([string](Get-OutlookOptionalProperty -Source $plan -Name 'storeId' -DefaultValue '')).Trim()
    if ($mode -ne 'new') {
        if ([string]::IsNullOrWhiteSpace($sourceEntryId) -or [string]::IsNullOrWhiteSpace($sourceStoreId)) {
            throw "Plan 'entryId' and 'storeId' are required for mode '$mode'."
        }
        if (($mode -eq 'forward') -and ($toList.Count -lt 1)) {
            throw "Plan 'to' must list at least one recipient for mode 'forward'."
        }
    }

    $application = New-Object -ComObject 'Outlook.Application'
    $namespace = $application.GetNamespace('MAPI')
    $defaultStore = $namespace.DefaultStore
    $defaultRoot = $defaultStore.GetRootFolder()

    $sourceSummary = $null
    if ($mode -eq 'new') {
        $draft = $application.CreateItem(0)
        $draft.Subject = $subject
        $draft.Body = $body
    }
    else {
        $resolved = Resolve-OutlookScopedMailItem -Namespace $namespace -DefaultRoot $defaultRoot `
            -ScopeFolders $settings.WriteScopeFolders -EntryId $sourceEntryId -StoreId $sourceStoreId
        $sourceItem = $resolved.Item
        $sourceSummary = [pscustomobject]@{
            Subject       = $resolved.Subject
            SenderName    = $resolved.SenderName
            SenderAddress = $resolved.SenderAddress
            ReceivedTime  = $resolved.ReceivedTime
            Folder        = $resolved.ConfiguredFolder
        }

        switch ($mode) {
            'reply' { $draft = $sourceItem.Reply() }
            'replyall' { $draft = $sourceItem.ReplyAll() }
            'forward' { $draft = $sourceItem.Forward() }
        }
        if ($null -eq $draft) {
            throw "Outlook did not return a draft for mode '$mode'."
        }
        # Keep the quoted history below the new text so the thread stays readable.
        $existingBody = Get-OutlookStringProperty -ComObject $draft -PropertyName 'Body'
        $draft.Body = $body + "`r`n`r`n" + $existingBody
        if (-not [string]::IsNullOrWhiteSpace($subject)) {
            $draft.Subject = $subject
        }
    }

    $unresolved = New-Object System.Collections.ArrayList
    $draftRecipients = $draft.Recipients
    foreach ($address in $toList) {
        $recipient = $null
        try {
            $recipient = $draftRecipients.Add($address)
            $recipient.Type = 1
        }
        finally {
            Release-OutlookComObject -ComObject $recipient
        }
    }
    foreach ($address in $ccList) {
        $recipient = $null
        try {
            $recipient = $draftRecipients.Add($address)
            $recipient.Type = 2
        }
        finally {
            Release-OutlookComObject -ComObject $recipient
        }
    }
    $null = $draftRecipients.ResolveAll()
    for ($recipientIndex = 1; $recipientIndex -le [int]$draftRecipients.Count; $recipientIndex++) {
        $recipient = $null
        try {
            $recipient = $draftRecipients.Item($recipientIndex)
            if (-not (Get-OutlookBooleanProperty -ComObject $recipient -PropertyName 'Resolved' -DefaultValue $false)) {
                $null = $unresolved.Add((Get-OutlookStringProperty -ComObject $recipient -PropertyName 'Name'))
            }
        }
        finally {
            Release-OutlookComObject -ComObject $recipient
        }
    }

    $draft.Save()

    $draftEntryId = Get-OutlookStringProperty -ComObject $draft -PropertyName 'EntryID'
    $draftParent = $null
    $draftStoreId = ''
    $draftFolderName = ''
    try {
        $draftParent = $draft.Parent
        if ($null -ne $draftParent) {
            $draftStoreId = Get-OutlookStringProperty -ComObject $draftParent -PropertyName 'StoreID'
            $draftFolderName = Get-OutlookStringProperty -ComObject $draftParent -PropertyName 'Name'
        }
    }
    finally {
        Release-OutlookComObject -ComObject $draftParent
    }

    $finalBody = Get-OutlookStringProperty -ComObject $draft -PropertyName 'Body'
    $bodyPreviewLength = [math]::Min($finalBody.Length, 2000)

    $outputJson = [pscustomobject]@{
        Ok           = $true
        SettingsPath = $settings.SettingsPath
        Operation    = 'create-draft'
        Mode         = $mode
        Sent         = $false
        Draft        = [pscustomobject]@{
            EntryId              = $draftEntryId
            StoreId              = $draftStoreId
            FolderName           = $draftFolderName
            Subject              = (Get-OutlookStringProperty -ComObject $draft -PropertyName 'Subject')
            To                   = (Get-OutlookStringProperty -ComObject $draft -PropertyName 'To')
            Cc                   = (Get-OutlookStringProperty -ComObject $draft -PropertyName 'CC')
            UnresolvedRecipients = @($unresolved)
            BodyPreview          = $finalBody.Substring(0, $bodyPreviewLength)
            BodyCharactersTotal  = $finalBody.Length
            BodyTruncatedInPreview = ($finalBody.Length -gt $bodyPreviewLength)
        }
        Source       = $sourceSummary
        Message      = 'The draft was saved to Drafts and has NOT been sent. Show it to the user; send only after they explicitly approve it.'
    } | ConvertTo-Json -Depth 8 -Compress
}
catch {
    $errorJson = ConvertTo-OutlookErrorJson -ErrorRecord $_ -ScriptName 'New-OutlookDraft.ps1'
}
finally {
    Release-OutlookComObject -ComObject $draftRecipients
    Release-OutlookComObject -ComObject $draft
    Release-OutlookComObject -ComObject $sourceItem
    Release-OutlookComObject -ComObject $defaultRoot
    Release-OutlookComObject -ComObject $defaultStore
    Release-OutlookComObject -ComObject $namespace
    Release-OutlookComObject -ComObject $application
}

if ($null -ne $errorJson) {
    [Console]::Error.WriteLine($errorJson)
    exit 1
}
[Console]::Out.WriteLine($outputJson)

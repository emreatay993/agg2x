#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$ParentFolder,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$Name
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Outlook.Common.psm1'
try {
    Import-Module -Name $modulePath -Force -DisableNameChecking -ErrorAction Stop
}
catch {
    $failure = [pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = 'New-OutlookMailFolder.ps1'
            Message = $_.Exception.Message
            Type    = $_.Exception.GetType().FullName
        }
    } | ConvertTo-Json -Depth 4 -Compress
    [Console]::Error.WriteLine($failure)
    exit 1
}

$application = $null
$namespace = $null
$defaultStore = $null
$defaultRoot = $null
$parent = $null
$children = $null
$created = $null
$outputJson = $null
$errorJson = $null

try {
    $settings = Get-OutlookSettings
    Assert-OutlookWriteEnabled -Settings $settings -Operation 'create-folder'

    $folderName = $Name.Trim()
    if ($folderName.IndexOfAny([char[]]'\/') -ge 0) {
        throw "Folder name '$Name' must not contain path separators. Create nested folders one level at a time."
    }
    if ($folderName.Length -gt 64) {
        throw 'Folder name must be 64 characters or fewer.'
    }
    if ($folderName -match '[\r\n\t]') {
        throw 'Folder name must not contain control characters.'
    }

    $application = New-Object -ComObject 'Outlook.Application'
    $namespace = $application.GetNamespace('MAPI')
    $defaultStore = $namespace.DefaultStore
    $defaultRoot = $defaultStore.GetRootFolder()

    $parent = Resolve-OutlookScopedFolder -Namespace $namespace -DefaultRoot $defaultRoot `
        -ScopeFolders $settings.Write.AllowedFolders -FolderPath $ParentFolder

    $children = $parent.Folders
    for ($childIndex = 1; $childIndex -le [int]$children.Count; $childIndex++) {
        $child = $null
        try {
            $child = $children.Item($childIndex)
            $childName = Get-OutlookStringProperty -ComObject $child -PropertyName 'Name'
            if ($childName.Equals($folderName, [StringComparison]::OrdinalIgnoreCase)) {
                throw "A folder named '$folderName' already exists under '$ParentFolder'."
            }
        }
        finally {
            Release-OutlookComObject -ComObject $child
        }
    }

    $created = $children.Add($folderName)
    if ($null -eq $created) {
        throw 'Outlook did not return the created folder.'
    }

    $createdPath = ($ParentFolder.Trim().TrimEnd('\', '/') + '\' + $folderName)
    $outputJson = [pscustomobject]@{
        Ok           = $true
        SettingsPath = $settings.SettingsPath
        Operation    = 'create-folder'
        ParentFolder = $ParentFolder.Trim()
        Name         = $folderName
        FolderPath   = $createdPath
        EntryId      = (Get-OutlookStringProperty -ComObject $created -PropertyName 'EntryID')
        StoreId      = (Get-OutlookStringProperty -ComObject $created -PropertyName 'StoreID')
        Message      = "Add '$createdPath' to 'write.allowedFolders' in the settings file before moving mail into it."
    } | ConvertTo-Json -Depth 6 -Compress
}
catch {
    $errorJson = ConvertTo-OutlookErrorJson -ErrorRecord $_ -ScriptName 'New-OutlookMailFolder.ps1'
}
finally {
    Release-OutlookComObject -ComObject $created
    Release-OutlookComObject -ComObject $children
    Release-OutlookComObject -ComObject $parent
    Release-OutlookComObject -ComObject $defaultRoot
    Release-OutlookComObject -ComObject $defaultStore
    Release-OutlookComObject -ComObject $namespace
    Release-OutlookComObject -ComObject $application
}

if ($null -ne $errorJson) {
    [Console]::Error.WriteLine($errorJson)
    exit 1
}
[Console]::Out.WriteLine($outputJson)

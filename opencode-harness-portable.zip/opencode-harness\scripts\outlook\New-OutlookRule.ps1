#requires -Version 5.1

<#
    Creates one inbox rule that files incoming mail into a folder.

    A rule is standing configuration that keeps acting on the mailbox long after the session
    ends, so it is confirmation-gated exactly like delete and send. Only two condition types
    are supported (sender address and subject text) and only one action (move to folder),
    because the Outlook Rules COM surface is version-sensitive and a broad wrapper here would
    be more likely to corrupt an existing rule set than to help.

    RuleSet.Save() rewrites the whole client rule set. Existing rules are read back and
    reported before and after so an unexpected loss is visible rather than silent.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$PlanPath,

    [Parameter()]
    [AllowEmptyString()]
    [string]$ConfirmationToken = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Outlook.Common.psm1'
try {
    Import-Module -Name $modulePath -Force -DisableNameChecking -ErrorAction Stop
}
catch {
    $failure = [pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = 'New-OutlookRule.ps1'
            Message = $_.Exception.Message
            Type    = $_.Exception.GetType().FullName
        }
    } | ConvertTo-Json -Depth 4 -Compress
    [Console]::Error.WriteLine($failure)
    exit 1
}

$application = $null
$namespace = $null
$defaultStore = $null
$defaultRoot = $null
$destinationFolder = $null
$ruleSet = $null
$rule = $null
$outputJson = $null
$errorJson = $null

try {
    $settings = Get-OutlookSettings
    Assert-OutlookWriteEnabled -Settings $settings -Operation 'create-rule'
    if (-not $settings.Write.AllowRules) {
        throw "Rule creation is disabled. Set 'write.allowRules' to true in '$($settings.SettingsPath)' to allow it."
    }

    if (-not (Test-Path -LiteralPath $PlanPath -PathType Leaf)) {
        throw "The plan file '$PlanPath' was not found."
    }
    $plan = Get-Content -LiteralPath $PlanPath -Raw -Encoding UTF8 | ConvertFrom-Json

    $ruleName = ([string](Get-OutlookOptionalProperty -Source $plan -Name 'name' -DefaultValue '')).Trim()
    if ([string]::IsNullOrWhiteSpace($ruleName)) {
        throw "Plan 'name' is required."
    }
    if ($ruleName.Length -gt 128) {
        throw "Plan 'name' must be 128 characters or fewer."
    }

    $destinationPath = ([string](Get-OutlookOptionalProperty -Source $plan -Name 'moveToFolder' -DefaultValue '')).Trim()
    if ([string]::IsNullOrWhiteSpace($destinationPath)) {
        throw "Plan 'moveToFolder' is required."
    }

    $fromAddresses = New-Object System.Collections.ArrayList
    foreach ($address in @(Get-OutlookOptionalProperty -Source $plan -Name 'fromAddresses' -DefaultValue @())) {
        $addressText = ([string]$address).Trim()
        if ([string]::IsNullOrWhiteSpace($addressText)) { continue }
        if ($fromAddresses.Count -ge 25) { throw "Plan 'fromAddresses' exceeds the 25 entry limit." }
        $null = $fromAddresses.Add($addressText)
    }

    $subjectTerms = New-Object System.Collections.ArrayList
    foreach ($term in @(Get-OutlookOptionalProperty -Source $plan -Name 'subjectContains' -DefaultValue @())) {
        $termText = ([string]$term).Trim()
        if ([string]::IsNullOrWhiteSpace($termText)) { continue }
        if ($subjectTerms.Count -ge 25) { throw "Plan 'subjectContains' exceeds the 25 entry limit." }
        $null = $subjectTerms.Add($termText)
    }

    if (($fromAddresses.Count -lt 1) -and ($subjectTerms.Count -lt 1)) {
        throw "The rule needs at least one condition. Supply 'fromAddresses', 'subjectContains', or both."
    }

    $enabled = [bool](Get-OutlookOptionalProperty -Source $plan -Name 'enabled' -DefaultValue $true)

    $application = New-Object -ComObject 'Outlook.Application'
    $namespace = $application.GetNamespace('MAPI')
    $defaultStore = $namespace.DefaultStore
    $defaultRoot = $defaultStore.GetRootFolder()

    $destinationFolder = Resolve-OutlookScopedFolder -Namespace $namespace -DefaultRoot $defaultRoot `
        -ScopeFolders $settings.Write.AllowedFolders -FolderPath $destinationPath

    $ruleSet = $defaultStore.GetRules()
    $existingRules = New-Object System.Collections.ArrayList
    for ($ruleIndex = 1; $ruleIndex -le [int]$ruleSet.Count; $ruleIndex++) {
        $existingRule = $null
        try {
            $existingRule = $ruleSet.Item($ruleIndex)
            $existingName = Get-OutlookStringProperty -ComObject $existingRule -PropertyName 'Name'
            $null = $existingRules.Add([pscustomobject]@{
                Name    = $existingName
                Enabled = (Get-OutlookBooleanProperty -ComObject $existingRule -PropertyName 'Enabled' -DefaultValue $false)
            })
            if ($existingName.Equals($ruleName, [StringComparison]::OrdinalIgnoreCase)) {
                throw "A rule named '$ruleName' already exists. Choose a different name or edit the existing rule in Outlook."
            }
        }
        finally {
            Release-OutlookComObject -ComObject $existingRule
        }
    }

    $fingerprintParts = New-Object System.Collections.ArrayList
    $null = $fingerprintParts.Add('create-rule')
    $null = $fingerprintParts.Add($ruleName)
    $null = $fingerprintParts.Add($destinationPath)
    $null = $fingerprintParts.Add([string]::Join(',', @($fromAddresses | Sort-Object)))
    $null = $fingerprintParts.Add([string]::Join(',', @($subjectTerms | Sort-Object)))
    $null = $fingerprintParts.Add([string]$enabled)
    $fingerprint = Get-OutlookFingerprint -Parts @($fingerprintParts)

    if ([string]::IsNullOrWhiteSpace($ConfirmationToken)) {
        $confirmation = New-OutlookConfirmation -Operation 'create-rule' -Fingerprint $fingerprint -Settings $settings
        $outputJson = [pscustomobject]@{
            Ok                    = $true
            SettingsPath          = $settings.SettingsPath
            Operation             = 'create-rule'
            Stage                 = 'PreviewOnly'
            RequiresConfirmation  = $true
            Created               = $false
            ConfirmationToken     = $confirmation.Token
            TokenExpiresUtc       = $confirmation.ExpiresUtc
            TokenExpiresInSeconds = $confirmation.ExpiresInSeconds
            Message               = 'No rule was created. A rule keeps acting on the mailbox after this session, so show it to the user and get an explicit yes before confirming.'
            Preview               = [pscustomobject]@{
                Name            = $ruleName
                FromAddresses   = @($fromAddresses)
                SubjectContains = @($subjectTerms)
                MoveToFolder    = $destinationPath
                Enabled         = $enabled
                AppliesTo       = 'Incoming mail only. Existing messages are not moved.'
            }
            ExistingRules         = @($existingRules)
        } | ConvertTo-Json -Depth 8 -Compress
    }
    else {
        $null = Assert-OutlookConfirmation -Token $ConfirmationToken.Trim() -Operation 'create-rule' -Fingerprint $fingerprint

        $rule = $ruleSet.Create($ruleName, 0)
        if ($null -eq $rule) {
            throw 'Outlook did not return a new rule object.'
        }

        if ($fromAddresses.Count -gt 0) {
            $fromCondition = $null
            $conditionRecipients = $null
            try {
                $fromCondition = $rule.Conditions.From
                $conditionRecipients = $fromCondition.Recipients
                foreach ($address in $fromAddresses) {
                    $recipient = $null
                    try {
                        $recipient = $conditionRecipients.Add($address)
                    }
                    finally {
                        Release-OutlookComObject -ComObject $recipient
                    }
                }
                $null = $conditionRecipients.ResolveAll()
                $fromCondition.Enabled = $true
            }
            finally {
                Release-OutlookComObject -ComObject $conditionRecipients
                Release-OutlookComObject -ComObject $fromCondition
            }
        }

        if ($subjectTerms.Count -gt 0) {
            $subjectCondition = $null
            try {
                $subjectCondition = $rule.Conditions.Subject
                $subjectCondition.Text = [string[]]@($subjectTerms)
                $subjectCondition.Enabled = $true
            }
            finally {
                Release-OutlookComObject -ComObject $subjectCondition
            }
        }

        $moveAction = $null
        try {
            $moveAction = $rule.Actions.MoveToFolder
            $moveAction.Folder = $destinationFolder
            $moveAction.Enabled = $true
        }
        finally {
            Release-OutlookComObject -ComObject $moveAction
        }

        $rule.Enabled = $enabled

        try {
            $ruleSet.Save($true)
        }
        catch {
            throw "Outlook refused to save the rule set: $($_.Exception.Message). No rule was added. Server-side rule limits or an Exchange policy are the usual cause."
        }

        $savedRules = New-Object System.Collections.ArrayList
        $verifySet = $null
        try {
            $verifySet = $defaultStore.GetRules()
            for ($verifyIndex = 1; $verifyIndex -le [int]$verifySet.Count; $verifyIndex++) {
                $verifyRule = $null
                try {
                    $verifyRule = $verifySet.Item($verifyIndex)
                    $null = $savedRules.Add([pscustomobject]@{
                        Name    = (Get-OutlookStringProperty -ComObject $verifyRule -PropertyName 'Name')
                        Enabled = (Get-OutlookBooleanProperty -ComObject $verifyRule -PropertyName 'Enabled' -DefaultValue $false)
                    })
                }
                finally {
                    Release-OutlookComObject -ComObject $verifyRule
                }
            }
        }
        finally {
            Release-OutlookComObject -ComObject $verifySet
        }

        $outputJson = [pscustomobject]@{
            Ok                   = $true
            SettingsPath         = $settings.SettingsPath
            Operation            = 'create-rule'
            Stage                = 'Executed'
            RequiresConfirmation = $false
            Created              = $true
            Name                 = $ruleName
            MoveToFolder         = $destinationPath
            Enabled              = $enabled
            RuleCountBefore      = $existingRules.Count
            RuleCountAfter       = $savedRules.Count
            RulesAfterSave       = @($savedRules)
            Message              = 'The rule applies to incoming mail only. Verify it under File > Manage Rules & Alerts in Outlook.'
        } | ConvertTo-Json -Depth 8 -Compress
    }
}
catch {
    $errorJson = ConvertTo-OutlookErrorJson -ErrorRecord $_ -ScriptName 'New-OutlookRule.ps1'
}
finally {
    Release-OutlookComObject -ComObject $rule
    Release-OutlookComObject -ComObject $ruleSet
    Release-OutlookComObject -ComObject $destinationFolder
    Release-OutlookComObject -ComObject $defaultRoot
    Release-OutlookComObject -ComObject $defaultStore
    Release-OutlookComObject -ComObject $namespace
    Release-OutlookComObject -ComObject $application
}

if ($null -ne $errorJson) {
    [Console]::Error.WriteLine($errorJson)
    exit 1
}
[Console]::Out.WriteLine($outputJson)

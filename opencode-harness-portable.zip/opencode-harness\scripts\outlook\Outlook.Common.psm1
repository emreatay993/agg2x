#requires -Version 5.1

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Release-OutlookComObject {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        [object]$ComObject
    )

    if (($null -ne $ComObject) -and [System.Runtime.InteropServices.Marshal]::IsComObject($ComObject)) {
        $null = [System.Runtime.InteropServices.Marshal]::FinalReleaseComObject($ComObject)
    }
}

function Get-OutlookSettings {
    [CmdletBinding()]
    param()

    if (-not [string]::IsNullOrWhiteSpace($env:OFFICE_HARNESS_SETTINGS)) {
        $settingsDirectory = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($env:OFFICE_HARNESS_SETTINGS))
    }
    else {
        $repositoryRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
        $settingsDirectory = Join-Path -Path $repositoryRoot -ChildPath 'settings'
    }
    $localPath = Join-Path -Path $settingsDirectory -ChildPath 'outlook.local.json'
    $examplePath = Join-Path -Path $settingsDirectory -ChildPath 'outlook.example.json'

    if (Test-Path -LiteralPath $localPath -PathType Leaf) {
        $settingsPath = $localPath
    }
    elseif (Test-Path -LiteralPath $examplePath -PathType Leaf) {
        $settingsPath = $examplePath
    }
    else {
        throw "Outlook settings were not found at '$localPath' or '$examplePath'."
    }

    $settings = Get-Content -LiteralPath $settingsPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $requiredProperties = @(
        'folders',
        'maxItemsScannedPerFolder',
        'maxSearchResults',
        'maxBodyCharacters'
    )
    $propertyNames = @($settings.PSObject.Properties.Name)

    foreach ($propertyName in $requiredProperties) {
        if ($propertyNames -notcontains $propertyName) {
            throw "Outlook settings '$settingsPath' is missing '$propertyName'."
        }
    }

    $folders = @($settings.folders)
    if (($folders.Count -lt 1) -or ($folders.Count -gt 100)) {
        throw "Outlook settings 'folders' must contain between 1 and 100 folder names."
    }

    $validatedFolders = New-Object System.Collections.ArrayList
    foreach ($folder in $folders) {
        $folderName = [string]$folder
        if ([string]::IsNullOrWhiteSpace($folderName)) {
            throw "Outlook settings 'folders' contains an empty folder name."
        }
        $null = $validatedFolders.Add($folderName.Trim())
    }

    $maxItemsScannedPerFolder = [int]$settings.maxItemsScannedPerFolder
    $maxSearchResults = [int]$settings.maxSearchResults
    $maxBodyCharacters = [int]$settings.maxBodyCharacters

    if (($maxItemsScannedPerFolder -lt 1) -or ($maxItemsScannedPerFolder -gt 100000)) {
        throw "Outlook settings 'maxItemsScannedPerFolder' must be between 1 and 100000."
    }
    if (($maxSearchResults -lt 1) -or ($maxSearchResults -gt 1000)) {
        throw "Outlook settings 'maxSearchResults' must be between 1 and 1000."
    }
    if (($maxBodyCharacters -lt 1) -or ($maxBodyCharacters -gt 1000000)) {
        throw "Outlook settings 'maxBodyCharacters' must be between 1 and 1000000."
    }

    $writeSettings = Get-OutlookWriteSettings -Settings $settings -PropertyNames $propertyNames -ReadFolders $validatedFolders

    $writeScope = New-Object System.Collections.ArrayList
    foreach ($scopeFolder in @(@($validatedFolders) + @($writeSettings.AllowedFolders))) {
        $existing = $false
        foreach ($known in $writeScope) {
            if ($known.Equals($scopeFolder, [StringComparison]::OrdinalIgnoreCase)) { $existing = $true; break }
        }
        if (-not $existing) { $null = $writeScope.Add($scopeFolder) }
    }

    return [pscustomobject]@{
        SettingsPath             = $settingsPath
        Folders                  = @($validatedFolders)
        MaxItemsScannedPerFolder = $maxItemsScannedPerFolder
        MaxSearchResults         = $maxSearchResults
        MaxBodyCharacters        = $maxBodyCharacters
        Write                    = $writeSettings
        WriteScopeFolders        = @($writeScope)
    }
}

function Get-OutlookOptionalProperty {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        [object]$Source,

        [Parameter(Mandatory = $true)]
        [string]$Name,

        [Parameter()]
        [AllowNull()]
        [object]$DefaultValue = $null
    )

    if ($null -eq $Source) { return $DefaultValue }
    if (@($Source.PSObject.Properties.Name) -notcontains $Name) { return $DefaultValue }
    $value = $Source.$Name
    if ($null -eq $value) { return $DefaultValue }
    return $value
}

function Get-OutlookWriteSettings {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Settings,

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [string[]]$PropertyNames,

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [string[]]$ReadFolders
    )

    $defaultBlockedExtensions = @(
        '.ade', '.adp', '.app', '.asp', '.bas', '.bat', '.cer', '.chm', '.cmd', '.com', '.cpl',
        '.crt', '.csh', '.der', '.dll', '.exe', '.fxp', '.gadget', '.hlp', '.hta', '.inf', '.ins',
        '.isp', '.its', '.jar', '.js', '.jse', '.ksh', '.lnk', '.mad', '.maf', '.mag', '.mam',
        '.maq', '.mar', '.mas', '.mat', '.mau', '.mav', '.maw', '.mda', '.mdb', '.mde', '.mdt',
        '.mdw', '.mdz', '.msc', '.msi', '.msp', '.mst', '.ops', '.pcd', '.pif', '.plg', '.prf',
        '.prg', '.ps1', '.ps1xml', '.ps2', '.ps2xml', '.psc1', '.psc2', '.psd1', '.psm1', '.pst',
        '.reg', '.scf', '.scr', '.sct', '.shb', '.shs', '.sys', '.tmp', '.url', '.vb', '.vbe',
        '.vbs', '.vsmacros', '.vss', '.vst', '.vsw', '.ws', '.wsc', '.wsf', '.wsh'
    )

    # A settings file with no 'write' block keeps the historical read-only contract.
    if ($PropertyNames -notcontains 'write') {
        return [pscustomobject]@{
            Enabled                    = $false
            AllowedFolders             = @()
            ArchiveFolder              = ''
            AllowSend                  = $false
            AllowDelete                = $false
            AllowRules                 = $false
            AllowAttachmentDownload    = $false
            ConfirmationTimeoutSeconds = 300
            MaxBatchSize               = 1
            AttachmentDirectory        = ''
            MaxAttachmentBytes         = 0
            BlockedAttachmentExtensions = @($defaultBlockedExtensions)
        }
    }

    $write = $Settings.write
    $enabled = [bool](Get-OutlookOptionalProperty -Source $write -Name 'enabled' -DefaultValue $false)

    $allowedFolders = New-Object System.Collections.ArrayList
    foreach ($folder in @(Get-OutlookOptionalProperty -Source $write -Name 'allowedFolders' -DefaultValue @($ReadFolders))) {
        $folderName = [string]$folder
        if ([string]::IsNullOrWhiteSpace($folderName)) {
            throw "Outlook settings 'write.allowedFolders' contains an empty folder name."
        }
        $null = $allowedFolders.Add($folderName.Trim())
    }
    if ($allowedFolders.Count -gt 100) {
        throw "Outlook settings 'write.allowedFolders' must not exceed 100 entries."
    }

    $confirmationTimeout = [int](Get-OutlookOptionalProperty -Source $write -Name 'confirmationTimeoutSeconds' -DefaultValue 300)
    if (($confirmationTimeout -lt 30) -or ($confirmationTimeout -gt 3600)) {
        throw "Outlook settings 'write.confirmationTimeoutSeconds' must be between 30 and 3600."
    }

    $maxBatchSize = [int](Get-OutlookOptionalProperty -Source $write -Name 'maxBatchSize' -DefaultValue 25)
    if (($maxBatchSize -lt 1) -or ($maxBatchSize -gt 500)) {
        throw "Outlook settings 'write.maxBatchSize' must be between 1 and 500."
    }

    $maxAttachmentBytes = [int64](Get-OutlookOptionalProperty -Source $write -Name 'maxAttachmentBytes' -DefaultValue 26214400)
    if (($maxAttachmentBytes -lt 1) -or ($maxAttachmentBytes -gt 1073741824)) {
        throw "Outlook settings 'write.maxAttachmentBytes' must be between 1 and 1073741824."
    }

    $blockedExtensions = New-Object System.Collections.ArrayList
    foreach ($extension in @(Get-OutlookOptionalProperty -Source $write -Name 'blockedAttachmentExtensions' -DefaultValue $defaultBlockedExtensions)) {
        $extensionText = ([string]$extension).Trim().ToLowerInvariant()
        if ([string]::IsNullOrWhiteSpace($extensionText)) { continue }
        if (-not $extensionText.StartsWith('.')) { $extensionText = '.' + $extensionText }
        $null = $blockedExtensions.Add($extensionText)
    }

    return [pscustomobject]@{
        Enabled                     = $enabled
        AllowedFolders              = @($allowedFolders)
        ArchiveFolder               = ([string](Get-OutlookOptionalProperty -Source $write -Name 'archiveFolder' -DefaultValue '')).Trim()
        AllowSend                   = [bool](Get-OutlookOptionalProperty -Source $write -Name 'allowSend' -DefaultValue $false)
        AllowDelete                 = [bool](Get-OutlookOptionalProperty -Source $write -Name 'allowDelete' -DefaultValue $false)
        AllowRules                  = [bool](Get-OutlookOptionalProperty -Source $write -Name 'allowRules' -DefaultValue $false)
        AllowAttachmentDownload     = [bool](Get-OutlookOptionalProperty -Source $write -Name 'allowAttachmentDownload' -DefaultValue $false)
        ConfirmationTimeoutSeconds  = $confirmationTimeout
        MaxBatchSize                = $maxBatchSize
        AttachmentDirectory         = ([string](Get-OutlookOptionalProperty -Source $write -Name 'attachmentDirectory' -DefaultValue '')).Trim()
        MaxAttachmentBytes          = $maxAttachmentBytes
        BlockedAttachmentExtensions = @($blockedExtensions)
    }
}

function Assert-OutlookWriteEnabled {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Settings,

        [Parameter(Mandatory = $true)]
        [string]$Operation
    )

    if (-not $Settings.Write.Enabled) {
        throw "Outlook write operations are disabled. Set 'write.enabled' to true in '$($Settings.SettingsPath)' to allow '$Operation'."
    }
}

function Get-OutlookStringProperty {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$ComObject,

        [Parameter(Mandatory = $true)]
        [string]$PropertyName
    )

    try {
        $value = $ComObject.$PropertyName
        if ($null -eq $value) {
            return ''
        }
        return [string]$value
    }
    catch {
        return ''
    }
}

function Get-OutlookBooleanProperty {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$ComObject,

        [Parameter(Mandatory = $true)]
        [string]$PropertyName,

        [Parameter()]
        [bool]$DefaultValue = $false
    )

    try {
        return [bool]$ComObject.$PropertyName
    }
    catch {
        return $DefaultValue
    }
}

function Get-OutlookIntegerProperty {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$ComObject,

        [Parameter(Mandatory = $true)]
        [string]$PropertyName,

        [Parameter()]
        [int]$DefaultValue = 0
    )

    try {
        return [int]$ComObject.$PropertyName
    }
    catch {
        return $DefaultValue
    }
}

function Get-OutlookDateProperty {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$ComObject,

        [Parameter(Mandatory = $true)]
        [string]$PropertyName
    )

    try {
        $value = $ComObject.$PropertyName
        if ($null -eq $value) {
            return $null
        }
        $date = [datetime]$value
        if (($date.Year -lt 1900) -or ($date.Year -gt 3000)) {
            return $null
        }
        return $date
    }
    catch {
        return $null
    }
}

function ConvertTo-OutlookLocalDate {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [datetime]$Value
    )

    if ($Value.Kind -eq [System.DateTimeKind]::Utc) {
        return $Value.ToLocalTime()
    }
    return $Value
}

function ConvertTo-OutlookIsoDate {
    [CmdletBinding()]
    param(
        [Parameter()]
        [AllowNull()]
        [object]$Value
    )

    if ($null -eq $Value) {
        return $null
    }

    $date = [datetime]$Value
    if ($date.Kind -eq [System.DateTimeKind]::Unspecified) {
        $date = [datetime]::SpecifyKind($date, [System.DateTimeKind]::Local)
    }
    return $date.ToString('o', [System.Globalization.CultureInfo]::InvariantCulture)
}

function Get-OutlookConfiguredFolder {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Namespace,

        [Parameter(Mandatory = $true)]
        [object]$DefaultRoot,

        [Parameter(Mandatory = $true)]
        [string]$FolderPath
    )

    $trimmedPath = $FolderPath.Trim()
    if ($trimmedPath.IndexOfAny([char[]]'\/') -lt 0) {
        switch ($trimmedPath.ToLowerInvariant()) {
            'deleted items' { return $Namespace.GetDefaultFolder(3) }
            'outbox' { return $Namespace.GetDefaultFolder(4) }
            'sent items' { return $Namespace.GetDefaultFolder(5) }
            'sent mail' { return $Namespace.GetDefaultFolder(5) }
            'inbox' { return $Namespace.GetDefaultFolder(6) }
            'drafts' { return $Namespace.GetDefaultFolder(16) }
            'junk email' { return $Namespace.GetDefaultFolder(23) }
        }
    }

    $segments = @(
        $trimmedPath -split '[\\/]' |
            ForEach-Object { $_.Trim() } |
            Where-Object { -not [string]::IsNullOrWhiteSpace($_) }
    )
    $rootName = Get-OutlookStringProperty -ComObject $DefaultRoot -PropertyName 'Name'
    if (($segments.Count -gt 0) -and ($segments[0] -ieq $rootName)) {
        $segments = @($segments | Select-Object -Skip 1)
    }
    if ($segments.Count -eq 0) {
        throw "Configured folder '$FolderPath' does not identify a folder below the default store root."
    }

    $current = $DefaultRoot
    $ownsCurrent = $false
    try {
        foreach ($segment in $segments) {
            $children = $null
            $next = $null
            try {
                $children = $current.Folders
                $next = $children.Item($segment)
            }
            finally {
                Release-OutlookComObject -ComObject $children
            }

            if ($null -eq $next) {
                throw "Configured folder '$FolderPath' was not found in the default Outlook store."
            }
            if ($ownsCurrent) {
                Release-OutlookComObject -ComObject $current
            }
            $current = $next
            $next = $null
            $ownsCurrent = $true
        }

        $result = $current
        $current = $null
        $ownsCurrent = $false
        return $result
    }
    finally {
        if ($ownsCurrent) {
            Release-OutlookComObject -ComObject $current
        }
    }
}

function Get-OutlookConfirmationDirectory {
    [CmdletBinding()]
    param()

    if (-not [string]::IsNullOrWhiteSpace($env:OFFICE_HARNESS_STATE)) {
        $stateRoot = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($env:OFFICE_HARNESS_STATE))
    }
    else {
        $stateRoot = Join-Path -Path ([IO.Path]::GetTempPath()) -ChildPath 'OpenCodeOfficeHarness'
    }
    $confirmationRoot = Join-Path -Path $stateRoot -ChildPath 'outlook-confirmations'
    if (-not (Test-Path -LiteralPath $confirmationRoot -PathType Container)) {
        $null = New-Item -ItemType Directory -Path $confirmationRoot -Force
    }
    return $confirmationRoot
}

function Get-OutlookFingerprint {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [string[]]$Parts
    )

    $separator = [string][char]31
    $canonical = [string]::Join($separator, $Parts)
    $algorithm = [System.Security.Cryptography.SHA256]::Create()
    try {
        $hash = $algorithm.ComputeHash([System.Text.Encoding]::UTF8.GetBytes($canonical))
    }
    finally {
        $algorithm.Dispose()
    }
    return ([System.BitConverter]::ToString($hash).Replace('-', '').ToLowerInvariant())
}

function Remove-OutlookExpiredConfirmation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$ConfirmationDirectory
    )

    $now = [datetime]::UtcNow
    foreach ($file in @(Get-ChildItem -LiteralPath $ConfirmationDirectory -File -Filter '*.json' -ErrorAction SilentlyContinue)) {
        try {
            $record = Get-Content -LiteralPath $file.FullName -Raw -Encoding UTF8 | ConvertFrom-Json
            $expires = [datetime]::Parse($record.ExpiresUtc, [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::RoundtripKind)
            if ($expires -lt $now) { Remove-Item -LiteralPath $file.FullName -Force -ErrorAction SilentlyContinue }
        }
        catch {
            Remove-Item -LiteralPath $file.FullName -Force -ErrorAction SilentlyContinue
        }
    }
}

function New-OutlookConfirmation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Operation,

        [Parameter(Mandatory = $true)]
        [string]$Fingerprint,

        [Parameter(Mandatory = $true)]
        [object]$Settings
    )

    $confirmationRoot = Get-OutlookConfirmationDirectory
    Remove-OutlookExpiredConfirmation -ConfirmationDirectory $confirmationRoot

    $buffer = New-Object byte[] 24
    $generator = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try {
        $generator.GetBytes($buffer)
    }
    finally {
        $generator.Dispose()
    }
    $token = ([System.BitConverter]::ToString($buffer).Replace('-', '').ToLowerInvariant())

    $issuedUtc = [datetime]::UtcNow
    $expiresUtc = $issuedUtc.AddSeconds($Settings.Write.ConfirmationTimeoutSeconds)
    $record = [pscustomobject]@{
        Operation   = $Operation
        Fingerprint = $Fingerprint
        IssuedUtc   = $issuedUtc.ToString('o', [System.Globalization.CultureInfo]::InvariantCulture)
        ExpiresUtc  = $expiresUtc.ToString('o', [System.Globalization.CultureInfo]::InvariantCulture)
    }

    $recordPath = Join-Path -Path $confirmationRoot -ChildPath ($token + '.json')
    [IO.File]::WriteAllText($recordPath, ($record | ConvertTo-Json -Depth 4 -Compress), (New-Object Text.UTF8Encoding($false)))

    return [pscustomobject]@{
        Token      = $token
        ExpiresUtc = $record.ExpiresUtc
        ExpiresInSeconds = $Settings.Write.ConfirmationTimeoutSeconds
    }
}

function Assert-OutlookConfirmation {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Token,

        [Parameter(Mandatory = $true)]
        [string]$Operation,

        [Parameter(Mandatory = $true)]
        [string]$Fingerprint
    )

    if ($Token -notmatch '^[0-9a-f]{48}$') {
        throw 'The supplied confirmation token is malformed. Request a fresh preview and pass the token it returns.'
    }

    $confirmationRoot = Get-OutlookConfirmationDirectory
    $recordPath = Join-Path -Path $confirmationRoot -ChildPath ($Token + '.json')
    if (-not (Test-Path -LiteralPath $recordPath -PathType Leaf)) {
        throw 'The confirmation token is unknown, already used, or expired. Request a fresh preview and confirm again.'
    }

    $record = $null
    try {
        $record = Get-Content -LiteralPath $recordPath -Raw -Encoding UTF8 | ConvertFrom-Json
    }
    catch {
        Remove-Item -LiteralPath $recordPath -Force -ErrorAction SilentlyContinue
        throw 'The confirmation token record is unreadable. Request a fresh preview and confirm again.'
    }

    # Single use: consume the record before acting so a replay cannot repeat the operation.
    Remove-Item -LiteralPath $recordPath -Force

    $expires = [datetime]::Parse($record.ExpiresUtc, [System.Globalization.CultureInfo]::InvariantCulture, [System.Globalization.DateTimeStyles]::RoundtripKind)
    if ($expires -lt [datetime]::UtcNow) {
        throw 'The confirmation token expired. Request a fresh preview and confirm again.'
    }
    if (-not ([string]$record.Operation).Equals($Operation, [StringComparison]::Ordinal)) {
        throw "The confirmation token was issued for '$($record.Operation)', not '$Operation'."
    }
    if (-not ([string]$record.Fingerprint).Equals($Fingerprint, [StringComparison]::Ordinal)) {
        throw 'The confirmation token does not match the requested targets. The mailbox or the request changed after the preview, so nothing was done.'
    }

    return $record
}

function Resolve-OutlookScopedFolder {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Namespace,

        [Parameter(Mandatory = $true)]
        [object]$DefaultRoot,

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [string[]]$ScopeFolders,

        [Parameter(Mandatory = $true)]
        [string]$FolderPath
    )

    $requested = $FolderPath.Trim()
    foreach ($scopeFolder in $ScopeFolders) {
        if ($scopeFolder.Equals($requested, [StringComparison]::OrdinalIgnoreCase)) {
            return Get-OutlookConfiguredFolder -Namespace $Namespace -DefaultRoot $DefaultRoot -FolderPath $scopeFolder
        }
    }
    throw "Folder '$FolderPath' is outside the configured Outlook write scope. Allowed folders: $([string]::Join(', ', $ScopeFolders))."
}

function Resolve-OutlookScopedMailItem {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Namespace,

        [Parameter(Mandatory = $true)]
        [object]$DefaultRoot,

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [string[]]$ScopeFolders,

        [Parameter(Mandatory = $true)]
        [string]$EntryId,

        [Parameter(Mandatory = $true)]
        [string]$StoreId
    )

    $item = $Namespace.GetItemFromID($EntryId, $StoreId)
    if ($null -eq $item) {
        throw 'Outlook did not return an item for the supplied EntryId and StoreId.'
    }

    $released = $false
    try {
        $itemClass = Get-OutlookIntegerProperty -ComObject $item -PropertyName 'Class' -DefaultValue 0
        if ($itemClass -ne 43) {
            throw "The supplied identifiers refer to Outlook item class $itemClass, not a mail message."
        }

        $parentFolder = $null
        $folderName = ''
        $parentEntryId = ''
        $parentStoreId = ''
        try {
            $parentFolder = $item.Parent
            if ($null -ne $parentFolder) {
                $folderName = Get-OutlookStringProperty -ComObject $parentFolder -PropertyName 'Name'
                $parentEntryId = Get-OutlookStringProperty -ComObject $parentFolder -PropertyName 'EntryID'
                $parentStoreId = Get-OutlookStringProperty -ComObject $parentFolder -PropertyName 'StoreID'
            }
        }
        finally {
            Release-OutlookComObject -ComObject $parentFolder
        }

        if ([string]::IsNullOrWhiteSpace($parentEntryId) -or [string]::IsNullOrWhiteSpace($parentStoreId)) {
            throw 'The message parent folder did not provide stable identifiers.'
        }

        $authorizedFolder = $null
        foreach ($scopeFolderPath in $ScopeFolders) {
            $scopeFolder = $null
            try {
                $scopeFolder = Get-OutlookConfiguredFolder -Namespace $Namespace -DefaultRoot $DefaultRoot -FolderPath $scopeFolderPath
                $scopeEntryId = Get-OutlookStringProperty -ComObject $scopeFolder -PropertyName 'EntryID'
                $scopeStoreId = Get-OutlookStringProperty -ComObject $scopeFolder -PropertyName 'StoreID'
                if ($scopeStoreId.Equals($parentStoreId, [StringComparison]::OrdinalIgnoreCase) -and
                    $Namespace.CompareEntryIDs($scopeEntryId, $parentEntryId)) {
                    $authorizedFolder = $scopeFolderPath
                    break
                }
            }
            finally {
                Release-OutlookComObject -ComObject $scopeFolder
            }
        }
        if ($null -eq $authorizedFolder) {
            throw 'The requested message is outside the configured Outlook folder scope.'
        }

        $result = [pscustomobject]@{
            Item             = $item
            ConfiguredFolder = $authorizedFolder
            FolderName       = $folderName
            Subject          = Get-OutlookStringProperty -ComObject $item -PropertyName 'Subject'
            SenderName       = Get-OutlookStringProperty -ComObject $item -PropertyName 'SenderName'
            SenderAddress    = Get-OutlookStringProperty -ComObject $item -PropertyName 'SenderEmailAddress'
            ReceivedTime     = ConvertTo-OutlookIsoDate -Value (Get-OutlookDateProperty -ComObject $item -PropertyName 'ReceivedTime')
            EntryId          = Get-OutlookStringProperty -ComObject $item -PropertyName 'EntryID'
        }
        $released = $true
        return $result
    }
    finally {
        if (-not $released) {
            Release-OutlookComObject -ComObject $item
        }
    }
}

function Get-OutlookMessagePlanTargets {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Plan,

        [Parameter(Mandatory = $true)]
        [object]$Settings
    )

    if (@($Plan.PSObject.Properties.Name) -notcontains 'messages') {
        throw "The plan is missing the required 'messages' array."
    }
    $messages = @($Plan.messages)
    if ($messages.Count -lt 1) {
        throw "The plan 'messages' array must contain at least one message."
    }
    if ($messages.Count -gt $Settings.Write.MaxBatchSize) {
        throw "The plan targets $($messages.Count) messages, which exceeds the configured write.maxBatchSize of $($Settings.Write.MaxBatchSize)."
    }

    $targets = New-Object System.Collections.ArrayList
    foreach ($message in $messages) {
        $entryId = [string](Get-OutlookOptionalProperty -Source $message -Name 'entryId' -DefaultValue '')
        $storeId = [string](Get-OutlookOptionalProperty -Source $message -Name 'storeId' -DefaultValue '')
        if ([string]::IsNullOrWhiteSpace($entryId) -or [string]::IsNullOrWhiteSpace($storeId)) {
            throw 'Every plan message requires a non-empty entryId and storeId from a prior search.'
        }
        $null = $targets.Add([pscustomobject]@{ EntryId = $entryId.Trim(); StoreId = $storeId.Trim() })
    }
    return @($targets)
}

function ConvertTo-OutlookSafeFileName {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$Name,

        [Parameter()]
        [string]$FallbackName = 'attachment'
    )

    $candidate = $Name
    if ([string]::IsNullOrWhiteSpace($candidate)) { $candidate = $FallbackName }

    # Take the last path segment by hand. [IO.Path]::GetFileName would treat a leading "a:" as a
    # drive qualifier and silently discard it, losing part of the caller's file name.
    $segments = @($candidate.Replace('/', '\') -split '\\')
    for ($segmentIndex = $segments.Length - 1; $segmentIndex -ge 0; $segmentIndex--) {
        if (-not [string]::IsNullOrWhiteSpace($segments[$segmentIndex])) {
            $candidate = $segments[$segmentIndex]
            break
        }
    }

    $builder = New-Object System.Text.StringBuilder
    $invalid = [IO.Path]::GetInvalidFileNameChars()
    foreach ($character in $candidate.ToCharArray()) {
        if (($invalid -contains $character) -or ([int]$character -lt 32)) { $null = $builder.Append('_') }
        else { $null = $builder.Append($character) }
    }
    $candidate = $builder.ToString().Trim().Trim('.')
    if ([string]::IsNullOrWhiteSpace($candidate)) { $candidate = $FallbackName }

    $reserved = @('CON', 'PRN', 'AUX', 'NUL', 'COM1', 'COM2', 'COM3', 'COM4', 'COM5', 'COM6', 'COM7',
        'COM8', 'COM9', 'LPT1', 'LPT2', 'LPT3', 'LPT4', 'LPT5', 'LPT6', 'LPT7', 'LPT8', 'LPT9')
    $stem = [IO.Path]::GetFileNameWithoutExtension($candidate)
    if ($reserved -contains $stem.ToUpperInvariant()) { $candidate = '_' + $candidate }

    if ($candidate.Length -gt 120) {
        $extension = [IO.Path]::GetExtension($candidate)
        $stem = [IO.Path]::GetFileNameWithoutExtension($candidate)
        $keep = [math]::Max(1, 120 - $extension.Length)
        $candidate = $stem.Substring(0, [math]::Min($stem.Length, $keep)) + $extension
    }
    return $candidate
}

function ConvertTo-OutlookErrorJson {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [System.Management.Automation.ErrorRecord]$ErrorRecord,

        [Parameter(Mandatory = $true)]
        [string]$ScriptName
    )

    $exception = $ErrorRecord.Exception
    $hresult = '0x' + $exception.HResult.ToString('X8', [System.Globalization.CultureInfo]::InvariantCulture)
    return ([pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = $ScriptName
            Message = $exception.Message
            Type    = $exception.GetType().FullName
            HResult = $hresult
        }
    } | ConvertTo-Json -Depth 5 -Compress)
}

Export-ModuleMember -Function @(
    'Release-OutlookComObject',
    'Get-OutlookSettings',
    'Get-OutlookOptionalProperty',
    'Get-OutlookWriteSettings',
    'Assert-OutlookWriteEnabled',
    'Get-OutlookStringProperty',
    'Get-OutlookBooleanProperty',
    'Get-OutlookIntegerProperty',
    'Get-OutlookDateProperty',
    'ConvertTo-OutlookLocalDate',
    'ConvertTo-OutlookIsoDate',
    'Get-OutlookConfiguredFolder',
    'Get-OutlookConfirmationDirectory',
    'Get-OutlookFingerprint',
    'New-OutlookConfirmation',
    'Assert-OutlookConfirmation',
    'Resolve-OutlookScopedFolder',
    'Resolve-OutlookScopedMailItem',
    'Get-OutlookMessagePlanTargets',
    'ConvertTo-OutlookSafeFileName',
    'ConvertTo-OutlookErrorJson'
)

#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$EntryId,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$StoreId,

    [Parameter()]
    [ValidateRange(0, 1000000)]
    [int]$MaxBodyCharacters = 0
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Outlook.Common.psm1'
try {
    Import-Module -Name $modulePath -Force -DisableNameChecking -ErrorAction Stop
}
catch {
    $failure = [pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = 'Read-OutlookMail.ps1'
            Message = $_.Exception.Message
            Type    = $_.Exception.GetType().FullName
        }
    } | ConvertTo-Json -Depth 4 -Compress
    [Console]::Error.WriteLine($failure)
    exit 1
}

$application = $null
$namespace = $null
$defaultStore = $null
$defaultRoot = $null
$item = $null
$attachments = $null
$parentFolder = $null
$outputJson = $null
$errorJson = $null

try {
    $settings = Get-OutlookSettings
    $effectiveMaxBodyCharacters = $settings.MaxBodyCharacters
    if ($MaxBodyCharacters -gt 0) {
        $effectiveMaxBodyCharacters = [math]::Min($MaxBodyCharacters, $settings.MaxBodyCharacters)
    }

    $application = New-Object -ComObject 'Outlook.Application'
    $namespace = $application.GetNamespace('MAPI')
    $defaultStore = $namespace.DefaultStore
    $defaultRoot = $defaultStore.GetRootFolder()
    $item = $namespace.GetItemFromID($EntryId, $StoreId)
    if ($null -eq $item) {
        throw 'Outlook did not return an item for the supplied EntryId and StoreId.'
    }

    $itemClass = Get-OutlookIntegerProperty -ComObject $item -PropertyName 'Class' -DefaultValue 0
    if ($itemClass -ne 43) {
        throw "The supplied identifiers refer to Outlook item class $itemClass, not a mail message."
    }

    $actualEntryId = Get-OutlookStringProperty -ComObject $item -PropertyName 'EntryID'
    if ([string]::IsNullOrWhiteSpace($actualEntryId)) {
        throw 'The Outlook mail item did not provide an EntryID.'
    }

    $folderName = ''
    $parentEntryId = ''
    $parentStoreId = ''
    try {
        $parentFolder = $item.Parent
        if ($null -ne $parentFolder) {
            $folderName = Get-OutlookStringProperty -ComObject $parentFolder -PropertyName 'Name'
            $parentEntryId = Get-OutlookStringProperty -ComObject $parentFolder -PropertyName 'EntryID'
            $parentStoreId = Get-OutlookStringProperty -ComObject $parentFolder -PropertyName 'StoreID'
        }
    }
    finally {
        Release-OutlookComObject -ComObject $parentFolder
        $parentFolder = $null
    }

    if ([string]::IsNullOrWhiteSpace($parentEntryId) -or [string]::IsNullOrWhiteSpace($parentStoreId)) {
        throw 'The message parent folder did not provide stable identifiers.'
    }
    $authorizedFolder = $null
    foreach ($configuredFolderPath in $settings.Folders) {
        $configuredFolder = $null
        try {
            $configuredFolder = Get-OutlookConfiguredFolder -Namespace $namespace -DefaultRoot $defaultRoot -FolderPath $configuredFolderPath
            $configuredEntryId = Get-OutlookStringProperty -ComObject $configuredFolder -PropertyName 'EntryID'
            $configuredStoreId = Get-OutlookStringProperty -ComObject $configuredFolder -PropertyName 'StoreID'
            if ($configuredStoreId.Equals($parentStoreId, [StringComparison]::OrdinalIgnoreCase) -and
                $namespace.CompareEntryIDs($configuredEntryId, $parentEntryId)) {
                $authorizedFolder = $configuredFolderPath
                break
            }
        }
        finally {
            Release-OutlookComObject -ComObject $configuredFolder
        }
    }
    if ($null -eq $authorizedFolder) {
        throw 'The requested message is outside the configured Outlook folder scope.'
    }

    $attachmentNames = New-Object System.Collections.ArrayList
    $attachments = $item.Attachments
    $attachmentCount = [int]$attachments.Count
    for ($attachmentIndex = 1; $attachmentIndex -le $attachmentCount; $attachmentIndex++) {
        $attachment = $null
        try {
            $attachment = $attachments.Item($attachmentIndex)
            $attachmentName = Get-OutlookStringProperty -ComObject $attachment -PropertyName 'FileName'
            if ([string]::IsNullOrWhiteSpace($attachmentName)) {
                $attachmentName = Get-OutlookStringProperty -ComObject $attachment -PropertyName 'DisplayName'
            }
            $null = $attachmentNames.Add($attachmentName)
        }
        finally {
            Release-OutlookComObject -ComObject $attachment
        }
    }

    $bodyValue = $item.Body
    if ($null -eq $bodyValue) {
        $fullBody = ''
    }
    else {
        $fullBody = [string]$bodyValue
    }
    $bodyLength = $fullBody.Length
    $charactersToReturn = [math]::Min($bodyLength, $effectiveMaxBodyCharacters)
    if (($charactersToReturn -gt 0) -and ($charactersToReturn -lt $bodyLength) -and
        [char]::IsHighSurrogate($fullBody[$charactersToReturn - 1]) -and
        [char]::IsLowSurrogate($fullBody[$charactersToReturn])) {
        $charactersToReturn--
    }
    $boundedBody = $fullBody.Substring(0, $charactersToReturn)

    $receivedTime = Get-OutlookDateProperty -ComObject $item -PropertyName 'ReceivedTime'
    $sentTime = Get-OutlookDateProperty -ComObject $item -PropertyName 'SentOn'
    $outputJson = [pscustomobject]@{
        Ok           = $true
        SettingsPath = $settings.SettingsPath
        ReadOnly     = $true
        Message      = [pscustomobject]@{
            EntryId                 = $actualEntryId
            StoreId                 = $StoreId
            FolderName             = $folderName
            ConfiguredFolder       = $authorizedFolder
            Subject                = Get-OutlookStringProperty -ComObject $item -PropertyName 'Subject'
            SenderName             = Get-OutlookStringProperty -ComObject $item -PropertyName 'SenderName'
            SenderEmailAddress     = Get-OutlookStringProperty -ComObject $item -PropertyName 'SenderEmailAddress'
            To                     = Get-OutlookStringProperty -ComObject $item -PropertyName 'To'
            Cc                     = Get-OutlookStringProperty -ComObject $item -PropertyName 'CC'
            ConversationTopic      = Get-OutlookStringProperty -ComObject $item -PropertyName 'ConversationTopic'
            ReceivedTime           = ConvertTo-OutlookIsoDate -Value $receivedTime
            SentTime               = ConvertTo-OutlookIsoDate -Value $sentTime
            Unread                 = Get-OutlookBooleanProperty -ComObject $item -PropertyName 'UnRead' -DefaultValue $false
            Importance             = Get-OutlookIntegerProperty -ComObject $item -PropertyName 'Importance' -DefaultValue 1
            Size                   = Get-OutlookIntegerProperty -ComObject $item -PropertyName 'Size' -DefaultValue 0
            Body                   = $boundedBody
            BodyCharactersReturned = $charactersToReturn
            BodyCharactersTotal    = $bodyLength
            BodyTruncated          = ($bodyLength -gt $charactersToReturn)
            AttachmentNames        = @($attachmentNames)
        }
    } | ConvertTo-Json -Depth 7 -Compress
}
catch {
    $errorJson = ConvertTo-OutlookErrorJson -ErrorRecord $_ -ScriptName 'Read-OutlookMail.ps1'
}
finally {
    Release-OutlookComObject -ComObject $parentFolder
    Release-OutlookComObject -ComObject $attachments
    Release-OutlookComObject -ComObject $item
    Release-OutlookComObject -ComObject $defaultRoot
    Release-OutlookComObject -ComObject $defaultStore
    Release-OutlookComObject -ComObject $namespace
    Release-OutlookComObject -ComObject $application
}

if ($null -ne $errorJson) {
    [Console]::Error.WriteLine($errorJson)
    exit 1
}
[Console]::Out.WriteLine($outputJson)

#requires -Version 5.1

<#
    Deletion here is always recoverable: MailItem.Delete() moves the message to Deleted Items.
    There is deliberately no purge path, and messages already in Deleted Items are refused,
    because deleting those would be permanent.

    Two-phase contract:
      Phase 1 (no -ConfirmationToken) resolves the targets, returns a preview, and mints a
              single-use token bound to a fingerprint of those exact messages.
      Phase 2 (with -ConfirmationToken) re-resolves the targets, recomputes the fingerprint,
              and refuses unless it still matches the token that was issued.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$PlanPath,

    [Parameter()]
    [AllowEmptyString()]
    [string]$ConfirmationToken = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Outlook.Common.psm1'
try {
    Import-Module -Name $modulePath -Force -DisableNameChecking -ErrorAction Stop
}
catch {
    $failure = [pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = 'Remove-OutlookMail.ps1'
            Message = $_.Exception.Message
            Type    = $_.Exception.GetType().FullName
        }
    } | ConvertTo-Json -Depth 4 -Compress
    [Console]::Error.WriteLine($failure)
    exit 1
}

$application = $null
$namespace = $null
$defaultStore = $null
$defaultRoot = $null
$deletedItemsFolder = $null
$outputJson = $null
$errorJson = $null

try {
    $settings = Get-OutlookSettings
    Assert-OutlookWriteEnabled -Settings $settings -Operation 'delete'
    if (-not $settings.Write.AllowDelete) {
        throw "Deletion is disabled. Set 'write.allowDelete' to true in '$($settings.SettingsPath)' to allow it."
    }

    if (-not (Test-Path -LiteralPath $PlanPath -PathType Leaf)) {
        throw "The plan file '$PlanPath' was not found."
    }
    $plan = Get-Content -LiteralPath $PlanPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $targets = Get-OutlookMessagePlanTargets -Plan $plan -Settings $settings

    $application = New-Object -ComObject 'Outlook.Application'
    $namespace = $application.GetNamespace('MAPI')
    $defaultStore = $namespace.DefaultStore
    $defaultRoot = $defaultStore.GetRootFolder()
    $deletedItemsFolder = $namespace.GetDefaultFolder(3)
    $deletedItemsEntryId = Get-OutlookStringProperty -ComObject $deletedItemsFolder -PropertyName 'EntryID'

    $previews = New-Object System.Collections.ArrayList
    $fingerprintParts = New-Object System.Collections.ArrayList
    $null = $fingerprintParts.Add('delete')

    foreach ($target in $targets) {
        $resolved = $null
        try {
            $resolved = Resolve-OutlookScopedMailItem -Namespace $namespace -DefaultRoot $defaultRoot `
                -ScopeFolders $settings.WriteScopeFolders -EntryId $target.EntryId -StoreId $target.StoreId

            $sourceParent = $null
            $sourceEntryId = ''
            try {
                $sourceParent = $resolved.Item.Parent
                if ($null -ne $sourceParent) {
                    $sourceEntryId = Get-OutlookStringProperty -ComObject $sourceParent -PropertyName 'EntryID'
                }
            }
            finally {
                Release-OutlookComObject -ComObject $sourceParent
            }
            if ($namespace.CompareEntryIDs($sourceEntryId, $deletedItemsEntryId)) {
                throw "The message '$($resolved.Subject)' is already in Deleted Items. Removing it again would be permanent, which this tool does not do. Empty Deleted Items in Outlook yourself if that is what you want."
            }

            $null = $previews.Add([pscustomobject]@{
                EntryId          = $target.EntryId
                StoreId          = $target.StoreId
                ConfiguredFolder = $resolved.ConfiguredFolder
                FolderName       = $resolved.FolderName
                Subject          = $resolved.Subject
                SenderName       = $resolved.SenderName
                SenderAddress    = $resolved.SenderAddress
                ReceivedTime     = $resolved.ReceivedTime
            })
        }
        finally {
            if ($null -ne $resolved) { Release-OutlookComObject -ComObject $resolved.Item }
        }
    }

    foreach ($preview in @($previews | Sort-Object -Property EntryId)) {
        $null = $fingerprintParts.Add("$($preview.EntryId)|$($preview.StoreId)|$($preview.Subject)|$($preview.ReceivedTime)")
    }
    $fingerprint = Get-OutlookFingerprint -Parts @($fingerprintParts)

    if ([string]::IsNullOrWhiteSpace($ConfirmationToken)) {
        $confirmation = New-OutlookConfirmation -Operation 'delete' -Fingerprint $fingerprint -Settings $settings
        $outputJson = [pscustomobject]@{
            Ok                   = $true
            SettingsPath         = $settings.SettingsPath
            Operation            = 'delete'
            Stage                = 'PreviewOnly'
            RequiresConfirmation = $true
            Deleted              = 0
            Destination          = 'Deleted Items'
            Reversible           = $true
            ConfirmationToken    = $confirmation.Token
            TokenExpiresUtc      = $confirmation.ExpiresUtc
            TokenExpiresInSeconds = $confirmation.ExpiresInSeconds
            Message              = 'Nothing was deleted. Show this list to the user, get an explicit yes, then call again with the confirmation token.'
            Preview              = @($previews)
        } | ConvertTo-Json -Depth 8 -Compress
    }
    else {
        $null = Assert-OutlookConfirmation -Token $ConfirmationToken.Trim() -Operation 'delete' -Fingerprint $fingerprint

        $results = New-Object System.Collections.ArrayList
        $deletedCount = 0
        $failedCount = 0

        foreach ($target in $targets) {
            $resolved = $null
            try {
                $resolved = Resolve-OutlookScopedMailItem -Namespace $namespace -DefaultRoot $defaultRoot `
                    -ScopeFolders $settings.WriteScopeFolders -EntryId $target.EntryId -StoreId $target.StoreId
                $subject = $resolved.Subject
                $senderName = $resolved.SenderName
                $receivedTime = $resolved.ReceivedTime
                $sourceFolder = $resolved.ConfiguredFolder
                $resolved.Item.Delete()
                $deletedCount++
                $null = $results.Add([pscustomobject]@{
                    Subject      = $subject
                    SenderName   = $senderName
                    ReceivedTime = $receivedTime
                    SourceFolder = $sourceFolder
                    Ok           = $true
                    Error        = $null
                })
            }
            catch {
                $failedCount++
                $null = $results.Add([pscustomobject]@{
                    Subject      = if ($null -ne $resolved) { $resolved.Subject } else { $null }
                    SenderName   = if ($null -ne $resolved) { $resolved.SenderName } else { $null }
                    ReceivedTime = if ($null -ne $resolved) { $resolved.ReceivedTime } else { $null }
                    SourceFolder = if ($null -ne $resolved) { $resolved.ConfiguredFolder } else { $null }
                    Ok           = $false
                    Error        = $_.Exception.Message
                })
            }
            finally {
                if ($null -ne $resolved) { Release-OutlookComObject -ComObject $resolved.Item }
            }
        }

        $outputJson = [pscustomobject]@{
            Ok                   = ($failedCount -eq 0)
            SettingsPath         = $settings.SettingsPath
            Operation            = 'delete'
            Stage                = 'Executed'
            RequiresConfirmation = $false
            Requested            = $targets.Count
            Deleted              = $deletedCount
            Failed               = $failedCount
            Destination          = 'Deleted Items'
            Reversible           = $true
            Message              = 'Messages were moved to Deleted Items and can be restored from there.'
            Results              = @($results)
        } | ConvertTo-Json -Depth 8 -Compress
    }
}
catch {
    $errorJson = ConvertTo-OutlookErrorJson -ErrorRecord $_ -ScriptName 'Remove-OutlookMail.ps1'
}
finally {
    Release-OutlookComObject -ComObject $deletedItemsFolder
    Release-OutlookComObject -ComObject $defaultRoot
    Release-OutlookComObject -ComObject $defaultStore
    Release-OutlookComObject -ComObject $namespace
    Release-OutlookComObject -ComObject $application
}

if ($null -ne $errorJson) {
    [Console]::Error.WriteLine($errorJson)
    exit 1
}
[Console]::Out.WriteLine($outputJson)

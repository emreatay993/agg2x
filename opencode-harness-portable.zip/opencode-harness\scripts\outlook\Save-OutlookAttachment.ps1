#requires -Version 5.1

<#
    Saves attachments from one scoped mail message to a bounded output directory.
    Executable and script file types are refused, output is confined to the configured
    attachment root, and file names are sanitized before they touch the file system.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$EntryId,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$StoreId,

    [Parameter()]
    [AllowEmptyString()]
    [string]$AttachmentName = '',

    [Parameter()]
    [AllowEmptyString()]
    [string]$OutputDirectory = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Outlook.Common.psm1'
try {
    Import-Module -Name $modulePath -Force -DisableNameChecking -ErrorAction Stop
}
catch {
    $failure = [pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = 'Save-OutlookAttachment.ps1'
            Message = $_.Exception.Message
            Type    = $_.Exception.GetType().FullName
        }
    } | ConvertTo-Json -Depth 4 -Compress
    [Console]::Error.WriteLine($failure)
    exit 1
}

$application = $null
$namespace = $null
$defaultStore = $null
$defaultRoot = $null
$resolved = $null
$attachments = $null
$outputJson = $null
$errorJson = $null

try {
    $settings = Get-OutlookSettings
    Assert-OutlookWriteEnabled -Settings $settings -Operation 'save-attachment'
    if (-not $settings.Write.AllowAttachmentDownload) {
        throw "Attachment download is disabled. Set 'write.allowAttachmentDownload' to true in '$($settings.SettingsPath)' to allow it."
    }

    if (-not [string]::IsNullOrWhiteSpace($settings.Write.AttachmentDirectory)) {
        $attachmentRoot = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($settings.Write.AttachmentDirectory))
    }
    else {
        if (-not [string]::IsNullOrWhiteSpace($env:OFFICE_HARNESS_STATE)) {
            $stateRoot = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($env:OFFICE_HARNESS_STATE))
        }
        else {
            $stateRoot = Join-Path -Path ([IO.Path]::GetTempPath()) -ChildPath 'OpenCodeOfficeHarness'
        }
        $attachmentRoot = Join-Path -Path $stateRoot -ChildPath 'outlook-attachments'
    }

    if ([string]::IsNullOrWhiteSpace($OutputDirectory)) {
        $targetDirectory = $attachmentRoot
    }
    else {
        $targetDirectory = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($OutputDirectory))
        $rootComparison = $attachmentRoot.TrimEnd('\') + '\'
        if (-not ($targetDirectory.TrimEnd('\') + '\').StartsWith($rootComparison, [StringComparison]::OrdinalIgnoreCase)) {
            throw "The output directory must be inside the configured attachment root '$attachmentRoot'."
        }
    }
    if (-not (Test-Path -LiteralPath $targetDirectory -PathType Container)) {
        $null = New-Item -ItemType Directory -Path $targetDirectory -Force
    }

    $application = New-Object -ComObject 'Outlook.Application'
    $namespace = $application.GetNamespace('MAPI')
    $defaultStore = $namespace.DefaultStore
    $defaultRoot = $defaultStore.GetRootFolder()

    $resolved = Resolve-OutlookScopedMailItem -Namespace $namespace -DefaultRoot $defaultRoot `
        -ScopeFolders $settings.WriteScopeFolders -EntryId $EntryId.Trim() -StoreId $StoreId.Trim()

    $requestedName = $AttachmentName.Trim()
    $saved = New-Object System.Collections.ArrayList
    $skipped = New-Object System.Collections.ArrayList

    $attachments = $resolved.Item.Attachments
    $attachmentCount = [int]$attachments.Count
    if ($attachmentCount -lt 1) {
        throw 'That message has no attachments.'
    }

    $matchedAny = $false
    for ($attachmentIndex = 1; $attachmentIndex -le $attachmentCount; $attachmentIndex++) {
        $attachment = $null
        try {
            $attachment = $attachments.Item($attachmentIndex)
            $sourceName = Get-OutlookStringProperty -ComObject $attachment -PropertyName 'FileName'
            if ([string]::IsNullOrWhiteSpace($sourceName)) {
                $sourceName = Get-OutlookStringProperty -ComObject $attachment -PropertyName 'DisplayName'
            }

            if ((-not [string]::IsNullOrWhiteSpace($requestedName)) -and
                (-not $sourceName.Equals($requestedName, [StringComparison]::OrdinalIgnoreCase))) {
                continue
            }
            $matchedAny = $true

            $attachmentSize = Get-OutlookIntegerProperty -ComObject $attachment -PropertyName 'Size' -DefaultValue 0
            if ($attachmentSize -gt $settings.Write.MaxAttachmentBytes) {
                $null = $skipped.Add([pscustomobject]@{
                    Name   = $sourceName
                    Reason = "Size $attachmentSize exceeds the configured maxAttachmentBytes of $($settings.Write.MaxAttachmentBytes)."
                })
                continue
            }

            $safeName = ConvertTo-OutlookSafeFileName -Name $sourceName -FallbackName "attachment-$attachmentIndex"
            $extension = [IO.Path]::GetExtension($safeName).ToLowerInvariant()
            if ($settings.Write.BlockedAttachmentExtensions -contains $extension) {
                $null = $skipped.Add([pscustomobject]@{
                    Name   = $sourceName
                    Reason = "Extension '$extension' is on the blocked attachment list."
                })
                continue
            }

            $destinationPath = Join-Path -Path $targetDirectory -ChildPath $safeName
            $stem = [IO.Path]::GetFileNameWithoutExtension($safeName)
            $suffix = 1
            while (Test-Path -LiteralPath $destinationPath -PathType Leaf) {
                $destinationPath = Join-Path -Path $targetDirectory -ChildPath ("$stem($suffix)$extension")
                $suffix++
                if ($suffix -gt 500) { throw "Could not find a free file name for '$safeName'." }
            }

            $attachment.SaveAsFile($destinationPath)
            $savedInfo = Get-Item -LiteralPath $destinationPath
            $null = $saved.Add([pscustomobject]@{
                SourceName = $sourceName
                SavedAs    = $savedInfo.Name
                Path       = $savedInfo.FullName
                Bytes      = $savedInfo.Length
            })
        }
        finally {
            Release-OutlookComObject -ComObject $attachment
        }
    }

    if ((-not [string]::IsNullOrWhiteSpace($requestedName)) -and (-not $matchedAny)) {
        throw "No attachment named '$requestedName' was found on that message."
    }

    $outputJson = [pscustomobject]@{
        Ok              = $true
        SettingsPath    = $settings.SettingsPath
        Operation       = 'save-attachment'
        Subject         = $resolved.Subject
        SenderName      = $resolved.SenderName
        ReceivedTime    = $resolved.ReceivedTime
        OutputDirectory = $targetDirectory
        SavedCount      = $saved.Count
        SkippedCount    = $skipped.Count
        Saved           = @($saved)
        Skipped         = @($skipped)
    } | ConvertTo-Json -Depth 7 -Compress
}
catch {
    $errorJson = ConvertTo-OutlookErrorJson -ErrorRecord $_ -ScriptName 'Save-OutlookAttachment.ps1'
}
finally {
    Release-OutlookComObject -ComObject $attachments
    if ($null -ne $resolved) { Release-OutlookComObject -ComObject $resolved.Item }
    Release-OutlookComObject -ComObject $defaultRoot
    Release-OutlookComObject -ComObject $defaultStore
    Release-OutlookComObject -ComObject $namespace
    Release-OutlookComObject -ComObject $application
}

if ($null -ne $errorJson) {
    [Console]::Error.WriteLine($errorJson)
    exit 1
}
[Console]::Out.WriteLine($outputJson)

#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter()]
    [AllowEmptyString()]
    [string]$Sender = '',

    [Parameter()]
    [AllowEmptyString()]
    [string]$Subject = '',

    [Parameter()]
    [AllowEmptyString()]
    [string]$Text = '',

    [Parameter()]
    [Alias('From', 'After', 'DateFrom')]
    [Nullable[datetime]]$StartDate,

    [Parameter()]
    [Alias('To', 'Before', 'DateTo')]
    [Nullable[datetime]]$EndDate,

    [Parameter()]
    [Alias('Unread')]
    [switch]$UnreadOnly,

    [Parameter()]
    [ValidateRange(0, 1000)]
    [int]$MaxResults = 0
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Outlook.Common.psm1'
try {
    Import-Module -Name $modulePath -Force -DisableNameChecking -ErrorAction Stop
}
catch {
    $failure = [pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = 'Search-OutlookMail.ps1'
            Message = $_.Exception.Message
            Type    = $_.Exception.GetType().FullName
        }
    } | ConvertTo-Json -Depth 4 -Compress
    [Console]::Error.WriteLine($failure)
    exit 1
}

function Test-SubstringMatch {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyString()]
        [string]$Needle,

        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [string[]]$Values
    )

    if ([string]::IsNullOrEmpty($Needle)) {
        return $true
    }
    foreach ($value in $Values) {
        if (($null -ne $value) -and ($value.IndexOf($Needle, [System.StringComparison]::OrdinalIgnoreCase) -ge 0)) {
            return $true
        }
    }
    return $false
}

$application = $null
$namespace = $null
$defaultStore = $null
$defaultRoot = $null
$outputJson = $null
$errorJson = $null

try {
    $settings = Get-OutlookSettings
    $effectiveMaxResults = $settings.MaxSearchResults
    if ($MaxResults -gt 0) {
        $effectiveMaxResults = [math]::Min($MaxResults, $settings.MaxSearchResults)
    }

    $normalizedStartDate = $null
    $normalizedEndDate = $null
    if ($null -ne $StartDate) {
        $normalizedStartDate = ConvertTo-OutlookLocalDate -Value ([datetime]$StartDate)
    }
    if ($null -ne $EndDate) {
        $normalizedEndDate = ConvertTo-OutlookLocalDate -Value ([datetime]$EndDate)
    }
    if (($null -ne $normalizedStartDate) -and ($null -ne $normalizedEndDate) -and ($normalizedEndDate -lt $normalizedStartDate)) {
        throw 'EndDate must not be earlier than StartDate.'
    }

    $application = New-Object -ComObject 'Outlook.Application'
    $namespace = $application.GetNamespace('MAPI')
    $defaultStore = $namespace.DefaultStore
    $defaultRoot = $defaultStore.GetRootFolder()

    $matches = New-Object System.Collections.ArrayList
    $folderCoverage = New-Object System.Collections.ArrayList
    $totalScanned = 0

    foreach ($configuredFolder in $settings.Folders) {
        $folder = $null
        $items = $null
        try {
            try {
                $folder = Get-OutlookConfiguredFolder -Namespace $namespace -DefaultRoot $defaultRoot -FolderPath $configuredFolder
            }
            catch {
                throw "Unable to resolve configured Outlook folder '$configuredFolder': $($_.Exception.Message)"
            }

            $folderName = Get-OutlookStringProperty -ComObject $folder -PropertyName 'Name'
            $storeId = Get-OutlookStringProperty -ComObject $folder -PropertyName 'StoreID'
            if ([string]::IsNullOrWhiteSpace($storeId)) {
                throw "Outlook folder '$configuredFolder' did not provide a StoreID."
            }

            $normalizedFolderPath = $configuredFolder.Trim().Replace('/', '\').ToLowerInvariant()
            $isSentFolder = (($normalizedFolderPath -eq 'sent items') -or
                ($normalizedFolderPath -eq 'sent mail') -or
                $normalizedFolderPath.StartsWith('sent items\') -or
                $normalizedFolderPath.StartsWith('sent mail\'))
            if ($isSentFolder) {
                $sortProperty = '[SentOn]'
            }
            else {
                $sortProperty = '[ReceivedTime]'
            }

            $items = $folder.Items
            $items.Sort($sortProperty, $true)
            $totalItems = [int]$items.Count
            $itemsToScan = [math]::Min($totalItems, $settings.MaxItemsScannedPerFolder)
            $folderScanned = 0
            $folderMatched = 0

            for ($index = 1; $index -le $itemsToScan; $index++) {
                $item = $null
                $attachments = $null
                try {
                    $item = $items.Item($index)
                    $folderScanned++
                    $totalScanned++

                    $itemClass = Get-OutlookIntegerProperty -ComObject $item -PropertyName 'Class' -DefaultValue 0
                    if ($itemClass -ne 43) {
                        continue
                    }

                    $entryId = Get-OutlookStringProperty -ComObject $item -PropertyName 'EntryID'
                    if ([string]::IsNullOrWhiteSpace($entryId)) {
                        continue
                    }

                    $itemSubject = Get-OutlookStringProperty -ComObject $item -PropertyName 'Subject'
                    $senderName = Get-OutlookStringProperty -ComObject $item -PropertyName 'SenderName'
                    $senderAddress = Get-OutlookStringProperty -ComObject $item -PropertyName 'SenderEmailAddress'
                    $toRecipients = Get-OutlookStringProperty -ComObject $item -PropertyName 'To'
                    $ccRecipients = Get-OutlookStringProperty -ComObject $item -PropertyName 'CC'
                    $conversationTopic = Get-OutlookStringProperty -ComObject $item -PropertyName 'ConversationTopic'
                    $categories = Get-OutlookStringProperty -ComObject $item -PropertyName 'Categories'
                    $isUnread = Get-OutlookBooleanProperty -ComObject $item -PropertyName 'UnRead' -DefaultValue $false
                    $receivedTime = Get-OutlookDateProperty -ComObject $item -PropertyName 'ReceivedTime'
                    $sentTime = Get-OutlookDateProperty -ComObject $item -PropertyName 'SentOn'

                    if ($isSentFolder) {
                        $messageDate = $sentTime
                        if ($null -eq $messageDate) {
                            $messageDate = $receivedTime
                        }
                    }
                    else {
                        $messageDate = $receivedTime
                        if ($null -eq $messageDate) {
                            $messageDate = $sentTime
                        }
                    }

                    if (-not (Test-SubstringMatch -Needle $Sender -Values @($senderName, $senderAddress))) {
                        continue
                    }
                    if (-not (Test-SubstringMatch -Needle $Subject -Values @($itemSubject))) {
                        continue
                    }
                    if (-not (Test-SubstringMatch -Needle $Text -Values @(
                        $itemSubject,
                        $senderName,
                        $senderAddress,
                        $toRecipients,
                        $ccRecipients,
                        $conversationTopic,
                        $categories
                    ))) {
                        continue
                    }
                    if ($UnreadOnly.IsPresent -and (-not $isUnread)) {
                        continue
                    }
                    if (($null -ne $normalizedStartDate) -and (($null -eq $messageDate) -or ($messageDate -lt $normalizedStartDate))) {
                        continue
                    }
                    if (($null -ne $normalizedEndDate) -and (($null -eq $messageDate) -or ($messageDate -gt $normalizedEndDate))) {
                        continue
                    }

                    $attachmentCount = 0
                    try {
                        $attachments = $item.Attachments
                        $attachmentCount = [int]$attachments.Count
                    }
                    catch {
                        $attachmentCount = 0
                    }
                    finally {
                        Release-OutlookComObject -ComObject $attachments
                        $attachments = $null
                    }

                    $folderMatched++
                    $sortDate = [datetime]::MinValue
                    if ($null -ne $messageDate) {
                        $sortDate = $messageDate
                    }
                    $null = $matches.Add([pscustomobject]@{
                        SortDate = $sortDate
                        Result   = [pscustomobject]@{
                            EntryId           = $entryId
                            StoreId           = $storeId
                            Folder            = $configuredFolder
                            FolderName        = $folderName
                            Subject           = $itemSubject
                            SenderName        = $senderName
                            SenderEmailAddress = $senderAddress
                            To                = $toRecipients
                            Cc                = $ccRecipients
                            ConversationTopic = $conversationTopic
                            Categories        = $categories
                            ReceivedTime      = ConvertTo-OutlookIsoDate -Value $receivedTime
                            SentTime          = ConvertTo-OutlookIsoDate -Value $sentTime
                            Unread            = $isUnread
                            AttachmentCount   = $attachmentCount
                            Importance        = Get-OutlookIntegerProperty -ComObject $item -PropertyName 'Importance' -DefaultValue 1
                            Size              = Get-OutlookIntegerProperty -ComObject $item -PropertyName 'Size' -DefaultValue 0
                        }
                    })
                }
                finally {
                    Release-OutlookComObject -ComObject $attachments
                    Release-OutlookComObject -ComObject $item
                }
            }

            $null = $folderCoverage.Add([pscustomobject]@{
                Folder        = $configuredFolder
                FolderName    = $folderName
                TotalItems    = $totalItems
                Scanned       = $folderScanned
                Matched       = $folderMatched
                SortProperty  = $sortProperty.Trim('[', ']')
                ScanTruncated = ($totalItems -gt $itemsToScan)
            })
        }
        finally {
            Release-OutlookComObject -ComObject $items
            Release-OutlookComObject -ComObject $folder
        }
    }

    $sortedMatches = @($matches | Sort-Object -Property SortDate -Descending)
    $results = New-Object System.Collections.ArrayList
    $resultCount = [math]::Min($sortedMatches.Count, $effectiveMaxResults)
    for ($resultIndex = 0; $resultIndex -lt $resultCount; $resultIndex++) {
        $null = $results.Add($sortedMatches[$resultIndex].Result)
    }

    $scanTruncated = $false
    foreach ($coverage in $folderCoverage) {
        if ($coverage.ScanTruncated) {
            $scanTruncated = $true
            break
        }
    }

    $outputJson = [pscustomobject]@{
        Ok           = $true
        SettingsPath = $settings.SettingsPath
        Query        = [pscustomobject]@{
            Sender       = $Sender
            Subject      = $Subject
            Text         = $Text
            StartDate    = ConvertTo-OutlookIsoDate -Value $normalizedStartDate
            EndDate      = ConvertTo-OutlookIsoDate -Value $normalizedEndDate
            UnreadOnly   = $UnreadOnly.IsPresent
            MaxResults   = $effectiveMaxResults
            TextScope    = 'MetadataOnly'
        }
        Coverage     = [pscustomobject]@{
            Order                    = 'NewestFirst'
            MaxItemsScannedPerFolder = $settings.MaxItemsScannedPerFolder
            TotalItemsScanned        = $totalScanned
            TotalMatches             = $sortedMatches.Count
            Returned                 = $results.Count
            ScanTruncated            = $scanTruncated
            ResultsTruncated         = ($sortedMatches.Count -gt $effectiveMaxResults)
            Folders                  = @($folderCoverage)
        }
        Results      = @($results)
    } | ConvertTo-Json -Depth 8 -Compress
}
catch {
    $errorJson = ConvertTo-OutlookErrorJson -ErrorRecord $_ -ScriptName 'Search-OutlookMail.ps1'
}
finally {
    Release-OutlookComObject -ComObject $defaultRoot
    Release-OutlookComObject -ComObject $defaultStore
    Release-OutlookComObject -ComObject $namespace
    Release-OutlookComObject -ComObject $application
}

if ($null -ne $errorJson) {
    [Console]::Error.WriteLine($errorJson)
    exit 1
}
[Console]::Out.WriteLine($outputJson)

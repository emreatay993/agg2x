#requires -Version 5.1

<#
    Sends an existing Outlook draft. This is the only outbound path in the harness and it is
    deliberately narrow:
      - the item must live in the default Drafts folder and must not already be sent
      - phase 1 (no -ConfirmationToken) returns a full preview and mints a single-use token
      - the token is bound to the draft's identity, recipients, subject, and body hash, so any
        edit between preview and send invalidates it and nothing goes out
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$EntryId,

    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$StoreId,

    [Parameter()]
    [AllowEmptyString()]
    [string]$ConfirmationToken = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Outlook.Common.psm1'
try {
    Import-Module -Name $modulePath -Force -DisableNameChecking -ErrorAction Stop
}
catch {
    $failure = [pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = 'Send-OutlookDraft.ps1'
            Message = $_.Exception.Message
            Type    = $_.Exception.GetType().FullName
        }
    } | ConvertTo-Json -Depth 4 -Compress
    [Console]::Error.WriteLine($failure)
    exit 1
}

$application = $null
$namespace = $null
$draftsFolder = $null
$draft = $null
$draftRecipients = $null
$attachments = $null
$outputJson = $null
$errorJson = $null

try {
    $settings = Get-OutlookSettings
    Assert-OutlookWriteEnabled -Settings $settings -Operation 'send'
    if (-not $settings.Write.AllowSend) {
        throw "Sending is disabled. Set 'write.allowSend' to true in '$($settings.SettingsPath)' to allow it."
    }

    $application = New-Object -ComObject 'Outlook.Application'
    $namespace = $application.GetNamespace('MAPI')
    $draftsFolder = $namespace.GetDefaultFolder(16)
    $draftsEntryId = Get-OutlookStringProperty -ComObject $draftsFolder -PropertyName 'EntryID'

    $draft = $namespace.GetItemFromID($EntryId.Trim(), $StoreId.Trim())
    if ($null -eq $draft) {
        throw 'Outlook did not return an item for the supplied EntryId and StoreId.'
    }

    $itemClass = Get-OutlookIntegerProperty -ComObject $draft -PropertyName 'Class' -DefaultValue 0
    if ($itemClass -ne 43) {
        throw "The supplied identifiers refer to Outlook item class $itemClass, not a mail message."
    }
    if (Get-OutlookBooleanProperty -ComObject $draft -PropertyName 'Sent' -DefaultValue $true) {
        throw 'That message has already been sent. Only unsent drafts can be sent by this tool.'
    }

    $draftParent = $null
    $parentEntryId = ''
    try {
        $draftParent = $draft.Parent
        if ($null -ne $draftParent) {
            $parentEntryId = Get-OutlookStringProperty -ComObject $draftParent -PropertyName 'EntryID'
        }
    }
    finally {
        Release-OutlookComObject -ComObject $draftParent
    }
    if ([string]::IsNullOrWhiteSpace($parentEntryId) -or (-not $namespace.CompareEntryIDs($parentEntryId, $draftsEntryId))) {
        throw 'Only items in the default Drafts folder can be sent by this tool.'
    }

    $recipientDetails = New-Object System.Collections.ArrayList
    $unresolved = New-Object System.Collections.ArrayList
    $draftRecipients = $draft.Recipients
    for ($recipientIndex = 1; $recipientIndex -le [int]$draftRecipients.Count; $recipientIndex++) {
        $recipient = $null
        try {
            $recipient = $draftRecipients.Item($recipientIndex)
            $recipientName = Get-OutlookStringProperty -ComObject $recipient -PropertyName 'Name'
            $recipientAddress = Get-OutlookStringProperty -ComObject $recipient -PropertyName 'Address'
            $recipientType = Get-OutlookIntegerProperty -ComObject $recipient -PropertyName 'Type' -DefaultValue 1
            $isResolved = Get-OutlookBooleanProperty -ComObject $recipient -PropertyName 'Resolved' -DefaultValue $false
            if (-not $isResolved) { $null = $unresolved.Add($recipientName) }
            $typeName = switch ($recipientType) { 1 { 'To' } 2 { 'Cc' } 3 { 'Bcc' } default { "Type$recipientType" } }
            $null = $recipientDetails.Add([pscustomobject]@{
                Name     = $recipientName
                Address  = $recipientAddress
                Type     = $typeName
                Resolved = $isResolved
            })
        }
        finally {
            Release-OutlookComObject -ComObject $recipient
        }
    }

    if ($recipientDetails.Count -lt 1) {
        throw 'The draft has no recipients.'
    }
    if ($unresolved.Count -gt 0) {
        throw "The draft has unresolved recipients: $([string]::Join(', ', @($unresolved))). Fix them in Outlook before sending."
    }

    $attachmentNames = New-Object System.Collections.ArrayList
    $attachments = $draft.Attachments
    for ($attachmentIndex = 1; $attachmentIndex -le [int]$attachments.Count; $attachmentIndex++) {
        $attachment = $null
        try {
            $attachment = $attachments.Item($attachmentIndex)
            $attachmentName = Get-OutlookStringProperty -ComObject $attachment -PropertyName 'FileName'
            if ([string]::IsNullOrWhiteSpace($attachmentName)) {
                $attachmentName = Get-OutlookStringProperty -ComObject $attachment -PropertyName 'DisplayName'
            }
            $null = $attachmentNames.Add($attachmentName)
        }
        finally {
            Release-OutlookComObject -ComObject $attachment
        }
    }

    $draftSubject = Get-OutlookStringProperty -ComObject $draft -PropertyName 'Subject'
    $draftBody = Get-OutlookStringProperty -ComObject $draft -PropertyName 'Body'
    $bodyHash = Get-OutlookFingerprint -Parts @($draftBody)

    $recipientFingerprint = New-Object System.Collections.ArrayList
    foreach ($detail in @($recipientDetails | Sort-Object -Property Type, Address)) {
        $null = $recipientFingerprint.Add("$($detail.Type)|$($detail.Address)")
    }

    $fingerprintParts = New-Object System.Collections.ArrayList
    $null = $fingerprintParts.Add('send')
    $null = $fingerprintParts.Add((Get-OutlookStringProperty -ComObject $draft -PropertyName 'EntryID'))
    $null = $fingerprintParts.Add($draftSubject)
    $null = $fingerprintParts.Add($bodyHash)
    $null = $fingerprintParts.Add([string]::Join(',', @($attachmentNames)))
    foreach ($entry in $recipientFingerprint) { $null = $fingerprintParts.Add($entry) }
    $fingerprint = Get-OutlookFingerprint -Parts @($fingerprintParts)

    $bodyPreviewLength = [math]::Min($draftBody.Length, 4000)

    if ([string]::IsNullOrWhiteSpace($ConfirmationToken)) {
        $confirmation = New-OutlookConfirmation -Operation 'send' -Fingerprint $fingerprint -Settings $settings
        $outputJson = [pscustomobject]@{
            Ok                    = $true
            SettingsPath          = $settings.SettingsPath
            Operation             = 'send'
            Stage                 = 'PreviewOnly'
            RequiresConfirmation  = $true
            Sent                  = $false
            ConfirmationToken     = $confirmation.Token
            TokenExpiresUtc       = $confirmation.ExpiresUtc
            TokenExpiresInSeconds = $confirmation.ExpiresInSeconds
            Message               = 'Nothing was sent. Show the recipients, subject, and body to the user, get an explicit yes, then call again with the confirmation token. Editing the draft invalidates the token.'
            Preview               = [pscustomobject]@{
                EntryId                = (Get-OutlookStringProperty -ComObject $draft -PropertyName 'EntryID')
                StoreId                = $StoreId.Trim()
                Subject                = $draftSubject
                Recipients             = @($recipientDetails)
                AttachmentNames        = @($attachmentNames)
                BodyPreview            = $draftBody.Substring(0, $bodyPreviewLength)
                BodyCharactersTotal    = $draftBody.Length
                BodyTruncatedInPreview = ($draftBody.Length -gt $bodyPreviewLength)
            }
        } | ConvertTo-Json -Depth 8 -Compress
    }
    else {
        $null = Assert-OutlookConfirmation -Token $ConfirmationToken.Trim() -Operation 'send' -Fingerprint $fingerprint
        $draft.Send()
        $outputJson = [pscustomobject]@{
            Ok                   = $true
            SettingsPath         = $settings.SettingsPath
            Operation            = 'send'
            Stage                = 'Executed'
            RequiresConfirmation = $false
            Sent                 = $true
            Subject              = $draftSubject
            Recipients           = @($recipientDetails)
            AttachmentNames      = @($attachmentNames)
            Message              = 'The message was handed to Outlook for sending. Check the Outbox or Sent Items to confirm delivery.'
        } | ConvertTo-Json -Depth 8 -Compress
    }
}
catch {
    $errorJson = ConvertTo-OutlookErrorJson -ErrorRecord $_ -ScriptName 'Send-OutlookDraft.ps1'
}
finally {
    Release-OutlookComObject -ComObject $attachments
    Release-OutlookComObject -ComObject $draftRecipients
    Release-OutlookComObject -ComObject $draft
    Release-OutlookComObject -ComObject $draftsFolder
    Release-OutlookComObject -ComObject $namespace
    Release-OutlookComObject -ComObject $application
}

if ($null -ne $errorJson) {
    [Console]::Error.WriteLine($errorJson)
    exit 1
}
[Console]::Out.WriteLine($outputJson)

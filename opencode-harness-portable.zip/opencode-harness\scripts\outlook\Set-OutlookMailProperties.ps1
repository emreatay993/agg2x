#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [ValidateNotNullOrEmpty()]
    [string]$PlanPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Outlook.Common.psm1'
try {
    Import-Module -Name $modulePath -Force -DisableNameChecking -ErrorAction Stop
}
catch {
    $failure = [pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = 'Set-OutlookMailProperties.ps1'
            Message = $_.Exception.Message
            Type    = $_.Exception.GetType().FullName
        }
    } | ConvertTo-Json -Depth 4 -Compress
    [Console]::Error.WriteLine($failure)
    exit 1
}

$application = $null
$namespace = $null
$defaultStore = $null
$defaultRoot = $null
$outputJson = $null
$errorJson = $null

try {
    $settings = Get-OutlookSettings
    Assert-OutlookWriteEnabled -Settings $settings -Operation 'set-properties'

    if (-not (Test-Path -LiteralPath $PlanPath -PathType Leaf)) {
        throw "The plan file '$PlanPath' was not found."
    }
    $plan = Get-Content -LiteralPath $PlanPath -Raw -Encoding UTF8 | ConvertFrom-Json
    $targets = Get-OutlookMessagePlanTargets -Plan $plan -Settings $settings

    $readState = [string](Get-OutlookOptionalProperty -Source $plan -Name 'readState' -DefaultValue '')
    if (-not [string]::IsNullOrWhiteSpace($readState)) {
        $readState = $readState.Trim().ToLowerInvariant()
        if (@('read', 'unread') -notcontains $readState) {
            throw "Plan 'readState' must be 'read' or 'unread'."
        }
    }

    $importance = [string](Get-OutlookOptionalProperty -Source $plan -Name 'importance' -DefaultValue '')
    $importanceValue = -1
    if (-not [string]::IsNullOrWhiteSpace($importance)) {
        switch ($importance.Trim().ToLowerInvariant()) {
            'low' { $importanceValue = 0 }
            'normal' { $importanceValue = 1 }
            'high' { $importanceValue = 2 }
            default { throw "Plan 'importance' must be 'low', 'normal', or 'high'." }
        }
    }

    $flag = Get-OutlookOptionalProperty -Source $plan -Name 'flag' -DefaultValue $null
    $flagAction = ''
    $flagText = ''
    $flagDueDate = $null
    $flagInterval = 3
    if ($null -ne $flag) {
        $flagAction = ([string](Get-OutlookOptionalProperty -Source $flag -Name 'action' -DefaultValue '')).Trim().ToLowerInvariant()
        if (@('followup', 'complete', 'clear') -notcontains $flagAction) {
            throw "Plan 'flag.action' must be 'followup', 'complete', or 'clear'."
        }
        $flagText = ([string](Get-OutlookOptionalProperty -Source $flag -Name 'text' -DefaultValue 'Follow up')).Trim()
        if ([string]::IsNullOrWhiteSpace($flagText)) { $flagText = 'Follow up' }
        $dueDateText = [string](Get-OutlookOptionalProperty -Source $flag -Name 'dueDate' -DefaultValue '')
        if (-not [string]::IsNullOrWhiteSpace($dueDateText)) {
            $flagDueDate = ConvertTo-OutlookLocalDate -Value ([datetime]::Parse($dueDateText, [System.Globalization.CultureInfo]::InvariantCulture))
        }
        $intervalText = ([string](Get-OutlookOptionalProperty -Source $flag -Name 'interval' -DefaultValue 'thisweek')).Trim().ToLowerInvariant()
        switch ($intervalText) {
            'nodate' { $flagInterval = 0 }
            'today' { $flagInterval = 1 }
            'tomorrow' { $flagInterval = 2 }
            'thisweek' { $flagInterval = 3 }
            'nextweek' { $flagInterval = 4 }
            default { throw "Plan 'flag.interval' must be 'nodate', 'today', 'tomorrow', 'thisweek', or 'nextweek'." }
        }
    }

    $categories = Get-OutlookOptionalProperty -Source $plan -Name 'categories' -DefaultValue $null
    $categoryMode = ''
    $categoryNames = @()
    $createMissingCategories = $true
    if ($null -ne $categories) {
        $categoryMode = ([string](Get-OutlookOptionalProperty -Source $categories -Name 'mode' -DefaultValue '')).Trim().ToLowerInvariant()
        if (@('add', 'remove', 'set', 'clear') -notcontains $categoryMode) {
            throw "Plan 'categories.mode' must be 'add', 'remove', 'set', or 'clear'."
        }
        $requestedNames = New-Object System.Collections.ArrayList
        foreach ($name in @(Get-OutlookOptionalProperty -Source $categories -Name 'names' -DefaultValue @())) {
            $categoryName = ([string]$name).Trim()
            if ([string]::IsNullOrWhiteSpace($categoryName)) { continue }
            if ($categoryName.Contains(';')) {
                throw "Category '$categoryName' must not contain a semicolon."
            }
            $null = $requestedNames.Add($categoryName)
        }
        $categoryNames = @($requestedNames)
        if (($categoryMode -ne 'clear') -and ($categoryNames.Count -lt 1)) {
            throw "Plan 'categories.names' must list at least one category for mode '$categoryMode'."
        }
        $createMissingCategories = [bool](Get-OutlookOptionalProperty -Source $categories -Name 'createMissing' -DefaultValue $true)
    }

    if ([string]::IsNullOrWhiteSpace($readState) -and ($importanceValue -lt 0) -and
        [string]::IsNullOrWhiteSpace($flagAction) -and [string]::IsNullOrWhiteSpace($categoryMode)) {
        throw 'The plan requested no change. Supply at least one of readState, flag, categories, or importance.'
    }

    $application = New-Object -ComObject 'Outlook.Application'
    $namespace = $application.GetNamespace('MAPI')
    $defaultStore = $namespace.DefaultStore
    $defaultRoot = $defaultStore.GetRootFolder()

    $createdCategories = New-Object System.Collections.ArrayList
    if (($categoryNames.Count -gt 0) -and ($categoryMode -ne 'remove') -and $createMissingCategories) {
        $masterCategories = $null
        try {
            $masterCategories = $namespace.Categories
            foreach ($categoryName in $categoryNames) {
                $exists = $false
                for ($categoryIndex = 1; $categoryIndex -le [int]$masterCategories.Count; $categoryIndex++) {
                    $masterCategory = $null
                    try {
                        $masterCategory = $masterCategories.Item($categoryIndex)
                        $masterName = Get-OutlookStringProperty -ComObject $masterCategory -PropertyName 'Name'
                        if ($masterName.Equals($categoryName, [StringComparison]::OrdinalIgnoreCase)) { $exists = $true; break }
                    }
                    finally {
                        Release-OutlookComObject -ComObject $masterCategory
                    }
                }
                if (-not $exists) {
                    $null = $masterCategories.Add($categoryName)
                    $null = $createdCategories.Add($categoryName)
                }
            }
        }
        finally {
            Release-OutlookComObject -ComObject $masterCategories
        }
    }

    $results = New-Object System.Collections.ArrayList
    $changedCount = 0
    $failedCount = 0

    foreach ($target in $targets) {
        $resolved = $null
        $item = $null
        try {
            $resolved = Resolve-OutlookScopedMailItem -Namespace $namespace -DefaultRoot $defaultRoot `
                -ScopeFolders $settings.WriteScopeFolders -EntryId $target.EntryId -StoreId $target.StoreId
            $item = $resolved.Item
            $applied = New-Object System.Collections.ArrayList

            if (-not [string]::IsNullOrWhiteSpace($readState)) {
                $item.UnRead = ($readState -eq 'unread')
                $null = $applied.Add("readState=$readState")
            }

            if ($importanceValue -ge 0) {
                $item.Importance = $importanceValue
                $null = $applied.Add("importance=$($importance.Trim().ToLowerInvariant())")
            }

            if (-not [string]::IsNullOrWhiteSpace($flagAction)) {
                switch ($flagAction) {
                    'followup' {
                        $item.MarkAsTask($flagInterval)
                        $item.FlagRequest = $flagText
                        if ($null -ne $flagDueDate) {
                            $item.TaskDueDate = $flagDueDate
                            $item.TaskStartDate = $flagDueDate
                        }
                        $null = $applied.Add("flag=followup")
                    }
                    'complete' {
                        $item.MarkAsTask(0)
                        $item.TaskCompletedDate = (Get-Date)
                        $item.FlagStatus = 1
                        $null = $applied.Add('flag=complete')
                    }
                    'clear' {
                        $item.ClearTaskFlag()
                        $null = $applied.Add('flag=clear')
                    }
                }
            }

            if (-not [string]::IsNullOrWhiteSpace($categoryMode)) {
                $currentText = Get-OutlookStringProperty -ComObject $item -PropertyName 'Categories'
                $currentList = New-Object System.Collections.ArrayList
                foreach ($piece in @($currentText -split ';')) {
                    $trimmed = ([string]$piece).Trim()
                    if (-not [string]::IsNullOrWhiteSpace($trimmed)) { $null = $currentList.Add($trimmed) }
                }

                $nextList = New-Object System.Collections.ArrayList
                switch ($categoryMode) {
                    'clear' { }
                    'set' {
                        foreach ($categoryName in $categoryNames) { $null = $nextList.Add($categoryName) }
                    }
                    'add' {
                        foreach ($existing in $currentList) { $null = $nextList.Add($existing) }
                        foreach ($categoryName in $categoryNames) {
                            $present = $false
                            foreach ($existing in $nextList) {
                                if ($existing.Equals($categoryName, [StringComparison]::OrdinalIgnoreCase)) { $present = $true; break }
                            }
                            if (-not $present) { $null = $nextList.Add($categoryName) }
                        }
                    }
                    'remove' {
                        foreach ($existing in $currentList) {
                            $removed = $false
                            foreach ($categoryName in $categoryNames) {
                                if ($existing.Equals($categoryName, [StringComparison]::OrdinalIgnoreCase)) { $removed = $true; break }
                            }
                            if (-not $removed) { $null = $nextList.Add($existing) }
                        }
                    }
                }
                $item.Categories = [string]::Join('; ', @($nextList))
                $null = $applied.Add("categories=$categoryMode")
            }

            $item.Save()
            $changedCount++
            $null = $results.Add([pscustomobject]@{
                EntryId          = $resolved.EntryId
                StoreId          = $target.StoreId
                ConfiguredFolder = $resolved.ConfiguredFolder
                Subject          = $resolved.Subject
                SenderName       = $resolved.SenderName
                ReceivedTime     = $resolved.ReceivedTime
                Ok               = $true
                Applied          = @($applied)
                Categories       = (Get-OutlookStringProperty -ComObject $item -PropertyName 'Categories')
                Unread           = (Get-OutlookBooleanProperty -ComObject $item -PropertyName 'UnRead' -DefaultValue $false)
                Error            = $null
            })
        }
        catch {
            $failedCount++
            $null = $results.Add([pscustomobject]@{
                EntryId          = $target.EntryId
                StoreId          = $target.StoreId
                ConfiguredFolder = $null
                Subject          = $null
                SenderName       = $null
                ReceivedTime     = $null
                Ok               = $false
                Applied          = @()
                Categories       = $null
                Unread           = $null
                Error            = $_.Exception.Message
            })
        }
        finally {
            if ($null -ne $resolved) { Release-OutlookComObject -ComObject $resolved.Item }
        }
    }

    $outputJson = [pscustomobject]@{
        Ok                = ($failedCount -eq 0)
        SettingsPath      = $settings.SettingsPath
        Operation         = 'set-properties'
        Requested         = $targets.Count
        Changed           = $changedCount
        Failed            = $failedCount
        CreatedCategories = @($createdCategories)
        Results           = @($results)
    } | ConvertTo-Json -Depth 8 -Compress
}
catch {
    $errorJson = ConvertTo-OutlookErrorJson -ErrorRecord $_ -ScriptName 'Set-OutlookMailProperties.ps1'
}
finally {
    Release-OutlookComObject -ComObject $defaultRoot
    Release-OutlookComObject -ComObject $defaultStore
    Release-OutlookComObject -ComObject $namespace
    Release-OutlookComObject -ComObject $application
}

if ($null -ne $errorJson) {
    [Console]::Error.WriteLine($errorJson)
    exit 1
}
[Console]::Out.WriteLine($outputJson)

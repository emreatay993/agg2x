#requires -Version 5.1

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$modulePath = Join-Path -Path $PSScriptRoot -ChildPath 'Outlook.Common.psm1'
try {
    Import-Module -Name $modulePath -Force -DisableNameChecking -ErrorAction Stop
}
catch {
    $failure = [pscustomobject]@{
        Ok    = $false
        Error = [pscustomobject]@{
            Script  = 'Test-OutlookConnection.ps1'
            Message = $_.Exception.Message
            Type    = $_.Exception.GetType().FullName
        }
    } | ConvertTo-Json -Depth 4 -Compress
    [Console]::Error.WriteLine($failure)
    exit 1
}

function Get-OutlookFolderTreeCount {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Folder
    )

    $count = 1
    $folders = $null
    try {
        $folders = $Folder.Folders
        $childCount = [int]$folders.Count
        for ($index = 1; $index -le $childCount; $index++) {
            $child = $null
            try {
                $child = $folders.Item($index)
                $count += Get-OutlookFolderTreeCount -Folder $child
            }
            finally {
                Release-OutlookComObject -ComObject $child
            }
        }
    }
    finally {
        Release-OutlookComObject -ComObject $folders
    }
    return $count
}

$application = $null
$namespace = $null
$stores = $null
$mapiRoots = $null
$defaultStore = $null
$defaultRoot = $null
$defaultRootFolders = $null
$outputJson = $null
$errorJson = $null

try {
    $application = New-Object -ComObject 'Outlook.Application'
    $namespace = $application.GetNamespace('MAPI')

    $stores = $namespace.Stores
    $storeCount = [int]$stores.Count
    Release-OutlookComObject -ComObject $stores
    $stores = $null

    $mapiRoots = $namespace.Folders
    $mapiRootCount = [int]$mapiRoots.Count
    Release-OutlookComObject -ComObject $mapiRoots
    $mapiRoots = $null

    $defaultStore = $namespace.DefaultStore
    $defaultRoot = $defaultStore.GetRootFolder()
    $defaultRootFolders = $defaultRoot.Folders
    $defaultStoreTopLevelFolderCount = [int]$defaultRootFolders.Count
    Release-OutlookComObject -ComObject $defaultRootFolders
    $defaultRootFolders = $null

    $defaultStoreFolderCount = Get-OutlookFolderTreeCount -Folder $defaultRoot
    $outputJson = [pscustomobject]@{
        Ok             = $true
        ReadOnly       = $true
        OutlookVersion = Get-OutlookStringProperty -ComObject $application -PropertyName 'Version'
        ProfileName    = Get-OutlookStringProperty -ComObject $namespace -PropertyName 'CurrentProfileName'
        DefaultStore   = [pscustomobject]@{
            DisplayName    = Get-OutlookStringProperty -ComObject $defaultStore -PropertyName 'DisplayName'
            StoreId        = Get-OutlookStringProperty -ComObject $defaultStore -PropertyName 'StoreID'
            RootFolderName = Get-OutlookStringProperty -ComObject $defaultRoot -PropertyName 'Name'
        }
        Counts         = [pscustomobject]@{
            Stores                      = $storeCount
            MapiRootFolders             = $mapiRootCount
            DefaultStoreTopLevelFolders = $defaultStoreTopLevelFolderCount
            DefaultStoreFolders         = $defaultStoreFolderCount
        }
    } | ConvertTo-Json -Depth 6 -Compress
}
catch {
    $errorJson = ConvertTo-OutlookErrorJson -ErrorRecord $_ -ScriptName 'Test-OutlookConnection.ps1'
}
finally {
    Release-OutlookComObject -ComObject $defaultRootFolders
    Release-OutlookComObject -ComObject $defaultRoot
    Release-OutlookComObject -ComObject $defaultStore
    Release-OutlookComObject -ComObject $mapiRoots
    Release-OutlookComObject -ComObject $stores
    Release-OutlookComObject -ComObject $namespace
    Release-OutlookComObject -ComObject $application
}

if ($null -ne $errorJson) {
    [Console]::Error.WriteLine($errorJson)
    exit 1
}
[Console]::Out.WriteLine($outputJson)

<#
.SYNOPSIS
Applies a JSON edit plan to a read-only presentation and writes a copy with SaveCopyAs.

.DESCRIPTION
Each operation requires slideIndex. Shape operations also require one of shapeId,
shapeName, or shapeIndex. Supported operations and values are:
replace_text (find, replace), set_text (text), set_notes (text), move_resize
(left, top, width, height), and replace_image (imagePath). Existing outputs require
the plan-level JSON property "allowOverwrite": true.
#>
[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourcePath,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath,

    [Parameter(Mandatory = $true)]
    [string]$PlanPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path -Path $PSScriptRoot -ChildPath 'PowerPoint.Common.ps1')

function Get-PlanValue {
    param(
        [Parameter(Mandatory = $true)]
        [object]$InputObject,

        [Parameter(Mandatory = $true)]
        [string[]]$Names,

        [switch]$Required,

        [string]$Description = 'value'
    )

    foreach ($name in $Names) {
        $property = $InputObject.PSObject.Properties[$name]
        if ($null -ne $property) {
            return $property.Value
        }
    }

    if ($Required) {
        throw "The plan operation is missing $Description. Accepted properties: $($Names -join ', ')."
    }

    return $null
}

function ConvertTo-PositivePlanInteger {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Value,

        [Parameter(Mandatory = $true)]
        [string]$Description
    )

    $parsed = 0
    if (-not [int]::TryParse([string]$Value, [ref]$parsed) -or $parsed -le 0) {
        throw "$Description must be a positive integer."
    }

    return $parsed
}

function ConvertTo-FinitePlanDouble {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Value,

        [Parameter(Mandatory = $true)]
        [string]$Description
    )

    try {
        $parsed = [Convert]::ToDouble($Value, [Globalization.CultureInfo]::InvariantCulture)
    }
    catch {
        throw "$Description must be a finite number."
    }

    if ([double]::IsNaN($parsed) -or [double]::IsInfinity($parsed)) {
        throw "$Description must be a finite number."
    }

    return $parsed
}

function Get-PowerPointOperationSlide {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slides,

        [Parameter(Mandatory = $true)]
        [object]$Operation
    )

    $slideValue = Get-PlanValue -InputObject $Operation -Names @('slideIndex', 'slide_index', 'slide') -Required -Description 'slideIndex'
    $slideIndex = ConvertTo-PositivePlanInteger -Value $slideValue -Description 'slideIndex'
    if ($slideIndex -gt [int]$Slides.Count) {
        throw "slideIndex $slideIndex is outside the presentation's slide range."
    }

    return $Slides.Item($slideIndex)
}

function Get-PowerPointOperationShape {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Operation
    )

    $target = Get-PlanValue -InputObject $Operation -Names @('target')
    if ($null -eq $target) { $target = $Operation }

    $shapeIdValue = Get-PlanValue -InputObject $target -Names @('shapeId', 'shape_id')
    $shapeNameValue = Get-PlanValue -InputObject $target -Names @('shapeName', 'shape_name')
    $shapeIndexValue = Get-PlanValue -InputObject $target -Names @('shapeIndex', 'shape_index')
    if ($null -eq $shapeIdValue -and $null -eq $shapeNameValue -and $null -eq $shapeIndexValue) {
        throw 'A shape operation requires shapeId, shapeName, or shapeIndex.'
    }

    $shapes = $null
    $resultShape = $null
    $selector = ''
    try {
        $shapes = $Slide.Shapes
        if ($null -ne $shapeIdValue) {
            $shapeId = ConvertTo-PositivePlanInteger -Value $shapeIdValue -Description 'shapeId'
            $selector = "shapeId:$shapeId"
            for ($index = 1; $index -le [int]$shapes.Count; $index++) {
                $candidate = $null
                try {
                    $candidate = $shapes.Item($index)
                    if ([int]$candidate.Id -eq $shapeId) {
                        $resultShape = $candidate
                        $candidate = $null
                        break
                    }
                }
                finally {
                    Release-OfficeFileComObject -ComObject $candidate
                }
            }
        }
        elseif ($null -ne $shapeNameValue) {
            $shapeName = [string]$shapeNameValue
            if ([string]::IsNullOrWhiteSpace($shapeName)) {
                throw 'shapeName cannot be empty.'
            }
            $selector = "shapeName:$shapeName"
            try {
                $resultShape = $shapes.Item($shapeName)
            }
            catch {
                $resultShape = $null
            }
        }
        else {
            $shapeIndex = ConvertTo-PositivePlanInteger -Value $shapeIndexValue -Description 'shapeIndex'
            $selector = "shapeIndex:$shapeIndex"
            if ($shapeIndex -le [int]$shapes.Count) {
                $resultShape = $shapes.Item($shapeIndex)
            }
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $shapes
    }

    if ($null -eq $resultShape) {
        throw "No top-level shape matched $selector on slide $([int]$Slide.SlideIndex)."
    }

    return [pscustomobject][ordered]@{
        Shape    = $resultShape
        Selector = $selector
    }
}

function Invoke-ReplaceTextOperation {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Operation
    )

    $findValue = Get-PlanValue -InputObject $Operation -Names @('find', 'oldText', 'old_text', 'search') -Required -Description 'find text'
    $replaceValue = Get-PlanValue -InputObject $Operation -Names @('replace', 'newText', 'new_text', 'replacement') -Required -Description 'replacement text'
    $findText = [string]$findValue
    $replaceText = [string]$replaceValue
    if ($findText.Length -eq 0) { throw 'replace_text find text cannot be empty.' }

    $target = Get-PowerPointOperationShape -Slide $Slide -Operation $Operation
    $shape = $target.Shape
    $textFrame = $null
    $textRange = $null
    try {
        if ([int]$shape.HasTextFrame -ne -1) {
            throw "The selected shape '$([string]$shape.Name)' has no text frame."
        }

        $textFrame = $shape.TextFrame
        $textRange = $textFrame.TextRange
        $oldText = [string]$textRange.Text
        $occurrences = 0
        $offset = 0
        while ($offset -le $oldText.Length - $findText.Length) {
            $foundAt = $oldText.IndexOf($findText, $offset, [StringComparison]::Ordinal)
            if ($foundAt -lt 0) { break }
            $occurrences++
            $offset = $foundAt + $findText.Length
        }
        if ($occurrences -eq 0) {
            throw "The find text was not present in shape '$([string]$shape.Name)'."
        }

        $newText = $oldText.Replace($findText, $replaceText)
        $textRange.Text = $newText
        return [pscustomobject][ordered]@{
            selector      = $target.Selector
            shapeId       = [int]$shape.Id
            shapeName     = [string]$shape.Name
            replacements  = $occurrences
            oldTextLength = $oldText.Length
            newTextLength = $newText.Length
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $textRange
        Release-OfficeFileComObject -ComObject $textFrame
        Release-OfficeFileComObject -ComObject $shape
    }
}

function Invoke-SetTextOperation {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Operation
    )

    $textValue = Get-PlanValue -InputObject $Operation -Names @('text') -Required -Description 'text'
    if ($null -eq $textValue) { throw 'set_text text cannot be null.' }
    $newText = [string]$textValue
    $target = Get-PowerPointOperationShape -Slide $Slide -Operation $Operation
    $shape = $target.Shape
    $textFrame = $null
    $textRange = $null
    try {
        if ([int]$shape.HasTextFrame -ne -1) {
            throw "The selected shape '$([string]$shape.Name)' has no text frame."
        }

        $textFrame = $shape.TextFrame
        $textRange = $textFrame.TextRange
        $oldText = [string]$textRange.Text
        $textRange.Text = $newText
        return [pscustomobject][ordered]@{
            selector      = $target.Selector
            shapeId       = [int]$shape.Id
            shapeName     = [string]$shape.Name
            oldTextLength = $oldText.Length
            newTextLength = $newText.Length
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $textRange
        Release-OfficeFileComObject -ComObject $textFrame
        Release-OfficeFileComObject -ComObject $shape
    }
}

function Invoke-SetNotesOperation {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Operation
    )

    $textValue = Get-PlanValue -InputObject $Operation -Names @('text', 'notes') -Required -Description 'notes text'
    if ($null -eq $textValue) { throw 'set_notes text cannot be null.' }
    $newText = [string]$textValue
    $notesPage = $null
    $shapes = $null
    $bodyShape = $null
    $textFrame = $null
    $textRange = $null
    try {
        $notesPage = $Slide.NotesPage
        $shapes = $notesPage.Shapes
        for ($index = 1; $index -le [int]$shapes.Count; $index++) {
            $candidate = $null
            $placeholderFormat = $null
            try {
                $candidate = $shapes.Item($index)
                if ([int]$candidate.Type -eq 14) {
                    $placeholderFormat = $candidate.PlaceholderFormat
                    if ([int]$placeholderFormat.Type -eq 2) {
                        $bodyShape = $candidate
                        $candidate = $null
                        break
                    }
                }
            }
            finally {
                Release-OfficeFileComObject -ComObject $placeholderFormat
                Release-OfficeFileComObject -ComObject $candidate
            }
        }

        if ($null -eq $bodyShape) {
            throw "Slide $([int]$Slide.SlideIndex) has no notes body placeholder."
        }

        $textFrame = $bodyShape.TextFrame
        $textRange = $textFrame.TextRange
        $oldText = [string]$textRange.Text
        $textRange.Text = $newText
        return [pscustomobject][ordered]@{
            oldTextLength = $oldText.Length
            newTextLength = $newText.Length
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $textRange
        Release-OfficeFileComObject -ComObject $textFrame
        Release-OfficeFileComObject -ComObject $bodyShape
        Release-OfficeFileComObject -ComObject $shapes
        Release-OfficeFileComObject -ComObject $notesPage
    }
}

function Invoke-MoveResizeOperation {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Operation
    )

    $leftValue = Get-PlanValue -InputObject $Operation -Names @('left')
    $topValue = Get-PlanValue -InputObject $Operation -Names @('top')
    $widthValue = Get-PlanValue -InputObject $Operation -Names @('width')
    $heightValue = Get-PlanValue -InputObject $Operation -Names @('height')
    if ($null -eq $leftValue -and $null -eq $topValue -and $null -eq $widthValue -and $null -eq $heightValue) {
        throw 'move_resize requires at least one of left, top, width, or height.'
    }

    $target = Get-PowerPointOperationShape -Slide $Slide -Operation $Operation
    $shape = $target.Shape
    try {
        $before = [pscustomobject][ordered]@{
            left   = [double]$shape.Left
            top    = [double]$shape.Top
            width  = [double]$shape.Width
            height = [double]$shape.Height
        }

        $restoreAspectRatio = $false
        $originalAspectRatio = 0
        if ($null -ne $widthValue -or $null -ne $heightValue) {
            $originalAspectRatio = [int]$shape.LockAspectRatio
            $shape.LockAspectRatio = 0
            $restoreAspectRatio = $true
        }

        try {
            if ($null -ne $widthValue) {
                $width = ConvertTo-FinitePlanDouble -Value $widthValue -Description 'width'
                if ($width -le 0) { throw 'width must be greater than zero.' }
                $shape.Width = $width
            }
            if ($null -ne $heightValue) {
                $height = ConvertTo-FinitePlanDouble -Value $heightValue -Description 'height'
                if ($height -le 0) { throw 'height must be greater than zero.' }
                $shape.Height = $height
            }
            if ($null -ne $leftValue) {
                $shape.Left = ConvertTo-FinitePlanDouble -Value $leftValue -Description 'left'
            }
            if ($null -ne $topValue) {
                $shape.Top = ConvertTo-FinitePlanDouble -Value $topValue -Description 'top'
            }
        }
        finally {
            if ($restoreAspectRatio) { $shape.LockAspectRatio = $originalAspectRatio }
        }

        $after = [pscustomobject][ordered]@{
            left   = [double]$shape.Left
            top    = [double]$shape.Top
            width  = [double]$shape.Width
            height = [double]$shape.Height
        }
        return [pscustomobject][ordered]@{
            selector  = $target.Selector
            shapeId   = [int]$shape.Id
            shapeName = [string]$shape.Name
            before    = $before
            after     = $after
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $shape
    }
}

function Invoke-ReplaceImageOperation {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Operation,

        [Parameter(Mandatory = $true)]
        [string]$PlanDirectory,

        [Parameter(Mandatory = $true)]
        [object]$Settings
    )

    $imageValue = Get-PlanValue -InputObject $Operation -Names @('imagePath', 'image_path', 'path') -Required -Description 'imagePath'
    $imagePath = [Environment]::ExpandEnvironmentVariables([string]$imageValue)
    if (-not [IO.Path]::IsPathRooted($imagePath)) {
        $imagePath = Join-Path -Path $PlanDirectory -ChildPath $imagePath
    }
    $imagePath = Resolve-OfficeFileExistingFile -Path $imagePath -Description 'Replacement image'
    Assert-OfficeFileInputAllowed -Path $imagePath -Settings $Settings -Description 'Replacement image' -ToolName 'PowerPoint'

    $target = Get-PowerPointOperationShape -Slide $Slide -Operation $Operation
    $shape = $target.Shape
    $shapes = $null
    $newShape = $null
    try {
        $shapeType = [int]$shape.Type
        if ($shapeType -ne 11 -and $shapeType -ne 13) {
            throw "replace_image requires a top-level picture or linked picture shape; '$([string]$shape.Name)' has type $shapeType."
        }

        $left = [double]$shape.Left
        $top = [double]$shape.Top
        $width = [double]$shape.Width
        $height = [double]$shape.Height
        $rotation = [double]$shape.Rotation
        $zOrderPosition = [int]$shape.ZOrderPosition
        $oldShapeId = [int]$shape.Id
        $name = [string]$shape.Name
        $alternativeText = ''
        $title = ''
        try { $alternativeText = [string]$shape.AlternativeText } catch {}
        try { $title = [string]$shape.Title } catch {}

        $shape.Delete()
        $shapes = $Slide.Shapes
        $newShape = $shapes.AddPicture($imagePath, 0, -1, $left, $top, $width, $height)
        $newShape.Rotation = $rotation
        try { $newShape.Name = $name } catch {}
        try { $newShape.AlternativeText = $alternativeText } catch {}
        try { $newShape.Title = $title } catch {}
        while ([int]$newShape.ZOrderPosition -gt $zOrderPosition) {
            $newShape.ZOrder(3)
        }

        return [pscustomobject][ordered]@{
            selector     = $target.Selector
            oldShapeId   = $oldShapeId
            newShapeId   = [int]$newShape.Id
            shapeName    = [string]$newShape.Name
            imagePath    = $imagePath
            imageSha256  = Get-OfficeFileSha256 -Path $imagePath
            bounds       = [pscustomobject][ordered]@{
                left = $left; top = $top; width = $width; height = $height; rotation = $rotation
            }
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $newShape
        Release-OfficeFileComObject -ComObject $shapes
        Release-OfficeFileComObject -ComObject $shape
    }
}

$application = $null
$presentation = $null
$presentations = $null
$slides = $null
$sourceFullPath = $null
$outputFullPath = $null
$planFullPath = $null
$sourceHashBefore = $null
$sourceHashAfter = $null
$operationResults = @()
$outputExistedInitially = $false
$allowOverwrite = $false
$backupPath = $null
$backupCreated = $false
$saveAttempted = $false
$outputWritten = $false

try {
    $settings = Get-PowerPointSettings
    $sourceFullPath = Resolve-OfficeFileExistingFile -Path $SourcePath -Description 'Source presentation'
    $planFullPath = Resolve-OfficeFileExistingFile -Path $PlanPath -Description 'Edit plan'
    $outputFullPath = Resolve-OfficeFileOutputFile -Path $OutputPath
    Assert-PowerPointPresentationExtension -Path $sourceFullPath
    Assert-OfficeFileInputAllowed -Path $sourceFullPath -Settings $settings -Description 'Source presentation' -ToolName 'PowerPoint'
    # The harness writes edit plans to its machine-local state, which is intentionally
    # separate from the approved presentation roots.
    Assert-OfficeFileOutputAllowed -OutputPath $outputFullPath -SourcePath $sourceFullPath -Settings $settings -ToolName 'PowerPoint'

    if ($sourceFullPath.Equals($outputFullPath, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'SourcePath and OutputPath must resolve to distinct full paths.'
    }
    $sourceExtension = [IO.Path]::GetExtension($sourceFullPath)
    $outputExtension = [IO.Path]::GetExtension($outputFullPath)
    if (-not $sourceExtension.Equals($outputExtension, [StringComparison]::OrdinalIgnoreCase)) {
        throw "OutputPath must preserve the source extension '$sourceExtension'."
    }

    try {
        $plan = [IO.File]::ReadAllText($planFullPath) | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "Could not parse edit plan '$planFullPath': $($_.Exception.Message)"
    }

    $allowOverwriteValue = Get-PlanValue -InputObject $plan -Names @('allowOverwrite', 'allow_overwrite')
    if ($null -ne $allowOverwriteValue) {
        if ($allowOverwriteValue -isnot [bool]) {
            throw 'Plan allowOverwrite must be a JSON boolean.'
        }
        $allowOverwrite = [bool]$allowOverwriteValue
    }

    $operationsProperty = $plan.PSObject.Properties['operations']
    if ($null -eq $operationsProperty -or $null -eq $operationsProperty.Value) {
        throw 'The edit plan must contain an operations array.'
    }
    $operations = @($operationsProperty.Value)
    $outputExistedInitially = Test-Path -LiteralPath $outputFullPath -PathType Leaf
    if ($outputExistedInitially -and -not $allowOverwrite) {
        throw "OutputPath already exists and the plan does not explicitly set allowOverwrite to true: '$outputFullPath'."
    }
    if (Test-Path -LiteralPath $outputFullPath -PathType Container) {
        throw "OutputPath refers to a folder, not a file: '$outputFullPath'."
    }

    $sourceHashBefore = Get-OfficeFileSha256 -Path $sourceFullPath
    $planHash = Get-OfficeFileSha256 -Path $planFullPath
    $powerPointVersion = ''

    try {
        $application = New-Object -ComObject PowerPoint.Application
        $application.AutomationSecurity = 3
        if ([int]$application.AutomationSecurity -ne 3) { throw 'PowerPoint macro automation could not be disabled.' }
        try { $application.DisplayAlerts = 1 } catch {}
        $powerPointVersion = [string]$application.Version

        $presentations = $application.Presentations
        $presentation = $presentations.Open($sourceFullPath, -1, 0, 0)
        Release-OfficeFileComObject -ComObject $presentations
        $presentations = $null
        $slides = $presentation.Slides

        for ($operationIndex = 0; $operationIndex -lt $operations.Count; $operationIndex++) {
            $operation = $operations[$operationIndex]
            if ($null -eq $operation) { throw "Plan operation $($operationIndex + 1) is null." }
            $operationNameValue = Get-PlanValue -InputObject $operation -Names @('operation', 'type', 'op') -Required -Description 'operation name'
            $operationName = ([string]$operationNameValue).ToLowerInvariant()
            $slide = $null
            try {
                $slide = Get-PowerPointOperationSlide -Slides $slides -Operation $operation
                switch ($operationName) {
                    'replace_text' { $details = Invoke-ReplaceTextOperation -Slide $slide -Operation $operation }
                    'set_text' { $details = Invoke-SetTextOperation -Slide $slide -Operation $operation }
                    'set_notes' { $details = Invoke-SetNotesOperation -Slide $slide -Operation $operation }
                    'move_resize' { $details = Invoke-MoveResizeOperation -Slide $slide -Operation $operation }
                    'replace_image' {
                        $details = Invoke-ReplaceImageOperation -Slide $slide -Operation $operation -PlanDirectory ([IO.Path]::GetDirectoryName($planFullPath)) -Settings $settings
                    }
                    default { throw "Unsupported operation '$operationName'." }
                }

                $operationResults += [pscustomobject][ordered]@{
                    index      = $operationIndex + 1
                    operation  = $operationName
                    slideIndex = [int]$slide.SlideIndex
                    status     = 'applied'
                    details    = $details
                }
            }
            catch {
                $operationResults += [pscustomobject][ordered]@{
                    index      = $operationIndex + 1
                    operation  = $operationName
                    status     = 'failed'
                    error      = $_.Exception.Message
                }
                throw "Plan operation $($operationIndex + 1) ('$operationName') failed: $($_.Exception.Message)"
            }
            finally {
                Release-OfficeFileComObject -ComObject $slide
            }
        }

        $outputExistsBeforeSave = Test-Path -LiteralPath $outputFullPath -PathType Leaf
        if ($outputExistsBeforeSave) {
            if (-not $allowOverwrite) {
                throw "OutputPath appeared before SaveCopyAs and overwrite is not allowed: '$outputFullPath'."
            }
            $backupName = ([IO.Path]::GetFileName($outputFullPath)) + '.opencode-backup-' + [Guid]::NewGuid().ToString('N')
            $backupPath = Join-Path -Path ([IO.Path]::GetDirectoryName($outputFullPath)) -ChildPath $backupName
            [IO.File]::Move($outputFullPath, $backupPath)
            $backupCreated = $true
        }
        elseif ($outputExistedInitially) {
            $outputExistedInitially = $false
        }

        $saveAttempted = $true
        $presentation.SaveCopyAs($outputFullPath)
        $outputWritten = $true
    }
    finally {
        Release-OfficeFileComObject -ComObject $slides
        Release-OfficeFileComObject -ComObject $presentations
        if ($null -ne $presentation) {
            try { $presentation.Close() } catch {}
            Release-OfficeFileComObject -ComObject $presentation
            $presentation = $null
        }
        if ($null -ne $application) {
            try { $application.Quit() } catch {}
            Release-OfficeFileComObject -ComObject $application
            $application = $null
        }
        Complete-OfficeFileComCleanup
    }

    if (-not $outputWritten -or -not (Test-Path -LiteralPath $outputFullPath -PathType Leaf)) {
        throw "PowerPoint did not create the expected output copy '$outputFullPath'."
    }

    $sourceHashAfter = Get-OfficeFileSha256 -Path $sourceFullPath
    if ($sourceHashBefore -ne $sourceHashAfter) {
        throw 'The source presentation hash changed during editing.'
    }

    $outputHash = Get-OfficeFileSha256 -Path $outputFullPath
    $outputFile = Get-Item -LiteralPath $outputFullPath -ErrorAction Stop
    if ($backupCreated) {
        [IO.File]::Delete($backupPath)
        $backupCreated = $false
    }

    $manifest = [pscustomobject][ordered]@{
        success      = $true
        command      = 'Edit-PowerPointCopy'
        source       = [pscustomobject][ordered]@{
            path         = $sourceFullPath
            sha256Before = $sourceHashBefore
            sha256After  = $sourceHashAfter
            unchanged    = $true
        }
        plan         = [pscustomobject][ordered]@{
            path           = $planFullPath
            sha256         = $planHash
            allowOverwrite = $allowOverwrite
        }
        output       = [pscustomobject][ordered]@{
            path        = $outputFullPath
            sha256      = $outputHash
            bytes       = [long]$outputFile.Length
            overwritten = $outputExistedInitially
            saveMethod  = 'SaveCopyAs'
        }
        settingsPath = $settings.SettingsPath
        powerPointVersion = $powerPointVersion
        operations   = @($operationResults)
    }

    Write-OfficeFileJson -Value $manifest
}
catch {
    $failureRecord = $_
    $rollbackError = $null
    try {
        if ($backupCreated -and $null -ne $backupPath -and (Test-Path -LiteralPath $backupPath -PathType Leaf)) {
            if ($null -ne $outputFullPath -and (Test-Path -LiteralPath $outputFullPath -PathType Leaf)) {
                [IO.File]::Delete($outputFullPath)
            }
            [IO.File]::Move($backupPath, $outputFullPath)
            $backupCreated = $false
        }
        elseif ($saveAttempted -and -not $outputExistedInitially -and $null -ne $outputFullPath -and
            (Test-Path -LiteralPath $outputFullPath -PathType Leaf)) {
            [IO.File]::Delete($outputFullPath)
        }
    }
    catch {
        $rollbackError = $_.Exception.Message
    }

    $context = @{
        operations = @($operationResults)
    }
    if ($null -ne $sourceFullPath) { $context['sourcePath'] = $sourceFullPath }
    if ($null -ne $outputFullPath) { $context['outputPath'] = $outputFullPath }
    if ($null -ne $planFullPath) { $context['planPath'] = $planFullPath }
    if ($null -ne $sourceHashBefore) { $context['sourceSha256Before'] = $sourceHashBefore }
    if ($null -ne $sourceFullPath -and (Test-Path -LiteralPath $sourceFullPath -PathType Leaf)) {
        try { $context['sourceSha256After'] = Get-OfficeFileSha256 -Path $sourceFullPath } catch {}
    }
    if ($null -ne $rollbackError) { $context['rollbackError'] = $rollbackError }
    Write-OfficeFileFailure -Command 'Edit-PowerPointCopy' -ErrorRecord $failureRecord -Context $context
    exit 1
}

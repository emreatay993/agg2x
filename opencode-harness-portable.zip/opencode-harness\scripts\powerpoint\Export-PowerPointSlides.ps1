[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourcePath,

    [string]$OutputFolder = '',

    [int]$Width = 0,

    [int]$Height = 0
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path -Path $PSScriptRoot -ChildPath 'PowerPoint.Common.ps1')

$application = $null
$presentation = $null
$presentations = $null
$slides = $null
$sourceFullPath = $null
$outputFullPath = $null
$sourceHashBefore = $null
$createdOutputFolder = $false

try {
    $settings = Get-PowerPointSettings
    $sourceFullPath = Resolve-OfficeFileExistingFile -Path $SourcePath -Description 'Source presentation'
    Assert-PowerPointPresentationExtension -Path $sourceFullPath
    Assert-OfficeFileInputAllowed -Path $sourceFullPath -Settings $settings -Description 'Source presentation' -ToolName 'PowerPoint'

    if ($Width -eq 0) { $Width = $settings.RenderWidth }
    if ($Height -eq 0) { $Height = $settings.RenderHeight }
    if ($Width -le 0 -or $Height -le 0) {
        throw 'Width and Height must be positive integers.'
    }

    if ([string]::IsNullOrWhiteSpace($OutputFolder)) {
        $folderName = [IO.Path]::GetFileNameWithoutExtension($sourceFullPath) + '-slides'
        if (-not [string]::IsNullOrWhiteSpace([string]$settings.DefaultOutputRoot)) {
            $OutputFolder = Join-Path -Path $settings.DefaultOutputRoot -ChildPath $folderName
        }
        else {
            $OutputFolder = Join-Path -Path ([IO.Path]::GetDirectoryName($sourceFullPath)) -ChildPath $folderName
        }
    }

    $outputFullPath = Resolve-OfficeFileOutputDirectory -Path $OutputFolder
    Assert-OfficeFileOutputAllowed -OutputPath $outputFullPath -SourcePath $sourceFullPath -Settings $settings -Directory -ToolName 'PowerPoint'
    $outputFolderExisted = Test-Path -LiteralPath $outputFullPath -PathType Container
    if ($outputFolderExisted) { throw "The render output folder already exists: '$outputFullPath'. Choose a new folder." }
    [void](New-Item -ItemType Directory -Path $outputFullPath -ErrorAction Stop)
    $createdOutputFolder = $true
    $outputFullPath = (Get-Item -LiteralPath $outputFullPath -ErrorAction Stop).FullName

    $sourceHashBefore = Get-OfficeFileSha256 -Path $sourceFullPath
    $slideResults = @()
    $powerPointVersion = ''

    try {
        $application = New-Object -ComObject PowerPoint.Application
        $application.AutomationSecurity = 3
        if ([int]$application.AutomationSecurity -ne 3) { throw 'PowerPoint macro automation could not be disabled.' }
        try { $application.DisplayAlerts = 1 } catch {}
        $powerPointVersion = [string]$application.Version

        $presentations = $application.Presentations
        $presentation = $presentations.Open($sourceFullPath, -1, 0, 0)
        Release-OfficeFileComObject -ComObject $presentations
        $presentations = $null

        $slides = $presentation.Slides
        for ($slideIndex = 1; $slideIndex -le [int]$slides.Count; $slideIndex++) {
            $slide = $null
            try {
                $slide = $slides.Item($slideIndex)
                $fileName = 'slide-{0:D4}.png' -f $slideIndex
                $imagePath = Join-Path -Path $outputFullPath -ChildPath $fileName
                $overwritten = Test-Path -LiteralPath $imagePath -PathType Leaf
                [void]$slide.Export($imagePath, 'PNG', $Width, $Height)
                if (-not (Test-Path -LiteralPath $imagePath -PathType Leaf)) {
                    throw "PowerPoint did not create the expected slide image '$imagePath'."
                }

                $imageFile = Get-Item -LiteralPath $imagePath -ErrorAction Stop
                $slideResults += [pscustomobject][ordered]@{
                    slideIndex = $slideIndex
                    slideId    = [int]$slide.SlideID
                    path       = $imageFile.FullName
                    width      = $Width
                    height     = $Height
                    bytes      = [long]$imageFile.Length
                    sha256     = Get-OfficeFileSha256 -Path $imageFile.FullName
                    overwritten = $overwritten
                }
            }
            finally {
                Release-OfficeFileComObject -ComObject $slide
            }
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $slides
        Release-OfficeFileComObject -ComObject $presentations
        if ($null -ne $presentation) {
            try { $presentation.Close() } catch {}
            Release-OfficeFileComObject -ComObject $presentation
            $presentation = $null
        }
        if ($null -ne $application) {
            try { $application.Quit() } catch {}
            Release-OfficeFileComObject -ComObject $application
            $application = $null
        }
        Complete-OfficeFileComCleanup
    }

    $sourceHashAfter = Get-OfficeFileSha256 -Path $sourceFullPath
    if ($sourceHashBefore -ne $sourceHashAfter) {
        throw 'The source presentation hash changed during slide export.'
    }

    $manifest = [pscustomobject][ordered]@{
        success      = $true
        command      = 'Export-PowerPointSlides'
        source       = [pscustomobject][ordered]@{
            path          = $sourceFullPath
            sha256Before  = $sourceHashBefore
            sha256After   = $sourceHashAfter
            unchanged     = $true
        }
        settingsPath = $settings.SettingsPath
        powerPointVersion = $powerPointVersion
        output       = [pscustomobject][ordered]@{
            folder        = $outputFullPath
            folderExisted = $outputFolderExisted
            width         = $Width
            height        = $Height
            slideCount    = @($slideResults).Count
            slides        = @($slideResults)
        }
    }

    Write-OfficeFileJson -Value $manifest
}
catch {
    if ($createdOutputFolder -and $null -ne $outputFullPath -and (Test-Path -LiteralPath $outputFullPath -PathType Container)) {
        try { Remove-Item -LiteralPath $outputFullPath -Recurse -Force } catch {}
    }
    $context = @{}
    if ($null -ne $sourceFullPath) { $context['sourcePath'] = $sourceFullPath }
    if ($null -ne $outputFullPath) { $context['outputFolder'] = $outputFullPath }
    if ($null -ne $sourceHashBefore) { $context['sourceSha256Before'] = $sourceHashBefore }
    if ($null -ne $sourceFullPath -and (Test-Path -LiteralPath $sourceFullPath -PathType Leaf)) {
        try { $context['sourceSha256After'] = Get-OfficeFileSha256 -Path $sourceFullPath } catch {}
    }
    Write-OfficeFileFailure -Command 'Export-PowerPointSlides' -ErrorRecord $_ -Context $context
    exit 1
}

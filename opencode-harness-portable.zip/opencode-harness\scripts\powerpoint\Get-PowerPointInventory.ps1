[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourcePath,

    [ValidateRange(1, 2147483647)]
    [int]$StartSlide = 1,

    [ValidateRange(1, 25)]
    [int]$Limit = 10
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path -Path $PSScriptRoot -ChildPath 'PowerPoint.Common.ps1')

function Get-OfficeShapeTypeName {
    param([int]$Type)

    switch ($Type) {
        1 { return 'autoShape' }
        2 { return 'callout' }
        3 { return 'chart' }
        4 { return 'comment' }
        5 { return 'freeform' }
        6 { return 'group' }
        7 { return 'embeddedOleObject' }
        8 { return 'formControl' }
        9 { return 'line' }
        10 { return 'linkedOleObject' }
        11 { return 'linkedPicture' }
        12 { return 'oleControlObject' }
        13 { return 'picture' }
        14 { return 'placeholder' }
        15 { return 'textEffect' }
        16 { return 'media' }
        17 { return 'textBox' }
        19 { return 'table' }
        20 { return 'canvas' }
        24 { return 'diagram' }
        27 { return 'graphic' }
        default { return 'unknown' }
    }
}

function Get-PowerPointShapeText {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Shape
    )

    $textFrame = $null
    $textRange = $null
    $hasTextFrame = $false
    $hasText = $false
    $text = $null

    try {
        $hasTextFrame = ([int]$Shape.HasTextFrame -eq -1)
        if ($hasTextFrame) {
            $textFrame = $Shape.TextFrame
            $hasText = ([int]$textFrame.HasText -eq -1)
            if ($hasText) {
                $textRange = $textFrame.TextRange
                $text = [string]$textRange.Text
            }
            else {
                $text = ''
            }
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $textRange
        Release-OfficeFileComObject -ComObject $textFrame
    }

    return [pscustomobject][ordered]@{
        hasTextFrame = $hasTextFrame
        hasText      = $hasText
        text         = $text
    }
}

function Get-PowerPointShapeActions {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Shape
    )

    $results = @()
    $actionSettings = $null
    try {
        $actionSettings = $Shape.ActionSettings
        $triggers = @(
            [pscustomobject]@{ Index = 1; Name = 'click' },
            [pscustomobject]@{ Index = 2; Name = 'mouseOver' }
        )

        foreach ($trigger in $triggers) {
            $actionSetting = $null
            $hyperlink = $null
            try {
                $actionSetting = $actionSettings.Item($trigger.Index)
                $action = [int]$actionSetting.Action
                $run = ''
                $address = ''
                $subAddress = ''

                try {
                    $run = [string]$actionSetting.Run
                }
                catch {
                    $run = ''
                }

                try {
                    $hyperlink = $actionSetting.Hyperlink
                    $address = [string]$hyperlink.Address
                    $subAddress = [string]$hyperlink.SubAddress
                }
                catch {
                    $address = ''
                    $subAddress = ''
                }

                if ($action -ne 0 -or -not [string]::IsNullOrWhiteSpace($run) -or
                    -not [string]::IsNullOrWhiteSpace($address) -or -not [string]::IsNullOrWhiteSpace($subAddress)) {
                    $results += [pscustomobject][ordered]@{
                        trigger    = $trigger.Name
                        action     = $action
                        run        = $run
                        address    = $address
                        subAddress = $subAddress
                    }
                }
            }
            finally {
                Release-OfficeFileComObject -ComObject $hyperlink
                Release-OfficeFileComObject -ComObject $actionSetting
            }
        }
    }
    catch {
        return @()
    }
    finally {
        Release-OfficeFileComObject -ComObject $actionSettings
    }

    return @($results)
}

function Convert-PowerPointShapeInventory {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Shape,

        [Parameter(Mandatory = $true)]
        [int]$Index,

        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    $shapeType = [int]$Shape.Type
    $textInfo = Get-PowerPointShapeText -Shape $Shape
    $placeholderType = $null
    $alternativeText = ''
    $title = ''
    $linkedSource = ''
    $tableCells = @()
    $children = @()

    try {
        $alternativeText = [string]$Shape.AlternativeText
    }
    catch {
        $alternativeText = ''
    }

    try {
        $title = [string]$Shape.Title
    }
    catch {
        $title = ''
    }

    if ($shapeType -eq 14) {
        $placeholderFormat = $null
        try {
            $placeholderFormat = $Shape.PlaceholderFormat
            $placeholderType = [int]$placeholderFormat.Type
        }
        finally {
            Release-OfficeFileComObject -ComObject $placeholderFormat
        }
    }

    if ($shapeType -eq 10 -or $shapeType -eq 11) {
        $linkFormat = $null
        try {
            $linkFormat = $Shape.LinkFormat
            $linkedSource = [string]$linkFormat.SourceFullName
        }
        catch {
            $linkedSource = ''
        }
        finally {
            Release-OfficeFileComObject -ComObject $linkFormat
        }
    }

    $hasTable = $false
    try {
        $hasTable = ([int]$Shape.HasTable -eq -1)
    }
    catch {
        $hasTable = $false
    }

    if ($hasTable) {
        $table = $null
        $rows = $null
        $columns = $null
        try {
            $table = $Shape.Table
            $rows = $table.Rows
            $columns = $table.Columns
            for ($row = 1; $row -le [int]$rows.Count; $row++) {
                for ($column = 1; $column -le [int]$columns.Count; $column++) {
                    $cell = $null
                    $cellShape = $null
                    try {
                        $cell = $table.Cell($row, $column)
                        $cellShape = $cell.Shape
                        $cellText = Get-PowerPointShapeText -Shape $cellShape
                        $tableCells += [pscustomobject][ordered]@{
                            row     = $row
                            column  = $column
                            hasText = $cellText.hasText
                            text    = $cellText.text
                        }
                    }
                    finally {
                        Release-OfficeFileComObject -ComObject $cellShape
                        Release-OfficeFileComObject -ComObject $cell
                    }
                }
            }
        }
        finally {
            Release-OfficeFileComObject -ComObject $columns
            Release-OfficeFileComObject -ComObject $rows
            Release-OfficeFileComObject -ComObject $table
        }
    }

    if ($shapeType -eq 6) {
        $groupItems = $null
        try {
            $groupItems = $Shape.GroupItems
            for ($childIndex = 1; $childIndex -le [int]$groupItems.Count; $childIndex++) {
                $childShape = $null
                try {
                    $childShape = $groupItems.Item($childIndex)
                    $children += Convert-PowerPointShapeInventory -Shape $childShape -Index $childIndex -Path "$Path.$childIndex"
                }
                finally {
                    Release-OfficeFileComObject -ComObject $childShape
                }
            }
        }
        finally {
            Release-OfficeFileComObject -ComObject $groupItems
        }
    }

    return [pscustomobject][ordered]@{
        index           = $Index
        path            = $Path
        id              = [int]$Shape.Id
        name            = [string]$Shape.Name
        type            = $shapeType
        typeName        = Get-OfficeShapeTypeName -Type $shapeType
        placeholderType = $placeholderType
        bounds          = [pscustomobject][ordered]@{
            left     = [double]$Shape.Left
            top      = [double]$Shape.Top
            width    = [double]$Shape.Width
            height   = [double]$Shape.Height
            rotation = [double]$Shape.Rotation
        }
        visible         = ([int]$Shape.Visible -eq -1)
        alternativeText = $alternativeText
        title           = $title
        hasTextFrame    = $textInfo.hasTextFrame
        hasText         = $textInfo.hasText
        text            = $textInfo.text
        tableCells      = @($tableCells)
        linkedSource    = $linkedSource
        actions         = @(Get-PowerPointShapeActions -Shape $Shape)
        children        = @($children)
    }
}

function Get-PowerPointSlideNotes {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide
    )

    $notesPage = $null
    $noteShapes = $null
    $shapeResults = @()
    $bodyParts = @()
    try {
        $notesPage = $Slide.NotesPage
        $noteShapes = $notesPage.Shapes
        for ($shapeIndex = 1; $shapeIndex -le [int]$noteShapes.Count; $shapeIndex++) {
            $noteShape = $null
            try {
                $noteShape = $noteShapes.Item($shapeIndex)
                $shapeResult = Convert-PowerPointShapeInventory -Shape $noteShape -Index $shapeIndex -Path ([string]$shapeIndex)
                $shapeResults += $shapeResult
                if ($shapeResult.placeholderType -eq 2 -and $shapeResult.hasText) {
                    $bodyParts += [string]$shapeResult.text
                }
            }
            finally {
                Release-OfficeFileComObject -ComObject $noteShape
            }
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $noteShapes
        Release-OfficeFileComObject -ComObject $notesPage
    }

    return [pscustomobject][ordered]@{
        text   = $bodyParts -join "`r`n"
        shapes = @($shapeResults)
    }
}

function Get-PowerPointPresentationLinks {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Presentation
    )

    $results = @()
    $hyperlinks = $null
    try {
        $hyperlinks = $Presentation.Hyperlinks
        for ($index = 1; $index -le [int]$hyperlinks.Count; $index++) {
            $hyperlink = $null
            try {
                $hyperlink = $hyperlinks.Item($index)
                $emailSubject = ''
                try {
                    $emailSubject = [string]$hyperlink.EmailSubject
                }
                catch {
                    $emailSubject = ''
                }

                $results += [pscustomobject][ordered]@{
                    index        = $index
                    type         = [int]$hyperlink.Type
                    address      = [string]$hyperlink.Address
                    subAddress   = [string]$hyperlink.SubAddress
                    emailSubject = $emailSubject
                }
            }
            finally {
                Release-OfficeFileComObject -ComObject $hyperlink
            }
        }
    }
    catch {
        return @()
    }
    finally {
        Release-OfficeFileComObject -ComObject $hyperlinks
    }

    return @($results)
}

$application = $null
$presentation = $null
$presentations = $null
$slides = $null
$pageSetup = $null
$sourceFullPath = $null
$sourceHashBefore = $null
$sourceHashAfter = $null

try {
    $settings = Get-PowerPointSettings
    $sourceFullPath = Resolve-OfficeFileExistingFile -Path $SourcePath -Description 'Source presentation'
    Assert-PowerPointPresentationExtension -Path $sourceFullPath
    Assert-OfficeFileInputAllowed -Path $sourceFullPath -Settings $settings -Description 'Source presentation' -ToolName 'PowerPoint'
    $sourceHashBefore = Get-OfficeFileSha256 -Path $sourceFullPath

    $slideResults = @()
    $powerPointVersion = ''
    $slideWidth = 0.0
    $slideHeight = 0.0
    $hasVbProject = $null
    $presentationLinks = @()
    $totalSlideCount = 0
    $endSlide = 0
    $nextStart = $null

    try {
        $application = New-Object -ComObject PowerPoint.Application
        $application.AutomationSecurity = 3
        if ([int]$application.AutomationSecurity -ne 3) { throw 'PowerPoint macro automation could not be disabled.' }
        try { $application.DisplayAlerts = 1 } catch {}
        $powerPointVersion = [string]$application.Version

        $presentations = $application.Presentations
        $presentation = $presentations.Open($sourceFullPath, -1, 0, 0)
        Release-OfficeFileComObject -ComObject $presentations
        $presentations = $null

        try {
            $hasVbProject = ([int]$presentation.HasVBProject -eq -1)
        }
        catch {
            $hasVbProject = $null
        }

        $pageSetup = $presentation.PageSetup
        $slideWidth = [double]$pageSetup.SlideWidth
        $slideHeight = [double]$pageSetup.SlideHeight
        Release-OfficeFileComObject -ComObject $pageSetup
        $pageSetup = $null

        $presentationLinks = @(Get-PowerPointPresentationLinks -Presentation $presentation)
        $slides = $presentation.Slides
        $totalSlideCount = [int]$slides.Count
        if ($StartSlide -gt $totalSlideCount) {
            throw "StartSlide $StartSlide exceeds the presentation slide count $totalSlideCount."
        }
        $endSlide = [Math]::Min($totalSlideCount, $StartSlide + $Limit - 1)
        if ($endSlide -lt $totalSlideCount) { $nextStart = $endSlide + 1 }
        for ($slideIndex = $StartSlide; $slideIndex -le $endSlide; $slideIndex++) {
            $slide = $null
            $shapes = $null
            try {
                $slide = $slides.Item($slideIndex)
                $shapes = $slide.Shapes
                $shapeResults = @()
                for ($shapeIndex = 1; $shapeIndex -le [int]$shapes.Count; $shapeIndex++) {
                    $shape = $null
                    try {
                        $shape = $shapes.Item($shapeIndex)
                        $shapeResults += Convert-PowerPointShapeInventory -Shape $shape -Index $shapeIndex -Path ([string]$shapeIndex)
                    }
                    finally {
                        Release-OfficeFileComObject -ComObject $shape
                    }
                }

                $notes = Get-PowerPointSlideNotes -Slide $slide
                $slideResults += [pscustomobject][ordered]@{
                    index   = $slideIndex
                    id      = [int]$slide.SlideID
                    name    = [string]$slide.Name
                    shapes  = @($shapeResults)
                    notes   = $notes.text
                    noteShapes = @($notes.shapes)
                }
            }
            finally {
                Release-OfficeFileComObject -ComObject $shapes
                Release-OfficeFileComObject -ComObject $slide
            }
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $pageSetup
        Release-OfficeFileComObject -ComObject $slides
        Release-OfficeFileComObject -ComObject $presentations
        if ($null -ne $presentation) {
            try { $presentation.Close() } catch {}
            Release-OfficeFileComObject -ComObject $presentation
            $presentation = $null
        }
        if ($null -ne $application) {
            try { $application.Quit() } catch {}
            Release-OfficeFileComObject -ComObject $application
            $application = $null
        }
        Complete-OfficeFileComCleanup
    }

    $sourceHashAfter = Get-OfficeFileSha256 -Path $sourceFullPath
    if ($sourceHashBefore -ne $sourceHashAfter) {
        throw 'The source presentation hash changed during inventory.'
    }

    $extension = [IO.Path]::GetExtension($sourceFullPath).ToLowerInvariant()
    $macroCapable = @('.pptm', '.ppsm', '.potm', '.ppt') -contains $extension
    $manifest = [pscustomobject][ordered]@{
        success      = $true
        command      = 'Get-PowerPointInventory'
        source       = [pscustomobject][ordered]@{
            path       = $sourceFullPath
            sha256     = $sourceHashBefore
            unchanged  = $true
        }
        settingsPath = $settings.SettingsPath
        powerPointVersion = $powerPointVersion
        presentation = [pscustomobject][ordered]@{
            name          = [IO.Path]::GetFileName($sourceFullPath)
            slideCount    = $totalSlideCount
            slideWidth    = $slideWidth
            slideHeight   = $slideHeight
            macroCapable  = $macroCapable
            hasVbProject  = $hasVbProject
            hyperlinks    = @($presentationLinks)
        }
        truncation   = [pscustomobject][ordered]@{
            startSlide = $StartSlide
            limit      = $Limit
            included   = @($slideResults).Count
            endSlide   = $endSlide
            total      = $totalSlideCount
            truncated  = $null -ne $nextStart
            nextStart  = $nextStart
        }
        slides       = @($slideResults)
    }

    Write-OfficeFileJson -Value $manifest
}
catch {
    $context = @{}
    if ($null -ne $sourceFullPath) { $context['sourcePath'] = $sourceFullPath }
    if ($null -ne $sourceHashBefore) { $context['sourceSha256Before'] = $sourceHashBefore }
    if ($null -ne $sourceFullPath -and (Test-Path -LiteralPath $sourceFullPath -PathType Leaf)) {
        try { $context['sourceSha256After'] = Get-OfficeFileSha256 -Path $sourceFullPath } catch {}
    }
    Write-OfficeFileFailure -Command 'Get-PowerPointInventory' -ErrorRecord $_ -Context $context
    exit 1
}

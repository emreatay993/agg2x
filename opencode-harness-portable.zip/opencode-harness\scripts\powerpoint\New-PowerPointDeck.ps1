#requires -Version 5.1

<#
    .SYNOPSIS
    Builds a new PowerPoint deck in the house presentation style from a JSON deck spec.

    .DESCRIPTION
    Creates a new .pptx file. Never opens or modifies an existing deck except an optional
    read-only template. Refuses to write over an existing output file.
#>

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SpecPath,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath,

    [string]$TemplatePath = '',

    [string]$ImageRoot = ''
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path -Path $PSScriptRoot -ChildPath 'PowerPoint.Common.ps1')
. (Join-Path -Path $PSScriptRoot -ChildPath 'PresentationStyle.Common.ps1')

$script:PpSaveAsOpenXmlPresentation = 24
$script:DeckImageRoot = ''

function Resolve-DeckImagePath {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$SpecDirectory,

        [Parameter(Mandatory = $true)]
        [object]$Settings
    )

    $expanded = [Environment]::ExpandEnvironmentVariables($Path)
    if (-not [IO.Path]::IsPathRooted($expanded)) {
        # The OpenCode tool writes the spec to machine-local state, so relative image
        # paths must resolve against an explicit image root when one is supplied.
        $base = if (-not [string]::IsNullOrWhiteSpace($script:DeckImageRoot)) { $script:DeckImageRoot } else { $SpecDirectory }
        $expanded = Join-Path -Path $base -ChildPath $expanded
    }

    $full = [IO.Path]::GetFullPath($expanded)
    if (-not (Test-Path -LiteralPath $full -PathType Leaf)) {
        throw "Deck image does not exist: '$full'."
    }

    Assert-OfficeFileInputAllowed -Path $full -Settings $Settings -Description 'Deck image' -ToolName 'PowerPoint'
    return (Get-Item -LiteralPath $full -ErrorAction Stop).FullName
}

function Add-SlideChrome {
    <#
        .SYNOPSIS
        Adds the five non-negotiables: title, title rule, footer rule, slide number.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Style,

        [Parameter(Mandatory = $true)]
        [string]$Title,

        [Parameter(Mandatory = $true)]
        [int]$SlideNumber
    )

    $slideWidth = [double](Get-StyleValue -Style $Style -Section 'slideSize' -Name 'widthPt')
    $marginLeft = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'marginLeftPt')
    $marginRight = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'marginRightPt')
    $titleTop = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'titleTopPt')
    $titleHeight = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'titleHeightPt')
    $titleRuleGap = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'titleRuleGapPt')
    $footerRuleTop = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'footerRuleTopPt')
    $ruleWeight = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'ruleWeightPt')
    $textRight = $slideWidth - $marginRight

    $titleFont = Get-StyleValue -Style $Style -Section 'fonts' -Name 'title'
    $titleShape = Add-StyledTextbox -Slide $Slide -Text $Title `
        -Left $marginLeft -Top $titleTop -Width ($textRight - $marginLeft) -Height $titleHeight `
        -FontName ([string]$titleFont.name) -FontSize ([double]$titleFont.sizePt) -Bold ([bool]$titleFont.bold) `
        -Colour ([string]$titleFont.colour) -Alignment $script:PpAlignLeft
    Release-OfficeFileComObject -ComObject $titleShape

    $ruleColour = [string](Get-StyleValue -Style $Style -Section 'colours' -Name 'rule')
    if ([bool](Get-StyleValue -Style $Style -Section 'rules' -Name 'titleRuleOn')) {
        Add-StyledRule -Slide $Slide -Left $marginLeft -Top ($titleTop + $titleHeight + $titleRuleGap) `
            -Right $textRight -Colour $ruleColour -Weight $ruleWeight
    }

    if ([bool](Get-StyleValue -Style $Style -Section 'rules' -Name 'footerRuleOn')) {
        Add-StyledRule -Slide $Slide -Left $marginLeft -Top $footerRuleTop `
            -Right $textRight -Colour $ruleColour -Weight $ruleWeight
    }

    if ([bool](Get-StyleValue -Style $Style -Section 'rules' -Name 'slideNumbersOn')) {
        $numberFont = Get-StyleValue -Style $Style -Section 'fonts' -Name 'slideNumber'
        $numberShape = Add-StyledTextbox -Slide $Slide -Text ([string]$SlideNumber) `
            -Left ($textRight - 60) -Top ($footerRuleTop + 4) -Width 60 -Height 18 `
            -FontName ([string]$numberFont.name) -FontSize ([double]$numberFont.sizePt) -Bold $false `
            -Colour ([string]$numberFont.colour) -Alignment $script:PpAlignRight
        Release-OfficeFileComObject -ComObject $numberShape
    }
}

function Add-SlideBullets {
    <#
        .SYNOPSIS
        Adds a body textbox carrying the house bullet ladder. Returns the bottom edge in points.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Style,

        [Parameter(Mandatory = $true)]
        [object[]]$Bullets,

        [Parameter(Mandatory = $true)]
        [double]$Top,

        [Parameter(Mandatory = $true)]
        [ref]$BulletFallback
    )

    if ($Bullets.Count -eq 0) { return $Top }

    $slideWidth = [double](Get-StyleValue -Style $Style -Section 'slideSize' -Name 'widthPt')
    $marginLeft = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'marginLeftPt')
    $marginRight = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'marginRightPt')
    $lineSpacing = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'lineSpacing')
    $bodyFont = Get-StyleValue -Style $Style -Section 'fonts' -Name 'body'
    $bulletStyle = $Style.bullets
    $justifyThreshold = [int](Get-StyleValue -Style $Style -Section 'rules' -Name 'justifyThresholdChars')
    $justifyEnabled = [bool](Get-StyleValue -Style $Style -Section 'rules' -Name 'justifyLongParagraphs')
    $width = $slideWidth - $marginLeft - $marginRight

    $lines = @()
    $levels = @()
    $estimatedLines = 0
    foreach ($bullet in $Bullets) {
        $text = [string](Get-SpecValue -InputObject $bullet -Names @('text') -DefaultValue '')
        if ([string]::IsNullOrWhiteSpace($text)) { continue }
        $level = [int](Get-SpecValue -InputObject $bullet -Names @('level') -DefaultValue 1)
        if ($level -lt 1 -or $level -gt 3) { throw "Bullet level must be 1, 2, or 3. Received '$level'." }
        $lines += $text
        $levels += $level
        $estimatedLines += [Math]::Max(1, [Math]::Ceiling($text.Length / 110.0))
    }

    if ($lines.Count -eq 0) { return $Top }

    $height = [Math]::Max(24, $estimatedLines * [double]$bodyFont.sizePt * $lineSpacing * 1.25)
    $shape = Add-StyledTextbox -Slide $Slide -Text ($lines -join "`r") `
        -Left $marginLeft -Top $Top -Width $width -Height $height `
        -FontName ([string]$bodyFont.name) -FontSize ([double]$bodyFont.sizePt) -Bold $false `
        -Colour ([string]$bodyFont.colour) -Alignment $script:PpAlignLeft -LineSpacing $lineSpacing

    try {
        $applied = Set-BulletLadder -Shape $shape -Levels $levels -BulletStyle $bulletStyle
        if (-not $applied) { $BulletFallback.Value = $true }

        for ($index = 0; $index -lt $Bullets.Count; $index++) {
            $bullet = $Bullets[$index]
            $colour = [string](Get-SpecValue -InputObject $bullet -Names @('colour', 'color') -DefaultValue '')
            if (-not [string]::IsNullOrWhiteSpace($colour)) {
                Set-ParagraphColour -Shape $shape -ParagraphIndex ($index + 1) -Colour $colour
            }

            $justify = Get-SpecValue -InputObject $bullet -Names @('justify') -DefaultValue $null
            $shouldJustify = if ($null -ne $justify) { [bool]$justify } else { $justifyEnabled -and $lines[$index].Length -ge $justifyThreshold }
            if ($shouldJustify) {
                $paragraph = $null
                $paragraphFormat = $null
                try {
                    $paragraph = $shape.TextFrame.TextRange.Paragraphs($index + 1, 1)
                    $paragraphFormat = $paragraph.ParagraphFormat
                    $paragraphFormat.Alignment = $script:PpAlignJustify
                }
                finally {
                    Release-OfficeFileComObject -ComObject $paragraphFormat
                    Release-OfficeFileComObject -ComObject $paragraph
                }
            }
        }

        $bottom = [double]$shape.Top + [double]$shape.Height
    }
    finally {
        Release-OfficeFileComObject -ComObject $shape
    }

    return $bottom
}

function Add-SlidePanels {
    <#
        .SYNOPSIS
        Lays out a comparison grid: one badge per panel, images stacked beneath, optional row labels.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Style,

        [Parameter(Mandatory = $true)]
        [object[]]$Panels,

        [Parameter(Mandatory = $true)]
        [double]$Top,

        [Parameter(Mandatory = $true)]
        [double]$Bottom,

        [Parameter(Mandatory = $true)]
        [string]$SpecDirectory,

        [Parameter(Mandatory = $true)]
        [object]$Settings,

        [object[]]$RowLabels = @()
    )

    $slideWidth = [double](Get-StyleValue -Style $Style -Section 'slideSize' -Name 'widthPt')
    $marginLeft = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'marginLeftPt')
    $marginRight = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'marginRightPt')
    $badgeHeight = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'badgeHeightPt')
    $badgeFont = Get-StyleValue -Style $Style -Section 'fonts' -Name 'badge'
    $captionFont = Get-StyleValue -Style $Style -Section 'fonts' -Name 'figureCaption'
    $colours = $Style.colours

    $count = $Panels.Count
    if ($count -eq 0) { return }
    $gap = 12.0
    $available = $slideWidth - $marginLeft - $marginRight
    $panelWidth = ($available - ($gap * ($count - 1))) / $count

    $maxImages = 1
    foreach ($panel in $Panels) {
        $images = @(Get-SpecValue -InputObject $panel -Names @('images') -DefaultValue @())
        if ($images.Count -gt $maxImages) { $maxImages = $images.Count }
    }

    $labelHeight = if ($RowLabels.Count -gt 0) { 14.0 } else { 0.0 }
    $imageArea = $Bottom - $Top - $badgeHeight - 6
    $rowHeight = ($imageArea / $maxImages) - $labelHeight - 4

    for ($panelIndex = 0; $panelIndex -lt $count; $panelIndex++) {
        $panel = $Panels[$panelIndex]
        $panelLeft = $marginLeft + ($panelIndex * ($panelWidth + $gap))

        $badgeText = [string](Get-SpecValue -InputObject $panel -Names @('badge') -DefaultValue '')
        if (-not [string]::IsNullOrWhiteSpace($badgeText)) {
            $badgeKind = [string](Get-SpecValue -InputObject $panel -Names @('badgeKind') -DefaultValue 'red')
            $badgeColour = switch ($badgeKind.ToLowerInvariant()) {
                'blue' { [string]$colours.badgeBlue }
                'grey' { [string]$colours.badgeGrey }
                'gray' { [string]$colours.badgeGrey }
                default { [string]$colours.badgeRed }
            }
            $badgeWidth = [Math]::Min($panelWidth, [Math]::Max(70.0, ($badgeText.Length * 7.5) + 20.0))
            $badgeLeft = $panelLeft + (($panelWidth - $badgeWidth) / 2.0)
            $badgeShape = Add-StyledBadge -Slide $Slide -Text $badgeText -FillColour $badgeColour `
                -Left $badgeLeft -Top $Top -Width $badgeWidth -Height $badgeHeight `
                -FontName ([string]$badgeFont.name) -FontSize ([double]$badgeFont.sizePt) -FontColour ([string]$badgeFont.colour)
            Release-OfficeFileComObject -ComObject $badgeShape

            if ([bool](Get-SpecValue -InputObject $panel -Names @('governing') -DefaultValue $false)) {
                $starShape = Add-GoverningStar -Slide $Slide -Left ($badgeLeft + $badgeWidth - 8) -Top ($Top - 14)
                Release-OfficeFileComObject -ComObject $starShape
            }
        }

        $images = @(Get-SpecValue -InputObject $panel -Names @('images') -DefaultValue @())
        for ($imageIndex = 0; $imageIndex -lt $images.Count; $imageIndex++) {
            $rowTop = $Top + $badgeHeight + 6 + ($imageIndex * ($rowHeight + $labelHeight + 4))
            if ($imageIndex -lt $RowLabels.Count) {
                $labelShape = Add-StyledTextbox -Slide $Slide -Text ([string]$RowLabels[$imageIndex]) `
                    -Left $panelLeft -Top $rowTop -Width $panelWidth -Height $labelHeight `
                    -FontName ([string]$captionFont.name) -FontSize ([double]$captionFont.sizePt) -Bold $false `
                    -Colour ([string]$captionFont.colour) -Alignment $script:PpAlignLeft
                Release-OfficeFileComObject -ComObject $labelShape
            }

            $imagePath = Resolve-DeckImagePath -Path ([string]$images[$imageIndex]) -SpecDirectory $SpecDirectory -Settings $Settings
            $shapes = $null
            $picture = $null
            try {
                $shapes = $Slide.Shapes
                $picture = $shapes.AddPicture($imagePath, $script:MsoFalse, $script:MsoTrue,
                    $panelLeft, ($rowTop + $labelHeight), $panelWidth, $rowHeight)
            }
            finally {
                Release-OfficeFileComObject -ComObject $picture
                Release-OfficeFileComObject -ComObject $shapes
            }
        }
    }
}

function Add-SlideVerdict {
    <#
        .SYNOPSIS
        Adds the sand comparison box, block arrow, verdict word, and optional red reason.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Style,

        [Parameter(Mandatory = $true)]
        [object]$Verdict
    )

    $colours = $Style.colours
    $verdictFont = Get-StyleValue -Style $Style -Section 'fonts' -Name 'verdict'
    $calloutFont = Get-StyleValue -Style $Style -Section 'fonts' -Name 'callout'
    $slideWidth = [double](Get-StyleValue -Style $Style -Section 'slideSize' -Name 'widthPt')
    $marginRight = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'marginRightPt')

    $pass = [bool](Get-SpecValue -InputObject $Verdict -Names @('pass') -DefaultValue $true)
    $result = [string](Get-SpecValue -InputObject $Verdict -Names @('result') -DefaultValue $(if ($pass) { 'OK' } else { 'NOT OK' }))
    $comparison = [string](Get-SpecValue -InputObject $Verdict -Names @('comparison') -DefaultValue '')
    $reason = [string](Get-SpecValue -InputObject $Verdict -Names @('reason') -DefaultValue '')
    $verdictColour = if ($pass) { [string]$colours.verdictGreen } else { [string]$colours.verdictRed }

    $width = 260.0
    $left = [double](Get-SpecValue -InputObject $Verdict -Names @('left') -DefaultValue ($slideWidth - $marginRight - $width - 90))
    $top = [double](Get-SpecValue -InputObject $Verdict -Names @('top') -DefaultValue 455.0)

    if (-not [string]::IsNullOrWhiteSpace($comparison)) {
        $box = Add-StyledCallout -Slide $Slide -Text $comparison `
            -Left $left -Top $top -Width $width -Height 26 `
            -FillColour ([string]$colours.calloutSand) -EdgeColour ([string]$colours.calloutSand) `
            -FontName ([string]$verdictFont.name) -FontSize ([double]$verdictFont.sizePt) -FontColour $verdictColour
        $textFrame = $null
        try {
            $textFrame = $box.TextFrame
            $textFrame.TextRange.ParagraphFormat.Alignment = $script:PpAlignCenter
        }
        catch {}
        finally {
            Release-OfficeFileComObject -ComObject $textFrame
            Release-OfficeFileComObject -ComObject $box
        }
    }

    $arrow = Add-StyledArrow -Slide $Slide -Left ($left + $width + 6) -Top ($top + 5) -Width 26 -Height 16 -Colour $verdictColour
    Release-OfficeFileComObject -ComObject $arrow

    $word = Add-StyledTextbox -Slide $Slide -Text $result `
        -Left ($left + $width + 38) -Top $top -Width 90 -Height 26 `
        -FontName ([string]$verdictFont.name) -FontSize ([double]$verdictFont.sizePt) -Bold $true `
        -Colour $verdictColour -Alignment $script:PpAlignLeft
    Release-OfficeFileComObject -ComObject $word

    if (-not [string]::IsNullOrWhiteSpace($reason)) {
        $reasonShape = Add-StyledTextbox -Slide $Slide -Text $reason `
            -Left $left -Top ($top + 28) -Width ($width + 128) -Height 30 `
            -FontName ([string]$calloutFont.name) -FontSize ([double]$calloutFont.sizePt) -Bold $false `
            -Colour ([string]$colours.noteRed) -Alignment $script:PpAlignLeft -Italic $true
        Release-OfficeFileComObject -ComObject $reasonShape
    }
}

function Add-SlideBanner {
    <#
        .SYNOPSIS
        Adds the full-width scope banner that changes how following slides are read.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Style,

        [Parameter(Mandatory = $true)]
        [object]$Banner
    )

    $slideWidth = [double](Get-StyleValue -Style $Style -Section 'slideSize' -Name 'widthPt')
    $marginLeft = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'marginLeftPt')
    $marginRight = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'marginRightPt')
    $colours = $Style.colours
    $badgeFont = Get-StyleValue -Style $Style -Section 'fonts' -Name 'badge'

    $text = [string](Get-SpecValue -InputObject $Banner -Names @('text') -DefaultValue '')
    if ([string]::IsNullOrWhiteSpace($text)) { return }
    $kind = [string](Get-SpecValue -InputObject $Banner -Names @('kind') -DefaultValue 'red')
    $fill = if ($kind.ToLowerInvariant() -eq 'blue') { [string]$colours.badgeBlue } else { [string]$colours.badgeRed }
    $top = [double](Get-SpecValue -InputObject $Banner -Names @('top') -DefaultValue 468.0)
    $left = $marginLeft + 30
    $width = $slideWidth - $marginRight - $left

    $shape = Add-StyledBadge -Slide $Slide -Text $text -FillColour $fill `
        -Left $left -Top $top -Width $width -Height 24 `
        -FontName ([string]$badgeFont.name) -FontSize ([double]$badgeFont.sizePt) -FontColour ([string]$badgeFont.colour)
    try {
        Set-ShapeTextStyle -Shape $shape -FontName ([string]$badgeFont.name) -FontSize ([double]$badgeFont.sizePt) `
            -Bold $true -Colour ([string]$badgeFont.colour) -Alignment $script:PpAlignCenter -Italic $true
    }
    finally {
        Release-OfficeFileComObject -ComObject $shape
    }

    if ([bool](Get-SpecValue -InputObject $Banner -Names @('warning') -DefaultValue $false)) {
        $marker = Add-StyledTextbox -Slide $Slide -Text '!!!' `
            -Left ($left - 30) -Top $top -Width 28 -Height 24 `
            -FontName ([string]$badgeFont.name) -FontSize ([double]$badgeFont.sizePt) -Bold $true `
            -Colour ([string]$colours.noteRed) -Alignment $script:PpAlignRight
        Release-OfficeFileComObject -ComObject $marker
    }
}

function Add-SlideExtras {
    <#
        .SYNOPSIS
        Adds explicitly positioned badges, callouts, arrows, and images.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [object]$Style,

        [Parameter(Mandatory = $true)]
        [object]$SlideSpec,

        [Parameter(Mandatory = $true)]
        [string]$SpecDirectory,

        [Parameter(Mandatory = $true)]
        [object]$Settings
    )

    $colours = $Style.colours
    $badgeFont = Get-StyleValue -Style $Style -Section 'fonts' -Name 'badge'
    $calloutFont = Get-StyleValue -Style $Style -Section 'fonts' -Name 'callout'
    $badgeHeight = [double](Get-StyleValue -Style $Style -Section 'geometry' -Name 'badgeHeightPt')

    foreach ($badge in @(Get-SpecValue -InputObject $SlideSpec -Names @('badges') -DefaultValue @())) {
        $kind = [string](Get-SpecValue -InputObject $badge -Names @('kind') -DefaultValue 'blue')
        $fill = switch ($kind.ToLowerInvariant()) {
            'red' { [string]$colours.badgeRed }
            'grey' { [string]$colours.badgeGrey }
            'gray' { [string]$colours.badgeGrey }
            default { [string]$colours.badgeBlue }
        }
        $text = [string](Get-SpecValue -InputObject $badge -Names @('text') -DefaultValue '')
        if ([string]::IsNullOrWhiteSpace($text)) { continue }
        $shape = Add-StyledBadge -Slide $Slide -Text $text -FillColour $fill `
            -Left ([double](Get-SpecValue -InputObject $badge -Names @('left') -DefaultValue 40.0)) `
            -Top ([double](Get-SpecValue -InputObject $badge -Names @('top') -DefaultValue 90.0)) `
            -Width ([double](Get-SpecValue -InputObject $badge -Names @('width') -DefaultValue ([Math]::Max(80.0, ($text.Length * 7.5) + 20.0)))) `
            -Height ([double](Get-SpecValue -InputObject $badge -Names @('height') -DefaultValue $badgeHeight)) `
            -FontName ([string]$badgeFont.name) -FontSize ([double]$badgeFont.sizePt) -FontColour ([string]$badgeFont.colour)
        Release-OfficeFileComObject -ComObject $shape
    }

    foreach ($callout in @(Get-SpecValue -InputObject $SlideSpec -Names @('callouts') -DefaultValue @())) {
        $text = [string](Get-SpecValue -InputObject $callout -Names @('text') -DefaultValue '')
        if ([string]::IsNullOrWhiteSpace($text)) { continue }
        $shape = Add-StyledCallout -Slide $Slide -Text $text `
            -Left ([double](Get-SpecValue -InputObject $callout -Names @('left') -DefaultValue 600.0)) `
            -Top ([double](Get-SpecValue -InputObject $callout -Names @('top') -DefaultValue 120.0)) `
            -Width ([double](Get-SpecValue -InputObject $callout -Names @('width') -DefaultValue 180.0)) `
            -Height ([double](Get-SpecValue -InputObject $callout -Names @('height') -DefaultValue 40.0)) `
            -FillColour ([string]$colours.calloutSand) -EdgeColour ([string]$colours.calloutSandEdge) `
            -FontName ([string]$calloutFont.name) -FontSize ([double]$calloutFont.sizePt) -FontColour ([string]$calloutFont.colour)
        Release-OfficeFileComObject -ComObject $shape
    }

    foreach ($arrow in @(Get-SpecValue -InputObject $SlideSpec -Names @('arrows') -DefaultValue @())) {
        $left = [double](Get-SpecValue -InputObject $arrow -Names @('left') -DefaultValue 440.0)
        $top = [double](Get-SpecValue -InputObject $arrow -Names @('top') -DefaultValue 280.0)
        $width = [double](Get-SpecValue -InputObject $arrow -Names @('width') -DefaultValue 40.0)
        $height = [double](Get-SpecValue -InputObject $arrow -Names @('height') -DefaultValue 24.0)
        $shape = Add-StyledArrow -Slide $Slide -Left $left -Top $top -Width $width -Height $height -Colour ([string]$colours.noteRed)
        Release-OfficeFileComObject -ComObject $shape

        $label = [string](Get-SpecValue -InputObject $arrow -Names @('label') -DefaultValue '')
        if (-not [string]::IsNullOrWhiteSpace($label)) {
            $labelShape = Add-StyledTextbox -Slide $Slide -Text $label `
                -Left $left -Top ($top - 18) -Width ([Math]::Max($width, 120.0)) -Height 16 `
                -FontName ([string]$calloutFont.name) -FontSize ([double]$calloutFont.sizePt) -Bold $false `
                -Colour ([string]$colours.noteRed) -Alignment $script:PpAlignLeft
            Release-OfficeFileComObject -ComObject $labelShape
        }
    }

    foreach ($plus in @(Get-SpecValue -InputObject $SlideSpec -Names @('plusMarks') -DefaultValue @())) {
        $shape = Add-StyledPlus -Slide $Slide `
            -Left ([double](Get-SpecValue -InputObject $plus -Names @('left') -DefaultValue 220.0)) `
            -Top ([double](Get-SpecValue -InputObject $plus -Names @('top') -DefaultValue 300.0)) `
            -Size ([double](Get-SpecValue -InputObject $plus -Names @('size') -DefaultValue 22.0)) `
            -Colour ([string]$colours.noteRed)
        Release-OfficeFileComObject -ComObject $shape
    }

    foreach ($image in @(Get-SpecValue -InputObject $SlideSpec -Names @('images') -DefaultValue @())) {
        $path = [string](Get-SpecValue -InputObject $image -Names @('path') -DefaultValue '')
        if ([string]::IsNullOrWhiteSpace($path)) { continue }
        $resolved = Resolve-DeckImagePath -Path $path -SpecDirectory $SpecDirectory -Settings $Settings
        $shapes = $null
        $picture = $null
        try {
            $shapes = $Slide.Shapes
            $picture = $shapes.AddPicture($resolved, $script:MsoFalse, $script:MsoTrue,
                [double](Get-SpecValue -InputObject $image -Names @('left') -DefaultValue 40.0),
                [double](Get-SpecValue -InputObject $image -Names @('top') -DefaultValue 120.0),
                [double](Get-SpecValue -InputObject $image -Names @('width') -DefaultValue 400.0),
                [double](Get-SpecValue -InputObject $image -Names @('height') -DefaultValue 240.0))
        }
        finally {
            Release-OfficeFileComObject -ComObject $picture
            Release-OfficeFileComObject -ComObject $shapes
        }
    }
}

$application = $null
$presentation = $null
$slides = $null
$specFullPath = $null
$outputFullPath = $null
$templateFullPath = $null
$slideResults = @()
$outputWritten = $false
$saveAttempted = $false
$bulletFallback = $false

try {
    $settings = Get-PowerPointSettings
    $style = Get-PresentationStyle
    $specFullPath = Resolve-OfficeFileExistingFile -Path $SpecPath -Description 'Deck spec'
    $outputFullPath = Resolve-OfficeFileOutputFile -Path $OutputPath
    Assert-PowerPointPresentationExtension -Path $outputFullPath

    $outputExtension = [IO.Path]::GetExtension($outputFullPath).ToLowerInvariant()
    if ($outputExtension -ne '.pptx') {
        throw "New-PowerPointDeck writes .pptx only. Received '$outputExtension'."
    }
    if (Test-Path -LiteralPath $outputFullPath) {
        throw "OutputPath already exists. Choose a new path: '$outputFullPath'."
    }
    Assert-OfficeFileOutputAllowed -OutputPath $outputFullPath -SourcePath $specFullPath -Settings $settings -ToolName 'PowerPoint'

    if (-not [string]::IsNullOrWhiteSpace($ImageRoot)) {
        $imageRootFull = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($ImageRoot))
        if (-not (Test-Path -LiteralPath $imageRootFull -PathType Container)) {
            throw "ImageRoot does not exist or is not a folder: '$imageRootFull'."
        }
        Assert-OfficeFileInputAllowed -Path $imageRootFull -Settings $settings -Description 'Image root' -ToolName 'PowerPoint'
        $script:DeckImageRoot = (Get-Item -LiteralPath $imageRootFull -ErrorAction Stop).FullName
    }

    if (-not [string]::IsNullOrWhiteSpace($TemplatePath)) {
        $templateFullPath = Resolve-OfficeFileExistingFile -Path $TemplatePath -Description 'Template presentation'
        Assert-PowerPointPresentationExtension -Path $templateFullPath
        Assert-OfficeFileInputAllowed -Path $templateFullPath -Settings $settings -Description 'Template presentation' -ToolName 'PowerPoint'
    }

    try {
        $spec = [IO.File]::ReadAllText($specFullPath) | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "Could not parse deck spec '$specFullPath': $($_.Exception.Message)"
    }

    $slidesProperty = $spec.PSObject.Properties['slides']
    if ($null -eq $slidesProperty -or $null -eq $slidesProperty.Value) {
        throw 'The deck spec must contain a slides array.'
    }
    $slideSpecs = @($slidesProperty.Value)
    if ($slideSpecs.Count -eq 0) { throw 'The deck spec contains no slides.' }
    if ($slideSpecs.Count -gt 200) { throw "The deck spec requests $($slideSpecs.Count) slides. The builder limit is 200." }

    $specDirectory = [IO.Path]::GetDirectoryName($specFullPath)
    $specHash = Get-OfficeFileSha256 -Path $specFullPath
    $powerPointVersion = ''

    try {
        $application = New-Object -ComObject PowerPoint.Application
        $application.AutomationSecurity = 3
        if ([int]$application.AutomationSecurity -ne 3) { throw 'PowerPoint macro automation could not be disabled.' }
        try { $application.DisplayAlerts = 1 } catch {}
        $powerPointVersion = [string]$application.Version

        $presentations = $application.Presentations
        try {
            if ($null -ne $templateFullPath) {
                $presentation = $presentations.Open($templateFullPath, -1, -1, 0)
            }
            else {
                $presentation = $presentations.Add(0)
            }
        }
        finally {
            Release-OfficeFileComObject -ComObject $presentations
        }

        $pageSetup = $null
        try {
            $pageSetup = $presentation.PageSetup
            $pageSetup.SlideWidth = [double](Get-StyleValue -Style $style -Section 'slideSize' -Name 'widthPt')
            $pageSetup.SlideHeight = [double](Get-StyleValue -Style $style -Section 'slideSize' -Name 'heightPt')
        }
        finally {
            Release-OfficeFileComObject -ComObject $pageSetup
        }

        $slides = $presentation.Slides
        while ([int]$slides.Count -gt 0) {
            $existing = $null
            try {
                $existing = $slides.Item(1)
                $existing.Delete()
            }
            finally {
                Release-OfficeFileComObject -ComObject $existing
            }
        }

        $bodyTop = [double](Get-StyleValue -Style $style -Section 'geometry' -Name 'bodyTopPt')
        $footerRuleTop = [double](Get-StyleValue -Style $style -Section 'geometry' -Name 'footerRuleTopPt')
        $maxBullets = [int](Get-StyleValue -Style $style -Section 'rules' -Name 'maxBodyBulletsPerSlide')

        for ($slideIndex = 0; $slideIndex -lt $slideSpecs.Count; $slideIndex++) {
            $slideSpec = $slideSpecs[$slideIndex]
            $slideNumber = $slideIndex + 1
            $slide = $null
            $warnings = @()
            try {
                $title = [string](Get-SpecValue -InputObject $slideSpec -Names @('title') -DefaultValue '')
                if ([string]::IsNullOrWhiteSpace($title)) { throw "Slide $slideNumber has no title." }
                $pattern = [string](Get-SpecValue -InputObject $slideSpec -Names @('pattern') -DefaultValue 'summary')

                $slide = $slides.Add($slideNumber, $script:PpLayoutBlank)
                Add-SlideChrome -Slide $slide -Style $style -Title $title -SlideNumber $slideNumber

                $bullets = @(Get-SpecValue -InputObject $slideSpec -Names @('bullets') -DefaultValue @())
                if ($bullets.Count -gt $maxBullets) {
                    $warnings += "Slide $slideNumber has $($bullets.Count) body bullets; the house limit is $maxBullets."
                }
                $fallbackRef = [ref]$bulletFallback
                $cursor = Add-SlideBullets -Slide $slide -Style $style -Bullets $bullets -Top $bodyTop -BulletFallback $fallbackRef
                $bulletFallback = $fallbackRef.Value

                $closing = @(Get-SpecValue -InputObject $slideSpec -Names @('closingBullets') -DefaultValue @())
                $closingHeight = if ($closing.Count -gt 0) { 20.0 * $closing.Count + 8.0 } else { 0.0 }

                $panels = @(Get-SpecValue -InputObject $slideSpec -Names @('panels') -DefaultValue @())
                if ($panels.Count -gt 0) {
                    $rowLabels = @(Get-SpecValue -InputObject $slideSpec -Names @('rowLabels') -DefaultValue @())
                    Add-SlidePanels -Slide $slide -Style $style -Panels $panels `
                        -Top ($cursor + 10) -Bottom ($footerRuleTop - 10 - $closingHeight) `
                        -SpecDirectory $specDirectory -Settings $settings -RowLabels $rowLabels

                    $governingCount = 0
                    foreach ($panel in $panels) {
                        if ([bool](Get-SpecValue -InputObject $panel -Names @('governing') -DefaultValue $false)) { $governingCount++ }
                    }
                    if ($governingCount -gt 1) {
                        $warnings += "Slide $slideNumber marks $governingCount governing panels; exactly one gold star is allowed."
                    }
                }

                # Explicitly positioned elements are placed in absolute coordinates while the
                # bullet block flows, so an author cannot know where the text actually ends.
                # Report the collision rather than silently overlapping.
                foreach ($group in @('badges', 'callouts', 'images', 'arrows', 'plusMarks')) {
                    foreach ($item in @(Get-SpecValue -InputObject $slideSpec -Names @($group) -DefaultValue @())) {
                        $itemTop = Get-SpecValue -InputObject $item -Names @('top') -DefaultValue $null
                        if ($null -eq $itemTop) { continue }
                        if ([double]$itemTop -lt $cursor) {
                            $label = [string](Get-SpecValue -InputObject $item -Names @('text', 'label', 'path') -DefaultValue $group)
                            $warnings += ("Slide {0}: {1} '{2}' has top {3:N0} pt but the bullet block ends at {4:N0} pt, so they overlap." -f
                                $slideNumber, $group, $label, [double]$itemTop, $cursor)
                        }
                    }
                }

                Add-SlideExtras -Slide $slide -Style $style -SlideSpec $slideSpec -SpecDirectory $specDirectory -Settings $settings

                if ($closing.Count -gt 0) {
                    $closingRef = [ref]$bulletFallback
                    $null = Add-SlideBullets -Slide $slide -Style $style -Bullets $closing `
                        -Top ($footerRuleTop - $closingHeight - 4) -BulletFallback $closingRef
                    $bulletFallback = $closingRef.Value
                }

                $banner = Get-SpecValue -InputObject $slideSpec -Names @('banner') -DefaultValue $null
                if ($null -ne $banner) { Add-SlideBanner -Slide $slide -Style $style -Banner $banner }

                $verdict = Get-SpecValue -InputObject $slideSpec -Names @('verdict') -DefaultValue $null
                if ($null -ne $verdict) { Add-SlideVerdict -Slide $slide -Style $style -Verdict $verdict }

                $notes = [string](Get-SpecValue -InputObject $slideSpec -Names @('notes') -DefaultValue '')
                if (-not [string]::IsNullOrWhiteSpace($notes)) {
                    $notesPage = $null
                    $notesShapes = $null
                    $notesShape = $null
                    try {
                        $notesPage = $slide.NotesPage
                        $notesShapes = $notesPage.Shapes
                        $notesShape = $notesShapes.Item(2)
                        $notesShape.TextFrame.TextRange.Text = $notes
                    }
                    catch {
                        $warnings += "Slide $slideNumber notes could not be set."
                    }
                    finally {
                        Release-OfficeFileComObject -ComObject $notesShape
                        Release-OfficeFileComObject -ComObject $notesShapes
                        Release-OfficeFileComObject -ComObject $notesPage
                    }
                }

                $slideResults += [pscustomobject][ordered]@{
                    slideIndex   = $slideNumber
                    title        = $title
                    pattern      = $pattern
                    shapes       = [int]$slide.Shapes.Count
                    bodyBottomPt = [Math]::Round($cursor, 1)
                    warnings     = @($warnings)
                }
            }
            catch {
                throw "Slide $slideNumber failed: $($_.Exception.Message)"
            }
            finally {
                Release-OfficeFileComObject -ComObject $slide
            }
        }

        if (Test-Path -LiteralPath $outputFullPath) {
            throw "OutputPath appeared during the build: '$outputFullPath'."
        }

        $saveAttempted = $true
        $presentation.SaveAs($outputFullPath, $script:PpSaveAsOpenXmlPresentation)
        $outputWritten = $true
    }
    finally {
        Release-OfficeFileComObject -ComObject $slides
        if ($null -ne $presentation) {
            try { $presentation.Close() } catch {}
            Release-OfficeFileComObject -ComObject $presentation
            $presentation = $null
        }
        if ($null -ne $application) {
            try { $application.Quit() } catch {}
            Release-OfficeFileComObject -ComObject $application
            $application = $null
        }
        Complete-OfficeFileComCleanup
    }

    if (-not $outputWritten -or -not (Test-Path -LiteralPath $outputFullPath -PathType Leaf)) {
        throw "PowerPoint did not create the expected deck '$outputFullPath'."
    }

    $outputFile = Get-Item -LiteralPath $outputFullPath -ErrorAction Stop
    $allWarnings = @()
    foreach ($result in $slideResults) { $allWarnings += @($result.warnings) }
    if ($bulletFallback) {
        $allWarnings += 'PowerPoint rejected at least one bullet glyph or indent. Inspect rendered slides before use.'
    }

    $manifest = [pscustomobject][ordered]@{
        success           = $true
        command           = 'New-PowerPointDeck'
        spec              = [pscustomobject][ordered]@{ path = $specFullPath; sha256 = $specHash }
        template          = $templateFullPath
        output            = [pscustomobject][ordered]@{
            path       = $outputFullPath
            sha256     = (Get-OfficeFileSha256 -Path $outputFullPath)
            bytes      = [long]$outputFile.Length
            saveMethod = 'SaveAs'
        }
        settingsPath      = $settings.SettingsPath
        stylePath         = $style.StylePath
        powerPointVersion = $powerPointVersion
        slideCount        = $slideResults.Count
        slides            = @($slideResults)
        warnings          = @($allWarnings)
        verificationLimit = 'Visual layout is not verified. Render and inspect every slide.'
    }

    Write-OfficeFileJson -Value $manifest
}
catch {
    $failureRecord = $_
    $rollbackError = $null
    try {
        if ($saveAttempted -and -not $outputWritten -and $null -ne $outputFullPath -and
            (Test-Path -LiteralPath $outputFullPath -PathType Leaf)) {
            [IO.File]::Delete($outputFullPath)
        }
    }
    catch {
        $rollbackError = $_.Exception.Message
    }

    $context = @{ slides = @($slideResults) }
    if ($null -ne $specFullPath) { $context['specPath'] = $specFullPath }
    if ($null -ne $outputFullPath) { $context['outputPath'] = $outputFullPath }
    if ($null -ne $templateFullPath) { $context['templatePath'] = $templateFullPath }
    if ($null -ne $rollbackError) { $context['rollbackError'] = $rollbackError }
    Write-OfficeFileFailure -Command 'New-PowerPointDeck' -ErrorRecord $failureRecord -Context $context
    exit 1
}

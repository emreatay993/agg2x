Set-StrictMode -Version Latest

. (Join-Path -Path (Split-Path -Parent $PSScriptRoot) -ChildPath 'office\OfficeFile.Common.ps1')

function Get-PowerPointSettings {
    $repositoryRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
    if (-not [string]::IsNullOrWhiteSpace($env:OFFICE_HARNESS_SETTINGS)) {
        $settingsRoot = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($env:OFFICE_HARNESS_SETTINGS))
    }
    else {
        $settingsRoot = Join-Path -Path $repositoryRoot -ChildPath 'settings'
    }
    $localPath = Join-Path -Path $settingsRoot -ChildPath 'powerpoint.local.json'
    $examplePath = Join-Path -Path $settingsRoot -ChildPath 'powerpoint.example.json'

    if (Test-Path -LiteralPath $localPath -PathType Leaf) {
        $settingsPath = $localPath
    }
    elseif (Test-Path -LiteralPath $examplePath -PathType Leaf) {
        $settingsPath = $examplePath
    }
    else {
        throw 'PowerPoint settings were not found. Expected settings\powerpoint.local.json or settings\powerpoint.example.json.'
    }

    try {
        $settings = [IO.File]::ReadAllText($settingsPath) | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "Could not parse PowerPoint settings '$settingsPath': $($_.Exception.Message)"
    }

    $allowedRoots = @()
    $configuredRoots = Get-OfficeFilePropertyValue -InputObject $settings -Name 'allowedRoots' -DefaultValue @()
    foreach ($configuredRoot in @($configuredRoots)) {
        if ($null -eq $configuredRoot -or [string]::IsNullOrWhiteSpace([string]$configuredRoot)) {
            continue
        }

        $rootPath = Resolve-OfficeFileConfiguredPath -Path ([string]$configuredRoot) -RepositoryRoot $repositoryRoot
        if (-not (Test-Path -LiteralPath $rootPath -PathType Container)) {
            throw "Configured PowerPoint allowed root does not exist: '$rootPath'."
        }

        $allowedRoots += (Get-Item -LiteralPath $rootPath -ErrorAction Stop).FullName
    }

    $defaultOutputRoot = [string](Get-OfficeFilePropertyValue -InputObject $settings -Name 'defaultOutputRoot' -DefaultValue '')
    if (-not [string]::IsNullOrWhiteSpace($defaultOutputRoot)) {
        $defaultOutputRoot = Resolve-OfficeFileConfiguredPath -Path $defaultOutputRoot -RepositoryRoot $repositoryRoot
        if (Test-Path -LiteralPath $defaultOutputRoot -PathType Container) {
            $defaultOutputRoot = (Get-Item -LiteralPath $defaultOutputRoot -ErrorAction Stop).FullName
        }
    }

    $renderWidth = [int](Get-OfficeFilePropertyValue -InputObject $settings -Name 'renderWidth' -DefaultValue 1920)
    $renderHeight = [int](Get-OfficeFilePropertyValue -InputObject $settings -Name 'renderHeight' -DefaultValue 1080)
    if ($renderWidth -le 0 -or $renderHeight -le 0) {
        throw 'PowerPoint renderWidth and renderHeight settings must be positive integers.'
    }

    return [pscustomobject][ordered]@{
        SettingsPath      = $settingsPath
        RepositoryRoot    = $repositoryRoot
        AllowedRoots      = @($allowedRoots)
        DefaultOutputRoot = $defaultOutputRoot
        RenderWidth       = $renderWidth
        RenderHeight      = $renderHeight
    }
}

function Assert-PowerPointPresentationExtension {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    $extension = [IO.Path]::GetExtension($Path).ToLowerInvariant()
    $supportedExtensions = @('.ppt', '.pptx', '.pptm', '.pps', '.ppsx', '.ppsm', '.pot', '.potx', '.potm', '.odp')
    if ($supportedExtensions -notcontains $extension) {
        throw "Unsupported PowerPoint presentation extension '$extension'."
    }
}

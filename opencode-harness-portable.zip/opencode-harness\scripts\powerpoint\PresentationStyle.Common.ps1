Set-StrictMode -Version Latest

. (Join-Path -Path (Split-Path -Parent $PSScriptRoot) -ChildPath 'office\OfficeFile.Common.ps1')

# Office automation constants used by the deck builder.
$script:MsoTrue = -1
$script:MsoFalse = 0
$script:PpLayoutBlank = 12
$script:MsoTextOrientationHorizontal = 1
$script:MsoShapeRoundedRectangle = 5
$script:MsoShapeRightArrow = 33
$script:MsoShapeCross = 11
$script:MsoShapeFivePointStar = 92
$script:PpAlignLeft = 1
$script:PpAlignCenter = 2
$script:PpAlignRight = 3
$script:PpAlignJustify = 4
$script:MsoAnchorMiddle = 3

function Get-PresentationStyle {
    <#
        .SYNOPSIS
        Loads house style tokens, preferring presentation-style.local.json over the shipped example.
    #>
    $repositoryRoot = Split-Path -Parent (Split-Path -Parent $PSScriptRoot)
    if (-not [string]::IsNullOrWhiteSpace($env:OFFICE_HARNESS_SETTINGS)) {
        $settingsRoot = [IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($env:OFFICE_HARNESS_SETTINGS))
    }
    else {
        $settingsRoot = Join-Path -Path $repositoryRoot -ChildPath 'settings'
    }

    $localPath = Join-Path -Path $settingsRoot -ChildPath 'presentation-style.local.json'
    $examplePath = Join-Path -Path $settingsRoot -ChildPath 'presentation-style.example.json'

    if (Test-Path -LiteralPath $localPath -PathType Leaf) { $stylePath = $localPath }
    elseif (Test-Path -LiteralPath $examplePath -PathType Leaf) { $stylePath = $examplePath }
    else { throw 'Presentation style tokens were not found. Expected settings\presentation-style.local.json or settings\presentation-style.example.json.' }

    try {
        $style = [IO.File]::ReadAllText($stylePath) | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "Could not parse presentation style '$stylePath': $($_.Exception.Message)"
    }

    foreach ($required in @('slideSize', 'fonts', 'colours', 'bullets', 'geometry', 'rules')) {
        if ($null -eq $style.PSObject.Properties[$required]) {
            throw "Presentation style '$stylePath' is missing the '$required' section."
        }
    }

    Add-Member -InputObject $style -MemberType NoteProperty -Name 'StylePath' -Value $stylePath -Force
    return $style
}

function ConvertTo-OleColour {
    <#
        .SYNOPSIS
        Converts #RRGGBB to the BGR integer that Office COM expects.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [string]$Hex
    )

    $value = $Hex.Trim()
    if ($value.StartsWith('#')) { $value = $value.Substring(1) }
    if ($value.Length -ne 6) { throw "Colour '$Hex' must be in #RRGGBB form." }

    $r = [Convert]::ToInt32($value.Substring(0, 2), 16)
    $g = [Convert]::ToInt32($value.Substring(2, 2), 16)
    $b = [Convert]::ToInt32($value.Substring(4, 2), 16)
    return $r + ($g * 256) + ($b * 65536)
}

function Get-StyleValue {
    <#
        .SYNOPSIS
        Reads a nested style token and fails loudly rather than silently defaulting.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Style,

        [Parameter(Mandatory = $true)]
        [string]$Section,

        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    $sectionValue = $Style.PSObject.Properties[$Section]
    if ($null -eq $sectionValue) { throw "Style section '$Section' is missing." }
    $property = $sectionValue.Value.PSObject.Properties[$Name]
    if ($null -eq $property) { throw "Style token '$Section.$Name' is missing." }
    return $property.Value
}

function Get-SpecValue {
    <#
        .SYNOPSIS
        Reads an optional property from a deck-spec object.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$InputObject,

        [Parameter(Mandatory = $true)]
        [string[]]$Names,

        [object]$DefaultValue = $null
    )

    foreach ($name in $Names) {
        $property = $InputObject.PSObject.Properties[$name]
        if ($null -ne $property -and $null -ne $property.Value) {
            return $property.Value
        }
    }

    return $DefaultValue
}

function Set-ShapeTextStyle {
    <#
        .SYNOPSIS
        Applies font family, size, weight, colour, and alignment to a shape's text range.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Shape,

        [Parameter(Mandatory = $true)]
        [string]$FontName,

        [Parameter(Mandatory = $true)]
        [double]$FontSize,

        [Parameter(Mandatory = $true)]
        [bool]$Bold,

        [Parameter(Mandatory = $true)]
        [string]$Colour,

        [int]$Alignment = 1,

        [double]$LineSpacing = 1.0,

        [bool]$Italic = $false
    )

    $textFrame = $null
    $textRange = $null
    $font = $null
    $fontColour = $null
    $paragraphFormat = $null
    try {
        $textFrame = $Shape.TextFrame
        $textFrame.WordWrap = $script:MsoTrue
        try { $textFrame.AutoSize = 0 } catch {}
        $textRange = $textFrame.TextRange
        $font = $textRange.Font
        $font.Name = $FontName
        $font.Size = $FontSize
        $font.Bold = if ($Bold) { $script:MsoTrue } else { $script:MsoFalse }
        $font.Italic = if ($Italic) { $script:MsoTrue } else { $script:MsoFalse }
        $fontColour = $font.Color
        $fontColour.RGB = ConvertTo-OleColour -Hex $Colour
        $paragraphFormat = $textRange.ParagraphFormat
        $paragraphFormat.Alignment = $Alignment
        if ($LineSpacing -gt 0) {
            try { $paragraphFormat.SpaceWithin = $LineSpacing } catch {}
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $paragraphFormat
        Release-OfficeFileComObject -ComObject $fontColour
        Release-OfficeFileComObject -ComObject $font
        Release-OfficeFileComObject -ComObject $textRange
        Release-OfficeFileComObject -ComObject $textFrame
    }
}

function Set-ShapeFillAndLine {
    <#
        .SYNOPSIS
        Applies a solid fill and optional outline to a shape.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Shape,

        [string]$FillColour = '',

        [string]$LineColour = '',

        [double]$LineWeight = 1.0
    )

    # PowerShell variable names are case-insensitive, so a local named $fillColour would
    # be the same variable as the $FillColour parameter and would silently erase it.
    # Keep COM handles under names that cannot collide with a parameter.
    $fillFormat = $null
    $fillForeColor = $null
    $lineFormat = $null
    $lineForeColor = $null
    try {
        $fillFormat = $Shape.Fill
        if ([string]::IsNullOrWhiteSpace($FillColour)) {
            $fillFormat.Visible = $script:MsoFalse
        }
        else {
            $fillFormat.Visible = $script:MsoTrue
            $fillFormat.Solid()
            $fillForeColor = $fillFormat.ForeColor
            $fillForeColor.RGB = ConvertTo-OleColour -Hex $FillColour
            $fillFormat.Transparency = 0
        }

        $lineFormat = $Shape.Line
        if ([string]::IsNullOrWhiteSpace($LineColour)) {
            $lineFormat.Visible = $script:MsoFalse
        }
        else {
            $lineFormat.Visible = $script:MsoTrue
            $lineForeColor = $lineFormat.ForeColor
            $lineForeColor.RGB = ConvertTo-OleColour -Hex $LineColour
            $lineFormat.Weight = $LineWeight
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $lineForeColor
        Release-OfficeFileComObject -ComObject $lineFormat
        Release-OfficeFileComObject -ComObject $fillForeColor
        Release-OfficeFileComObject -ComObject $fillFormat
    }
}

function Add-StyledTextbox {
    <#
        .SYNOPSIS
        Adds a transparent textbox with house typography applied.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [string]$Text,

        [Parameter(Mandatory = $true)]
        [double]$Left,

        [Parameter(Mandatory = $true)]
        [double]$Top,

        [Parameter(Mandatory = $true)]
        [double]$Width,

        [Parameter(Mandatory = $true)]
        [double]$Height,

        [Parameter(Mandatory = $true)]
        [string]$FontName,

        [Parameter(Mandatory = $true)]
        [double]$FontSize,

        [Parameter(Mandatory = $true)]
        [bool]$Bold,

        [Parameter(Mandatory = $true)]
        [string]$Colour,

        [int]$Alignment = 1,

        [double]$LineSpacing = 1.0,

        [bool]$Italic = $false
    )

    $shapes = $null
    $shape = $null
    try {
        $shapes = $Slide.Shapes
        $shape = $shapes.AddTextbox($script:MsoTextOrientationHorizontal, $Left, $Top, $Width, $Height)
        $shape.TextFrame.TextRange.Text = $Text
        Set-ShapeTextStyle -Shape $shape -FontName $FontName -FontSize $FontSize -Bold $Bold -Colour $Colour -Alignment $Alignment -LineSpacing $LineSpacing -Italic $Italic
        return $shape
    }
    finally {
        Release-OfficeFileComObject -ComObject $shapes
    }
}

function Add-StyledRule {
    <#
        .SYNOPSIS
        Adds one of the two horizontal rules that frame every content slide.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [double]$Left,

        [Parameter(Mandatory = $true)]
        [double]$Top,

        [Parameter(Mandatory = $true)]
        [double]$Right,

        [Parameter(Mandatory = $true)]
        [string]$Colour,

        [Parameter(Mandatory = $true)]
        [double]$Weight
    )

    $shapes = $null
    $shape = $null
    $line = $null
    $lineColour = $null
    try {
        $shapes = $Slide.Shapes
        $shape = $shapes.AddLine($Left, $Top, $Right, $Top)
        $line = $shape.Line
        $line.Visible = $script:MsoTrue
        $lineColour = $line.ForeColor
        $lineColour.RGB = ConvertTo-OleColour -Hex $Colour
        $line.Weight = $Weight
    }
    finally {
        Release-OfficeFileComObject -ComObject $lineColour
        Release-OfficeFileComObject -ComObject $line
        Release-OfficeFileComObject -ComObject $shape
        Release-OfficeFileComObject -ComObject $shapes
    }
}

function Add-StyledBadge {
    <#
        .SYNOPSIS
        Adds a rounded solid badge with white bold centred text.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [string]$Text,

        [Parameter(Mandatory = $true)]
        [string]$FillColour,

        [Parameter(Mandatory = $true)]
        [double]$Left,

        [Parameter(Mandatory = $true)]
        [double]$Top,

        [Parameter(Mandatory = $true)]
        [double]$Width,

        [Parameter(Mandatory = $true)]
        [double]$Height,

        [Parameter(Mandatory = $true)]
        [string]$FontName,

        [Parameter(Mandatory = $true)]
        [double]$FontSize,

        [Parameter(Mandatory = $true)]
        [string]$FontColour
    )

    $shapes = $null
    $shape = $null
    $textFrame = $null
    try {
        $shapes = $Slide.Shapes
        $shape = $shapes.AddShape($script:MsoShapeRoundedRectangle, $Left, $Top, $Width, $Height)
        Set-ShapeFillAndLine -Shape $shape -FillColour $FillColour
        $shape.TextFrame.TextRange.Text = $Text
        $textFrame = $shape.TextFrame
        try { $textFrame.VerticalAnchor = $script:MsoAnchorMiddle } catch {}
        try { $textFrame.MarginLeft = 4; $textFrame.MarginRight = 4; $textFrame.MarginTop = 0; $textFrame.MarginBottom = 0 } catch {}
        Set-ShapeTextStyle -Shape $shape -FontName $FontName -FontSize $FontSize -Bold $true -Colour $FontColour -Alignment $script:PpAlignCenter
        return $shape
    }
    finally {
        Release-OfficeFileComObject -ComObject $textFrame
        Release-OfficeFileComObject -ComObject $shapes
    }
}

function Add-StyledCallout {
    <#
        .SYNOPSIS
        Adds a sand-filled aside box with a thin edge.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [string]$Text,

        [Parameter(Mandatory = $true)]
        [double]$Left,

        [Parameter(Mandatory = $true)]
        [double]$Top,

        [Parameter(Mandatory = $true)]
        [double]$Width,

        [Parameter(Mandatory = $true)]
        [double]$Height,

        [Parameter(Mandatory = $true)]
        [string]$FillColour,

        [Parameter(Mandatory = $true)]
        [string]$EdgeColour,

        [Parameter(Mandatory = $true)]
        [string]$FontName,

        [Parameter(Mandatory = $true)]
        [double]$FontSize,

        [Parameter(Mandatory = $true)]
        [string]$FontColour
    )

    $shapes = $null
    $shape = $null
    $textFrame = $null
    try {
        $shapes = $Slide.Shapes
        $shape = $shapes.AddShape($script:MsoShapeRoundedRectangle, $Left, $Top, $Width, $Height)
        Set-ShapeFillAndLine -Shape $shape -FillColour $FillColour -LineColour $EdgeColour -LineWeight 0.75
        $shape.TextFrame.TextRange.Text = $Text
        $textFrame = $shape.TextFrame
        try { $textFrame.VerticalAnchor = $script:MsoAnchorMiddle } catch {}
        Set-ShapeTextStyle -Shape $shape -FontName $FontName -FontSize $FontSize -Bold $false -Colour $FontColour -Alignment $script:PpAlignLeft
        return $shape
    }
    finally {
        Release-OfficeFileComObject -ComObject $textFrame
        Release-OfficeFileComObject -ComObject $shapes
    }
}

function Add-StyledArrow {
    <#
        .SYNOPSIS
        Adds a solid block arrow used to mark a transformation.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [double]$Left,

        [Parameter(Mandatory = $true)]
        [double]$Top,

        [Parameter(Mandatory = $true)]
        [double]$Width,

        [Parameter(Mandatory = $true)]
        [double]$Height,

        [Parameter(Mandatory = $true)]
        [string]$Colour
    )

    $shapes = $null
    $shape = $null
    try {
        $shapes = $Slide.Shapes
        $shape = $shapes.AddShape($script:MsoShapeRightArrow, $Left, $Top, $Width, $Height)
        Set-ShapeFillAndLine -Shape $shape -FillColour $Colour
        return $shape
    }
    finally {
        Release-OfficeFileComObject -ComObject $shapes
    }
}

function Add-StyledPlus {
    <#
        .SYNOPSIS
        Adds the red plus used between two superposed result fields.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [double]$Left,

        [Parameter(Mandatory = $true)]
        [double]$Top,

        [Parameter(Mandatory = $true)]
        [double]$Size,

        [Parameter(Mandatory = $true)]
        [string]$Colour
    )

    $shapes = $null
    $shape = $null
    try {
        $shapes = $Slide.Shapes
        $shape = $shapes.AddShape($script:MsoShapeCross, $Left, $Top, $Size, $Size)
        Set-ShapeFillAndLine -Shape $shape -FillColour $Colour
        return $shape
    }
    finally {
        Release-OfficeFileComObject -ComObject $shapes
    }
}

function Add-GoverningStar {
    <#
        .SYNOPSIS
        Adds the gold star that marks the single governing case on a comparison slide.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Slide,

        [Parameter(Mandatory = $true)]
        [double]$Left,

        [Parameter(Mandatory = $true)]
        [double]$Top,

        [double]$Size = 20
    )

    $shapes = $null
    $shape = $null
    try {
        $shapes = $Slide.Shapes
        $shape = $shapes.AddShape($script:MsoShapeFivePointStar, $Left, $Top, $Size, $Size)
        Set-ShapeFillAndLine -Shape $shape -FillColour '#FFC000' -LineColour '#BF9000' -LineWeight 0.75
        return $shape
    }
    finally {
        Release-OfficeFileComObject -ComObject $shapes
    }
}

function Set-BulletLadder {
    <#
        .SYNOPSIS
        Applies house bullet glyphs and indents to a body textbox.

        .DESCRIPTION
        Attempts real PowerPoint bullet formatting first. If the host PowerPoint rejects the
        bullet font or character, the caller is told so it can fall back to literal glyphs.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Shape,

        [Parameter(Mandatory = $true)]
        [int[]]$Levels,

        [Parameter(Mandatory = $true)]
        [object]$BulletStyle
    )

    $applied = $true
    $textFrame = $null
    $textRange = $null
    $ruler = $null
    try {
        $textFrame = $Shape.TextFrame
        $textRange = $textFrame.TextRange

        try {
            $ruler = $textFrame.Ruler
            for ($level = 1; $level -le 3; $level++) {
                $levelKey = "level$level"
                $levelProperty = $BulletStyle.PSObject.Properties[$levelKey]
                if ($null -eq $levelProperty) { continue }
                $indent = [double](Get-SpecValue -InputObject $levelProperty.Value -Names @('indentPt') -DefaultValue (18 * $level))
                $hanging = [double](Get-SpecValue -InputObject $levelProperty.Value -Names @('hangingPt') -DefaultValue 18)
                $rulerLevel = $null
                try {
                    $rulerLevel = $ruler.Levels.Item($level)
                    $rulerLevel.FirstMargin = [Math]::Max(0, $indent - $hanging)
                    $rulerLevel.LeftMargin = $indent
                }
                finally {
                    Release-OfficeFileComObject -ComObject $rulerLevel
                }
            }
        }
        catch {
            $applied = $false
        }

        for ($index = 0; $index -lt $Levels.Length; $index++) {
            $paragraph = $null
            $paragraphFormat = $null
            $bullet = $null
            $bulletFont = $null
            try {
                $paragraph = $textRange.Paragraphs($index + 1, 1)
                $level = $Levels[$index]
                $paragraph.IndentLevel = $level
                $levelProperty = $BulletStyle.PSObject.Properties["level$level"]
                if ($null -eq $levelProperty) { continue }
                $glyph = [string](Get-SpecValue -InputObject $levelProperty.Value -Names @('glyph') -DefaultValue '')
                $bulletFontName = [string](Get-SpecValue -InputObject $levelProperty.Value -Names @('font') -DefaultValue 'Arial')
                # Symbol fonts index characters in their own legacy encoding, so a Unicode
                # code point taken from the glyph would render as a missing-character box.
                $charCode = Get-SpecValue -InputObject $levelProperty.Value -Names @('charCode') -DefaultValue $null
                if ($null -eq $charCode) {
                    if ([string]::IsNullOrWhiteSpace($glyph)) { continue }
                    $charCode = [int][char]$glyph[0]
                }

                $paragraphFormat = $paragraph.ParagraphFormat
                $bullet = $paragraphFormat.Bullet
                $bullet.Visible = $script:MsoTrue
                $bulletFont = $bullet.Font
                $bulletFont.Name = $bulletFontName
                $bullet.Character = [int]$charCode
            }
            catch {
                $applied = $false
            }
            finally {
                Release-OfficeFileComObject -ComObject $bulletFont
                Release-OfficeFileComObject -ComObject $bullet
                Release-OfficeFileComObject -ComObject $paragraphFormat
                Release-OfficeFileComObject -ComObject $paragraph
            }
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $ruler
        Release-OfficeFileComObject -ComObject $textRange
        Release-OfficeFileComObject -ComObject $textFrame
    }

    return $applied
}

function Set-ParagraphColour {
    <#
        .SYNOPSIS
        Colours a single paragraph, used for load-case names keyed to plot series colours.
    #>
    param(
        [Parameter(Mandatory = $true)]
        [object]$Shape,

        [Parameter(Mandatory = $true)]
        [int]$ParagraphIndex,

        [Parameter(Mandatory = $true)]
        [string]$Colour
    )

    $textFrame = $null
    $textRange = $null
    $paragraph = $null
    $font = $null
    $fontColour = $null
    try {
        $textFrame = $Shape.TextFrame
        $textRange = $textFrame.TextRange
        $paragraph = $textRange.Paragraphs($ParagraphIndex, 1)
        $font = $paragraph.Font
        $fontColour = $font.Color
        $fontColour.RGB = ConvertTo-OleColour -Hex $Colour
    }
    finally {
        Release-OfficeFileComObject -ComObject $fontColour
        Release-OfficeFileComObject -ComObject $font
        Release-OfficeFileComObject -ComObject $paragraph
        Release-OfficeFileComObject -ComObject $textRange
        Release-OfficeFileComObject -ComObject $textFrame
    }
}

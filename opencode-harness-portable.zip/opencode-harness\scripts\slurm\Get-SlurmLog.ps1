[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$RemotePath,

    [int]$Lines = 0
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

try {
    . (Join-Path -Path $PSScriptRoot -ChildPath 'Slurm.Common.ps1')
    $settings = Get-SlurmSettings
    $remoteRoot = Get-SafeRemoteWorkRoot -Settings $settings
    Assert-RemotePathBelowRoot -Path $RemotePath -Root $remoteRoot

    if ($Lines -lt 0) {
        throw 'Lines must be a positive integer when supplied.'
    }
    if ($Lines -eq 0) {
        $lineCount = [Math]::Min(100, $settings.MaxTailLines)
    }
    else {
        $lineCount = $Lines
    }
    if ($lineCount -gt $settings.MaxTailLines) {
        throw "Lines must not exceed configured maxTailLines ($($settings.MaxTailLines))."
    }

    $quotedRoot = ConvertTo-ShellLiteral -Value $remoteRoot
    $quotedPath = ConvertTo-ShellLiteral -Value $RemotePath
    $remoteCommand = 'root=$(realpath -e -- {0}) || exit 20; path=$(realpath -e -- {1}) || exit 21; case "$path" in "$root"/*) ;; *) printf "%s\n" "Log path escapes remoteWorkRoot." >&2; exit 22 ;; esac; if [ ! -f "$path" ]; then printf "%s\n" "Log path is not a regular file." >&2; exit 23; fi; tail -n {2} -- "$path"' -f $quotedRoot, $quotedPath, $lineCount

    $result = Invoke-SlurmSsh -Settings $settings -RemoteCommand $remoteCommand
    Assert-SlurmSshSucceeded -Result $result -Operation 'Remote log read'

    ConvertTo-SlurmJson -InputObject ([ordered]@{
        ok             = $true
        remotePath     = $RemotePath
        requestedLines = $lineCount
        lines          = [string[]]$result.Output
    })
    exit 0
}
catch {
    ConvertTo-Json -InputObject ([ordered]@{
        ok    = $false
        error = $_.Exception.Message
    }) -Compress
    exit 1
}

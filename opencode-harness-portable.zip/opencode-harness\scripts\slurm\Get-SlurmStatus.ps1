[CmdletBinding()]
param(
    [string]$JobId
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

try {
    . (Join-Path -Path $PSScriptRoot -ChildPath 'Slurm.Common.ps1')
    $settings = Get-SlurmSettings
    $numericJobId = $null

    if ($PSBoundParameters.ContainsKey('JobId')) {
        $numericJobId = ConvertTo-PositiveJobId -JobId $JobId
        $squeueCommand = "squeue --noheader --jobs=$numericJobId --format='%i|%j|%T|%M|%R|%u|%P'"
        $sacctCommand = "sacct --noheader --parsable2 --allocations --jobs=$numericJobId --format=JobIDRaw,JobName,State,Elapsed,ExitCode,Partition,User"
    }
    else {
        $squeueCommand = "squeue --noheader --me --format='%i|%j|%T|%M|%R|%u|%P'"
        $sacctCommand = 'sacct --noheader --parsable2 --allocations --user="$(id -un)" --starttime=today --format=JobIDRaw,JobName,State,Elapsed,ExitCode,Partition,User'
    }

    $squeueResult = Invoke-SlurmSsh -Settings $settings -RemoteCommand $squeueCommand
    Assert-SlurmSshSucceeded -Result $squeueResult -Operation 'squeue status query'

    $sacctResult = Invoke-SlurmSsh -Settings $settings -RemoteCommand $sacctCommand
    Assert-SlurmSshSucceeded -Result $sacctResult -Operation 'sacct status query'

    $squeueRecords = @(ConvertFrom-SqueueOutput -Lines $squeueResult.Output)
    $sacctRecords = @(ConvertFrom-SacctOutput -Lines $sacctResult.Output)

    ConvertTo-SlurmJson -InputObject ([ordered]@{
        ok     = $true
        jobId  = $numericJobId
        squeue = $squeueRecords
        sacct  = $sacctRecords
    })
    exit 0
}
catch {
    ConvertTo-Json -InputObject ([ordered]@{
        ok    = $false
        error = $_.Exception.Message
    }) -Compress
    exit 1
}

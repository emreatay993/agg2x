Set-StrictMode -Version Latest

function Get-RequiredSetting {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Settings,

        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    $property = $Settings.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) {
        throw "SLURM setting '$Name' is required."
    }

    return $property.Value
}

function Get-SlurmSettings {
    [CmdletBinding()]
    param()

    if (-not [string]::IsNullOrWhiteSpace($env:OFFICE_HARNESS_SETTINGS)) {
        $settingsDirectory = [System.IO.Path]::GetFullPath([Environment]::ExpandEnvironmentVariables($env:OFFICE_HARNESS_SETTINGS))
    }
    else {
        $settingsDirectory = [System.IO.Path]::GetFullPath((Join-Path -Path $PSScriptRoot -ChildPath '..\..\settings'))
    }
    $localPath = Join-Path -Path $settingsDirectory -ChildPath 'slurm.local.json'
    $examplePath = Join-Path -Path $settingsDirectory -ChildPath 'slurm.example.json'

    if (Test-Path -LiteralPath $localPath -PathType Leaf) {
        $settingsPath = $localPath
    }
    elseif (Test-Path -LiteralPath $examplePath -PathType Leaf) {
        $settingsPath = $examplePath
    }
    else {
        throw 'Neither settings\slurm.local.json nor settings\slurm.example.json exists.'
    }

    try {
        $settings = [System.IO.File]::ReadAllText($settingsPath) | ConvertFrom-Json
    }
    catch {
        throw "Cannot read SLURM settings '$settingsPath': $($_.Exception.Message)"
    }

    $hostAlias = [string](Get-RequiredSetting -Settings $settings -Name 'hostAlias')
    if ($hostAlias -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]*$') {
        throw "SLURM setting 'hostAlias' is empty or contains unsafe characters."
    }

    $sshExecutable = [string](Get-RequiredSetting -Settings $settings -Name 'sshExecutable')
    if (-not [string]::Equals(
            [System.IO.Path]::GetFileName($sshExecutable),
            'ssh.exe',
            [System.StringComparison]::OrdinalIgnoreCase)) {
        throw "SLURM setting 'sshExecutable' must name ssh.exe."
    }

    $sshCommands = @(Get-Command -Name $sshExecutable -CommandType Application -ErrorAction Stop)
    if ($sshCommands.Count -eq 0) {
        throw "OpenSSH executable '$sshExecutable' was not found."
    }

    $connectTimeoutSeconds = 0
    $timeoutText = [string](Get-RequiredSetting -Settings $settings -Name 'connectTimeoutSeconds')
    if (-not [int]::TryParse($timeoutText, [ref]$connectTimeoutSeconds) -or
        $connectTimeoutSeconds -lt 1 -or $connectTimeoutSeconds -gt 300) {
        throw "SLURM setting 'connectTimeoutSeconds' must be an integer from 1 through 300."
    }

    $maxTailLines = 0
    $maxTailText = [string](Get-RequiredSetting -Settings $settings -Name 'maxTailLines')
    if (-not [int]::TryParse($maxTailText, [ref]$maxTailLines) -or
        $maxTailLines -lt 1 -or $maxTailLines -gt 10000) {
        throw "SLURM setting 'maxTailLines' must be an integer from 1 through 10000."
    }

    $partitionSetting = Get-RequiredSetting -Settings $settings -Name 'allowedPartitions'
    if ($partitionSetting -is [string]) {
        throw "SLURM setting 'allowedPartitions' must be an array."
    }

    $allowedPartitions = @()
    foreach ($partitionValue in @($partitionSetting)) {
        $partition = [string]$partitionValue
        if ($partition -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]*$') {
            throw "SLURM setting 'allowedPartitions' contains an unsafe partition name."
        }
        $allowedPartitions += $partition
    }

    return [pscustomobject]@{
        HostAlias             = $hostAlias
        SshExecutable         = [string]$sshCommands[0].Path
        ConnectTimeoutSeconds = $connectTimeoutSeconds
        MappedDriveRoot       = [string](Get-RequiredSetting -Settings $settings -Name 'mappedDriveRoot')
        RemoteWorkRoot        = [string](Get-RequiredSetting -Settings $settings -Name 'remoteWorkRoot')
        AllowedPartitions     = [string[]]$allowedPartitions
        MaxTailLines          = $maxTailLines
    }
}

function Invoke-SlurmSsh {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Settings,

        [Parameter(Mandatory = $true)]
        [string]$RemoteCommand
    )

    $sshArguments = @(
        '-o'
        'BatchMode=yes'
        '-o'
        'StrictHostKeyChecking=yes'
        '-o'
        "ConnectTimeout=$($Settings.ConnectTimeoutSeconds)"
        '--'
        [string]$Settings.HostAlias
        $RemoteCommand
    )

    $errorPath = [IO.Path]::GetTempFileName()
    try {
        $nativeOutput = @(& $Settings.SshExecutable @sshArguments 2> $errorPath)
        $nativeExitCode = $LASTEXITCODE
        $outputLines = @($nativeOutput | ForEach-Object { [string]$_ })
        $errorLines = if (Test-Path -LiteralPath $errorPath -PathType Leaf) {
            @(Get-Content -LiteralPath $errorPath -Encoding UTF8 | ForEach-Object { [string]$_ })
        }
        else { @() }
    }
    finally {
        if (Test-Path -LiteralPath $errorPath -PathType Leaf) { Remove-Item -LiteralPath $errorPath -Force }
    }

    return [pscustomobject]@{
        ExitCode = [int]$nativeExitCode
        Output   = [string[]]$outputLines
        Error    = [string[]]$errorLines
    }
}

function Assert-SlurmSshSucceeded {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Result,

        [Parameter(Mandatory = $true)]
        [string]$Operation
    )

    if ($Result.ExitCode -eq 0) {
        return
    }

    $detail = [string]::Join([Environment]::NewLine, [string[]]@($Result.Error + $Result.Output)).Trim()
    if ([string]::IsNullOrWhiteSpace($detail)) {
        $detail = 'No diagnostic output was returned.'
    }
    throw "$Operation failed with SSH exit code $($Result.ExitCode): $detail"
}

function ConvertTo-SlurmJson {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$InputObject
    )

    return ConvertTo-Json -InputObject $InputObject -Depth 8 -Compress
}

function ConvertTo-ShellLiteral {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Value
    )

    if ($Value.Contains("'")) {
        throw 'A remote value contains an unsafe quote character.'
    }
    return "'$Value'"
}

function Assert-SafeRemotePath {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    if ($Path -notmatch '^/[A-Za-z0-9._/-]+$' -or $Path.Contains('//')) {
        throw "$Name must be an absolute POSIX path containing only letters, digits, dot, underscore, slash, and hyphen."
    }

    foreach ($segment in @($Path.Split('/'))) {
        if ($segment -eq '.' -or $segment -eq '..') {
            throw "$Name must not contain dot path segments."
        }
    }
}

function Get-SafeRemoteWorkRoot {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [object]$Settings
    )

    $root = ([string]$Settings.RemoteWorkRoot).TrimEnd([char]'/')
    if ([string]::IsNullOrWhiteSpace($root) -or $root -eq '/') {
        throw "SLURM setting 'remoteWorkRoot' must identify a directory below the filesystem root."
    }
    Assert-SafeRemotePath -Path $root -Name "SLURM setting 'remoteWorkRoot'"
    return $root
}

function Assert-RemotePathBelowRoot {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$Root
    )

    Assert-SafeRemotePath -Path $Path -Name 'Remote path'
    if (-not $Path.StartsWith($Root + '/', [System.StringComparison]::Ordinal)) {
        throw "Remote path must be below configured remoteWorkRoot '$Root'."
    }
}

function ConvertTo-PositiveJobId {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [string]$JobId
    )

    if ($JobId -notmatch '^[1-9][0-9]*$') {
        throw 'JobId must be an explicit positive numeric SLURM job ID.'
    }

    $numericJobId = [long]0
    if (-not [long]::TryParse($JobId, [ref]$numericJobId)) {
        throw 'JobId is larger than a signed 64-bit integer.'
    }
    return $numericJobId
}

function ConvertFrom-DelimitedSlurmRows {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [string[]]$Lines,

        [Parameter(Mandatory = $true)]
        [string[]]$Columns,

        [Parameter(Mandatory = $true)]
        [string]$Source
    )

    foreach ($line in $Lines) {
        if ([string]::IsNullOrWhiteSpace($line)) {
            continue
        }

        $parts = @($line -split '\|', $Columns.Count)
        if ($parts.Count -ne $Columns.Count) {
            throw "$Source returned a malformed record: $line"
        }

        $record = [ordered]@{}
        for ($index = 0; $index -lt $Columns.Count; $index++) {
            $record[$Columns[$index]] = $parts[$index]
        }
        [pscustomobject]$record
    }
}

function ConvertFrom-SqueueOutput {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [string[]]$Lines
    )

    return ConvertFrom-DelimitedSlurmRows -Lines $Lines -Source 'squeue' -Columns @(
        'jobId'
        'name'
        'state'
        'elapsed'
        'reason'
        'user'
        'partition'
    )
}

function ConvertFrom-SacctOutput {
    [CmdletBinding()]
    param(
        [Parameter(Mandatory = $true)]
        [AllowEmptyCollection()]
        [string[]]$Lines
    )

    return ConvertFrom-DelimitedSlurmRows -Lines $Lines -Source 'sacct' -Columns @(
        'jobId'
        'name'
        'state'
        'elapsed'
        'exitCode'
        'partition'
        'user'
    )
}

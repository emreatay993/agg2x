[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$JobId
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

try {
    . (Join-Path -Path $PSScriptRoot -ChildPath 'Slurm.Common.ps1')
    $settings = Get-SlurmSettings
    $numericJobId = ConvertTo-PositiveJobId -JobId $JobId

    $userResult = Invoke-SlurmSsh -Settings $settings -RemoteCommand 'id -un'
    Assert-SlurmSshSucceeded -Result $userResult -Operation 'Remote user inspection'
    if ($userResult.Output.Count -ne 1 -or
        $userResult.Output[0] -notmatch '^[A-Za-z0-9._-]+$') {
        throw 'Could not determine a single safe remote user name.'
    }
    $remoteUser = $userResult.Output[0]

    $inspectCommand = "squeue --noheader --jobs=$numericJobId --format='%i|%j|%T|%M|%R|%u|%P'"
    $inspectResult = Invoke-SlurmSsh -Settings $settings -RemoteCommand $inspectCommand
    Assert-SlurmSshSucceeded -Result $inspectResult -Operation 'Job inspection'
    $jobs = @(ConvertFrom-SqueueOutput -Lines $inspectResult.Output)
    if ($jobs.Count -eq 0) {
        throw "Job $numericJobId is not an active job visible to squeue; it was not cancelled."
    }
    foreach ($job in $jobs) {
        if (-not [string]::Equals(
                [string]$job.user,
                $remoteUser,
                [System.StringComparison]::Ordinal)) {
            throw "Job $numericJobId is not owned by the remote SSH user; it was not cancelled."
        }
    }

    $cancelResult = Invoke-SlurmSsh -Settings $settings -RemoteCommand "scancel $numericJobId"
    Assert-SlurmSshSucceeded -Result $cancelResult -Operation 'scancel'

    ConvertTo-SlurmJson -InputObject ([ordered]@{
        ok        = $true
        jobId     = $numericJobId
        inspected = $jobs
        cancelled = $true
    })
    exit 0
}
catch {
    ConvertTo-Json -InputObject ([ordered]@{
        ok    = $false
        error = $_.Exception.Message
    }) -Compress
    exit 1
}

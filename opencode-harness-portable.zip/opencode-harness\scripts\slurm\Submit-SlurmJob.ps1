[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$LocalScriptPath,

    [Parameter(Mandatory = $true)]
    [string]$Partition
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

try {
    . (Join-Path -Path $PSScriptRoot -ChildPath 'Slurm.Common.ps1')
    $settings = Get-SlurmSettings

    if ($Partition -notmatch '^[A-Za-z0-9][A-Za-z0-9._-]*$') {
        throw 'Partition contains unsafe characters.'
    }
    if ($settings.AllowedPartitions -cnotcontains $Partition) {
        throw "Partition '$Partition' is not listed in allowedPartitions."
    }

    if ([string]::IsNullOrWhiteSpace($settings.MappedDriveRoot)) {
        throw "SLURM setting 'mappedDriveRoot' is required for submission."
    }

    $mappedRootItem = Get-Item -LiteralPath $settings.MappedDriveRoot -ErrorAction Stop
    if (-not $mappedRootItem.PSIsContainer) {
        throw "SLURM setting 'mappedDriveRoot' must identify a directory."
    }
    $scriptItem = Get-Item -LiteralPath $LocalScriptPath -ErrorAction Stop
    if ($scriptItem.PSIsContainer) {
        throw 'LocalScriptPath must identify a file.'
    }

    $separatorCharacters = [char[]]@(
        [System.IO.Path]::DirectorySeparatorChar,
        [System.IO.Path]::AltDirectorySeparatorChar
    )
    $mappedRootPath = $mappedRootItem.FullName.TrimEnd($separatorCharacters)
    $mappedRootPrefix = $mappedRootPath + [System.IO.Path]::DirectorySeparatorChar
    $resolvedScriptPath = $scriptItem.FullName

    if (-not $resolvedScriptPath.StartsWith(
            $mappedRootPrefix,
            [System.StringComparison]::OrdinalIgnoreCase)) {
        throw 'LocalScriptPath must be below configured mappedDriveRoot.'
    }

    $relativePath = $resolvedScriptPath.Substring($mappedRootPrefix.Length)
    if ($relativePath -notmatch '^[A-Za-z0-9._\\/-]+$') {
        throw 'The script path below mappedDriveRoot contains unsafe characters.'
    }
    foreach ($segment in @($relativePath.Split([char[]]@('\', '/')))) {
        if ([string]::IsNullOrWhiteSpace($segment) -or $segment -eq '.' -or $segment -eq '..') {
            throw 'The script path below mappedDriveRoot contains an unsafe path segment.'
        }
    }

    $scriptBytes = [System.IO.File]::ReadAllBytes($resolvedScriptPath)
    if ($scriptBytes -contains [byte]13) {
        throw 'The local job script contains CR or CRLF line endings; LF is required.'
    }
    if ($scriptBytes -contains [byte]0) {
        throw 'The local job script contains unsafe NUL bytes.'
    }

    $remoteRoot = Get-SafeRemoteWorkRoot -Settings $settings
    $remoteRelativePath = $relativePath.Replace('\', '/')
    $remoteScriptPath = $remoteRoot + '/' + $remoteRelativePath
    Assert-RemotePathBelowRoot -Path $remoteScriptPath -Root $remoteRoot

    $quotedRoot = ConvertTo-ShellLiteral -Value $remoteRoot
    $quotedScript = ConvertTo-ShellLiteral -Value $remoteScriptPath
    $quotedPartition = ConvertTo-ShellLiteral -Value $Partition
    $remoteCommand = 'root=$(realpath -e -- {0}) || exit 20; script=$(realpath -e -- {1}) || exit 21; case "$script" in "$root"/*) ;; *) printf "%s\n" "Job script escapes remoteWorkRoot." >&2; exit 22 ;; esac; if [ ! -f "$script" ]; then printf "%s\n" "Job script is not a regular file." >&2; exit 23; fi; bash -n -- "$script" || exit $?; sbatch --parsable --partition={2} -- "$script"' -f $quotedRoot, $quotedScript, $quotedPartition

    $result = Invoke-SlurmSsh -Settings $settings -RemoteCommand $remoteCommand
    Assert-SlurmSshSucceeded -Result $result -Operation 'SLURM job validation and submission'

    $submissionText = [string]::Join('', [string[]]$result.Output).Trim()
    if ($submissionText -notmatch '^(?<jobId>[1-9][0-9]*)(?:;[A-Za-z0-9._-]+)?$') {
        throw "sbatch --parsable returned an unexpected value: $submissionText"
    }

    $numericJobId = ConvertTo-PositiveJobId -JobId $Matches['jobId']
    ConvertTo-SlurmJson -InputObject ([ordered]@{
        ok         = $true
        jobId      = $numericJobId
        partition  = $Partition
        remotePath = $remoteScriptPath
    })
    exit 0
}
catch {
    ConvertTo-Json -InputObject ([ordered]@{
        ok    = $false
        error = $_.Exception.Message
    }) -Compress
    exit 1
}

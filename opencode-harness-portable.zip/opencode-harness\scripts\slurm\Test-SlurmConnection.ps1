[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

try {
    . (Join-Path -Path $PSScriptRoot -ChildPath 'Slurm.Common.ps1')
    $settings = Get-SlurmSettings
    $result = Invoke-SlurmSsh -Settings $settings -RemoteCommand 'command -v bash sbatch squeue sacct scancel >/dev/null && printf "%s|%s\n" "$(id -un)" "$(hostname)"'
    Assert-SlurmSshSucceeded -Result $result -Operation 'SLURM connection test'

    ConvertTo-SlurmJson -InputObject ([ordered]@{
        ok        = $true
        connected = $true
        hostAlias = $settings.HostAlias
        identity  = @($result.Output)
    })
    exit 0
}
catch {
    ConvertTo-Json -InputObject ([ordered]@{
        ok    = $false
        error = $_.Exception.Message
    }) -Compress
    exit 1
}

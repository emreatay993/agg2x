#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][ValidateSet('Internet', 'Intranet')][string]$Machine,
    [Parameter(Mandatory = $true)][string]$InstallRoot,
    [switch]$UseExistingOpenCode,
    [switch]$LiveModel,
    [switch]$LiveOffice,
    [switch]$LiveHpc
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$checks = New-Object System.Collections.ArrayList
$openCode = $null
function Add-Check {
    param([string]$Name, [ValidateSet('pass', 'warning', 'fail')][string]$Status, [string]$Detail)
    $null = $checks.Add([pscustomobject]@{ Name = $Name; Status = $Status; Detail = $Detail })
}

function Test-ComRegistration {
    param([string]$ProgId)
    try {
        $type = [Type]::GetTypeFromProgID($ProgId, $false)
        return $null -ne $type
    }
    catch { return $false }
}

function Test-AssemblyLoad {
    param([string]$AssemblyName)
    try {
        Add-Type -AssemblyName $AssemblyName -ErrorAction Stop
        return $true
    }
    catch { return $false }
}

try {
    $installRootFull = [IO.Path]::GetFullPath($InstallRoot)
    $runtimeRoot = Join-Path $installRootFull 'runtime'
    $stateRoot = Join-Path $installRootFull 'state'
    $configPath = Join-Path $stateRoot 'opencode.json'

    try {
        $powerShellVersion = $PSVersionTable.PSVersion.ToString()
        Add-Check 'PowerShell' 'pass' "Windows PowerShell $powerShellVersion"
    }
    catch { Add-Check 'PowerShell' 'fail' $_.Exception.Message }

    try {
        $openCode = @(Get-Command opencode -CommandType Application -ErrorAction Stop)[0]
        $version = (& $openCode.Path --version 2>&1 | Out-String).Trim()
        if ($LASTEXITCODE -ne 0) { throw "opencode --version exited $LASTEXITCODE." }
        Add-Check 'OpenCode' 'pass' $version
    }
    catch { Add-Check 'OpenCode' 'fail' $_.Exception.Message }

    try {
        $configText = [IO.File]::ReadAllText($configPath)
        if ($configText -cmatch '__[A-Z0-9_]+__') { throw "Unresolved template token: $($Matches[0])" }
        $config = $configText | ConvertFrom-Json -ErrorAction Stop
        Add-Check 'Generated config JSON' 'pass' $configPath
    }
    catch { Add-Check 'Generated config JSON' 'fail' $_.Exception.Message; $config = $null }

    if ($null -ne $openCode) {
        try {
            $resolvedConfig = & $openCode.Path debug config 2>&1
            if ($LASTEXITCODE -ne 0) { throw ($resolvedConfig | Out-String) }
            $null = ($resolvedConfig | Out-String) | ConvertFrom-Json -ErrorAction Stop
            Add-Check 'OpenCode resolved config' 'pass' 'Schema and discovered agents/commands loaded.'
        }
        catch { Add-Check 'OpenCode resolved config' 'fail' $_.Exception.Message }
    }

    try {
        $parseErrors = @()
        $scriptFiles = @(Get-ChildItem -LiteralPath (Join-Path $runtimeRoot 'scripts') -Recurse -File | Where-Object { $_.Extension -in @('.ps1', '.psm1') })
        foreach ($file in $scriptFiles) {
            $tokens = $null
            $errors = $null
            [void][Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
            if ($errors.Count -gt 0) { $parseErrors += @($errors | ForEach-Object { "$($file.Name):$($_.Extent.StartLineNumber) $($_.Message)" }) }
        }
        if ($parseErrors.Count -gt 0) { throw ($parseErrors -join '; ') }
        Add-Check 'PowerShell parse' 'pass' "$($scriptFiles.Count) files"
    }
    catch { Add-Check 'PowerShell parse' 'fail' $_.Exception.Message }

    $pluginPackage = Join-Path $runtimeRoot 'opencode\node_modules\@opencode-ai\plugin\package.json'
    if (Test-Path -LiteralPath $pluginPackage -PathType Leaf) { Add-Check 'Offline tool dependencies' 'pass' $pluginPackage }
    else { Add-Check 'Offline tool dependencies' 'fail' 'Run Prepare-Dependencies.ps1 on an internet PC and transfer the complete folder.' }

    if ($UseExistingOpenCode) {
        Add-Check 'Model configuration' 'pass' 'Using the existing OpenCode provider and model.'
    }
    elseif ([string]::IsNullOrWhiteSpace($env:OFFICE_LLM_BASE_URL)) {
        Add-Check 'Internal API URL' 'fail' 'OFFICE_LLM_BASE_URL is not set.'
    }
    else {
        try {
            $safeApiUri = [Uri]$env:OFFICE_LLM_BASE_URL
            if (-not [string]::IsNullOrEmpty($safeApiUri.UserInfo) -or -not [string]::IsNullOrEmpty($safeApiUri.Query)) {
                throw 'The API URL contains credentials or query parameters.'
            }
            Add-Check 'Internal API URL' 'pass' ($safeApiUri.Scheme + '://' + $safeApiUri.Authority + $safeApiUri.AbsolutePath)
        }
        catch { Add-Check 'Internal API URL' 'fail' $_.Exception.Message }
    }

    $approvedRoots = @()
    try {
        $powerPointSettingsPath = Join-Path $env:OFFICE_HARNESS_SETTINGS 'powerpoint.local.json'
        $powerPointSettings = [IO.File]::ReadAllText($powerPointSettingsPath) | ConvertFrom-Json -ErrorAction Stop
        $approvedRoots = @($powerPointSettings.allowedRoots | Where-Object { -not [string]::IsNullOrWhiteSpace([string]$_) })
        if ($approvedRoots.Count -eq 0) { throw 'Configure at least one shared Office allowedRoots entry.' }
        foreach ($approvedRoot in $approvedRoots) {
            $expandedRoot = [Environment]::ExpandEnvironmentVariables([string]$approvedRoot)
            if (-not (Test-Path -LiteralPath $expandedRoot -PathType Container)) { throw "Office root does not exist: '$expandedRoot'." }
        }
        Add-Check 'Office roots' 'pass' ($approvedRoots -join ', ')
    }
    catch { Add-Check 'Office roots' 'fail' $_.Exception.Message }

    try {
        if ($null -eq $config) { throw 'Generated OpenCode config is unavailable.' }
        $externalDirectoryRules = $config.permission.external_directory
        if ($externalDirectoryRules -is [string]) { throw 'External-directory permissions are not path-specific.' }
        $catchAllRule = $externalDirectoryRules.PSObject.Properties['*']
        if ($null -eq $catchAllRule -or [string]$catchAllRule.Value -ne 'ask') {
            throw 'Unapproved external directories must remain ask.'
        }
        foreach ($approvedRoot in $approvedRoots) {
            $rootPattern = (Get-Item -LiteralPath ([Environment]::ExpandEnvironmentVariables([string]$approvedRoot)) -ErrorAction Stop).FullName.TrimEnd('\', '/')
            if ($rootPattern -match '^[A-Za-z]:$') { $rootPattern += '\' }
            foreach ($expectedPattern in @($rootPattern, ($rootPattern.TrimEnd('\', '/') + '\**'))) {
                $rule = $externalDirectoryRules.PSObject.Properties[$expectedPattern]
                if ($null -eq $rule -or [string]$rule.Value -ne 'allow') {
                    throw "OpenCode external-directory permission is missing for '$expectedPattern'."
                }
            }
        }
        Add-Check 'External directory permissions' 'pass' "$($approvedRoots.Count) Office root(s) synchronized"
    }
    catch { Add-Check 'External directory permissions' 'fail' $_.Exception.Message }

    if ($Machine -eq 'Internet') {
        try {
            $node = @(Get-Command node.exe -CommandType Application -ErrorAction Stop)[0]
            $nodeVersionText = (& $node.Path --version).TrimStart('v')
            $nodeVersion = $null
            if (-not [Version]::TryParse($nodeVersionText, [ref]$nodeVersion) -or $nodeVersion.Major -lt 20) {
                throw "Node.js 20 or newer is required; found '$nodeVersionText'."
            }
            Add-Check 'Node.js' 'pass' ('v' + $nodeVersionText)
        }
        catch { Add-Check 'Node.js' 'fail' $_.Exception.Message }
        $classicOutlookRegistered = Test-ComRegistration 'Outlook.Application'
        if ($classicOutlookRegistered) { Add-Check 'Classic Outlook COM' 'pass' 'Registered' }
        else { Add-Check 'Classic Outlook COM' 'warning' 'Classic Outlook is unavailable; use the dedicated Outlook Web reader.' }
        if (Test-ComRegistration 'Word.Application') { Add-Check 'Word COM' 'pass' 'Registered' }
        else { Add-Check 'Word COM' 'fail' 'Desktop Word is not registered.' }
        if (Test-AssemblyLoad 'Microsoft.Office.Interop.Word') { Add-Check 'Word interop assembly' 'pass' 'Loadable' }
        else { Add-Check 'Word interop assembly' 'fail' 'The installed Word interop assembly required for PDF export is unavailable.' }
        if (Test-ComRegistration 'Excel.Application') { Add-Check 'Excel COM' 'pass' 'Registered' }
        else { Add-Check 'Excel COM' 'fail' 'Desktop Excel is not registered.' }
        if (Test-ComRegistration 'PowerPoint.Application') { Add-Check 'PowerPoint COM' 'pass' 'Registered' }
        else { Add-Check 'PowerPoint COM' 'fail' 'Desktop PowerPoint is not registered.' }
        $playwrightCli = Join-Path $runtimeRoot 'browser-mcp\node_modules\@playwright\mcp\cli.js'
        if (Test-Path -LiteralPath $playwrightCli -PathType Leaf) { Add-Check 'Playwright MCP' 'pass' $playwrightCli }
        else { Add-Check 'Playwright MCP' 'fail' 'Pinned Playwright MCP files are missing.' }
        try {
            if ($null -eq $config -or $null -eq $config.mcp.outlook_web -or -not [bool]$config.mcp.outlook_web.enabled) {
                throw 'The dedicated outlook_web MCP is not enabled.'
            }
            $outlookWebAgent = Join-Path $runtimeRoot 'opencode\agents\outlook-web-reader.md'
            $outlookWebState = Join-Path $stateRoot 'outlook-web-browser'
            $outlookWebOutput = Join-Path $stateRoot 'outlook-web-output'
            foreach ($requiredPath in @($outlookWebAgent, $outlookWebState, $outlookWebOutput)) {
                if (-not (Test-Path -LiteralPath $requiredPath)) { throw "Missing Outlook Web path: '$requiredPath'." }
            }
            Add-Check 'Outlook Web reader' 'pass' 'Dedicated MCP, agent, profile, and output directories are present.'
        }
        catch { Add-Check 'Outlook Web reader' 'fail' $_.Exception.Message }
        if ($LiveOffice) {
            if ($classicOutlookRegistered) {
                try {
                    $result = & (Join-Path $runtimeRoot 'scripts\outlook\Test-OutlookConnection.ps1') 2>&1
                    if ($LASTEXITCODE -ne 0) { throw ($result | Out-String) }
                    Add-Check 'Classic Outlook live read-only' 'pass' 'Connected without reading message bodies.'
                }
                catch { Add-Check 'Classic Outlook live read-only' 'fail' $_.Exception.Message }
            }
            else {
                Add-Check 'Outlook Web live check' 'warning' 'Complete the dedicated browser sign-in/MFA and run /mail-web-summary manually.'
            }
        }
    }
    else {
        try {
            $ssh = Get-Command ssh.exe -CommandType Application -ErrorAction Stop
            Add-Check 'OpenSSH' 'pass' $ssh.Source
        }
        catch { Add-Check 'OpenSSH' 'fail' $_.Exception.Message }
        if (Test-ComRegistration 'Word.Application') { Add-Check 'Word COM' 'pass' 'Registered' }
        else { Add-Check 'Word COM' 'warning' 'Desktop Word is not registered.' }
        if (Test-AssemblyLoad 'Microsoft.Office.Interop.Word') { Add-Check 'Word interop assembly' 'pass' 'Loadable' }
        else { Add-Check 'Word interop assembly' 'warning' 'The installed Word interop assembly required for PDF export is unavailable.' }
        if (Test-ComRegistration 'Excel.Application') { Add-Check 'Excel COM' 'pass' 'Registered' }
        else { Add-Check 'Excel COM' 'warning' 'Desktop Excel is not registered.' }
        if (Test-ComRegistration 'PowerPoint.Application') { Add-Check 'PowerPoint COM' 'pass' 'Registered' }
        else { Add-Check 'PowerPoint COM' 'warning' 'Desktop PowerPoint is not registered.' }
        try {
            $outlookWebAgent = Join-Path $runtimeRoot 'opencode\agents\outlook-web-reader.md'
            if (Test-Path -LiteralPath $outlookWebAgent) { throw 'Outlook Web agent is present in the intranet runtime.' }
            $mcpProperty = if ($null -ne $config) { $config.PSObject.Properties['mcp'] } else { $null }
            if ($null -ne $mcpProperty -and $null -ne $mcpProperty.Value.PSObject.Properties['outlook_web']) {
                throw 'Outlook Web MCP is present in the intranet config.'
            }
            Add-Check 'Outlook Web absent' 'pass' 'Intranet runtime contains no Outlook Web capability.'
        }
        catch { Add-Check 'Outlook Web absent' 'fail' $_.Exception.Message }
        if ($LiveHpc) {
            try {
                $result = & (Join-Path $runtimeRoot 'scripts\slurm\Test-SlurmConnection.ps1') 2>&1
                if ($LASTEXITCODE -ne 0) { throw ($result | Out-String) }
                Add-Check 'HPC live connection' 'pass' ($result | Out-String).Trim()
            }
            catch { Add-Check 'HPC live connection' 'fail' $_.Exception.Message }
        }
    }

    if ($LiveModel -and $null -ne $config) {
        if (-not $UseExistingOpenCode) {
            try {
                $headers = @{}
                if (-not [string]::IsNullOrWhiteSpace($env:OFFICE_LLM_API_KEY)) { $headers.Authorization = 'Bearer ' + $env:OFFICE_LLM_API_KEY }
                $modelsUri = $env:OFFICE_LLM_BASE_URL.TrimEnd('/') + '/models'
                $models = Invoke-RestMethod -Uri $modelsUri -Headers $headers -Method Get -TimeoutSec 30
                $availableIds = @($models.data | ForEach-Object { [string]$_.id })
                $configuredIds = @($config.provider.'office-llm'.models.PSObject.Properties.Name)
                $missing = @($configuredIds | Where-Object { $availableIds -notcontains $_ })
                if ($missing.Count -gt 0) { throw 'Configured model IDs not returned by /models: ' + ($missing -join ', ') }
                Add-Check 'Internal API models' 'pass' ($configuredIds -join ', ')
            }
            catch { Add-Check 'Internal API models' 'fail' $_.Exception.Message }
        }

        try {
            if ($null -eq $openCode) { throw 'OpenCode is unavailable.' }
            $smoke = @(& $openCode.Path run --format json --agent office-coordinator 'Use office_memory_list exactly once to list approved memory, then report only the count.' 2>&1)
            if ($LASTEXITCODE -ne 0) { throw ($smoke | Out-String) }
            $events = @($smoke | ForEach-Object {
                try { [string]$_ | ConvertFrom-Json -ErrorAction Stop } catch { $null }
            } | Where-Object { $null -ne $_ })
            $successfulToolEvents = @($events | Where-Object {
                $_.type -eq 'tool_use' -and $_.part.tool -eq 'office_memory_list' -and $_.part.state.status -eq 'completed'
            })
            if ($successfulToolEvents.Count -ne 1) { throw 'The model did not complete office_memory_list exactly once.' }
            Add-Check 'Model tool call' 'pass' 'The configured model completed a read-only custom-tool turn.'
        }
        catch { Add-Check 'Model tool call' 'fail' $_.Exception.Message }

        try {
            if ($null -eq $openCode) { throw 'OpenCode is unavailable.' }
            if ($approvedRoots.Count -eq 0) { throw 'No approved Office root is available for the failure-stop check.' }
            $disciplineRoot = (Get-Item -LiteralPath ([Environment]::ExpandEnvironmentVariables([string]$approvedRoots[0])) -ErrorAction Stop).FullName
            $missingDocument = Join-Path $disciplineRoot ('opencode-qwen-missing-' + [Guid]::NewGuid().ToString('N') + '.docx')
            $disciplinePrompt = "Use office_word_inspect exactly once on '$missingDocument'. Do not call any other tool. If the call fails, stop immediately and report the failure."
            $disciplineOutput = @(& $openCode.Path run --format json --agent office-coordinator $disciplinePrompt 2>&1)
            if ($LASTEXITCODE -ne 0) { throw ($disciplineOutput | Out-String) }
            $disciplineEvents = @($disciplineOutput | ForEach-Object {
                try { [string]$_ | ConvertFrom-Json -ErrorAction Stop } catch { $null }
            } | Where-Object { $null -ne $_ })
            $toolEvents = @($disciplineEvents | Where-Object { $_.type -eq 'tool_use' })
            $failedInspections = @($toolEvents | Where-Object {
                $_.part.tool -eq 'office_word_inspect' -and $_.part.state.status -eq 'error'
            })
            if ($toolEvents.Count -ne 1 -or $failedInspections.Count -ne 1) {
                throw 'The model did not make exactly one failed office_word_inspect call with zero fallback tool calls.'
            }
            $failureTimestamp = [long]$failedInspections[0].timestamp
            $laterToolEvents = @($toolEvents | Where-Object { [long]$_.timestamp -gt $failureTimestamp })
            if ($laterToolEvents.Count -ne 0) { throw 'The model called another tool after the expected failure.' }
            $terminalStops = @($disciplineEvents | Where-Object {
                $_.type -eq 'step_finish' -and $_.part.reason -eq 'stop' -and [long]$_.timestamp -gt $failureTimestamp
            })
            if ($terminalStops.Count -lt 1) { throw 'The model did not stop with a terminal report after the failed tool call.' }
            Add-Check 'Model failure stop' 'pass' 'One failed Word inspection, no fallback tool, terminal report.'
        }
        catch { Add-Check 'Model failure stop' 'fail' $_.Exception.Message }
    }

    $failed = @($checks | Where-Object Status -eq 'fail').Count
    [pscustomobject]@{ Ok = ($failed -eq 0); Machine = $Machine; Failed = $failed; Checks = @($checks) } | ConvertTo-Json -Depth 6
    if ($failed -gt 0) { exit 1 }
}
catch {
    [Console]::Error.WriteLine(([ordered]@{ Ok = $false; Error = $_.Exception.Message; Checks = @($checks) } | ConvertTo-Json -Depth 6 -Compress))
    exit 1
}

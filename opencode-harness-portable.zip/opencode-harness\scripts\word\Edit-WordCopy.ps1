[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourcePath,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath,

    [Parameter(Mandatory = $true)]
    [string]$PlanPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path -Path $PSScriptRoot -ChildPath 'Word.Common.ps1')

function Get-WordPlanProperty {
    param(
        [Parameter(Mandatory = $true)]
        [object]$InputObject,

        [Parameter(Mandatory = $true)]
        [string]$Name,

        [Parameter(Mandatory = $true)]
        [string]$Description
    )

    $property = $InputObject.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) {
        throw "$Description is required."
    }
    return $property.Value
}

function Get-WordPlanIndex {
    param(
        [Parameter(Mandatory = $true)]
        [object]$InputObject,

        [Parameter(Mandatory = $true)]
        [string]$Name,

        [Parameter(Mandatory = $true)]
        [string]$Description
    )

    $value = Get-WordPlanProperty -InputObject $InputObject -Name $Name -Description $Description
    if ($value -isnot [byte] -and $value -isnot [sbyte] -and
        $value -isnot [int16] -and $value -isnot [uint16] -and
        $value -isnot [int32] -and $value -isnot [uint32] -and
        $value -isnot [int64] -and $value -isnot [uint64]) {
        throw "$Description must be a JSON integer."
    }
    $index = [int64]$value
    if ($index -lt 1 -or $index -gt [int]::MaxValue) {
        throw "$Description must be between 1 and $([int]::MaxValue)."
    }
    return [int]$index
}

function Get-WordPlanText {
    param(
        [Parameter(Mandatory = $true)]
        [object]$InputObject,

        [Parameter(Mandatory = $true)]
        [string]$Name,

        [Parameter(Mandatory = $true)]
        [string]$Description,

        [switch]$NonEmpty
    )

    $value = Get-WordPlanProperty -InputObject $InputObject -Name $Name -Description $Description
    if ($value -isnot [string]) {
        throw "$Description must be a JSON string."
    }
    $text = [string]$value
    Assert-WordPlainText -Text $text -Description $Description
    if ($NonEmpty -and $text.Length -eq 0) {
        throw "$Description cannot be empty."
    }
    return $text
}

function Get-WordPlanOptionalValue {
    param(
        [Parameter(Mandatory = $true)][object]$InputObject,
        [Parameter(Mandatory = $true)][string]$Name
    )
    $property = $InputObject.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) { return $null }
    return $property.Value
}

function Get-WordPlanOptionalNumber {
    param(
        [Parameter(Mandatory = $true)][object]$InputObject,
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$Description,
        [double]$Minimum = [double]::MinValue,
        [double]$Maximum = [double]::MaxValue,
        [switch]$Integer
    )
    $value = Get-WordPlanOptionalValue -InputObject $InputObject -Name $Name
    if ($null -eq $value) { return $null }
    if ($value -is [bool] -or $value -isnot [ValueType]) { throw "$Description must be a JSON number." }
    $number = [double]$value
    if ($number -lt $Minimum -or $number -gt $Maximum -or ($Integer -and $number -ne [Math]::Truncate($number))) {
        throw "$Description is outside the supported range."
    }
    if ($Integer) { return [int]$number }
    return $number
}

function Get-WordPlanOptionalBoolean {
    param(
        [Parameter(Mandatory = $true)][object]$InputObject,
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$Description
    )
    $value = Get-WordPlanOptionalValue -InputObject $InputObject -Name $Name
    if ($null -eq $value) { return $null }
    if ($value -isnot [bool]) { throw "$Description must be a JSON boolean." }
    return [bool]$value
}

function Get-WordPlanOptionalChoice {
    param(
        [Parameter(Mandatory = $true)][object]$InputObject,
        [Parameter(Mandatory = $true)][string]$Name,
        [Parameter(Mandatory = $true)][string]$Description,
        [Parameter(Mandatory = $true)][string[]]$Allowed
    )
    $value = Get-WordPlanOptionalValue -InputObject $InputObject -Name $Name
    if ($null -eq $value) { return $null }
    if ($value -isnot [string] -or $Allowed -notcontains ([string]$value).ToLowerInvariant()) {
        throw "$Description must be one of: $($Allowed -join ', ')."
    }
    return ([string]$value).ToLowerInvariant()
}

function ConvertTo-ValidatedWordOperation {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Operation,

        [Parameter(Mandatory = $true)]
        [int]$Index
    )

    $nameValue = Get-WordPlanProperty -InputObject $Operation -Name 'operation' -Description "Plan operation $Index name"
    if ($nameValue -isnot [string] -or [string]::IsNullOrWhiteSpace([string]$nameValue)) {
        throw "Plan operation $Index name must be a nonempty JSON string."
    }
    $name = ([string]$nameValue).ToLowerInvariant()
    $expectedText = Get-WordPlanText -InputObject $Operation -Name 'expectedText' -Description "Plan operation $Index expectedText"

    switch ($name) {
        'replace_paragraph_text' {
            return [pscustomobject][ordered]@{
                operation      = $name
                paragraphIndex = Get-WordPlanIndex -InputObject $Operation -Name 'paragraphIndex' -Description "Plan operation $Index paragraphIndex"
                expectedText   = $expectedText
                find           = Get-WordPlanText -InputObject $Operation -Name 'find' -Description "Plan operation $Index find" -NonEmpty
                replace        = Get-WordPlanText -InputObject $Operation -Name 'replace' -Description "Plan operation $Index replace"
            }
        }
        'replace_text_with_cross_reference' {
            $targetType = Get-WordPlanOptionalChoice -InputObject $Operation -Name 'targetType' -Description "Plan operation $Index targetType" -Allowed @('heading', 'figure', 'table')
            $referenceKind = Get-WordPlanOptionalChoice -InputObject $Operation -Name 'referenceKind' -Description "Plan operation $Index referenceKind" -Allowed @('heading_text', 'heading_number', 'label_and_number', 'entire_caption', 'caption_text', 'page_number')
            if ($null -eq $targetType) { throw "Plan operation $Index targetType is required." }
            if ($null -eq $referenceKind) { throw "Plan operation $Index referenceKind is required." }
            [void](Get-WordCrossReferenceKindId -TargetType $targetType -ReferenceKind $referenceKind)
            return [pscustomobject][ordered]@{
                operation         = $name
                paragraphIndex    = Get-WordPlanIndex -InputObject $Operation -Name 'paragraphIndex' -Description "Plan operation $Index paragraphIndex"
                expectedText      = $expectedText
                find              = Get-WordPlanText -InputObject $Operation -Name 'find' -Description "Plan operation $Index find" -NonEmpty
                targetType        = $targetType
                targetIndex       = Get-WordPlanIndex -InputObject $Operation -Name 'targetIndex' -Description "Plan operation $Index targetIndex"
                expectedTargetText = Get-WordPlanText -InputObject $Operation -Name 'expectedTargetText' -Description "Plan operation $Index expectedTargetText" -NonEmpty
                referenceKind     = $referenceKind
            }
        }
        'set_paragraph_text' {
            return [pscustomobject][ordered]@{
                operation      = $name
                paragraphIndex = Get-WordPlanIndex -InputObject $Operation -Name 'paragraphIndex' -Description "Plan operation $Index paragraphIndex"
                expectedText   = $expectedText
                text           = Get-WordPlanText -InputObject $Operation -Name 'text' -Description "Plan operation $Index text"
            }
        }
        'set_table_cell_text' {
            return [pscustomobject][ordered]@{
                operation  = $name
                tableIndex = Get-WordPlanIndex -InputObject $Operation -Name 'tableIndex' -Description "Plan operation $Index tableIndex"
                rowIndex   = Get-WordPlanIndex -InputObject $Operation -Name 'rowIndex' -Description "Plan operation $Index rowIndex"
                columnIndex = Get-WordPlanIndex -InputObject $Operation -Name 'columnIndex' -Description "Plan operation $Index columnIndex"
                expectedText = $expectedText
                text          = Get-WordPlanText -InputObject $Operation -Name 'text' -Description "Plan operation $Index text"
            }
        }
        'set_text_format' {
            $startOffset = Get-WordPlanOptionalNumber -InputObject $Operation -Name 'startOffset' -Description "Plan operation $Index startOffset" -Minimum 0 -Maximum ([int]::MaxValue) -Integer
            $length = Get-WordPlanOptionalNumber -InputObject $Operation -Name 'length' -Description "Plan operation $Index length" -Minimum 1 -Maximum ([int]::MaxValue) -Integer
            if (($null -eq $startOffset) -ne ($null -eq $length)) { throw "Plan operation $Index startOffset and length must be supplied together." }
            $fontNameValue = Get-WordPlanOptionalValue -InputObject $Operation -Name 'fontName'
            if ($null -ne $fontNameValue -and ($fontNameValue -isnot [string] -or [string]::IsNullOrWhiteSpace([string]$fontNameValue) -or ([string]$fontNameValue).Length -gt 100)) {
                throw "Plan operation $Index fontName must be a nonempty string of at most 100 characters."
            }
            $validated = [pscustomobject][ordered]@{
                operation = $name
                paragraphIndex = Get-WordPlanIndex -InputObject $Operation -Name 'paragraphIndex' -Description "Plan operation $Index paragraphIndex"
                expectedText = $expectedText
                startOffset = $startOffset
                length = $length
                fontName = if ($null -ne $fontNameValue) { [string]$fontNameValue } else { $null }
                fontSize = Get-WordPlanOptionalNumber -InputObject $Operation -Name 'fontSize' -Description "Plan operation $Index fontSize" -Minimum 0.5 -Maximum 200
                bold = Get-WordPlanOptionalBoolean -InputObject $Operation -Name 'bold' -Description "Plan operation $Index bold"
                italic = Get-WordPlanOptionalBoolean -InputObject $Operation -Name 'italic' -Description "Plan operation $Index italic"
                underline = Get-WordPlanOptionalBoolean -InputObject $Operation -Name 'underline' -Description "Plan operation $Index underline"
            }
            if ($null -eq $validated.fontName -and $null -eq $validated.fontSize -and $null -eq $validated.bold -and
                $null -eq $validated.italic -and $null -eq $validated.underline) {
                throw "Plan operation $Index set_text_format must name at least one format property."
            }
            return $validated
        }
        'set_paragraph_format' {
            $validated = [pscustomobject][ordered]@{
                operation = $name
                paragraphIndex = Get-WordPlanIndex -InputObject $Operation -Name 'paragraphIndex' -Description "Plan operation $Index paragraphIndex"
                expectedText = $expectedText
                paragraphStyle = Get-WordPlanOptionalChoice -InputObject $Operation -Name 'paragraphStyle' -Description "Plan operation $Index paragraphStyle" -Allowed @('normal', 'caption', 'title', 'heading1', 'heading2', 'heading3', 'bullet')
                alignment = Get-WordPlanOptionalChoice -InputObject $Operation -Name 'alignment' -Description "Plan operation $Index alignment" -Allowed @('left', 'center', 'right', 'justify')
                spaceBefore = Get-WordPlanOptionalNumber -InputObject $Operation -Name 'spaceBefore' -Description "Plan operation $Index spaceBefore" -Minimum 0 -Maximum 200
                spaceAfter = Get-WordPlanOptionalNumber -InputObject $Operation -Name 'spaceAfter' -Description "Plan operation $Index spaceAfter" -Minimum 0 -Maximum 200
                lineSpacing = Get-WordPlanOptionalNumber -InputObject $Operation -Name 'lineSpacing' -Description "Plan operation $Index lineSpacing" -Minimum 0.5 -Maximum 200
            }
            if ($null -eq $validated.paragraphStyle -and $null -eq $validated.alignment -and $null -eq $validated.spaceBefore -and
                $null -eq $validated.spaceAfter -and $null -eq $validated.lineSpacing) {
                throw "Plan operation $Index set_paragraph_format must name at least one format property."
            }
            return $validated
        }
        'insert_paragraph_after' {
            $paragraphStyle = Get-WordPlanOptionalChoice -InputObject $Operation -Name 'paragraphStyle' -Description "Plan operation $Index paragraphStyle" -Allowed @('normal', 'caption', 'title', 'heading1', 'heading2', 'heading3', 'bullet')
            if ($null -eq $paragraphStyle) { throw "Plan operation $Index paragraphStyle is required." }
            return [pscustomobject][ordered]@{
                operation = $name
                paragraphIndex = Get-WordPlanIndex -InputObject $Operation -Name 'paragraphIndex' -Description "Plan operation $Index paragraphIndex"
                expectedText = $expectedText
                text = Get-WordPlanText -InputObject $Operation -Name 'text' -Description "Plan operation $Index text" -NonEmpty
                paragraphStyle = $paragraphStyle
            }
        }
        default {
            throw "Unsupported Word operation '$name' at plan index $Index."
        }
    }
}

$application = $null
$documents = $null
$document = $null
$content = $null
$paragraphs = $null
$tables = $null
$sourceFullPath = $null
$outputFullPath = $null
$planFullPath = $null
$sourceHashBefore = $null
$sourceHashAfter = $null
$operationResults = @()
$outputCreated = $false
$oldUpdateLinksAtOpen = $null
$options = $null

try {
    $settings = Get-WordSettings
    $sourceFullPath = Resolve-ExistingWordFile -Path $SourcePath -Description 'Source document'
    $planFullPath = Resolve-ExistingWordFile -Path $PlanPath -Description 'Edit plan'
    $outputFullPath = Resolve-WordOutputFile -Path $OutputPath
    Assert-WordDocumentExtension -Path $sourceFullPath
    Assert-WordInputAllowed -Path $sourceFullPath -Settings $settings -Description 'Source document'
    Assert-WordOutputAllowed -OutputPath $outputFullPath -SourcePath $sourceFullPath -Settings $settings

    if ($sourceFullPath.Equals($outputFullPath, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'SourcePath and OutputPath must resolve to distinct full paths.'
    }
    $sourceExtension = [IO.Path]::GetExtension($sourceFullPath)
    if (-not $sourceExtension.Equals([IO.Path]::GetExtension($outputFullPath), [StringComparison]::OrdinalIgnoreCase)) {
        throw "OutputPath must preserve the source extension '$sourceExtension'."
    }
    if (Test-Path -LiteralPath $outputFullPath) {
        throw "OutputPath already exists: '$outputFullPath'."
    }

    try {
        $plan = [IO.File]::ReadAllText($planFullPath) | ConvertFrom-Json -ErrorAction Stop
    }
    catch {
        throw "Could not parse edit plan '$planFullPath': $($_.Exception.Message)"
    }
    $operationsProperty = $plan.PSObject.Properties['operations']
    if ($null -eq $operationsProperty -or $null -eq $operationsProperty.Value) {
        throw 'The edit plan must contain an operations array.'
    }
    $operations = @($operationsProperty.Value)
    if ($operations.Count -lt 1 -or $operations.Count -gt 100) {
        throw 'The edit plan must contain between 1 and 100 operations.'
    }

    $validatedOperations = @()
    for ($operationIndex = 0; $operationIndex -lt $operations.Count; $operationIndex++) {
        if ($null -eq $operations[$operationIndex]) {
            throw "Plan operation $($operationIndex + 1) is null."
        }
        $validatedOperations += ConvertTo-ValidatedWordOperation -Operation $operations[$operationIndex] -Index ($operationIndex + 1)
    }

    $sourceHashBefore = Get-WordFileHash -Path $sourceFullPath
    $planHash = Get-WordFileHash -Path $planFullPath
    [IO.File]::Copy($sourceFullPath, $outputFullPath, $false)
    $outputCreated = $true
    $wordVersion = ''

    try {
        $application = New-Object -ComObject Word.Application
        $application.Visible = $false
        $application.DisplayAlerts = 0
        $application.AutomationSecurity = 3
        if ([int]$application.AutomationSecurity -ne 3) { throw 'Word macro automation could not be disabled.' }
        $wordVersion = [string]$application.Version
        try {
            $options = $application.Options
            $oldUpdateLinksAtOpen = [bool]$options.UpdateLinksAtOpen
            $options.UpdateLinksAtOpen = $false
        }
        catch {
            $oldUpdateLinksAtOpen = $null
        }

        $documents = $application.Documents
        $document = $documents.Open($outputFullPath, $false, $false, $false)
        Release-WordComObject -ComObject $documents
        $documents = $null
        $content = $document.Content
        $paragraphs = $content.Paragraphs
        $tables = $document.Tables

        for ($operationIndex = 0; $operationIndex -lt $validatedOperations.Count; $operationIndex++) {
            $operation = $validatedOperations[$operationIndex]
            $paragraph = $null
            $newParagraph = $null
            $table = $null
            $cell = $null
            $range = $null
            $editableRange = $null
            $targetRange = $null
            $font = $null
            $paragraphFormat = $null
            $inlineShapes = $null
            $fields = $null
            $insertedField = $null
            $codeRange = $null
            $resultRange = $null
            try {
                switch ($operation.operation) {
                    'replace_paragraph_text' {
                        if ($operation.paragraphIndex -gt [int]$paragraphs.Count) {
                            throw "Paragraph index $($operation.paragraphIndex) is outside the document."
                        }
                        $paragraph = $paragraphs.Item($operation.paragraphIndex)
                        $range = $paragraph.Range
                        $beforeText = Get-WordRangePlainText -Range $range
                        if (-not [string]::Equals($beforeText, $operation.expectedText, [StringComparison]::Ordinal)) {
                            throw "Paragraph $($operation.paragraphIndex) text no longer matches expectedText."
                        }
                        $matchIndex = $beforeText.IndexOf($operation.find, [StringComparison]::Ordinal)
                        if ($matchIndex -lt 0) {
                            throw "Paragraph $($operation.paragraphIndex) does not contain the requested find text."
                        }
                        if ($beforeText.LastIndexOf($operation.find, [StringComparison]::Ordinal) -ne $matchIndex) {
                            throw "Paragraph $($operation.paragraphIndex) contains the requested find text more than once."
                        }
                        $editableRange = Get-WordEditableRange -Range $range
                        $targetRange = $editableRange.Duplicate
                        $targetRange.Start = [int]$targetRange.Start + $matchIndex
                        $targetRange.End = [int]$targetRange.Start + $operation.find.Length
                        $targetRange.Text = $operation.replace
                        $afterText = $beforeText.Substring(0, $matchIndex) + $operation.replace + $beforeText.Substring($matchIndex + $operation.find.Length)
                        $details = [pscustomobject][ordered]@{
                            paragraphIndex = $operation.paragraphIndex
                            beforeText     = $beforeText
                            afterText      = $afterText
                            find           = $operation.find
                            replace        = $operation.replace
                        }
                    }
                    'replace_text_with_cross_reference' {
                        if ($operation.paragraphIndex -gt [int]$paragraphs.Count) {
                            throw "Paragraph index $($operation.paragraphIndex) is outside the document."
                        }
                        $paragraph = $paragraphs.Item($operation.paragraphIndex)
                        $range = $paragraph.Range
                        $beforeText = Get-WordRangePlainText -Range $range
                        if (-not [string]::Equals($beforeText, $operation.expectedText, [StringComparison]::Ordinal)) {
                            throw "Paragraph $($operation.paragraphIndex) text no longer matches expectedText."
                        }
                        $matchIndex = $beforeText.IndexOf($operation.find, [StringComparison]::Ordinal)
                        if ($matchIndex -lt 0) {
                            throw "Paragraph $($operation.paragraphIndex) does not contain the requested find text."
                        }
                        if ($beforeText.LastIndexOf($operation.find, [StringComparison]::Ordinal) -ne $matchIndex) {
                            throw "Paragraph $($operation.paragraphIndex) contains the requested find text more than once."
                        }

                        $referenceType = Get-WordCrossReferenceTypeId -Name $operation.targetType
                        $referenceKind = Get-WordCrossReferenceKindId -TargetType $operation.targetType -ReferenceKind $operation.referenceKind
                        $referenceItems = @($document.GetCrossReferenceItems($referenceType))
                        if ($operation.targetIndex -gt $referenceItems.Count) {
                            throw "$($operation.targetType) target index $($operation.targetIndex) is outside Word's current cross-reference list."
                        }
                        $targetText = Get-WordCrossReferenceItemText -Value $referenceItems[$operation.targetIndex - 1]
                        if (-not [string]::Equals($targetText, $operation.expectedTargetText, [StringComparison]::Ordinal)) {
                            throw "$($operation.targetType) target $($operation.targetIndex) no longer matches expectedTargetText."
                        }

                        if ($operation.referenceKind -eq 'page_number') { $document.Repaginate() }
                        $editableRange = Get-WordEditableRange -Range $range
                        $targetRange = $editableRange.Duplicate
                        $targetRange.Start = [int]$targetRange.Start + $matchIndex
                        $targetRange.End = [int]$targetRange.Start + $operation.find.Length
                        $insertionStart = [int]$targetRange.Start
                        $targetRange.Text = ''
                        $targetRange.Collapse(1)
                        $targetRange.InsertCrossReference($referenceType, $referenceKind, $operation.targetIndex, $true, $false, $false, '')

                        $expectedFieldType = if ($operation.referenceKind -eq 'page_number') { 37 } else { 3 }
                        $fields = $document.Fields
                        for ($fieldIndex = 1; $fieldIndex -le [int]$fields.Count; $fieldIndex++) {
                            $candidateField = $null
                            $candidateCodeRange = $null
                            try {
                                $candidateField = $fields.Item($fieldIndex)
                                if ([int]$candidateField.Type -ne $expectedFieldType) { continue }
                                $candidateCodeRange = $candidateField.Code
                                if ([int]$candidateCodeRange.Start -eq $insertionStart + 1) {
                                    $insertedField = $candidateField
                                    $candidateField = $null
                                    break
                                }
                            }
                            finally {
                                Release-WordComObject -ComObject $candidateCodeRange
                                Release-WordComObject -ComObject $candidateField
                            }
                        }
                        if ($null -eq $insertedField) { throw 'Word inserted the cross-reference, but its field could not be verified.' }
                        if (-not [bool]$insertedField.Update()) { throw 'Word could not update the inserted cross-reference field.' }
                        $codeRange = $insertedField.Code
                        $resultRange = $insertedField.Result
                        $afterText = Get-WordRangePlainText -Range $range
                        $details = [pscustomobject][ordered]@{
                            paragraphIndex = $operation.paragraphIndex
                            beforeText = $beforeText
                            afterText = $afterText
                            find = $operation.find
                            targetType = $operation.targetType
                            targetIndex = $operation.targetIndex
                            targetText = $targetText
                            referenceKind = $operation.referenceKind
                            fieldType = if ($expectedFieldType -eq 37) { 'PAGEREF' } else { 'REF' }
                            fieldCode = ([string]$codeRange.Text).Trim()
                            resultText = Get-WordRangePlainText -Range $resultRange
                        }
                    }
                    'set_paragraph_text' {
                        if ($operation.paragraphIndex -gt [int]$paragraphs.Count) {
                            throw "Paragraph index $($operation.paragraphIndex) is outside the document."
                        }
                        $paragraph = $paragraphs.Item($operation.paragraphIndex)
                        $range = $paragraph.Range
                        $beforeText = Get-WordRangePlainText -Range $range
                        if (-not [string]::Equals($beforeText, $operation.expectedText, [StringComparison]::Ordinal)) {
                            throw "Paragraph $($operation.paragraphIndex) text no longer matches expectedText."
                        }
                        Set-WordRangePlainText -Range $range -Text $operation.text
                        $details = [pscustomobject][ordered]@{
                            paragraphIndex = $operation.paragraphIndex
                            beforeText     = $beforeText
                            afterText      = $operation.text
                        }
                    }
                    'set_text_format' {
                        if ($operation.paragraphIndex -gt [int]$paragraphs.Count) {
                            throw "Paragraph index $($operation.paragraphIndex) is outside the document."
                        }
                        $paragraph = $paragraphs.Item($operation.paragraphIndex)
                        $range = $paragraph.Range
                        $beforeText = Get-WordRangePlainText -Range $range
                        if (-not [string]::Equals($beforeText, $operation.expectedText, [StringComparison]::Ordinal)) {
                            throw "Paragraph $($operation.paragraphIndex) text no longer matches expectedText."
                        }
                        $editableRange = Get-WordEditableRange -Range $range
                        $targetRange = $editableRange.Duplicate
                        if ($null -ne $operation.startOffset) {
                            if ($operation.startOffset + $operation.length -gt $beforeText.Length) {
                                throw "Paragraph $($operation.paragraphIndex) format range is outside the paragraph text."
                            }
                            $targetRange.Start = [int]$targetRange.Start + $operation.startOffset
                            $targetRange.End = [int]$targetRange.Start + $operation.length
                        }
                        $beforeFormat = Get-WordFontSnapshot -Range $targetRange
                        $font = $targetRange.Font
                        if ($null -ne $operation.fontName) { $font.Name = $operation.fontName }
                        if ($null -ne $operation.fontSize) { $font.Size = $operation.fontSize }
                        if ($null -ne $operation.bold) { $font.Bold = if ($operation.bold) { -1 } else { 0 } }
                        if ($null -ne $operation.italic) { $font.Italic = if ($operation.italic) { -1 } else { 0 } }
                        if ($null -ne $operation.underline) { $font.Underline = if ($operation.underline) { 1 } else { 0 } }
                        $details = [pscustomobject][ordered]@{
                            paragraphIndex = $operation.paragraphIndex
                            startOffset = $operation.startOffset
                            length = $operation.length
                            targetText = Get-WordRangePlainText -Range $targetRange
                            before = $beforeFormat
                            after = Get-WordFontSnapshot -Range $targetRange
                        }
                    }
                    'set_paragraph_format' {
                        if ($operation.paragraphIndex -gt [int]$paragraphs.Count) {
                            throw "Paragraph index $($operation.paragraphIndex) is outside the document."
                        }
                        $paragraph = $paragraphs.Item($operation.paragraphIndex)
                        $range = $paragraph.Range
                        $beforeText = Get-WordRangePlainText -Range $range
                        if (-not [string]::Equals($beforeText, $operation.expectedText, [StringComparison]::Ordinal)) {
                            throw "Paragraph $($operation.paragraphIndex) text no longer matches expectedText."
                        }
                        $beforeFormat = Get-WordParagraphFormatSnapshot -Range $range
                        $beforeStyle = ''
                        $styleObject = $null
                        try {
                            $styleObject = $range.Style
                            $beforeStyle = [string]$styleObject.NameLocal
                        }
                        finally { Release-WordComObject -ComObject $styleObject }
                        if ($null -ne $operation.paragraphStyle) { $range.Style = Get-WordBuiltInStyleId -Name $operation.paragraphStyle }
                        $paragraphFormat = $range.ParagraphFormat
                        if ($null -ne $operation.alignment) {
                            $paragraphFormat.Alignment = switch ($operation.alignment) {
                                'left' { 0 }
                                'center' { 1 }
                                'right' { 2 }
                                'justify' { 3 }
                            }
                        }
                        if ($null -ne $operation.spaceBefore) { $paragraphFormat.SpaceBefore = $operation.spaceBefore }
                        if ($null -ne $operation.spaceAfter) { $paragraphFormat.SpaceAfter = $operation.spaceAfter }
                        if ($null -ne $operation.lineSpacing) { $paragraphFormat.LineSpacing = $operation.lineSpacing }
                        $afterStyleObject = $null
                        try {
                            $afterStyleObject = $range.Style
                            $afterStyle = [string]$afterStyleObject.NameLocal
                        }
                        finally { Release-WordComObject -ComObject $afterStyleObject }
                        $details = [pscustomobject][ordered]@{
                            paragraphIndex = $operation.paragraphIndex
                            beforeStyle = $beforeStyle
                            afterStyle = $afterStyle
                            before = $beforeFormat
                            after = Get-WordParagraphFormatSnapshot -Range $range
                        }
                    }
                    'insert_paragraph_after' {
                        if ($operation.paragraphIndex -gt [int]$paragraphs.Count) {
                            throw "Paragraph index $($operation.paragraphIndex) is outside the document."
                        }
                        $paragraph = $paragraphs.Item($operation.paragraphIndex)
                        $range = $paragraph.Range
                        $beforeText = Get-WordRangePlainText -Range $range
                        if (-not [string]::Equals($beforeText, $operation.expectedText, [StringComparison]::Ordinal)) {
                            throw "Paragraph $($operation.paragraphIndex) text no longer matches expectedText."
                        }
                        if ($operation.paragraphStyle -eq 'caption') {
                            $inlineShapes = $range.InlineShapes
                            if ([int]$inlineShapes.Count -lt 1) {
                                throw "Paragraph $($operation.paragraphIndex) has no inline image to caption."
                            }
                        }
                        $range.InsertParagraphAfter()
                        $newParagraph = $paragraphs.Item($operation.paragraphIndex + 1)
                        $targetRange = $newParagraph.Range
                        Set-WordRangePlainText -Range $targetRange -Text $operation.text
                        $targetRange.Style = Get-WordBuiltInStyleId -Name $operation.paragraphStyle
                        $details = [pscustomobject][ordered]@{
                            paragraphIndex = $operation.paragraphIndex
                            insertedText = $operation.text
                            paragraphStyle = $operation.paragraphStyle
                        }
                    }
                    'set_table_cell_text' {
                        if ($operation.tableIndex -gt [int]$tables.Count) {
                            throw "Table index $($operation.tableIndex) is outside the document."
                        }
                        $table = $tables.Item($operation.tableIndex)
                        try {
                            $cell = $table.Cell($operation.rowIndex, $operation.columnIndex)
                        }
                        catch {
                            throw "Table $($operation.tableIndex) does not contain cell ($($operation.rowIndex), $($operation.columnIndex))."
                        }
                        $range = $cell.Range
                        $beforeText = Get-WordRangePlainText -Range $range
                        if (-not [string]::Equals($beforeText, $operation.expectedText, [StringComparison]::Ordinal)) {
                            throw "Table $($operation.tableIndex) cell ($($operation.rowIndex), $($operation.columnIndex)) text no longer matches expectedText."
                        }
                        Set-WordRangePlainText -Range $range -Text $operation.text
                        $details = [pscustomobject][ordered]@{
                            tableIndex  = $operation.tableIndex
                            rowIndex    = $operation.rowIndex
                            columnIndex = $operation.columnIndex
                            beforeText  = $beforeText
                            afterText   = $operation.text
                        }
                    }
                }

                $operationResults += [pscustomobject][ordered]@{
                    index     = $operationIndex + 1
                    operation = $operation.operation
                    status    = 'applied'
                    details   = $details
                }
            }
            catch {
                $operationResults += [pscustomobject][ordered]@{
                    index     = $operationIndex + 1
                    operation = $operation.operation
                    status    = 'failed'
                    error     = $_.Exception.Message
                }
                throw "Plan operation $($operationIndex + 1) ('$($operation.operation)') failed: $($_.Exception.Message)"
            }
            finally {
                Release-WordComObject -ComObject $resultRange
                Release-WordComObject -ComObject $codeRange
                Release-WordComObject -ComObject $insertedField
                Release-WordComObject -ComObject $fields
                Release-WordComObject -ComObject $inlineShapes
                Release-WordComObject -ComObject $paragraphFormat
                Release-WordComObject -ComObject $font
                Release-WordComObject -ComObject $targetRange
                Release-WordComObject -ComObject $editableRange
                Release-WordComObject -ComObject $range
                Release-WordComObject -ComObject $newParagraph
                Release-WordComObject -ComObject $cell
                Release-WordComObject -ComObject $table
                Release-WordComObject -ComObject $paragraph
            }
        }

        $document.Save()
    }
    finally {
        Release-WordComObject -ComObject $tables
        Release-WordComObject -ComObject $paragraphs
        Release-WordComObject -ComObject $content
        Release-WordComObject -ComObject $documents
        if ($null -ne $document) {
            try { $document.Close(0) } catch {}
            Release-WordComObject -ComObject $document
            $document = $null
        }
        if ($null -ne $application) {
            if ($null -ne $oldUpdateLinksAtOpen -and $null -ne $options) {
                try { $options.UpdateLinksAtOpen = $oldUpdateLinksAtOpen } catch {}
            }
            Release-WordComObject -ComObject $options
            $options = $null
            try { $application.Quit() } catch {}
            Release-WordComObject -ComObject $application
            $application = $null
        }
        Complete-WordComCleanup
    }

    if (-not (Test-Path -LiteralPath $outputFullPath -PathType Leaf)) {
        throw "Word did not preserve the expected output copy '$outputFullPath'."
    }
    $sourceHashAfter = Get-WordFileHash -Path $sourceFullPath
    if ($sourceHashBefore -ne $sourceHashAfter) {
        throw 'The source document hash changed during editing.'
    }

    $outputFile = Get-Item -LiteralPath $outputFullPath -ErrorAction Stop
    $manifest = [pscustomobject][ordered]@{
        success      = $true
        command      = 'Edit-WordCopy'
        source       = [pscustomobject][ordered]@{
            path         = $sourceFullPath
            sha256Before = $sourceHashBefore
            sha256After  = $sourceHashAfter
            unchanged    = $true
        }
        plan         = [pscustomobject][ordered]@{
            path           = $planFullPath
            sha256         = $planHash
            operationCount = $validatedOperations.Count
        }
        output       = [pscustomobject][ordered]@{
            path       = $outputFile.FullName
            sha256     = Get-WordFileHash -Path $outputFile.FullName
            bytes      = [long]$outputFile.Length
            overwritten = $false
            saveMethod = 'File.Copy + Document.Save'
        }
        settingsPath = $settings.SettingsPath
        wordVersion  = $wordVersion
        operations   = @($operationResults)
        truncation   = [pscustomobject][ordered]@{
            truncated = $false
        }
    }

    Write-WordJson -Value $manifest
}
catch {
    $failureRecord = $_
    $cleanupError = $null
    if ($outputCreated -and $null -ne $outputFullPath -and (Test-Path -LiteralPath $outputFullPath -PathType Leaf)) {
        try { [IO.File]::Delete($outputFullPath) } catch { $cleanupError = $_.Exception.Message }
    }

    $context = @{
        operations = @($operationResults)
    }
    if ($null -ne $sourceFullPath) { $context['sourcePath'] = $sourceFullPath }
    if ($null -ne $outputFullPath) { $context['outputPath'] = $outputFullPath }
    if ($null -ne $planFullPath) { $context['planPath'] = $planFullPath }
    if ($null -ne $sourceHashBefore) { $context['sourceSha256Before'] = $sourceHashBefore }
    if ($null -ne $sourceFullPath -and (Test-Path -LiteralPath $sourceFullPath -PathType Leaf)) {
        try { $context['sourceSha256After'] = Get-WordFileHash -Path $sourceFullPath } catch {}
    }
    if ($null -ne $cleanupError) { $context['cleanupError'] = $cleanupError }
    Write-WordFailure -Command 'Edit-WordCopy' -ErrorRecord $failureRecord -Context $context
    exit 1
}

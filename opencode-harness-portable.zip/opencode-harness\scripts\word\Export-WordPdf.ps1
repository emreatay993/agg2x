[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourcePath,

    [Parameter(Mandatory = $true)]
    [string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path -Path $PSScriptRoot -ChildPath 'Word.Common.ps1')
Add-Type -AssemblyName Microsoft.Office.Interop.Word -ErrorAction Stop

function Invoke-WordPdfExport {
    param(
        [Parameter(Mandatory = $true)]
        [string]$SourcePath,

        [Parameter(Mandatory = $true)]
        [string]$DestinationPath
    )

    $application = $null
    $documents = $null
    $document = $null
    try {
        $application = New-Object -ComObject Word.Application
        $application.Visible = $false
        $application.DisplayAlerts = 0
        $application.AutomationSecurity = 3
        if ([int]$application.AutomationSecurity -ne 3) { throw 'Word macro automation could not be disabled.' }

        $documents = $application.Documents
        $document = $documents.Open($SourcePath, $false, $true, $false)
        $typedDocument = [Microsoft.Office.Interop.Word._Document]$document
        $typedDocument.ExportAsFixedFormat(
            $DestinationPath,
            [Microsoft.Office.Interop.Word.WdExportFormat]::wdExportFormatPDF,
            $false,
            [Microsoft.Office.Interop.Word.WdExportOptimizeFor]::wdExportOptimizeForPrint,
            [Microsoft.Office.Interop.Word.WdExportRange]::wdExportAllDocument,
            1,
            1,
            [Microsoft.Office.Interop.Word.WdExportItem]::wdExportDocumentContent,
            $true,
            $true,
            [Microsoft.Office.Interop.Word.WdExportCreateBookmarks]::wdExportCreateNoBookmarks,
            $true,
            $true,
            $false
        )

        return [pscustomobject][ordered]@{
            wordVersion = [string]$application.Version
            pageCount   = [int]$document.ComputeStatistics(2)
        }
    }
    finally {
        if ($null -ne $document) {
            try { $document.Close(0) } catch {}
            Release-WordComObject -ComObject $document
        }
        Release-WordComObject -ComObject $documents
        if ($null -ne $application) {
            try { $application.Quit() } catch {}
            Release-WordComObject -ComObject $application
        }
    }
}

$sourceFullPath = $null
$outputFullPath = $null
$temporaryPdfPath = $null
$sourceHashBefore = $null
$sourceHashAfter = $null
$outputCreated = $false

try {
    $settings = Get-WordSettings
    $sourceFullPath = Resolve-ExistingWordFile -Path $SourcePath -Description 'Source document'
    $outputFullPath = Resolve-WordOutputFile -Path $OutputPath
    Assert-WordDocumentExtension -Path $sourceFullPath
    Assert-WordPdfExtension -Path $outputFullPath
    Assert-WordInputAllowed -Path $sourceFullPath -Settings $settings -Description 'Source document'
    Assert-WordOutputAllowed -OutputPath $outputFullPath -SourcePath $sourceFullPath -Settings $settings

    if ($sourceFullPath.Equals($outputFullPath, [StringComparison]::OrdinalIgnoreCase)) {
        throw 'SourcePath and OutputPath must resolve to distinct full paths.'
    }
    if (Test-Path -LiteralPath $outputFullPath) {
        throw "The PDF output path already exists: '$outputFullPath'."
    }

    $sourceHashBefore = Get-WordFileHash -Path $sourceFullPath
    $wordVersion = ''
    $pageCount = 0
    $temporaryPdfName = ([IO.Path]::GetFileName($outputFullPath)) + '.opencode-' + [Guid]::NewGuid().ToString('N') + '.pdf'
    $temporaryPdfPath = Join-Path -Path ([IO.Path]::GetDirectoryName($outputFullPath)) -ChildPath $temporaryPdfName

    $exportResult = Invoke-WordPdfExport -SourcePath $sourceFullPath -DestinationPath $temporaryPdfPath
    $wordVersion = $exportResult.wordVersion
    $pageCount = $exportResult.pageCount

    if (-not (Test-Path -LiteralPath $temporaryPdfPath -PathType Leaf)) {
        throw "Word did not create the expected temporary PDF '$temporaryPdfPath'."
    }

    $sourceHashAfter = Get-WordFileHash -Path $sourceFullPath
    if ($sourceHashBefore -ne $sourceHashAfter) {
        throw 'The source document hash changed during PDF export.'
    }
    if (Test-Path -LiteralPath $outputFullPath) {
        throw "The PDF output path appeared during export: '$outputFullPath'."
    }

    [IO.File]::Move($temporaryPdfPath, $outputFullPath)
    $outputCreated = $true
    $outputFile = Get-Item -LiteralPath $outputFullPath -ErrorAction Stop
    $manifest = [pscustomobject][ordered]@{
        success      = $true
        command      = 'Export-WordPdf'
        source       = [pscustomobject][ordered]@{
            path         = $sourceFullPath
            sha256Before = $sourceHashBefore
            sha256After  = $sourceHashAfter
            unchanged    = $true
        }
        settingsPath = $settings.SettingsPath
        wordVersion  = $wordVersion
        output       = [pscustomobject][ordered]@{
            path      = $outputFile.FullName
            sha256    = Get-WordFileHash -Path $outputFile.FullName
            bytes     = [long]$outputFile.Length
            pageCount = $pageCount
            format    = 'PDF'
        }
        truncation   = [pscustomobject][ordered]@{
            truncated = $false
        }
    }

    Write-WordJson -Value $manifest
}
catch {
    if ($null -ne $temporaryPdfPath -and (Test-Path -LiteralPath $temporaryPdfPath -PathType Leaf)) {
        try { [IO.File]::Delete($temporaryPdfPath) } catch {}
    }
    if ($outputCreated -and $null -ne $outputFullPath -and (Test-Path -LiteralPath $outputFullPath -PathType Leaf)) {
        try { [IO.File]::Delete($outputFullPath) } catch {}
    }
    $context = @{}
    if ($null -ne $sourceFullPath) { $context['sourcePath'] = $sourceFullPath }
    if ($null -ne $outputFullPath) { $context['outputPath'] = $outputFullPath }
    if ($null -ne $sourceHashBefore) { $context['sourceSha256Before'] = $sourceHashBefore }
    if ($null -ne $sourceFullPath -and (Test-Path -LiteralPath $sourceFullPath -PathType Leaf)) {
        try { $context['sourceSha256After'] = Get-WordFileHash -Path $sourceFullPath } catch {}
    }
    Write-WordFailure -Command 'Export-WordPdf' -ErrorRecord $_ -Context $context
    exit 1
}

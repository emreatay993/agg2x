[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)]
    [string]$SourcePath,

    [ValidateSet('inventory', 'find', 'formatting', 'media', 'proofing', 'references')]
    [string]$Mode = 'inventory',

    [string]$FindText = '',

    [ValidateRange(1, [int]::MaxValue)]
    [int]$Start = 1,

    [ValidateRange(1, 25)]
    [int]$Limit = 25
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path -Path $PSScriptRoot -ChildPath 'Word.Common.ps1')

function Get-WordBuiltInProperty {
    param([Parameter(Mandatory = $true)][object]$Document, [Parameter(Mandatory = $true)][string]$Name)
    $properties = $null
    $property = $null
    try {
        $properties = $Document.BuiltInDocumentProperties
        $property = $properties.Item($Name)
        if ($null -eq $property.Value) { return $null }
        return [string]$property.Value
    }
    catch { return $null }
    finally {
        Release-WordComObject -ComObject $property
        Release-WordComObject -ComObject $properties
    }
}

function Get-WordStyleName {
    param([Parameter(Mandatory = $true)][object]$Range)
    $style = $null
    try {
        $style = $Range.Style
        return [string]$style.NameLocal
    }
    catch { return '' }
    finally { Release-WordComObject -ComObject $style }
}

function Get-WordParagraphRecordForRange {
    param(
        [Parameter(Mandatory = $true)][object]$Document,
        [Parameter(Mandatory = $true)][object]$Range
    )
    $rangeParagraphs = $null
    $paragraph = $null
    $paragraphRange = $null
    $prefixRange = $null
    try {
        $rangeParagraphs = $Range.Paragraphs
        if ([int]$rangeParagraphs.Count -lt 1) { return $null }
        $paragraph = $rangeParagraphs.Item(1)
        $paragraphRange = $paragraph.Range
        $prefixRange = $Document.Range(0, [int]$paragraphRange.Start)
        $index = if ([int]$paragraphRange.Start -eq 0) { 1 } else { [int]$prefixRange.Paragraphs.Count + 1 }
        return [pscustomobject][ordered]@{
            index = $index
            text = Get-WordRangePlainText -Range $paragraphRange
            style = Get-WordStyleName -Range $paragraphRange
            start = [int]$paragraphRange.Start
            end = [int]$paragraphRange.End
            inTable = [bool]$paragraphRange.Information(12)
        }
    }
    finally {
        Release-WordComObject -ComObject $prefixRange
        Release-WordComObject -ComObject $paragraphRange
        Release-WordComObject -ComObject $paragraph
        Release-WordComObject -ComObject $rangeParagraphs
    }
}

function Get-WordFontKey {
    param([Parameter(Mandatory = $true)][object]$Snapshot)
    return @($Snapshot.name, $Snapshot.size, $Snapshot.bold, $Snapshot.italic, $Snapshot.underline) -join '|'
}

$paragraphLimit = 1000
$tableLimit = 100
$cellLimit = 2000
$hyperlinkLimit = 500
$formatCharacterLimit = 20000
$formatRunLimit = 500
$application = $null
$documents = $null
$document = $null
$content = $null
$paragraphs = $null
$tables = $null
$hyperlinks = $null
$inlineShapes = $null
$shapes = $null
$styles = $null
$captionStyle = $null
$fields = $null
$sourceFullPath = $null
$sourceHashBefore = $null

try {
    $settings = Get-WordSettings
    $sourceFullPath = Resolve-ExistingWordFile -Path $SourcePath -Description 'Source document'
    Assert-WordDocumentExtension -Path $sourceFullPath
    Assert-WordInputAllowed -Path $sourceFullPath -Settings $settings -Description 'Source document'
    $sourceHashBefore = Get-WordFileHash -Path $sourceFullPath

    $paragraphResults = @()
    $tableResults = @()
    $hyperlinkResults = @()
    $formattingResults = @()
    $mediaResults = @()
    $proofingResults = @()
    $referenceResults = @()
    $findResults = @()
    $paragraphMap = @()
    $wordVersion = ''
    $hasVbProject = $null
    $pageCount = $null
    $wordCount = $null
    $characterCount = $null
    $totalCellCount = 0
    $includedCellCount = 0
    $modeTotal = 0
    $modeIncluded = 0
    $modeTruncated = $false
    $nextStart = $null

    try {
        $application = New-Object -ComObject Word.Application
        $application.Visible = $false
        $application.DisplayAlerts = 0
        $application.AutomationSecurity = 3
        if ([int]$application.AutomationSecurity -ne 3) { throw 'Word macro automation could not be disabled.' }
        $wordVersion = [string]$application.Version
        try { $application.Options.UpdateLinksAtOpen = $false } catch {}

        $documents = $application.Documents
        $document = $documents.Open($sourceFullPath, $false, $true, $false)
        Release-WordComObject -ComObject $documents
        $documents = $null

        try { $hasVbProject = ([int]$document.HasVBProject -eq -1) } catch { $hasVbProject = $null }
        $content = $document.Content
        $paragraphs = $content.Paragraphs
        $paragraphCount = [int]$paragraphs.Count

        if ($Mode -eq 'inventory') {
            try { $document.Repaginate() } catch {}
            $pageCount = [int]$document.ComputeStatistics(2)
            $wordCount = [int]$document.ComputeStatistics(0)
            $characterCount = [int]$document.ComputeStatistics(3)
            $includedParagraphCount = [Math]::Min($paragraphCount, $paragraphLimit)
            for ($paragraphIndex = 1; $paragraphIndex -le $includedParagraphCount; $paragraphIndex++) {
                $paragraph = $null
                $range = $null
                try {
                    $paragraph = $paragraphs.Item($paragraphIndex)
                    $range = $paragraph.Range
                    $paragraphResults += [pscustomobject][ordered]@{
                        index = $paragraphIndex
                        text = Get-WordRangePlainText -Range $range
                        style = Get-WordStyleName -Range $range
                        start = [int]$range.Start
                        end = [int]$range.End
                        inTable = [bool]$range.Information(12)
                    }
                }
                finally {
                    Release-WordComObject -ComObject $range
                    Release-WordComObject -ComObject $paragraph
                }
            }

            $tables = $document.Tables
            $tableCount = [int]$tables.Count
            $includedTableCount = [Math]::Min($tableCount, $tableLimit)
            for ($tableIndex = 1; $tableIndex -le $includedTableCount; $tableIndex++) {
                $table = $null
                $tableRange = $null
                $cells = $null
                try {
                    $table = $tables.Item($tableIndex)
                    $tableRange = $table.Range
                    $cells = $tableRange.Cells
                    $tableCellCount = [int]$cells.Count
                    $totalCellCount += $tableCellCount
                    $cellResults = @()
                    $includedTableCells = [Math]::Min($tableCellCount, [Math]::Max(0, $cellLimit - $includedCellCount))
                    for ($cellIndex = 1; $cellIndex -le $includedTableCells; $cellIndex++) {
                        $cell = $null
                        $cellRange = $null
                        try {
                            $cell = $cells.Item($cellIndex)
                            $cellRange = $cell.Range
                            $cellResults += [pscustomobject][ordered]@{
                                rowIndex = [int]$cell.RowIndex
                                columnIndex = [int]$cell.ColumnIndex
                                text = Get-WordRangePlainText -Range $cellRange
                            }
                        }
                        finally {
                            Release-WordComObject -ComObject $cellRange
                            Release-WordComObject -ComObject $cell
                        }
                    }
                    $includedCellCount += $includedTableCells
                    $tableResults += [pscustomobject][ordered]@{
                        index = $tableIndex
                        rowCount = [int]$table.Rows.Count
                        columnCount = [int]$table.Columns.Count
                        cellCount = $tableCellCount
                        cells = @($cellResults)
                    }
                }
                finally {
                    Release-WordComObject -ComObject $cells
                    Release-WordComObject -ComObject $tableRange
                    Release-WordComObject -ComObject $table
                }
            }

            $hyperlinks = $document.Hyperlinks
            $hyperlinkCount = [int]$hyperlinks.Count
            $includedHyperlinkCount = [Math]::Min($hyperlinkCount, $hyperlinkLimit)
            for ($hyperlinkIndex = 1; $hyperlinkIndex -le $includedHyperlinkCount; $hyperlinkIndex++) {
                $hyperlink = $null
                $range = $null
                try {
                    $hyperlink = $hyperlinks.Item($hyperlinkIndex)
                    $range = $hyperlink.Range
                    $hyperlinkResults += [pscustomobject][ordered]@{
                        index = $hyperlinkIndex
                        text = Get-WordRangePlainText -Range $range
                        address = [string]$hyperlink.Address
                        subAddress = [string]$hyperlink.SubAddress
                    }
                }
                finally {
                    Release-WordComObject -ComObject $range
                    Release-WordComObject -ComObject $hyperlink
                }
            }

            $modeTotal = $paragraphCount + $tableCount + $totalCellCount + $hyperlinkCount
            $modeIncluded = $includedParagraphCount + $includedTableCount + $includedCellCount + $includedHyperlinkCount
            $modeTruncated = $modeTotal -gt $modeIncluded
        }
        elseif ($Mode -eq 'find') {
            Assert-WordPlainText -Text $FindText -Description 'FindText'
            if ([string]::IsNullOrWhiteSpace($FindText)) { throw 'FindText is required in find mode.' }
            $matchCount = 0
            for ($paragraphIndex = 1; $paragraphIndex -le $paragraphCount; $paragraphIndex++) {
                $paragraph = $null
                $range = $null
                try {
                    $paragraph = $paragraphs.Item($paragraphIndex)
                    $range = $paragraph.Range
                    $paragraphText = Get-WordRangePlainText -Range $range
                    if ($paragraphText.IndexOf($FindText, [StringComparison]::OrdinalIgnoreCase) -lt 0) { continue }
                    $matchCount++
                    if ($matchCount -ge $Start -and $findResults.Count -lt $Limit) {
                        $findResults += [pscustomobject][ordered]@{
                            index = $matchCount
                            paragraphIndex = $paragraphIndex
                            text = $paragraphText
                            style = Get-WordStyleName -Range $range
                            start = [int]$range.Start
                            end = [int]$range.End
                            inTable = [bool]$range.Information(12)
                        }
                    }
                }
                finally {
                    Release-WordComObject -ComObject $range
                    Release-WordComObject -ComObject $paragraph
                }
            }
            $modeTotal = $matchCount
            $modeIncluded = $findResults.Count
            if ($Start + $modeIncluded - 1 -lt $modeTotal) { $nextStart = $Start + $modeIncluded }
            $modeTruncated = $null -ne $nextStart
        }
        elseif ($Mode -eq 'formatting') {
            $modeTotal = $paragraphCount
            $lastParagraph = [Math]::Min($paragraphCount, $Start + $Limit - 1)
            $characterCountInspected = 0
            $runCount = 0
            for ($paragraphIndex = $Start; $paragraphIndex -le $lastParagraph; $paragraphIndex++) {
                $paragraph = $null
                $range = $null
                $editableRange = $null
                try {
                    $paragraph = $paragraphs.Item($paragraphIndex)
                    $range = $paragraph.Range
                    $editableRange = Get-WordEditableRange -Range $range
                    $runs = @()
                    $currentRun = $null
                    $characters = $editableRange.Characters
                    try {
                        $characterTotal = [int]$characters.Count
                        for ($characterIndex = 1; $characterIndex -le $characterTotal; $characterIndex++) {
                            if ($characterCountInspected -ge $formatCharacterLimit -or $runCount -ge $formatRunLimit) {
                                $modeTruncated = $true
                                break
                            }
                            $characterRange = $null
                            try {
                                $characterRange = $characters.Item($characterIndex)
                                $snapshot = Get-WordFontSnapshot -Range $characterRange
                                $key = Get-WordFontKey -Snapshot $snapshot
                                if ($null -eq $currentRun -or $currentRun.key -ne $key) {
                                    if ($null -ne $currentRun) { $runs += $currentRun.value }
                                    $currentRun = [pscustomobject]@{
                                        key = $key
                                        value = [pscustomobject][ordered]@{
                                            startOffset = $characterIndex - 1
                                            length = 1
                                            text = [string]$characterRange.Text
                                            font = $snapshot
                                        }
                                    }
                                    $runCount++
                                }
                                else {
                                    $currentRun.value.length++
                                    $currentRun.value.text += [string]$characterRange.Text
                                }
                                $characterCountInspected++
                            }
                            finally { Release-WordComObject -ComObject $characterRange }
                        }
                        if ($null -ne $currentRun) { $runs += $currentRun.value }
                    }
                    finally { Release-WordComObject -ComObject $characters }

                    $formattingResults += [pscustomobject][ordered]@{
                        paragraphIndex = $paragraphIndex
                        text = Get-WordRangePlainText -Range $range
                        style = Get-WordStyleName -Range $range
                        font = Get-WordFontSnapshot -Range $editableRange
                        paragraphFormat = Get-WordParagraphFormatSnapshot -Range $range
                        runs = @($runs)
                        runsTruncated = $modeTruncated
                    }
                }
                finally {
                    Release-WordComObject -ComObject $editableRange
                    Release-WordComObject -ComObject $range
                    Release-WordComObject -ComObject $paragraph
                }
                if ($modeTruncated) { break }
            }
            $modeIncluded = $formattingResults.Count
            if (-not $modeTruncated -and $lastParagraph -lt $paragraphCount) { $nextStart = $lastParagraph + 1 }
            if ($modeTruncated -and $modeIncluded -gt 0) { $nextStart = $Start + $modeIncluded }
            $modeTruncated = $modeTruncated -or $null -ne $nextStart
        }
        elseif ($Mode -eq 'media') {
            $styles = $document.Styles
            try {
                $captionStyle = $styles.Item((Get-WordBuiltInStyleId -Name 'caption'))
                $captionStyleName = [string]$captionStyle.NameLocal
            }
            catch { $captionStyleName = '' }

            $inlineShapes = $document.InlineShapes
            $shapes = $document.Shapes
            $inlineCount = [int]$inlineShapes.Count
            $floatingCount = [int]$shapes.Count
            $modeTotal = $inlineCount + $floatingCount
            $lastMedia = [Math]::Min($modeTotal, $Start + $Limit - 1)
            for ($mediaIndex = $Start; $mediaIndex -le $lastMedia; $mediaIndex++) {
                $shape = $null
                $range = $null
                try {
                    if ($mediaIndex -le $inlineCount) {
                        $shape = $inlineShapes.Item($mediaIndex)
                        $range = $shape.Range
                        $kind = 'inline'
                        $kindIndex = $mediaIndex
                    }
                    else {
                        $kindIndex = $mediaIndex - $inlineCount
                        $shape = $shapes.Item($kindIndex)
                        $range = $shape.Anchor
                        $kind = 'floating'
                    }
                    $anchor = Get-WordParagraphRecordForRange -Document $document -Range $range
                    $following = $null
                    if ($null -ne $anchor -and $anchor.index -lt $paragraphCount) {
                        $followingParagraph = $null
                        $followingRange = $null
                        try {
                            $followingParagraph = $paragraphs.Item($anchor.index + 1)
                            $followingRange = $followingParagraph.Range
                            $following = [pscustomobject][ordered]@{
                                index = $anchor.index + 1
                                text = Get-WordRangePlainText -Range $followingRange
                                style = Get-WordStyleName -Range $followingRange
                            }
                        }
                        finally {
                            Release-WordComObject -ComObject $followingRange
                            Release-WordComObject -ComObject $followingParagraph
                        }
                    }
                    $captionStatus = 'uncertain'
                    if ($kind -eq 'inline' -and $null -ne $anchor) {
                        $captionStatus = if ($null -ne $following -and -not [string]::IsNullOrWhiteSpace($captionStyleName) -and
                            ($following.style.Equals($captionStyleName, [StringComparison]::OrdinalIgnoreCase) -or $following.style -match '(?i)caption')) { 'present' } else { 'missing' }
                    }
                    $alternativeText = try { [string]$shape.AlternativeText } catch { '' }
                    $shapeTitle = try { [string]$shape.Title } catch { '' }
                    $mediaResults += [pscustomobject][ordered]@{
                        index = $mediaIndex
                        kind = $kind
                        kindIndex = $kindIndex
                        anchorParagraphIndex = if ($null -ne $anchor) { $anchor.index } else { $null }
                        anchorText = if ($null -ne $anchor) { $anchor.text } else { '' }
                        anchorStart = [int]$range.Start
                        width = [Math]::Round([double]$shape.Width, 2)
                        height = [Math]::Round([double]$shape.Height, 2)
                        alternativeText = $alternativeText
                        title = $shapeTitle
                        followingParagraphIndex = if ($null -ne $following) { $following.index } else { $null }
                        followingText = if ($null -ne $following) { $following.text } else { '' }
                        followingStyle = if ($null -ne $following) { $following.style } else { '' }
                        captionStatus = $captionStatus
                    }
                }
                finally {
                    Release-WordComObject -ComObject $range
                    Release-WordComObject -ComObject $shape
                }
            }
            $modeIncluded = $mediaResults.Count
            if ($lastMedia -lt $modeTotal) { $nextStart = $lastMedia + 1 }
            $modeTruncated = $null -ne $nextStart
        }
        elseif ($Mode -eq 'proofing') {
            $spellingErrors = $null
            $grammarErrors = $null
            try {
                $spellingErrors = $document.SpellingErrors
                $grammarErrors = $document.GrammaticalErrors
                $spellingCount = [int]$spellingErrors.Count
                $grammarCount = [int]$grammarErrors.Count
                $modeTotal = $spellingCount + $grammarCount
                $lastIssue = [Math]::Min($modeTotal, $Start + $Limit - 1)
                for ($issueIndex = $Start; $issueIndex -le $lastIssue; $issueIndex++) {
                    $range = $null
                    $suggestions = $null
                    try {
                        if ($issueIndex -le $spellingCount) {
                            $range = $spellingErrors.Item($issueIndex)
                            $kind = 'spelling'
                        }
                        else {
                            $range = $grammarErrors.Item($issueIndex - $spellingCount)
                            $kind = 'grammar'
                        }
                        $anchor = Get-WordParagraphRecordForRange -Document $document -Range $range
                        $suggestionResults = @()
                        if ($kind -eq 'spelling') {
                            try {
                                $suggestions = $application.GetSpellingSuggestions([string]$range.Text)
                                $suggestionLimit = [Math]::Min(5, [int]$suggestions.Count)
                                for ($suggestionIndex = 1; $suggestionIndex -le $suggestionLimit; $suggestionIndex++) {
                                    $suggestion = $null
                                    try {
                                        $suggestion = $suggestions.Item($suggestionIndex)
                                        $suggestionResults += [string]$suggestion.Name
                                    }
                                    finally { Release-WordComObject -ComObject $suggestion }
                                }
                            }
                            catch { $suggestionResults = @() }
                        }
                        $proofingResults += [pscustomobject][ordered]@{
                            index = $issueIndex
                            kind = $kind
                            text = [string]$range.Text
                            paragraphIndex = if ($null -ne $anchor) { $anchor.index } else { $null }
                            paragraphText = if ($null -ne $anchor) { $anchor.text } else { '' }
                            startOffset = if ($null -ne $anchor) { [int]$range.Start - [int]$anchor.start } else { $null }
                            length = [int]$range.End - [int]$range.Start
                            suggestions = @($suggestionResults)
                        }
                    }
                    finally {
                        Release-WordComObject -ComObject $suggestions
                        Release-WordComObject -ComObject $range
                    }
                }
                $modeIncluded = $proofingResults.Count
                if ($lastIssue -lt $modeTotal) { $nextStart = $lastIssue + 1 }
                $modeTruncated = $null -ne $nextStart
            }
            finally {
                Release-WordComObject -ComObject $grammarErrors
                Release-WordComObject -ComObject $spellingErrors
            }
        }
        else {
            $allReferenceResults = @()
            foreach ($targetType in @('heading', 'figure', 'table')) {
                $referenceType = Get-WordCrossReferenceTypeId -Name $targetType
                $targetItems = @($document.GetCrossReferenceItems($referenceType))
                for ($targetOffset = 0; $targetOffset -lt $targetItems.Count; $targetOffset++) {
                    $allReferenceResults += [pscustomobject][ordered]@{
                        recordType = 'target'
                        targetType = $targetType
                        targetIndex = $targetOffset + 1
                        targetText = Get-WordCrossReferenceItemText -Value $targetItems[$targetOffset]
                    }
                }
            }

            $fields = $document.Fields
            for ($fieldIndex = 1; $fieldIndex -le [int]$fields.Count; $fieldIndex++) {
                $field = $null
                $codeRange = $null
                $resultRange = $null
                try {
                    $field = $fields.Item($fieldIndex)
                    $fieldTypeId = [int]$field.Type
                    if (@(3, 37) -notcontains $fieldTypeId) { continue }
                    $codeRange = $field.Code
                    $resultRange = $field.Result
                    $anchor = Get-WordParagraphRecordForRange -Document $document -Range $resultRange
                    $allReferenceResults += [pscustomobject][ordered]@{
                        recordType = 'field'
                        fieldIndex = $fieldIndex
                        fieldType = if ($fieldTypeId -eq 37) { 'PAGEREF' } else { 'REF' }
                        code = ([string]$codeRange.Text).Trim()
                        resultText = Get-WordRangePlainText -Range $resultRange
                        paragraphIndex = if ($null -ne $anchor) { $anchor.index } else { $null }
                    }
                }
                finally {
                    Release-WordComObject -ComObject $resultRange
                    Release-WordComObject -ComObject $codeRange
                    Release-WordComObject -ComObject $field
                }
            }

            $modeTotal = $allReferenceResults.Count
            if ($Start -le $modeTotal) {
                $lastReference = [Math]::Min($modeTotal, $Start + $Limit - 1)
                for ($referenceIndex = $Start; $referenceIndex -le $lastReference; $referenceIndex++) {
                    $referenceResults += $allReferenceResults[$referenceIndex - 1]
                }
                if ($lastReference -lt $modeTotal) { $nextStart = $lastReference + 1 }
            }
            $modeIncluded = $referenceResults.Count
            $modeTruncated = $null -ne $nextStart
        }

        $tableCount = [int]$document.Tables.Count
        $hyperlinkCount = [int]$document.Hyperlinks.Count
        $metadata = [pscustomobject][ordered]@{
            title = Get-WordBuiltInProperty -Document $document -Name 'Title'
            subject = Get-WordBuiltInProperty -Document $document -Name 'Subject'
            author = Get-WordBuiltInProperty -Document $document -Name 'Author'
            keywords = Get-WordBuiltInProperty -Document $document -Name 'Keywords'
            comments = Get-WordBuiltInProperty -Document $document -Name 'Comments'
            company = Get-WordBuiltInProperty -Document $document -Name 'Company'
            lastSaveTime = Get-WordBuiltInProperty -Document $document -Name 'Last Save Time'
        }
    }
    finally {
        Release-WordComObject -ComObject $fields
        Release-WordComObject -ComObject $captionStyle
        Release-WordComObject -ComObject $styles
        Release-WordComObject -ComObject $shapes
        Release-WordComObject -ComObject $inlineShapes
        Release-WordComObject -ComObject $hyperlinks
        Release-WordComObject -ComObject $tables
        Release-WordComObject -ComObject $paragraphs
        Release-WordComObject -ComObject $content
        Release-WordComObject -ComObject $documents
        if ($null -ne $document) {
            try { $document.Close(0) } catch {}
            Release-WordComObject -ComObject $document
        }
        if ($null -ne $application) {
            try { $application.Quit() } catch {}
            Release-WordComObject -ComObject $application
        }
        Complete-WordComCleanup
    }

    $sourceHashAfter = Get-WordFileHash -Path $sourceFullPath
    if ($sourceHashBefore -ne $sourceHashAfter) { throw 'The source document hash changed during inventory.' }
    $extension = [IO.Path]::GetExtension($sourceFullPath).ToLowerInvariant()
    Write-WordJson -Value ([pscustomobject][ordered]@{
        success = $true
        command = 'Get-WordInventory'
        mode = $Mode
        source = [pscustomobject][ordered]@{
            path = $sourceFullPath
            sha256Before = $sourceHashBefore
            sha256After = $sourceHashAfter
            unchanged = $true
        }
        settingsPath = $settings.SettingsPath
        wordVersion = $wordVersion
        document = [pscustomobject][ordered]@{
            name = [IO.Path]::GetFileName($sourceFullPath)
            pageCount = $pageCount
            wordCount = $wordCount
            characterCount = $characterCount
            paragraphCount = $paragraphCount
            tableCount = $tableCount
            hyperlinkCount = $hyperlinkCount
            macroCapable = @('.doc', '.docm') -contains $extension
            hasVbProject = $hasVbProject
            metadata = $metadata
        }
        paragraphs = @($paragraphResults)
        tables = @($tableResults)
        hyperlinks = @($hyperlinkResults)
        formatting = @($formattingResults)
        media = @($mediaResults)
        proofing = @($proofingResults)
        references = @($referenceResults)
        find = @($findResults)
        truncation = [pscustomobject][ordered]@{
            truncated = $modeTruncated
            start = $Start
            limit = $Limit
            total = $modeTotal
            included = $modeIncluded
            nextStart = $nextStart
        }
    })
}
catch {
    $context = @{}
    if ($null -ne $sourceFullPath) { $context['sourcePath'] = $sourceFullPath }
    if ($null -ne $sourceHashBefore) { $context['sourceSha256Before'] = $sourceHashBefore }
    if ($null -ne $sourceFullPath -and (Test-Path -LiteralPath $sourceFullPath -PathType Leaf)) {
        try { $context['sourceSha256After'] = Get-WordFileHash -Path $sourceFullPath } catch {}
    }
    Write-WordFailure -Command 'Get-WordInventory' -ErrorRecord $_ -Context $context
    exit 1
}

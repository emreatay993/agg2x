#requires -Version 5.1

[CmdletBinding()]
param(
    [Parameter(Mandatory = $true)][string]$SpecPath,
    [Parameter(Mandatory = $true)][string]$OutputPath
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

. (Join-Path -Path $PSScriptRoot -ChildPath 'Word.Common.ps1')

function Get-NewWordProperty {
    param([Parameter(Mandatory = $true)][object]$InputObject, [Parameter(Mandatory = $true)][string]$Name, [Parameter(Mandatory = $true)][string]$Description)
    $property = $InputObject.PSObject.Properties[$Name]
    if ($null -eq $property -or $null -eq $property.Value) { throw "$Description is required." }
    return $property.Value
}

function ConvertTo-NewWordBlock {
    param([Parameter(Mandatory = $true)][object]$Block, [Parameter(Mandatory = $true)][int]$Index)
    $kindValue = Get-NewWordProperty -InputObject $Block -Name 'kind' -Description "Block $Index kind"
    if ($kindValue -isnot [string]) { throw "Block $Index kind must be a JSON string." }
    $kind = ([string]$kindValue).ToLowerInvariant()
    if (@('title', 'heading', 'paragraph', 'bullet') -notcontains $kind) { throw "Unsupported block $Index kind '$kind'." }

    $textValue = Get-NewWordProperty -InputObject $Block -Name 'text' -Description "Block $Index text"
    if ($textValue -isnot [string] -or [string]::IsNullOrWhiteSpace([string]$textValue)) { throw "Block $Index text must be a nonempty JSON string." }
    $text = [string]$textValue
    Assert-WordPlainText -Text $text -Description "Block $Index text"
    if ($text.Length -gt 10000) { throw "Block $Index text exceeds 10000 characters." }

    $level = 1
    $levelProperty = $Block.PSObject.Properties['level']
    if ($null -ne $levelProperty -and $null -ne $levelProperty.Value) {
        if ($levelProperty.Value -isnot [ValueType] -or $levelProperty.Value -is [bool]) { throw "Block $Index level must be a JSON integer." }
        $level = [int]$levelProperty.Value
        if ([double]$levelProperty.Value -ne $level -or $level -lt 1 -or $level -gt 3) { throw "Block $Index level must be 1, 2, or 3." }
    }
    if ($kind -ne 'heading' -and $null -ne $levelProperty -and $null -ne $levelProperty.Value) { throw "Block $Index level is valid only for heading blocks." }

    $style = switch ($kind) {
        'title' { 'Title' }
        'heading' { "Heading$level" }
        'paragraph' { 'Normal' }
        'bullet' { 'ListBullet' }
    }
    return [pscustomobject][ordered]@{ kind = $kind; text = $text; style = $style }
}

function Add-NewWordEntry {
    param(
        [Parameter(Mandatory = $true)][object]$Archive,
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][string]$Content
    )
    $stream = $null
    try {
        $entry = $Archive.CreateEntry($Path)
        $stream = $entry.Open()
        $bytes = (New-Object Text.UTF8Encoding($false)).GetBytes($Content)
        $stream.Write($bytes, 0, $bytes.Length)
    }
    finally { if ($null -ne $stream) { $stream.Dispose() } }
}

$specFullPath = $null
$outputFullPath = $null
$temporaryPath = $null
$outputWritten = $false

try {
    $settings = Get-WordSettings
    $specFullPath = Resolve-ExistingWordFile -Path $SpecPath -Description 'Document spec'
    $outputFullPath = Resolve-WordOutputFile -Path $OutputPath
    if (-not [IO.Path]::GetExtension($outputFullPath).Equals('.docx', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'New Word document OutputPath must use the .docx extension.'
    }
    Assert-WordInputAllowed -Path $outputFullPath -Settings $settings -Description 'New document output'
    if (Test-Path -LiteralPath $outputFullPath) { throw "OutputPath already exists: '$outputFullPath'." }

    try { $spec = [IO.File]::ReadAllText($specFullPath) | ConvertFrom-Json -ErrorAction Stop }
    catch { throw "Could not parse document spec '$specFullPath': $($_.Exception.Message)" }
    $blocksProperty = $spec.PSObject.Properties['blocks']
    if ($null -eq $blocksProperty -or $null -eq $blocksProperty.Value) { throw 'The document spec must contain a blocks array.' }
    $blocks = @($blocksProperty.Value)
    if ($blocks.Count -lt 1 -or $blocks.Count -gt 500) { throw 'The document spec must contain between 1 and 500 blocks.' }
    $validatedBlocks = @()
    for ($index = 0; $index -lt $blocks.Count; $index++) {
        if ($null -eq $blocks[$index]) { throw "Block $($index + 1) is null." }
        $validatedBlocks += ConvertTo-NewWordBlock -Block $blocks[$index] -Index ($index + 1)
    }

    $paragraphXml = foreach ($block in $validatedBlocks) {
        $escapedText = [Security.SecurityElement]::Escape($(if ($block.kind -eq 'bullet') { [char]0x2022 + ' ' + $block.text } else { $block.text }))
        '<w:p><w:pPr><w:pStyle w:val="{0}"/></w:pPr><w:r><w:t xml:space="preserve">{1}</w:t></w:r></w:p>' -f $block.style, $escapedText
    }
    $documentXml = @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main"><w:body>
'@ + ($paragraphXml -join "`n") + @'
<w:sectPr><w:pgSz w:w="12240" w:h="15840"/><w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440"/></w:sectPr></w:body></w:document>
'@
    $stylesXml = @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:styles xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main">
  <w:style w:type="paragraph" w:default="1" w:styleId="Normal"><w:name w:val="Normal"/><w:rPr><w:rFonts w:ascii="Calibri" w:hAnsi="Calibri"/><w:sz w:val="22"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Title"><w:name w:val="Title"/><w:basedOn w:val="Normal"/><w:pPr><w:spacing w:after="240"/></w:pPr><w:rPr><w:b/><w:sz w:val="40"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading1"><w:name w:val="heading 1"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:sz w:val="32"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading2"><w:name w:val="heading 2"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:sz w:val="28"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="Heading3"><w:name w:val="heading 3"/><w:basedOn w:val="Normal"/><w:rPr><w:b/><w:sz w:val="24"/></w:rPr></w:style>
  <w:style w:type="paragraph" w:styleId="ListBullet"><w:name w:val="List Bullet"/><w:basedOn w:val="Normal"/><w:pPr><w:ind w:left="720" w:hanging="360"/></w:pPr></w:style>
</w:styles>
'@
    $temporaryName = ([IO.Path]::GetFileNameWithoutExtension($outputFullPath)) + '.opencode-' + [Guid]::NewGuid().ToString('N') + '.docx'
    $temporaryPath = Join-Path -Path ([IO.Path]::GetDirectoryName($outputFullPath)) -ChildPath $temporaryName
    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [IO.Compression.ZipFile]::Open($temporaryPath, [IO.Compression.ZipArchiveMode]::Create)
    try {
        Add-NewWordEntry -Archive $archive -Path '[Content_Types].xml' -Content @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/word/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.styles+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>
'@
        Add-NewWordEntry -Archive $archive -Path '_rels/.rels' -Content @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>
'@
        Add-NewWordEntry -Archive $archive -Path 'word/_rels/document.xml.rels' -Content @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>
'@
        Add-NewWordEntry -Archive $archive -Path 'word/document.xml' -Content $documentXml
        Add-NewWordEntry -Archive $archive -Path 'word/styles.xml' -Content $stylesXml
        Add-NewWordEntry -Archive $archive -Path 'docProps/core.xml' -Content @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:creator>OpenCode Office Harness</dc:creator></cp:coreProperties>
'@
        Add-NewWordEntry -Archive $archive -Path 'docProps/app.xml' -Content @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties"><Application>OpenCode Office Harness</Application></Properties>
'@
    }
    finally { $archive.Dispose() }

    if (Test-Path -LiteralPath $outputFullPath) { throw "OutputPath appeared during document creation: '$outputFullPath'." }
    [IO.File]::Move($temporaryPath, $outputFullPath)
    $outputWritten = $true
    $outputFile = Get-Item -LiteralPath $outputFullPath -ErrorAction Stop
    Write-WordJson -Value ([pscustomobject][ordered]@{
        success = $true
        command = 'New-WordDocument'
        spec = [pscustomobject][ordered]@{ path = $specFullPath; sha256 = Get-WordFileHash -Path $specFullPath; blockCount = $validatedBlocks.Count }
        output = [pscustomobject][ordered]@{ path = $outputFile.FullName; sha256 = Get-WordFileHash -Path $outputFile.FullName; bytes = [long]$outputFile.Length; overwritten = $false; saveMethod = 'Open XML package + File.Move' }
        settingsPath = $settings.SettingsPath
        verificationLimit = 'The package is structurally created but Word compatibility and layout require inspect and render.'
    })
}
catch {
    $failureRecord = $_
    foreach ($path in @($temporaryPath, $(if (-not $outputWritten) { $outputFullPath } else { $null }))) {
        if ($null -ne $path -and (Test-Path -LiteralPath $path -PathType Leaf)) { try { [IO.File]::Delete($path) } catch {} }
    }
    $context = @{}
    if ($null -ne $specFullPath) { $context['specPath'] = $specFullPath }
    if ($null -ne $outputFullPath) { $context['outputPath'] = $outputFullPath }
    Write-WordFailure -Command 'New-WordDocument' -ErrorRecord $failureRecord -Context $context
    exit 1
}

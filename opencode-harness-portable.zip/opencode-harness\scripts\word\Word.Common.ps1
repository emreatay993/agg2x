Set-StrictMode -Version Latest

$scriptsRoot = Split-Path -Parent $PSScriptRoot
. (Join-Path -Path $scriptsRoot -ChildPath 'office\OfficeFile.Common.ps1')
. (Join-Path -Path $scriptsRoot -ChildPath 'powerpoint\PowerPoint.Common.ps1')

function Get-WordSettings {
    return Get-PowerPointSettings
}

function Resolve-ExistingWordFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$Description
    )

    return Resolve-OfficeFileExistingFile -Path $Path -Description $Description
}

function Resolve-WordOutputFile {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    return Resolve-OfficeFileOutputFile -Path $Path
}

function Assert-WordInputAllowed {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [object]$Settings,

        [Parameter(Mandatory = $true)]
        [string]$Description
    )

    Assert-OfficeFileInputAllowed -Path $Path -Settings $Settings -Description $Description -ToolName 'Word'
}

function Assert-WordOutputAllowed {
    param(
        [Parameter(Mandatory = $true)]
        [string]$OutputPath,

        [Parameter(Mandatory = $true)]
        [string]$SourcePath,

        [Parameter(Mandatory = $true)]
        [object]$Settings
    )

    Assert-OfficeFileOutputAllowed -OutputPath $OutputPath -SourcePath $SourcePath -Settings $Settings -ToolName 'Word'
}

function Assert-WordDocumentExtension {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    $extension = [IO.Path]::GetExtension($Path).ToLowerInvariant()
    if (@('.doc', '.docx', '.docm') -notcontains $extension) {
        throw "Unsupported Word document extension '$extension'."
    }
}

function Assert-WordPdfExtension {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    if (-not [IO.Path]::GetExtension($Path).Equals('.pdf', [StringComparison]::OrdinalIgnoreCase)) {
        throw 'Word render OutputPath must use the .pdf extension.'
    }
}

function Get-WordFileHash {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    return Get-OfficeFileSha256 -Path $Path
}

function Release-WordComObject {
    param(
        [AllowNull()]
        [object]$ComObject
    )

    Release-OfficeFileComObject -ComObject $ComObject
}

function Complete-WordComCleanup {
    Complete-OfficeFileComCleanup
}

function Write-WordJson {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Value
    )

    Write-OfficeFileJson -Value $Value
}

function Write-WordFailure {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Command,

        [Parameter(Mandatory = $true)]
        [Management.Automation.ErrorRecord]$ErrorRecord,

        [hashtable]$Context = @{}
    )

    Write-OfficeFileFailure -Command $Command -ErrorRecord $ErrorRecord -Context $Context
}

function Assert-WordPlainText {
    param(
        [AllowEmptyString()]
        [Parameter(Mandatory = $true)]
        [string]$Text,

        [Parameter(Mandatory = $true)]
        [string]$Description
    )

    if ($Text.Contains("`r") -or $Text.Contains("`n")) {
        throw "$Description cannot contain CR or LF characters."
    }
}

function Get-WordRangePlainText {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Range
    )

    $text = [string]$Range.Text
    while ($text.Length -gt 0) {
        $lastCharacter = [int][char]$text[$text.Length - 1]
        if ($lastCharacter -ne 13 -and $lastCharacter -ne 7) {
            break
        }
        $text = $text.Substring(0, $text.Length - 1)
    }
    return $text
}

function Set-WordRangePlainText {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Range,

        [AllowEmptyString()]
        [Parameter(Mandatory = $true)]
        [string]$Text
    )

    $editableRange = $null
    try {
        $rawText = [string]$Range.Text
        $editableRange = $Range.Duplicate
        if ($rawText.Length -gt 0) {
            $lastCharacter = [int][char]$rawText[$rawText.Length - 1]
            if ($lastCharacter -eq 13 -or $lastCharacter -eq 7) {
                $editableRange.End = [int]$editableRange.End - 1
            }
        }
        $editableRange.Text = $Text
    }
    finally {
        Release-WordComObject -ComObject $editableRange
    }
}

function Get-WordEditableRange {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Range
    )

    $editableRange = $Range.Duplicate
    $rawText = [string]$editableRange.Text
    if ($rawText.Length -gt 0) {
        $lastCharacter = [int][char]$rawText[$rawText.Length - 1]
        if ($lastCharacter -eq 13 -or $lastCharacter -eq 7) {
            $editableRange.End = [int]$editableRange.End - 1
        }
    }
    return $editableRange
}

function ConvertFrom-WordUndefined {
    param([AllowNull()][object]$Value)

    if ($null -eq $Value) { return $null }
    try {
        if ([double]$Value -eq 9999999) { return $null }
    }
    catch {}
    return $Value
}

function Get-WordFontSnapshot {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Range
    )

    $font = $null
    try {
        $font = $Range.Font
        $bold = ConvertFrom-WordUndefined -Value ([int]$font.Bold)
        $italic = ConvertFrom-WordUndefined -Value ([int]$font.Italic)
        $underline = ConvertFrom-WordUndefined -Value ([int]$font.Underline)
        return [pscustomobject][ordered]@{
            name      = ConvertFrom-WordUndefined -Value ([string]$font.Name)
            size      = ConvertFrom-WordUndefined -Value ([double]$font.Size)
            bold      = if ($null -eq $bold) { $null } else { [int]$bold -ne 0 }
            italic    = if ($null -eq $italic) { $null } else { [int]$italic -ne 0 }
            underline = if ($null -eq $underline) { $null } else { [int]$underline -ne 0 }
        }
    }
    finally {
        Release-WordComObject -ComObject $font
    }
}

function Get-WordParagraphFormatSnapshot {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Range
    )

    $format = $null
    try {
        $format = $Range.ParagraphFormat
        return [pscustomobject][ordered]@{
            alignment  = ConvertFrom-WordUndefined -Value ([int]$format.Alignment)
            spaceBefore = ConvertFrom-WordUndefined -Value ([double]$format.SpaceBefore)
            spaceAfter = ConvertFrom-WordUndefined -Value ([double]$format.SpaceAfter)
            lineSpacing = ConvertFrom-WordUndefined -Value ([double]$format.LineSpacing)
        }
    }
    finally {
        Release-WordComObject -ComObject $format
    }
}

function Get-WordBuiltInStyleId {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    switch ($Name.ToLowerInvariant()) {
        'normal' { return -1 }
        'heading1' { return -2 }
        'heading2' { return -3 }
        'heading3' { return -4 }
        'caption' { return -35 }
        'bullet' { return -49 }
        'title' { return -63 }
        default { throw "Unsupported Word built-in style '$Name'." }
    }
}

function Get-WordCrossReferenceTypeId {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name
    )

    switch ($Name.ToLowerInvariant()) {
        'heading' { return 1 }
        'figure' { return -1 }
        'table' { return -2 }
        default { throw "Unsupported Word cross-reference target type '$Name'." }
    }
}

function Get-WordCrossReferenceItemText {
    param(
        [AllowNull()]
        [object]$Value
    )

    $text = if ($null -eq $Value) { '' } else { [string]$Value }
    return $text.TrimEnd([char[]]@(13, 7))
}

function Get-WordCrossReferenceKindId {
    param(
        [Parameter(Mandatory = $true)]
        [string]$TargetType,

        [Parameter(Mandatory = $true)]
        [string]$ReferenceKind
    )

    switch ("$($TargetType.ToLowerInvariant())|$($ReferenceKind.ToLowerInvariant())") {
        'heading|heading_text' { return -1 }
        'heading|heading_number' { return -4 }
        'heading|page_number' { return 7 }
        'figure|entire_caption' { return 2 }
        'figure|label_and_number' { return 3 }
        'figure|caption_text' { return 4 }
        'figure|page_number' { return 7 }
        'table|entire_caption' { return 2 }
        'table|label_and_number' { return 3 }
        'table|caption_text' { return 4 }
        'table|page_number' { return 7 }
        default { throw "Reference kind '$ReferenceKind' is not supported for Word target type '$TargetType'." }
    }
}

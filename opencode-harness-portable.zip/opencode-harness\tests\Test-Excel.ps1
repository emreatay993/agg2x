#requires -Version 5.1

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$testRoot = Join-Path $env:TEMP ('opencode-office-excel-' + [Guid]::NewGuid().ToString('N'))
$allowedRoot = Join-Path $testRoot 'allowed'
$settingsRoot = Join-Path $testRoot 'settings'
$source = Join-Path $allowedRoot 'source.xlsx'
$outsideSource = Join-Path $testRoot 'outside.xlsx'
$wrongExtension = Join-Path $allowedRoot 'source.txt'
$output = Join-Path $allowedRoot 'edited.xlsx'
$renderPath = Join-Path $allowedRoot 'rendered.pdf'
$application = $null
$workbook = $null
$workbooks = $null
$worksheets = $null
$worksheet = $null
$previousSettings = $env:OFFICE_HARNESS_SETTINGS

function Write-TestJson {
    param(
        [Parameter(Mandatory = $true)][string]$Path,
        [Parameter(Mandatory = $true)][object]$Value
    )
    [IO.File]::WriteAllText($Path, ($Value | ConvertTo-Json -Depth 12), (New-Object Text.UTF8Encoding($false)))
}

function Assert-ExcelScriptFails {
    param(
        [Parameter(Mandatory = $true)][string]$Script,
        [Parameter(Mandatory = $true)][string[]]$Arguments,
        [Parameter(Mandatory = $true)][string]$ExpectedMessage
    )

    $powerShell = Join-Path $PSHOME 'powershell.exe'
    $outputText = (& $powerShell -NoLogo -NoProfile -NonInteractive -File $Script @Arguments 2>&1 | Out-String)
    $exitCode = $LASTEXITCODE
    if ($exitCode -eq 0) {
        throw "Expected '$Script' to fail, but it succeeded."
    }
    if ($outputText -notlike "*$ExpectedMessage*") {
        throw "Expected failure containing '$ExpectedMessage', received: $outputText"
    }
}

try {
    $null = New-Item -ItemType Directory -Path $allowedRoot
    $null = New-Item -ItemType Directory -Path $settingsRoot
    Write-TestJson -Path (Join-Path $settingsRoot 'powerpoint.local.json') -Value ([ordered]@{
        allowedRoots      = @($allowedRoot)
        defaultOutputRoot = ''
    })
    $env:OFFICE_HARNESS_SETTINGS = $settingsRoot

    $application = New-Object -ComObject Excel.Application
    $application.Visible = $false
    $application.DisplayAlerts = $false
    $workbooks = $application.Workbooks
    $workbook = $workbooks.Add()
    $worksheets = $workbook.Worksheets
    $worksheet = $worksheets.Item(1)
    $worksheet.Name = 'Data'
    $worksheet.Range('A1').Value2 = 'Original'
    $worksheet.Range('B1').Value2 = 'To clear'
    $worksheet.Range('C1').Formula = '=1+1'
    $worksheet.Range('D1').Value2 = 'Protected'
    $worksheet.Range('A1:B1').Locked = $false
    $worksheet.Protect()
    $workbook.SaveAs($source, 51)
    $workbook.Close($false)
    foreach ($comObject in @($worksheet, $worksheets, $workbook, $workbooks)) {
        if ($null -ne $comObject -and [Runtime.InteropServices.Marshal]::IsComObject($comObject)) {
            [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($comObject)
        }
    }
    $worksheet = $null
    $worksheets = $null
    $workbook = $null
    $workbooks = $null
    $application.Quit()
    [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($application)
    $application = $null
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()

    Copy-Item -LiteralPath $source -Destination $outsideSource
    Copy-Item -LiteralPath $source -Destination $wrongExtension
    $sourceHashBefore = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    $inventoryScript = Join-Path $root 'scripts\excel\Get-ExcelInventory.ps1'
    $renderScript = Join-Path $root 'scripts\excel\Export-ExcelWorkbook.ps1'
    $editScript = Join-Path $root 'scripts\excel\Edit-ExcelCopy.ps1'

    $inventoryJson = & $inventoryScript -SourcePath $source -SheetName 'Data' -RangeAddress 'A1:D1'
    if (-not $?) { throw "Excel inventory failed: $inventoryJson" }
    $inventory = $inventoryJson | ConvertFrom-Json
    if (-not $inventory.success -or $inventory.workbook.worksheetCount -lt 1) {
        throw 'Excel inventory returned unexpected workbook metadata.'
    }
    if ($inventory.inspectedRange.cellCount -ne 4) {
        throw 'Excel inventory returned an unexpected inspected range.'
    }

    $renderJson = & $renderScript -SourcePath $source -OutputPath $renderPath
    if (-not $?) { throw 'Excel PDF export failed.' }
    $render = $renderJson | ConvertFrom-Json
    if (-not $render.success -or -not (Test-Path -LiteralPath $renderPath -PathType Leaf)) {
        throw 'Excel PDF export did not create the expected file.'
    }

    $planPath = Join-Path $allowedRoot 'plan.json'
    Write-TestJson -Path $planPath -Value ([ordered]@{
        allowOverwrite = $false
        operations = @(
            [ordered]@{
                operation   = 'set_value'
                sheetName   = 'Data'
                address     = 'A1'
                expectedText = 'Original'
                value       = 'Edited'
            },
            [ordered]@{
                operation   = 'clear'
                sheetName   = 'Data'
                address     = 'B1'
                expectedText = 'To clear'
            }
        )
    })
    $editJson = & $editScript -SourcePath $source -OutputPath $output -PlanPath $planPath
    if (-not $?) { throw 'Excel save-copy edit failed.' }
    $edit = $editJson | ConvertFrom-Json
    if (-not $edit.success -or $edit.operations.Count -ne 2) {
        throw 'Excel edit returned unexpected operation results.'
    }
    if ($edit.output.saveMethod -ne 'SaveCopyAsThenAtomicMove') {
        throw 'Excel edit did not report the atomic save-copy path.'
    }
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $sourceHashBefore) {
        throw 'Source workbook changed.'
    }

    $editedInventoryJson = & $inventoryScript -SourcePath $output -SheetName 'Data' -RangeAddress 'A1:B1'
    $editedInventory = $editedInventoryJson | ConvertFrom-Json
    if ($editedInventory.inspectedRange.cells[0].displayedText -ne 'Edited') {
        throw 'set_value did not persist in the output copy.'
    }
    if ($editedInventory.inspectedRange.cells[1].displayedText -ne '') {
        throw 'clear did not persist in the output copy.'
    }

    Assert-ExcelScriptFails -Script $inventoryScript -Arguments @(
        '-SourcePath', $outsideSource
    ) -ExpectedMessage 'outside the configured Excel allowed roots'
    Assert-ExcelScriptFails -Script $inventoryScript -Arguments @(
        '-SourcePath', $wrongExtension
    ) -ExpectedMessage 'Unsupported Excel workbook extension'
    Assert-ExcelScriptFails -Script $inventoryScript -Arguments @(
        '-SourcePath', $source, '-SheetName', 'Data', '-RangeAddress', 'A1:A33'
    ) -ExpectedMessage 'maximum is 32'
    Assert-ExcelScriptFails -Script $renderScript -Arguments @(
        '-SourcePath', $source, '-OutputPath', $renderPath
    ) -ExpectedMessage 'already exists'
    Assert-ExcelScriptFails -Script $editScript -Arguments @(
        '-SourcePath', $source, '-OutputPath', $source, '-PlanPath', $planPath
    ) -ExpectedMessage 'distinct full paths'
    Assert-ExcelScriptFails -Script $editScript -Arguments @(
        '-SourcePath', $source, '-OutputPath', $output, '-PlanPath', $planPath
    ) -ExpectedMessage 'already exists'

    $negativePlans = @(
        [pscustomobject]@{
            Name = 'stale'
            Expected = 'Stale target'
            Operation = [ordered]@{
                operation = 'set_value'; sheetName = 'Data'; address = 'A1'
                expectedText = 'Wrong'; value = 'Edited'
            }
        },
        [pscustomobject]@{
            Name = 'range'
            Expected = 'single-cell A1 reference'
            Operation = [ordered]@{
                operation = 'clear'; sheetName = 'Data'; address = 'A1:B1'
                expectedText = 'Original'
            }
        },
        [pscustomobject]@{
            Name = 'formula-target'
            Expected = 'Formula cell'
            Operation = [ordered]@{
                operation = 'clear'; sheetName = 'Data'; address = 'C1'
                expectedText = '2'
            }
        },
        [pscustomobject]@{
            Name = 'protected-target'
            Expected = 'Protected cell'
            Operation = [ordered]@{
                operation = 'clear'; sheetName = 'Data'; address = 'D1'
                expectedText = 'Protected'
            }
        },
        [pscustomobject]@{
            Name = 'formula-like'
            Expected = 'Formula-like string'
            Operation = [ordered]@{
                operation = 'set_value'; sheetName = 'Data'; address = 'A1'
                expectedText = 'Original'; value = '=1+1'
            }
        },
        [pscustomobject]@{
            Name = 'formatting'
            Expected = 'Unsupported operation'
            Operation = [ordered]@{
                operation = 'set_format'; sheetName = 'Data'; address = 'A1'
                expectedText = 'Original'
            }
        }
    )

    foreach ($negative in $negativePlans) {
        $negativePlan = Join-Path $allowedRoot ($negative.Name + '.json')
        $negativeOutput = Join-Path $allowedRoot ($negative.Name + '.xlsx')
        Write-TestJson -Path $negativePlan -Value ([ordered]@{
            allowOverwrite = $false
            operations = @($negative.Operation)
        })
        Assert-ExcelScriptFails -Script $editScript -Arguments @(
            '-SourcePath', $source, '-OutputPath', $negativeOutput, '-PlanPath', $negativePlan
        ) -ExpectedMessage $negative.Expected
        if (Test-Path -LiteralPath $negativeOutput) {
            throw "Failed edit left an output file '$negativeOutput'."
        }
    }

    $tooManyPlan = Join-Path $allowedRoot 'too-many.json'
    $tooManyOperations = @()
    for ($index = 1; $index -le 101; $index++) {
        $tooManyOperations += [ordered]@{
            operation = 'clear'; sheetName = 'Data'; address = 'A1'; expectedText = 'Original'
        }
    }
    Write-TestJson -Path $tooManyPlan -Value ([ordered]@{
        allowOverwrite = $false
        operations = $tooManyOperations
    })
    Assert-ExcelScriptFails -Script $editScript -Arguments @(
        '-SourcePath', $source
        '-OutputPath', (Join-Path $allowedRoot 'too-many.xlsx')
        '-PlanPath', $tooManyPlan
    ) -ExpectedMessage 'between 1 and 100 operations'

    [pscustomobject]@{
        Ok              = $true
        SourceUnchanged = $true
        RenderedPdf     = $renderPath
        EditedCopy      = $output
        NegativeCases   = $negativePlans.Count + 7
    } | ConvertTo-Json
}
finally {
    foreach ($comObject in @($worksheet, $worksheets, $workbook, $workbooks)) {
        if ($null -ne $comObject -and [Runtime.InteropServices.Marshal]::IsComObject($comObject)) {
            try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($comObject) } catch {}
        }
    }
    if ($null -ne $application) {
        try { $application.Quit() } catch {}
        if ([Runtime.InteropServices.Marshal]::IsComObject($application)) {
            try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($application) } catch {}
        }
    }
    if ($null -eq $previousSettings) {
        Remove-Item Env:OFFICE_HARNESS_SETTINGS -ErrorAction SilentlyContinue
    }
    else {
        $env:OFFICE_HARNESS_SETTINGS = $previousSettings
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    if (Test-Path -LiteralPath $testRoot -PathType Container) {
        Remove-Item -LiteralPath $testRoot -Recurse -Force
    }
}

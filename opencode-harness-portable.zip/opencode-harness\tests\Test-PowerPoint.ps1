#requires -Version 5.1

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$testRoot = Join-Path $env:TEMP ('opencode-office-ppt-' + [Guid]::NewGuid().ToString('N'))
$null = New-Item -ItemType Directory -Path $testRoot
$source = Join-Path $testRoot 'source.pptx'
$output = Join-Path $testRoot 'edited.pptx'
$renderRoot = Join-Path $testRoot 'rendered'
$planPath = Join-Path $testRoot 'plan.json'
$settingsRoot = Join-Path $testRoot 'settings'
$application = $null
$presentation = $null
$presentations = $null
$slides = $null
$slide = $null
$shapes = $null
$shape = $null
$previousSettings = if (Test-Path Env:OFFICE_HARNESS_SETTINGS) { $env:OFFICE_HARNESS_SETTINGS } else { $null }

try {
    $null = New-Item -ItemType Directory -Path $settingsRoot
    $settings = [ordered]@{
        allowedRoots = @($testRoot)
        defaultOutputRoot = ''
        renderWidth = 1920
        renderHeight = 1080
    }
    [IO.File]::WriteAllText((Join-Path $settingsRoot 'powerpoint.local.json'), ($settings | ConvertTo-Json -Depth 4), (New-Object Text.UTF8Encoding($false)))
    $env:OFFICE_HARNESS_SETTINGS = $settingsRoot
    $application = New-Object -ComObject PowerPoint.Application
    $presentations = $application.Presentations
    $presentation = $presentations.Add()
    $slides = $presentation.Slides
    for ($fixtureSlideIndex = 1; $fixtureSlideIndex -le 12; $fixtureSlideIndex++) {
        $slide = $slides.Add($fixtureSlideIndex, 12)
        $shapes = $slide.Shapes
        $shape = $shapes.AddTextbox(1, 80, 80, 600, 100)
        $shape.Name = 'HarnessTitle'
        $shape.TextFrame.TextRange.Text = "Original harness text $fixtureSlideIndex"
        foreach ($comObject in @($shape, $shapes, $slide)) {
            if ($null -ne $comObject -and [Runtime.InteropServices.Marshal]::IsComObject($comObject)) {
                [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($comObject)
            }
        }
        $shape = $null
        $shapes = $null
        $slide = $null
    }
    $presentation.SaveAs($source, 24)
    $presentation.Close()
    $presentation = $null
    $application.Quit()
    $application = $null

    $sourceHashBefore = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    $inventoryScript = Join-Path $root 'scripts\powerpoint\Get-PowerPointInventory.ps1'
    $inventoryJson = & $inventoryScript -SourcePath $source -StartSlide 1 -Limit 5
    if (-not $?) { throw 'PowerPoint inventory failed.' }
    $inventory = $inventoryJson | ConvertFrom-Json
    if ($inventory.presentation.slideCount -ne 12 -or @($inventory.slides).Count -ne 5) { throw 'Unexpected first inventory page.' }
    if ($inventory.truncation.nextStart -ne 6 -or $inventory.slides[0].index -ne 1 -or $inventory.slides[4].index -ne 5) {
        throw 'First PowerPoint inventory page has incorrect boundaries.'
    }
    $secondInventory = (& $inventoryScript -SourcePath $source -StartSlide 6 -Limit 5) | ConvertFrom-Json
    if ($secondInventory.truncation.nextStart -ne 11 -or $secondInventory.slides[0].index -ne 6 -or $secondInventory.slides[4].index -ne 10) {
        throw 'Second PowerPoint inventory page has incorrect boundaries.'
    }
    $finalInventory = (& $inventoryScript -SourcePath $source -StartSlide 11 -Limit 5) | ConvertFrom-Json
    if ($finalInventory.truncation.truncated -or $null -ne $finalInventory.truncation.nextStart -or @($finalInventory.slides).Count -ne 2) {
        throw 'Final PowerPoint inventory page has incorrect completion metadata.'
    }

    $renderJson = & (Join-Path $root 'scripts\powerpoint\Export-PowerPointSlides.ps1') -SourcePath $source -OutputFolder $renderRoot
    if (-not $?) { throw 'PowerPoint render failed.' }
    $render = $renderJson | ConvertFrom-Json
    if (-not $render.success) { throw 'PowerPoint render reported failure.' }

    $plan = [ordered]@{
        allowOverwrite = $false
        operations = @(
            [ordered]@{
                operation = 'replace_text'
                slideIndex = 1
                shapeName = 'HarnessTitle'
                find = 'Original'
                replace = 'Edited'
            }
        )
    }
    [IO.File]::WriteAllText($planPath, ($plan | ConvertTo-Json -Depth 6), (New-Object Text.UTF8Encoding($false)))
    $editJson = & (Join-Path $root 'scripts\powerpoint\Edit-PowerPointCopy.ps1') -SourcePath $source -OutputPath $output -PlanPath $planPath
    if (-not $?) { throw 'PowerPoint save-copy edit failed.' }
    $edit = $editJson | ConvertFrom-Json
    if (-not $edit.success) { throw 'PowerPoint edit reported failure.' }
    if (-not (Test-Path -LiteralPath $output -PathType Leaf)) { throw 'Edited deck was not created.' }
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $sourceHashBefore) { throw 'Source deck changed.' }

    $editedInventoryJson = & $inventoryScript -SourcePath $output -StartSlide 1 -Limit 1
    $editedInventory = $editedInventoryJson | ConvertFrom-Json
    $editedShape = @($editedInventory.slides[0].shapes | Where-Object name -eq 'HarnessTitle')[0]
    if ($editedShape.text -ne 'Edited harness text 1') { throw "Unexpected edited text '$($editedShape.text)'." }

    [pscustomobject]@{
        Ok = $true
        Source = $source
        Output = $output
        RenderedSlides = @($render.output.slides).Count
        SourceUnchanged = $true
    } | ConvertTo-Json
}
finally {
    foreach ($comObject in @($shape, $shapes, $slide, $slides, $presentation, $presentations)) {
        if ($null -ne $comObject -and [Runtime.InteropServices.Marshal]::IsComObject($comObject)) {
            try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($comObject) } catch {}
        }
    }
    if ($null -ne $application) {
        try { $application.Quit() } catch {}
        if ([Runtime.InteropServices.Marshal]::IsComObject($application)) {
            try { [void][Runtime.InteropServices.Marshal]::FinalReleaseComObject($application) } catch {}
        }
    }
    [GC]::Collect()
    [GC]::WaitForPendingFinalizers()
    if ($null -eq $previousSettings) {
        Remove-Item Env:OFFICE_HARNESS_SETTINGS -ErrorAction SilentlyContinue
    }
    else {
        $env:OFFICE_HARNESS_SETTINGS = $previousSettings
    }
    if (Test-Path -LiteralPath $testRoot -PathType Container) {
        Remove-Item -LiteralPath $testRoot -Recurse -Force
    }
}

#requires -Version 5.1

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$failures = New-Object System.Collections.ArrayList

function Add-Failure { param([string]$Message) $null = $failures.Add($Message) }

function Assert-FileContains {
    param(
        [Parameter(Mandatory = $true)][string]$RelativePath,
        [Parameter(Mandatory = $true)][string]$Pattern,
        [Parameter(Mandatory = $true)][string]$Message
    )
    $path = Join-Path $root $RelativePath
    if (-not (Test-Path -LiteralPath $path -PathType Leaf)) {
        Add-Failure "Missing required file: $RelativePath"
        return
    }
    if ([IO.File]::ReadAllText($path) -notmatch $Pattern) { Add-Failure $Message }
}

$powerShellFiles = @(Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object { $_.Extension -in @('.ps1', '.psm1') })
foreach ($file in $powerShellFiles) {
    $tokens = $null
    $errors = $null
    [void][Management.Automation.Language.Parser]::ParseFile($file.FullName, [ref]$tokens, [ref]$errors)
    foreach ($error in @($errors)) { Add-Failure "$($file.FullName):$($error.Extent.StartLineNumber): $($error.Message)" }
}

$jsonFiles = @(Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object {
    $_.Extension -eq '.json' -and $_.Name -ne 'package-lock.json' -and $_.FullName -notmatch '[\\/]node_modules[\\/]'
})
foreach ($file in $jsonFiles) {
    try { $null = [IO.File]::ReadAllText($file.FullName) | ConvertFrom-Json -ErrorAction Stop }
    catch { Add-Failure "Invalid JSON $($file.FullName): $($_.Exception.Message)" }
}

foreach ($template in @(Get-ChildItem -LiteralPath (Join-Path $root 'profiles') -Recurse -File -Filter '*.template')) {
    try {
        $text = [IO.File]::ReadAllText($template.FullName)
        $text = $text.Replace('__GENERAL_MODEL_ID__', 'general-model')
        $text = $text.Replace('__CODER_MODEL_ID__', 'coder-model')
        $text = [regex]::Replace($text, '__[A-Z0-9_]+__', 'placeholder')
        $null = $text | ConvertFrom-Json -ErrorAction Stop
    }
    catch { Add-Failure "Invalid config template $($template.FullName): $($_.Exception.Message)" }
}

$skillFiles = @(Get-ChildItem -LiteralPath (Join-Path $root 'opencode\skills') -Recurse -File -Filter 'SKILL.md')
foreach ($file in $skillFiles) {
    $folderName = Split-Path -Leaf (Split-Path -Parent $file.FullName)
    $content = [IO.File]::ReadAllText($file.FullName)
    if ($folderName -notmatch '^[a-z0-9]+(?:-[a-z0-9]+)*$') { Add-Failure "Invalid skill folder name: $folderName" }
    if ($content -notmatch "(?m)^name:\s+$([regex]::Escape($folderName))\s*$") { Add-Failure "Skill name does not match folder: $($file.FullName)" }
    if ($content -notmatch '(?m)^description:\s+\S') { Add-Failure "Skill description missing: $($file.FullName)" }
}

$trackedTextFiles = @(Get-ChildItem -LiteralPath $root -Recurse -File | Where-Object {
    $_.FullName -notmatch '[\\/](node_modules|local)[\\/]' -and $_.Extension -in @('.md', '.ps1', '.psm1', '.ts', '.json', '.template')
})
foreach ($file in $trackedTextFiles) {
    $content = [IO.File]::ReadAllText($file.FullName)
    if ($content -match 'C:\\Users\\emre_') { Add-Failure "Personal absolute path found: $($file.FullName)" }
    if ($content -match '(?i)(api[_-]?key|x-goog-api-key)\s*[:=]\s*["''][A-Za-z0-9_-]{16,}') { Add-Failure "Possible plaintext secret found: $($file.FullName)" }
}

$powerPointEdit = [IO.File]::ReadAllText((Join-Path $root 'scripts\powerpoint\Edit-PowerPointCopy.ps1'))
if ($powerPointEdit -match '\.Save\(' -or $powerPointEdit -match '\.SaveAs\(') { Add-Failure 'PowerPoint edit script contains Save or SaveAs.' }
if ($powerPointEdit -notmatch '\.SaveCopyAs\(') { Add-Failure 'PowerPoint edit script does not call SaveCopyAs.' }

Assert-FileContains 'scripts\powerpoint\PowerPoint.Common.ps1' 'OfficeFile\.Common\.ps1' 'PowerPoint does not use the shared Office-file helper.'
Assert-FileContains 'opencode\tools\office_word.ts' 'export const apply_plan' 'Word custom tools are incomplete.'
Assert-FileContains 'opencode\tools\office_word.ts' 'export const new_document' 'Word document creation tool is missing.'
Assert-FileContains 'opencode\tools\office_word.ts' 'discriminatedUnion\("operation"' 'Word operations do not use operation-specific schemas.'
foreach ($wordOperation in @('replace_paragraph_text', 'replace_text_with_cross_reference', 'set_paragraph_text', 'set_table_cell_text', 'set_text_format', 'set_paragraph_format', 'insert_paragraph_after')) {
    Assert-FileContains 'opencode\tools\office_word.ts' ('literal\("{0}"\)' -f [regex]::Escape($wordOperation)) "Word tool is missing strict schema branch '$wordOperation'."
}
Assert-FileContains 'scripts\word\New-WordDocument.ps1' 'Open XML package \+ File\.Move' 'Word document creation does not use the guarded Open XML path.'
Assert-FileContains 'opencode\tools\office_excel.ts' 'export const apply_plan' 'Excel custom tools are incomplete.'
Assert-FileContains 'opencode\tools\office_word.ts' 'export const apply_saved_plan' 'Word saved-plan tool is missing.'

$wordAutoPath = Join-Path $root 'opencode\agents\word-auto.md'
if (-not (Test-Path -LiteralPath $wordAutoPath -PathType Leaf)) {
    Add-Failure 'Word-only primary agent is missing.'
}
else {
    $wordAuto = [IO.File]::ReadAllText($wordAutoPath)
    foreach ($requiredWordAutoGate in @(
        'mode: primary',
        'temperature: 0.1',
        '"*": deny',
        'read: allow',
        'edit: allow',
        'glob: allow',
        'office_word_inspect: allow',
        'office_word_render: allow',
        'office_word_apply_plan: allow',
        'office_word_apply_saved_plan: allow',
        'office_word_new_document: allow'
    )) {
        if ($wordAuto -notmatch [regex]::Escape($requiredWordAutoGate)) {
            Add-Failure "Word-only agent is missing guardrail '$requiredWordAutoGate'."
        }
    }
    if ($wordAuto -match '(?m)^model:') { Add-Failure 'Word-only agent overrides the user-selected model.' }
}

$wordEditPath = Join-Path $root 'scripts\word\Edit-WordCopy.ps1'
if (Test-Path -LiteralPath $wordEditPath -PathType Leaf) {
    $wordEdit = [IO.File]::ReadAllText($wordEditPath)
    if ($wordEdit -notmatch '\[IO\.File\]::Copy\(') { Add-Failure 'Word edit script does not create its output through atomic File.Copy.' }
    if ($wordEdit -match '\.SaveAs2?\(') { Add-Failure 'Word edit script contains SaveAs or SaveAs2.' }
}

$excelEditPath = Join-Path $root 'scripts\excel\Edit-ExcelCopy.ps1'
if (Test-Path -LiteralPath $excelEditPath -PathType Leaf) {
    $excelEdit = [IO.File]::ReadAllText($excelEditPath)
    if ($excelEdit -match '\.Save\(' -or $excelEdit -match '\.SaveAs\(') { Add-Failure 'Excel edit script contains Save or SaveAs.' }
    if ($excelEdit -notmatch '\.SaveCopyAs\(') { Add-Failure 'Excel edit script does not call SaveCopyAs.' }
}

$internetTemplate = [IO.File]::ReadAllText((Join-Path $root 'profiles\internet\opencode.json.template'))
$intranetTemplate = [IO.File]::ReadAllText((Join-Path $root 'profiles\intranet\opencode.json.template'))
if ($internetTemplate -notmatch '"outlook_web"\s*:') { Add-Failure 'Internet profile does not configure the dedicated Outlook Web MCP.' }
if ($internetTemplate -notmatch '__OUTLOOK_WEB_BROWSER_PROFILE_DIR__' -or
    $internetTemplate -notmatch '__OUTLOOK_WEB_BROWSER_OUTPUT_DIR__') {
    Add-Failure 'Internet profile does not isolate Outlook Web browser state and output.'
}
if ($intranetTemplate -match '"outlook_web"\s*:') { Add-Failure 'Intranet profile configures an Outlook Web MCP.' }

$outlookWebAgent = [IO.File]::ReadAllText((Join-Path $root 'opencode\agents\outlook-web-reader.md'))
foreach ($requiredPattern in @(
    'outlook_web_browser_*: deny',
    'Open Outlook folder:*',
    'Open Outlook message:*',
    'Outlook search box',
    'outlook_web_browser_file_upload: deny',
    'outlook_web_browser_network_request: deny',
    'outlook_web_browser_cookie_*: deny'
)) {
    if ($outlookWebAgent -notmatch [regex]::Escape($requiredPattern)) {
        Add-Failure "Outlook Web reader is missing guardrail '$requiredPattern'."
    }
}

$outlookReaderAgent = [IO.File]::ReadAllText((Join-Path $root 'opencode\agents\outlook-reader.md'))
foreach ($forbiddenReaderTool in @(
    'office_outlook_set_properties',
    'office_outlook_move',
    'office_outlook_delete_messages',
    'office_outlook_create_draft',
    'office_outlook_send_draft',
    'office_outlook_save_attachment',
    'office_outlook_create_folder',
    'office_outlook_create_rule'
)) {
    if ($outlookReaderAgent -match [regex]::Escape($forbiddenReaderTool)) {
        Add-Failure "Read-only Outlook reader agent references write tool '$forbiddenReaderTool'."
    }
}

$outlookOperatorAgent = [IO.File]::ReadAllText((Join-Path $root 'opencode\agents\outlook-operator.md'))
foreach ($requiredOperatorGate in @(
    'office_outlook_delete_messages: ask',
    'office_outlook_send_draft: ask',
    'office_outlook_create_rule: ask',
    'bash: deny',
    'office_memory_*: deny'
)) {
    if ($outlookOperatorAgent -notmatch [regex]::Escape($requiredOperatorGate)) {
        Add-Failure "Outlook operator agent is missing guardrail '$requiredOperatorGate'."
    }
}

foreach ($gatedScript in @(
    'scripts\outlook\Remove-OutlookMail.ps1',
    'scripts\outlook\Send-OutlookDraft.ps1',
    'scripts\outlook\New-OutlookRule.ps1'
)) {
    $gatedText = [IO.File]::ReadAllText((Join-Path $root $gatedScript))
    if ($gatedText -notmatch 'Assert-OutlookConfirmation') {
        Add-Failure "Gated Outlook script does not validate a confirmation token: $gatedScript"
    }
    if ($gatedText -notmatch 'New-OutlookConfirmation') {
        Add-Failure "Gated Outlook script does not mint a preview confirmation token: $gatedScript"
    }
}

$outlookDelete = [IO.File]::ReadAllText((Join-Path $root 'scripts\outlook\Remove-OutlookMail.ps1'))
if ($outlookDelete -match '(?i)DeleteAfterSubmit|PermanentlyDelete|EmptyFolder') {
    Add-Failure 'Outlook delete script contains a permanent-deletion path.'
}
if ($outlookDelete -notmatch 'GetDefaultFolder\(3\)') {
    Add-Failure 'Outlook delete script does not check whether the message is already in Deleted Items.'
}

$outlookDraft = [IO.File]::ReadAllText((Join-Path $root 'scripts\outlook\New-OutlookDraft.ps1'))
if ($outlookDraft -match '\.Send\(\)') {
    Add-Failure 'Outlook draft script sends mail. Drafting and sending must stay separate.'
}
if ($outlookDraft -notmatch '\.Save\(\)') {
    Add-Failure 'Outlook draft script does not save the draft.'
}

$outlookSend = [IO.File]::ReadAllText((Join-Path $root 'scripts\outlook\Send-OutlookDraft.ps1'))
if ($outlookSend -notmatch 'GetDefaultFolder\(16\)') {
    Add-Failure 'Outlook send script does not confine sending to the default Drafts folder.'
}

Assert-FileContains 'scripts\outlook\Move-OutlookMail.ps1' 'deleted items' 'Outlook move script does not block Deleted Items as a destination.'
Assert-FileContains 'opencode\tools\office_outlook.ts' 'export const delete_messages' 'Outlook custom tools are incomplete.'
Assert-FileContains 'opencode\tools\office_outlook.ts' 'export const send_draft' 'Outlook custom tools are incomplete.'
Assert-FileContains 'settings\outlook.example.json' '"write"' 'Outlook example settings do not document the write block.'

$outlookExample = Get-Content -LiteralPath (Join-Path $root 'settings\outlook.example.json') -Raw | ConvertFrom-Json
foreach ($defaultOffSwitch in @('enabled', 'allowSend', 'allowDelete', 'allowRules', 'allowAttachmentDownload')) {
    if ($outlookExample.write.$defaultOffSwitch -ne $false) {
        Add-Failure "Outlook example settings must ship with 'write.$defaultOffSwitch' set to false."
    }
}

$packager = [IO.File]::ReadAllText((Join-Path $root 'scripts\install\New-HarnessPackage.ps1'))
foreach ($requiredExclusion in @("'releases'", "'local'", "'.git'", "'CONTEXT.md'", "'*.local.json'")) {
    if ($packager -notmatch [regex]::Escape($requiredExclusion)) {
        Add-Failure "Harness packager does not exclude $requiredExclusion from the portable archive."
    }
}
if ($packager -notmatch 'Get-FileHash') { Add-Failure 'Harness packager does not regenerate the package checksum.' }
if ($packager -match '\$excludedFiles\s*=\s*@\([^\)]*''CONTEXT\.md''') {
    Add-Failure 'Harness packager globally excludes nested portable-workspace CONTEXT.md files.'
}
if ($packager -notmatch 'Join-Path\s+\$stage\s+''CONTEXT\.md''') {
    Add-Failure 'Harness packager does not remove only the containing MyLife router.'
}
if ($packager -notmatch 'missing \{0\} staged file') { Add-Failure 'Harness packager does not verify staged files against archive contents.' }
if ($packager -match '(?m)Copy-Item[^\r\n]*\$resolvedOutput[\s\S]{0,200}CreateFromDirectory') {
    Add-Failure 'Harness packager replaces the deliverable before compressing it.'
}

$sitesSettings = [IO.File]::ReadAllText((Join-Path $root 'settings\sites.example.json'))
if ($sitesSettings -match '"outlook-web"') { Add-Failure 'General browser aliases still expose Outlook Web.' }

$installer = [IO.File]::ReadAllText((Join-Path $root 'scripts\install\Install-Harness.ps1'))
foreach ($requiredInstallerText in @(
    'opencode\agents\outlook-web-reader.md',
    'opencode\skills\outlook-web-read',
    'opencode\commands\mail-web-summary.md',
    '__OUTLOOK_WEB_BROWSER_PROFILE_DIR__',
    '__OUTLOOK_WEB_BROWSER_OUTPUT_DIR__',
    'UseExistingOpenCode',
    '$environmentValues[''OPENCODE_CONFIG_DIR''] = $openCodeConfigRoot',
    '$configObject.PSObject.Properties.Remove($propertyName)'
    'workspace-template\word'
    'Start-WordOpenCode.ps1'
    'Uninstall-Harness.ps1'
    'install-registration.json'
)) {
    if ($installer -notmatch [regex]::Escape($requiredInstallerText)) {
        Add-Failure "Installer is missing Outlook Web integration '$requiredInstallerText'."
    }
}

$launcherTemplate = [IO.File]::ReadAllText((Join-Path $root 'scripts\install\Start-OfficeOpenCode.ps1.template'))
if ($launcherTemplate -notmatch '__USE_EXISTING_OPENCODE__' -or
    $launcherTemplate -notmatch 'Get-Command opencode') {
    Add-Failure 'Harness launcher does not support the existing OpenCode configuration mode.'
}
$diagnosticTemplate = [IO.File]::ReadAllText((Join-Path $root 'scripts\install\Test-OfficeHarness.ps1.template'))
if ($diagnosticTemplate -notmatch '__USE_EXISTING_OPENCODE__') {
    Add-Failure 'Harness diagnostic does not support the existing OpenCode configuration mode.'
}
if ($installer -match 'ActivateAsDefaultOpenCode|opencode\.cmd') {
    Add-Failure 'Installer still contains the discarded command-shim activation path.'
}

$wordLauncherTemplate = [IO.File]::ReadAllText((Join-Path $root 'scripts\install\Start-WordOpenCode.ps1.template'))
foreach ($requiredWordLauncherText in @('state\workspaces\word', 'Start-OfficeOpenCode.ps1', '--agent word-auto')) {
    if ($wordLauncherTemplate -notmatch [regex]::Escape($requiredWordLauncherText)) {
        Add-Failure "Word launcher is missing '$requiredWordLauncherText'."
    }
}

$uninstallerTemplate = [IO.File]::ReadAllText((Join-Path $root 'scripts\install\Uninstall-Harness.ps1.template'))
foreach ($requiredUninstallerText in @(
    'install-registration.json',
    'PurgeState',
    'SkippedChangedEnvironment',
    '[Environment]::GetEnvironmentVariable($name, ''User'')',
    '[string]::Equals($currentValue, [string]$entry.installedValue',
    'State purge requires a matching install registration'
)) {
    if ($uninstallerTemplate -notmatch [regex]::Escape($requiredUninstallerText)) {
        Add-Failure "Uninstaller is missing guardrail '$requiredUninstallerText'."
    }
}
foreach ($forbiddenUninstallerText in @('Get-Process', 'Stop-Process', 'taskkill')) {
    if ($uninstallerTemplate -match [regex]::Escape($forbiddenUninstallerText)) {
        Add-Failure "Uninstaller contains forbidden behavior '$forbiddenUninstallerText'."
    }
}
if ($uninstallerTemplate -match 'SetEnvironmentVariable\(\s*["'']PATH["'']') {
    Add-Failure 'Uninstaller changes PATH.'
}

foreach ($wordWorkspaceFile in @(
    'workspace-template\word\AGENTS.md',
    'workspace-template\word\CONTEXT.md',
    'workspace-template\word\stages\prepare\CONTEXT.md',
    'workspace-template\word\stages\edit\CONTEXT.md',
    'workspace-template\word\stages\verify\CONTEXT.md',
    'workspace-template\word\current\README.md'
)) {
    if (-not (Test-Path -LiteralPath (Join-Path $root $wordWorkspaceFile) -PathType Leaf)) {
        Add-Failure "Portable Word workspace file is missing: $wordWorkspaceFile"
    }
}

if ($failures.Count -gt 0) {
    $failures | ForEach-Object { [Console]::Error.WriteLine($_) }
    exit 1
}

[pscustomobject]@{
    Ok = $true
    PowerShellFiles = $powerShellFiles.Count
    JsonFiles = $jsonFiles.Count
    Skills = $skillFiles.Count
    TextFilesScanned = $trackedTextFiles.Count
} | ConvertTo-Json

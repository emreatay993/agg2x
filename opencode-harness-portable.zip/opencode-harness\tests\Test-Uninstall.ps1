#requires -Version 5.1

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
$testRoot = Join-Path ([IO.Path]::GetTempPath()) ('office-harness-uninstall-' + [Guid]::NewGuid().ToString('N'))
$installRoot = Join-Path $testRoot 'installed'
$environmentNames = @(
    'OPENCODE_CONFIG_DIR',
    'OFFICE_HARNESS_ROOT',
    'OFFICE_HARNESS_STATE',
    'OFFICE_HARNESS_SETTINGS',
    'OFFICE_HARNESS_MACHINE',
    'OFFICE_HARNESS_POWERSHELL',
    'OFFICE_LLM_BASE_URL'
)
$savedEnvironment = @{}
foreach ($name in $environmentNames) {
    $savedEnvironment[$name] = [Environment]::GetEnvironmentVariable($name, 'User')
}

function Assert-InstalledOfficeRoots {
    param(
        [Parameter(Mandatory = $true)][string]$InstalledRoot,
        [Parameter(Mandatory = $true)][string[]]$ExpectedRoots
    )
    $settings = [IO.File]::ReadAllText((Join-Path $InstalledRoot 'state\settings\powerpoint.local.json')) |
        ConvertFrom-Json -ErrorAction Stop
    $actualRoots = @($settings.allowedRoots)
    if ($actualRoots.Count -ne $ExpectedRoots.Count) { throw 'Installed Office root count is incorrect.' }
    foreach ($expectedRoot in $ExpectedRoots) {
        if (-not @($actualRoots | Where-Object {
            ([string]$_).Equals($expectedRoot, [StringComparison]::OrdinalIgnoreCase)
        })) { throw "Installed Office root is missing: '$expectedRoot'." }
    }

    foreach ($configPath in @(
        (Join-Path $InstalledRoot 'state\opencode.json'),
        (Join-Path $InstalledRoot 'runtime\opencode\opencode.json')
    )) {
        $config = [IO.File]::ReadAllText($configPath) | ConvertFrom-Json -ErrorAction Stop
        $rules = $config.permission.external_directory
        if ($rules -is [string] -or [string]$rules.PSObject.Properties['*'].Value -ne 'ask') {
            throw "External-directory catch-all is unsafe in '$configPath'."
        }
        foreach ($expectedRoot in $ExpectedRoots) {
            $rootPattern = $expectedRoot.TrimEnd('\', '/')
            if ($rootPattern -match '^[A-Za-z]:$') { $rootPattern += '\' }
            foreach ($expectedPattern in @($rootPattern, ($rootPattern.TrimEnd('\', '/') + '\**'))) {
                $rule = $rules.PSObject.Properties[$expectedPattern]
                if ($null -eq $rule -or [string]$rule.Value -ne 'allow') {
                    throw "External-directory permission is missing for '$expectedPattern' in '$configPath'."
                }
            }
        }
    }
}

try {
    $null = New-Item -ItemType Directory -Path $testRoot
    $officeRootOne = (New-Item -ItemType Directory -Path (Join-Path $testRoot 'office-one')).FullName
    $officeRootTwo = (New-Item -ItemType Directory -Path (Join-Path $testRoot 'office-two')).FullName
    foreach ($name in $environmentNames) { [Environment]::SetEnvironmentVariable($name, $null, 'User') }
    [Environment]::SetEnvironmentVariable('OFFICE_HARNESS_ROOT', 'previous-root-sentinel', 'User')
    [Environment]::SetEnvironmentVariable('OFFICE_LLM_BASE_URL', 'https://existing.example.test/v1', 'User')

    $install = & (Join-Path $root 'scripts\install\Install-Harness.ps1') `
        -Machine Internet -UseExistingOpenCode -InstallRoot $installRoot `
        -OfficeRoot @($officeRootOne, $officeRootTwo) | ConvertFrom-Json
    if (-not $install.Ok) { throw 'Disposable install did not report success.' }
    Assert-InstalledOfficeRoots -InstalledRoot $installRoot -ExpectedRoots @($officeRootOne, $officeRootTwo)

    $null = & (Join-Path $root 'scripts\install\Install-Harness.ps1') `
        -Machine Internet -UseExistingOpenCode -InstallRoot $installRoot | ConvertFrom-Json
    Assert-InstalledOfficeRoots -InstalledRoot $installRoot -ExpectedRoots @($officeRootOne, $officeRootTwo)

    $null = & (Join-Path $root 'scripts\install\Install-Harness.ps1') `
        -Machine Internet -UseExistingOpenCode -InstallRoot $installRoot -OfficeRoot $officeRootTwo | ConvertFrom-Json
    Assert-InstalledOfficeRoots -InstalledRoot $installRoot -ExpectedRoots @($officeRootTwo)

    $uninstaller = Join-Path $installRoot 'Uninstall-Harness.ps1'
    $registrationPath = Join-Path $installRoot 'install-registration.json'
    if (-not (Test-Path -LiteralPath $uninstaller -PathType Leaf)) { throw 'Generated uninstaller is missing.' }
    if (-not (Test-Path -LiteralPath $registrationPath -PathType Leaf)) { throw 'Install registration is missing.' }

    $sentinel = Join-Path $installRoot 'state\preserve-me.txt'
    [IO.File]::WriteAllText($sentinel, 'preserve', (New-Object Text.UTF8Encoding($false)))
    [Environment]::SetEnvironmentVariable('OFFICE_HARNESS_MACHINE', 'changed-after-install', 'User')

    $disconnect = & $uninstaller | ConvertFrom-Json
    if (-not $disconnect.Ok -or -not $disconnect.StatePreserved) { throw 'Default disconnect did not report preserved state.' }
    if (Test-Path -LiteralPath (Join-Path $installRoot 'runtime')) { throw 'Default disconnect left runtime behind.' }
    if (-not (Test-Path -LiteralPath $sentinel -PathType Leaf)) { throw 'Default disconnect removed persistent state.' }
    if (-not (Test-Path -LiteralPath $uninstaller -PathType Leaf)) { throw 'Default disconnect removed its purge command.' }
    if ([Environment]::GetEnvironmentVariable('OPENCODE_CONFIG_DIR', 'User')) { throw 'OpenCode overlay environment was not disconnected.' }
    if ([Environment]::GetEnvironmentVariable('OFFICE_HARNESS_ROOT', 'User') -ne 'previous-root-sentinel') {
        throw 'Previous environment value was not restored.'
    }
    if ([Environment]::GetEnvironmentVariable('OFFICE_HARNESS_MACHINE', 'User') -ne 'changed-after-install') {
        throw 'Environment value changed after install was overwritten.'
    }
    if ([Environment]::GetEnvironmentVariable('OFFICE_LLM_BASE_URL', 'User') -ne 'https://existing.example.test/v1') {
        throw 'Unowned base URL was changed.'
    }
    $registration = [IO.File]::ReadAllText($registrationPath) | ConvertFrom-Json
    if ($registration.active) { throw 'Default disconnect did not mark the registration inactive.' }

    $purge = & $uninstaller -PurgeState | ConvertFrom-Json
    if (-not $purge.Ok -or -not $purge.PurgedState) { throw 'State purge did not report success.' }
    if (Test-Path -LiteralPath $installRoot) { throw 'State purge left the disposable install root behind.' }

    [pscustomobject]@{
        Ok = $true
        DefaultStatePreserved = $true
        ChangedEnvironmentPreserved = $true
        PreviousEnvironmentRestored = $true
        PurgeRemovedInstallRoot = $true
    } | ConvertTo-Json
}
finally {
    foreach ($name in $environmentNames) {
        [Environment]::SetEnvironmentVariable($name, $savedEnvironment[$name], 'User')
    }
    $resolvedTestRoot = [IO.Path]::GetFullPath($testRoot)
    $systemTemp = [IO.Path]::GetFullPath([IO.Path]::GetTempPath())
    if ($resolvedTestRoot.StartsWith($systemTemp, [StringComparison]::OrdinalIgnoreCase) -and
        (Test-Path -LiteralPath $resolvedTestRoot)) {
        Remove-Item -LiteralPath $resolvedTestRoot -Recurse -Force
    }
}

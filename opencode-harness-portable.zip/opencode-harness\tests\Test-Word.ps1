#requires -Version 5.1

[CmdletBinding()]
param()

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'
$root = [IO.Path]::GetFullPath((Join-Path $PSScriptRoot '..'))
. (Join-Path $root 'scripts\office\OfficeFile.Common.ps1')
$testRoot = Join-Path $env:TEMP ('opencode-office-word-' + [Guid]::NewGuid().ToString('N'))
$settingsRoot = Join-Path $testRoot 'settings'
$source = Join-Path $testRoot 'source.docx'
$output = Join-Path $testRoot 'edited.docx'
$rendered = Join-Path $testRoot 'edited.pdf'
$planPath = Join-Path $testRoot 'plan.json'
$newDocument = Join-Path $testRoot 'created.docx'
$newDocumentPdf = Join-Path $testRoot 'created.pdf'
$newDocumentSpec = Join-Path $testRoot 'new-document.json'
$imagePath = Join-Path $testRoot 'fixture.png'
$editScript = Join-Path $root 'scripts\word\Edit-WordCopy.ps1'
$powerShellExe = Join-Path $PSHOME 'powershell.exe'
$oldSettingsRoot = $env:OFFICE_HARNESS_SETTINGS

function Write-TestJson {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [object]$Value
    )

    [IO.File]::WriteAllText(
        $Path,
        ($Value | ConvertTo-Json -Depth 10),
        (New-Object Text.UTF8Encoding($false))
    )
}

function Add-TestDocxEntry {
    param(
        [Parameter(Mandatory = $true)]
        [object]$Archive,

        [Parameter(Mandatory = $true)]
        [string]$Path,

        [Parameter(Mandatory = $true)]
        [string]$Content
    )

    $entryStream = $null
    try {
        $entry = $Archive.CreateEntry($Path)
        $entryStream = $entry.Open()
        $bytes = (New-Object Text.UTF8Encoding($false)).GetBytes($Content)
        $entryStream.Write($bytes, 0, $bytes.Length)
    }
    finally {
        if ($null -ne $entryStream) { $entryStream.Dispose() }
    }
}

function New-TestWordFixture {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Path
    )

    Add-Type -AssemblyName System.IO.Compression
    Add-Type -AssemblyName System.IO.Compression.FileSystem
    $archive = [IO.Compression.ZipFile]::Open($Path, [IO.Compression.ZipArchiveMode]::Create)
    try {
        Add-TestDocxEntry -Archive $archive -Path '[Content_Types].xml' -Content @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="xml" ContentType="application/xml"/>
  <Override PartName="/word/document.xml" ContentType="application/vnd.openxmlformats-officedocument.wordprocessingml.document.main+xml"/>
  <Override PartName="/docProps/core.xml" ContentType="application/vnd.openxmlformats-package.core-properties+xml"/>
  <Override PartName="/docProps/app.xml" ContentType="application/vnd.openxmlformats-officedocument.extended-properties+xml"/>
</Types>
'@
        Add-TestDocxEntry -Archive $archive -Path '_rels/.rels' -Content @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="word/document.xml"/>
  <Relationship Id="rId2" Type="http://schemas.openxmlformats.org/package/2006/relationships/metadata/core-properties" Target="docProps/core.xml"/>
  <Relationship Id="rId3" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/extended-properties" Target="docProps/app.xml"/>
</Relationships>
'@
        Add-TestDocxEntry -Archive $archive -Path 'word/_rels/document.xml.rels' -Content @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink" Target="https://example.com" TargetMode="External"/>
</Relationships>
'@
        Add-TestDocxEntry -Archive $archive -Path 'word/document.xml' -Content @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<w:document xmlns:w="http://schemas.openxmlformats.org/wordprocessingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
  <w:body>
    <w:p><w:r><w:rPr><w:b/><w:sz w:val="24"/></w:rPr><w:t>Original first paragraph</w:t></w:r></w:p>
    <w:p><w:hyperlink r:id="rId1"><w:r><w:rPr><w:rStyle w:val="Hyperlink"/></w:rPr><w:t>Second paragraph</w:t></w:r></w:hyperlink></w:p>
    <w:p><w:r><w:rPr><w:lang w:val="en-US"/></w:rPr><w:t>The qzxwvvpkjhd token is wrong.</w:t></w:r></w:p>
    <w:tbl>
      <w:tblPr><w:tblW w:w="0" w:type="auto"/></w:tblPr>
      <w:tblGrid><w:gridCol w:w="3000"/><w:gridCol w:w="3000"/></w:tblGrid>
      <w:tr>
        <w:tc><w:tcPr><w:tcW w:w="3000" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>Cell original</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3000" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>B1</w:t></w:r></w:p></w:tc>
      </w:tr>
      <w:tr>
        <w:tc><w:tcPr><w:tcW w:w="3000" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>A2</w:t></w:r></w:p></w:tc>
        <w:tc><w:tcPr><w:tcW w:w="3000" w:type="dxa"/></w:tcPr><w:p><w:r><w:t>B2</w:t></w:r></w:p></w:tc>
      </w:tr>
    </w:tbl>
    <w:p><w:r><w:t>Image anchor</w:t></w:r></w:p>
    <w:sectPr>
      <w:pgSz w:w="12240" w:h="15840"/>
      <w:pgMar w:top="1440" w:right="1440" w:bottom="1440" w:left="1440" w:header="720" w:footer="720" w:gutter="0"/>
    </w:sectPr>
  </w:body>
</w:document>
'@
        Add-TestDocxEntry -Archive $archive -Path 'docProps/core.xml' -Content @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/">
  <dc:title>Harness fixture</dc:title>
  <dc:creator>OpenCode Harness</dc:creator>
</cp:coreProperties>
'@
        Add-TestDocxEntry -Archive $archive -Path 'docProps/app.xml' -Content @'
<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Properties xmlns="http://schemas.openxmlformats.org/officeDocument/2006/extended-properties">
  <Application>OpenCode Harness</Application>
</Properties>
'@
    }
    finally {
        $archive.Dispose()
    }
}

function Add-TestWordParagraph {
    param(
        [Parameter(Mandatory = $true)][object]$Document,
        [Parameter(Mandatory = $true)][string]$Text,
        [AllowNull()][object]$StyleId = $null
    )

    $paragraphs = $null
    $lastParagraph = $null
    $lastRange = $null
    $newParagraph = $null
    $newRange = $null
    $styles = $null
    $style = $null
    try {
        $paragraphs = $Document.Paragraphs
        $lastParagraph = $paragraphs.Item([int]$paragraphs.Count)
        $lastRange = $lastParagraph.Range
        $lastRange.InsertParagraphAfter()
        $newParagraph = $paragraphs.Item([int]$paragraphs.Count)
        $newRange = $newParagraph.Range
        $newRange.End = [int]$newRange.End - 1
        $newRange.Text = $Text
        if ($null -ne $StyleId) {
            $styles = $Document.Styles
            $style = $styles.Item([int]$StyleId)
            $newRange.Style = $style
        }
    }
    finally {
        Release-OfficeFileComObject -ComObject $style
        Release-OfficeFileComObject -ComObject $styles
        Release-OfficeFileComObject -ComObject $newRange
        Release-OfficeFileComObject -ComObject $newParagraph
        Release-OfficeFileComObject -ComObject $lastRange
        Release-OfficeFileComObject -ComObject $lastParagraph
        Release-OfficeFileComObject -ComObject $paragraphs
    }
}

function Add-TestWordRichFixtures {
    param(
        [Parameter(Mandatory = $true)][string]$DocumentPath,
        [Parameter(Mandatory = $true)][string]$PicturePath
    )

    [IO.File]::WriteAllBytes($PicturePath, [Convert]::FromBase64String(
        'iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAusB9Y9Zl1sAAAAASUVORK5CYII='))
    $application = $null
    $documents = $null
    $document = $null
    $content = $null
    $paragraphs = $null
    $paragraph = $null
    $range = $null
    $inlineShapes = $null
    $shape = $null
    $captionRange = $null
    $tables = $null
    $table = $null
    $tableRange = $null
    try {
        $application = New-Object -ComObject Word.Application
        $application.Visible = $false
        $application.DisplayAlerts = 0
        $application.AutomationSecurity = 3
        $documents = $application.Documents
        $document = $documents.Open($DocumentPath, $false, $false, $false)
        $content = $document.Content
        $paragraphs = $content.Paragraphs
        for ($index = 1; $index -le [int]$paragraphs.Count; $index++) {
            Release-OfficeFileComObject -ComObject $range
            Release-OfficeFileComObject -ComObject $paragraph
            $paragraph = $paragraphs.Item($index)
            $range = $paragraph.Range
            $text = ([string]$range.Text).TrimEnd([char[]]@(13, 7))
            if ($text -eq 'Image anchor') { break }
        }
        if ($text -ne 'Image anchor') { throw 'Could not find the image anchor paragraph.' }
        $range.End = [int]$range.End - 1
        $range.Collapse(0)
        $inlineShapes = $document.InlineShapes
        $shape = $inlineShapes.AddPicture($PicturePath, $false, $true, $range)
        $shape.AlternativeText = 'OpenCode harness image'

        $captionRange = $shape.Range
        $captionRange.InsertCaption(-1, ' - Harness image', [Type]::Missing, 1, $false)
        $tables = $document.Tables
        $table = $tables.Item(1)
        $tableRange = $table.Range
        $tableRange.InsertCaption(-2, ' - Harness table', [Type]::Missing, 0, $false)

        Add-TestWordParagraph -Document $document -Text 'Cross-reference heading' -StyleId -2
        foreach ($placeholderText in @(
            'Heading link: [[HEADING_REF]].',
            'Figure link: [[FIGURE_REF]].',
            'Table link: [[TABLE_REF]].',
            'Heading page: [[HEADING_PAGE]].'
        )) {
            Add-TestWordParagraph -Document $document -Text $placeholderText
        }
        $document.Save()
    }
    finally {
        Release-OfficeFileComObject -ComObject $tableRange
        Release-OfficeFileComObject -ComObject $table
        Release-OfficeFileComObject -ComObject $tables
        Release-OfficeFileComObject -ComObject $captionRange
        Release-OfficeFileComObject -ComObject $shape
        Release-OfficeFileComObject -ComObject $inlineShapes
        Release-OfficeFileComObject -ComObject $range
        Release-OfficeFileComObject -ComObject $paragraph
        Release-OfficeFileComObject -ComObject $paragraphs
        Release-OfficeFileComObject -ComObject $content
        if ($null -ne $document) { try { $document.Close(0) } catch {} }
        Release-OfficeFileComObject -ComObject $document
        Release-OfficeFileComObject -ComObject $documents
        if ($null -ne $application) { try { $application.Quit() } catch {} }
        Release-OfficeFileComObject -ComObject $application
        Complete-OfficeFileComCleanup
    }
}

function Invoke-ExpectedWordFailure {
    param(
        [Parameter(Mandatory = $true)]
        [string]$Name,

        [Parameter(Mandatory = $true)]
        [string]$SourcePath,

        [Parameter(Mandatory = $true)]
        [string]$OutputPath,

        [Parameter(Mandatory = $true)]
        [object]$Plan,

        [switch]$PreserveExisting
    )

    $negativePlanPath = Join-Path $testRoot ($Name + '.json')
    Write-TestJson -Path $negativePlanPath -Value $Plan
    $existingHash = if ($PreserveExisting -and (Test-Path -LiteralPath $OutputPath -PathType Leaf)) {
        (Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash
    }
    else {
        $null
    }

    $processOutput = @(& $powerShellExe -NoLogo -NoProfile -NonInteractive -File $editScript `
        -SourcePath $SourcePath -OutputPath $OutputPath -PlanPath $negativePlanPath 2>&1)
    if ($LASTEXITCODE -eq 0) {
        throw "Negative Word case '$Name' unexpectedly succeeded."
    }
    $jsonLine = @($processOutput | ForEach-Object { [string]$_ } | Where-Object { -not [string]::IsNullOrWhiteSpace($_) })[-1]
    $failure = $jsonLine | ConvertFrom-Json -ErrorAction Stop
    if ($failure.success -ne $false) {
        throw "Negative Word case '$Name' did not return structured failure JSON."
    }

    if ($PreserveExisting) {
        if (-not (Test-Path -LiteralPath $OutputPath -PathType Leaf)) {
            throw "Negative Word case '$Name' removed an existing file."
        }
        if ((Get-FileHash -LiteralPath $OutputPath -Algorithm SHA256).Hash -ne $existingHash) {
            throw "Negative Word case '$Name' changed an existing file."
        }
    }
    elseif (-not $SourcePath.Equals($OutputPath, [StringComparison]::OrdinalIgnoreCase) -and
        (Test-Path -LiteralPath $OutputPath)) {
        throw "Negative Word case '$Name' left an output behind."
    }
}

try {
    [void](New-Item -ItemType Directory -Path $testRoot)
    [void](New-Item -ItemType Directory -Path $settingsRoot)
    Write-TestJson -Path (Join-Path $settingsRoot 'powerpoint.local.json') -Value ([ordered]@{
        allowedRoots = @($testRoot)
        defaultOutputRoot = ''
        renderWidth = 1920
        renderHeight = 1080
    })
    $env:OFFICE_HARNESS_SETTINGS = $settingsRoot

    Write-Verbose 'Creating Word fixture.'
    New-TestWordFixture -Path $source
    Add-TestWordRichFixtures -DocumentPath $source -PicturePath $imagePath

    Write-Verbose 'Inspecting source fixture.'
    $sourceHashBefore = (Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash
    $inventoryJson = & (Join-Path $root 'scripts\word\Get-WordInventory.ps1') -SourcePath $source
    if (-not $?) { throw 'Word inventory failed.' }
    $inventory = $inventoryJson | ConvertFrom-Json
    if (-not $inventory.success -or $inventory.document.pageCount -lt 1) { throw 'Word inventory reported invalid document metadata.' }
    if (@($inventory.hyperlinks).Count -ne 1) { throw 'Word inventory did not return the fixture hyperlink.' }
    if (@($inventory.tables).Count -ne 1) { throw 'Word inventory did not return the fixture table.' }

    $firstParagraph = @($inventory.paragraphs | Where-Object text -eq 'Original first paragraph')[0]
    $secondParagraph = @($inventory.paragraphs | Where-Object text -eq 'Second paragraph')[0]
    $typoParagraph = @($inventory.paragraphs | Where-Object text -eq 'The qzxwvvpkjhd token is wrong.')[0]
    if ($null -eq $firstParagraph -or $null -eq $secondParagraph -or $null -eq $typoParagraph) { throw 'Word inventory did not return fixture paragraphs.' }

    $formatting = (& (Join-Path $root 'scripts\word\Get-WordInventory.ps1') -SourcePath $source -Mode formatting -Start ([int]$firstParagraph.index) -Limit 1) | ConvertFrom-Json
    $firstFormat = @($formatting.formatting)[0]
    if ($firstFormat.font.bold -ne $true -or [Math]::Abs([double]$firstFormat.font.size - 12) -gt 0.1) {
        throw 'Word formatting inventory did not return the seeded bold 12 pt paragraph.'
    }

    $mediaInventory = (& (Join-Path $root 'scripts\word\Get-WordInventory.ps1') -SourcePath $source -Mode media -Limit 10) | ConvertFrom-Json
    $fixtureMedia = $mediaInventory.media | Where-Object alternativeText -eq 'OpenCode harness image' | Select-Object -First 1
    if ($null -eq $fixtureMedia -or $fixtureMedia.kind -ne 'inline' -or $fixtureMedia.captionStatus -ne 'present' -or $fixtureMedia.followingText -notlike '*Harness image*') {
        throw "Word media inventory did not return the native-captioned inline fixture image: $($mediaInventory.media | ConvertTo-Json -Depth 5 -Compress)"
    }

    $proofingInventory = (& (Join-Path $root 'scripts\word\Get-WordInventory.ps1') -SourcePath $source -Mode proofing -Limit 25) | ConvertFrom-Json
    if (@($proofingInventory.proofing | Where-Object text -eq 'qzxwvvpkjhd').Count -ne 1) {
        throw 'Word proofing inventory did not return the seeded spelling candidate.'
    }

    $referenceInventory = (& (Join-Path $root 'scripts\word\Get-WordInventory.ps1') -SourcePath $source -Mode references -Limit 25) | ConvertFrom-Json
    $headingTarget = $referenceInventory.references | Where-Object { $_.recordType -eq 'target' -and $_.targetType -eq 'heading' -and $_.targetText -eq 'Cross-reference heading' } | Select-Object -First 1
    $figureTarget = $referenceInventory.references | Where-Object { $_.recordType -eq 'target' -and $_.targetType -eq 'figure' -and $_.targetText -like '*Harness image*' } | Select-Object -First 1
    $tableTarget = $referenceInventory.references | Where-Object { $_.recordType -eq 'target' -and $_.targetType -eq 'table' -and $_.targetText -like '*Harness table*' } | Select-Object -First 1
    if ($null -eq $headingTarget -or $null -eq $figureTarget -or $null -eq $tableTarget) {
        throw 'Word reference inventory did not return the seeded heading, figure, and table targets.'
    }
    $headingLinkParagraph = $inventory.paragraphs | Where-Object text -eq 'Heading link: [[HEADING_REF]].' | Select-Object -First 1
    $figureLinkParagraph = $inventory.paragraphs | Where-Object text -eq 'Figure link: [[FIGURE_REF]].' | Select-Object -First 1
    $tableLinkParagraph = $inventory.paragraphs | Where-Object text -eq 'Table link: [[TABLE_REF]].' | Select-Object -First 1
    $headingPageParagraph = $inventory.paragraphs | Where-Object text -eq 'Heading page: [[HEADING_PAGE]].' | Select-Object -First 1
    if ($null -eq $headingLinkParagraph -or $null -eq $figureLinkParagraph -or $null -eq $tableLinkParagraph -or $null -eq $headingPageParagraph) {
        throw 'Word inventory did not return the cross-reference placeholders.'
    }

    $findInventory = (& (Join-Path $root 'scripts\word\Get-WordInventory.ps1') -SourcePath $source -Mode find -FindText '[[' -Limit 25) | ConvertFrom-Json
    $expectedFindParagraphs = @($headingLinkParagraph.index, $figureLinkParagraph.index, $tableLinkParagraph.index, $headingPageParagraph.index)
    if (@($findInventory.find).Count -ne 4 -or @($findInventory.find | Where-Object paragraphIndex -in $expectedFindParagraphs).Count -ne 4) {
        throw 'Word find mode did not return all cross-reference placeholders.'
    }

    $plan = [ordered]@{
        operations = @(
            [ordered]@{
                operation = 'replace_paragraph_text'
                paragraphIndex = [int]$firstParagraph.index
                expectedText = 'Original first paragraph'
                find = 'Original'
                replace = 'Updated'
            },
            [ordered]@{
                operation = 'set_paragraph_text'
                paragraphIndex = [int]$secondParagraph.index
                expectedText = 'Second paragraph'
                text = 'Rewritten second paragraph'
            },
            [ordered]@{
                operation = 'set_table_cell_text'
                tableIndex = 1
                rowIndex = 1
                columnIndex = 1
                expectedText = 'Cell original'
                text = 'Cell edited'
            },
            [ordered]@{
                operation = 'set_text_format'
                paragraphIndex = [int]$firstParagraph.index
                expectedText = 'Updated first paragraph'
                fontSize = 11
                bold = $false
                italic = $true
            },
            [ordered]@{
                operation = 'set_paragraph_format'
                paragraphIndex = [int]$secondParagraph.index
                expectedText = 'Rewritten second paragraph'
                alignment = 'center'
            },
            [ordered]@{
                operation = 'replace_paragraph_text'
                paragraphIndex = [int]$typoParagraph.index
                expectedText = 'The qzxwvvpkjhd token is wrong.'
                find = 'qzxwvvpkjhd'
                replace = 'corrected'
            },
            [ordered]@{
                operation = 'replace_text_with_cross_reference'
                paragraphIndex = [int]$headingLinkParagraph.index
                expectedText = 'Heading link: [[HEADING_REF]].'
                find = '[[HEADING_REF]]'
                targetType = 'heading'
                targetIndex = [int]$headingTarget.targetIndex
                expectedTargetText = [string]$headingTarget.targetText
                referenceKind = 'heading_text'
            },
            [ordered]@{
                operation = 'replace_text_with_cross_reference'
                paragraphIndex = [int]$figureLinkParagraph.index
                expectedText = 'Figure link: [[FIGURE_REF]].'
                find = '[[FIGURE_REF]]'
                targetType = 'figure'
                targetIndex = [int]$figureTarget.targetIndex
                expectedTargetText = [string]$figureTarget.targetText
                referenceKind = 'label_and_number'
            },
            [ordered]@{
                operation = 'replace_text_with_cross_reference'
                paragraphIndex = [int]$tableLinkParagraph.index
                expectedText = 'Table link: [[TABLE_REF]].'
                find = '[[TABLE_REF]]'
                targetType = 'table'
                targetIndex = [int]$tableTarget.targetIndex
                expectedTargetText = [string]$tableTarget.targetText
                referenceKind = 'label_and_number'
            },
            [ordered]@{
                operation = 'replace_text_with_cross_reference'
                paragraphIndex = [int]$headingPageParagraph.index
                expectedText = 'Heading page: [[HEADING_PAGE]].'
                find = '[[HEADING_PAGE]]'
                targetType = 'heading'
                targetIndex = [int]$headingTarget.targetIndex
                expectedTargetText = [string]$headingTarget.targetText
                referenceKind = 'page_number'
            },
            [ordered]@{
                operation = 'insert_paragraph_after'
                paragraphIndex = [int]$fixtureMedia.anchorParagraphIndex
                expectedText = [string]$fixtureMedia.anchorText
                text = 'Harness image caption'
                paragraphStyle = 'caption'
            },
            [ordered]@{
                operation = 'insert_paragraph_after'
                paragraphIndex = [int]$secondParagraph.index
                expectedText = 'Rewritten second paragraph'
                text = 'Inserted harness content'
                paragraphStyle = 'normal'
            }
        )
    }
    Write-TestJson -Path $planPath -Value $plan
    Write-Verbose 'Applying and verifying Word edits.'
    $editJson = & $editScript -SourcePath $source -OutputPath $output -PlanPath $planPath
    if (-not $?) { throw "Word copy edit failed: $editJson" }
    $edit = $editJson | ConvertFrom-Json
    if (-not $edit.success -or @($edit.operations).Count -ne 12 -or @($edit.operations | Where-Object status -ne 'applied').Count -ne 0) { throw 'Word edit returned invalid operation results.' }
    if (-not (Test-Path -LiteralPath $output -PathType Leaf)) { throw 'Edited Word copy was not created.' }
    if ((Get-FileHash -LiteralPath $source -Algorithm SHA256).Hash -ne $sourceHashBefore) { throw 'Source Word document changed.' }

    $editedInventoryJson = & (Join-Path $root 'scripts\word\Get-WordInventory.ps1') -SourcePath $output
    $editedInventory = $editedInventoryJson | ConvertFrom-Json
    if (@($editedInventory.paragraphs | Where-Object text -eq 'Updated first paragraph').Count -ne 1) {
        throw 'Paragraph replacement was not persisted.'
    }
    if (@($editedInventory.paragraphs | Where-Object text -eq 'Rewritten second paragraph').Count -ne 1) {
        throw 'Paragraph assignment was not persisted.'
    }
    $editedCell = @($editedInventory.tables[0].cells | Where-Object { $_.rowIndex -eq 1 -and $_.columnIndex -eq 1 })[0]
    if ($editedCell.text -ne 'Cell edited') {
        throw "Table-cell assignment was not persisted; found '$($editedCell.text)'."
    }
    if (@($editedInventory.paragraphs | Where-Object text -eq 'The corrected token is wrong.').Count -ne 1) { throw 'Proofing correction was not persisted.' }
    if (@($editedInventory.paragraphs | Where-Object text -eq 'Inserted harness content').Count -ne 1) { throw 'Inserted content was not persisted.' }

    $editedFormatting = (& (Join-Path $root 'scripts\word\Get-WordInventory.ps1') -SourcePath $output -Mode formatting -Start ([int]$firstParagraph.index) -Limit 2) | ConvertFrom-Json
    $editedFirstFormat = @($editedFormatting.formatting | Where-Object text -eq 'Updated first paragraph')[0]
    $editedSecondFormat = @($editedFormatting.formatting | Where-Object text -eq 'Rewritten second paragraph')[0]
    if ($editedFirstFormat.font.bold -ne $false -or $editedFirstFormat.font.italic -ne $true -or [Math]::Abs([double]$editedFirstFormat.font.size - 11) -gt 0.1) {
        throw 'Text formatting edit was not persisted.'
    }
    if ([int]$editedSecondFormat.paragraphFormat.alignment -ne 1) { throw 'Paragraph formatting edit was not persisted.' }

    $editedMedia = (& (Join-Path $root 'scripts\word\Get-WordInventory.ps1') -SourcePath $output -Mode media -Limit 10) | ConvertFrom-Json
    $editedFixtureMedia = @($editedMedia.media | Where-Object alternativeText -eq 'OpenCode harness image')[0]
    if ($editedFixtureMedia.captionStatus -ne 'present' -or $editedFixtureMedia.followingText -ne 'Harness image caption') {
        throw 'Image caption insertion was not persisted.'
    }

    $editedReferences = (& (Join-Path $root 'scripts\word\Get-WordInventory.ps1') -SourcePath $output -Mode references -Limit 25) | ConvertFrom-Json
    $referenceFields = @($editedReferences.references | Where-Object recordType -eq 'field')
    if ($referenceFields.Count -ne 4 -or @($referenceFields | Where-Object fieldType -eq 'REF').Count -ne 3 -or @($referenceFields | Where-Object fieldType -eq 'PAGEREF').Count -ne 1) {
        throw 'Native Word cross-reference fields were not persisted.'
    }
    if (@($referenceFields | Where-Object { [string]::IsNullOrWhiteSpace([string]$_.code) -or [string]::IsNullOrWhiteSpace([string]$_.resultText) }).Count -ne 0) {
        throw 'A native Word cross-reference field has an empty code or result.'
    }
    if (@($editedInventory.paragraphs | Where-Object text -like '*[[*REF]]*').Count -ne 0) {
        throw 'A cross-reference placeholder remained after editing.'
    }

    Write-Verbose 'Rendering edited document.'
    $renderJson = & (Join-Path $root 'scripts\word\Export-WordPdf.ps1') -SourcePath $output -OutputPath $rendered
    $render = $renderJson | ConvertFrom-Json
    if (-not $render.success -or -not (Test-Path -LiteralPath $rendered -PathType Leaf)) { throw 'Word PDF render failed.' }

    Write-Verbose 'Creating and verifying a structured Word document.'
    Write-TestJson -Path $newDocumentSpec -Value ([ordered]@{
        blocks = @(
            [ordered]@{ kind = 'title'; text = 'Harness-created report' },
            [ordered]@{ kind = 'heading'; level = 1; text = 'Purpose' },
            [ordered]@{ kind = 'paragraph'; text = 'This document verifies structured Word creation.' },
            [ordered]@{ kind = 'bullet'; text = 'Verified with desktop Word' }
        )
    })
    $createJson = & (Join-Path $root 'scripts\word\New-WordDocument.ps1') -SpecPath $newDocumentSpec -OutputPath $newDocument
    $create = $createJson | ConvertFrom-Json
    if (-not $create.success -or $create.output.overwritten -ne $false -or -not (Test-Path -LiteralPath $newDocument -PathType Leaf)) {
        throw 'Structured Word creation failed.'
    }
    $createdInventory = (& (Join-Path $root 'scripts\word\Get-WordInventory.ps1') -SourcePath $newDocument) | ConvertFrom-Json
    foreach ($requiredText in @('Harness-created report', 'Purpose', 'This document verifies structured Word creation.')) {
        if (@($createdInventory.paragraphs | Where-Object text -eq $requiredText).Count -ne 1) { throw "Created document is missing '$requiredText'." }
    }
    if (@($createdInventory.paragraphs | Where-Object text -like '*Verified with desktop Word').Count -ne 1) { throw 'Created document is missing its bullet content.' }
    $createdRender = (& (Join-Path $root 'scripts\word\Export-WordPdf.ps1') -SourcePath $newDocument -OutputPath $newDocumentPdf) | ConvertFrom-Json
    if (-not $createdRender.success -or -not (Test-Path -LiteralPath $newDocumentPdf -PathType Leaf)) { throw 'Created document PDF render failed.' }

    Write-Verbose 'Running negative Word cases.'
    $staleOutput = Join-Path $testRoot 'stale.docx'
    Invoke-ExpectedWordFailure -Name 'stale' -SourcePath $source -OutputPath $staleOutput -Plan ([ordered]@{
        operations = @([ordered]@{
            operation = 'set_paragraph_text'
            paragraphIndex = [int]$firstParagraph.index
            expectedText = 'stale text'
            text = 'Never saved'
        })
    })

    Invoke-ExpectedWordFailure -Name 'newline' -SourcePath $source -OutputPath (Join-Path $testRoot 'newline.docx') -Plan ([ordered]@{
        operations = @([ordered]@{
            operation = 'set_paragraph_text'
            paragraphIndex = [int]$firstParagraph.index
            expectedText = 'Original first paragraph'
            text = "forbidden`nline"
        })
    })

    $tooManyOperations = @(1..101 | ForEach-Object {
        [ordered]@{
            operation = 'set_paragraph_text'
            paragraphIndex = [int]$firstParagraph.index
            expectedText = 'Original first paragraph'
            text = 'Never saved'
        }
    })
    Invoke-ExpectedWordFailure -Name 'too-many' -SourcePath $source -OutputPath (Join-Path $testRoot 'too-many.docx') -Plan ([ordered]@{
        operations = $tooManyOperations
    })

    $existingOutput = Join-Path $testRoot 'existing.docx'
    [IO.File]::Copy($source, $existingOutput, $false)
    Invoke-ExpectedWordFailure -Name 'existing-output' -SourcePath $source -OutputPath $existingOutput -Plan $plan -PreserveExisting
    Invoke-ExpectedWordFailure -Name 'same-path' -SourcePath $source -OutputPath $source -Plan $plan -PreserveExisting
    Invoke-ExpectedWordFailure -Name 'wrong-extension' -SourcePath $source -OutputPath (Join-Path $testRoot 'wrong.doc') -Plan $plan
    Invoke-ExpectedWordFailure -Name 'caption-without-image' -SourcePath $source -OutputPath (Join-Path $testRoot 'bad-caption.docx') -Plan ([ordered]@{
        operations = @([ordered]@{
            operation = 'insert_paragraph_after'
            paragraphIndex = [int]$firstParagraph.index
            expectedText = 'Original first paragraph'
            text = 'Invalid caption'
            paragraphStyle = 'caption'
        })
    })

    Invoke-ExpectedWordFailure -Name 'stale-reference-target' -SourcePath $source -OutputPath (Join-Path $testRoot 'stale-reference.docx') -Plan ([ordered]@{
        operations = @([ordered]@{
            operation = 'replace_text_with_cross_reference'
            paragraphIndex = [int]$headingLinkParagraph.index
            expectedText = 'Heading link: [[HEADING_REF]].'
            find = '[[HEADING_REF]]'
            targetType = 'heading'
            targetIndex = [int]$headingTarget.targetIndex
            expectedTargetText = 'Stale heading target'
            referenceKind = 'heading_text'
        })
    })

    Write-Verbose 'Word tests passed.'
    [pscustomobject][ordered]@{
        Ok              = $true
        Operations      = @($edit.operations).Count
        PdfPages        = [int]$render.output.pageCount
        CreatedPdfPages = [int]$createdRender.output.pageCount
        NegativeCases   = 8
        SourceUnchanged = $true
    } | ConvertTo-Json -Compress
}
finally {
    Write-Verbose 'Cleaning up Word test resources.'
    $env:OFFICE_HARNESS_SETTINGS = $oldSettingsRoot
    $resolvedTestRoot = [IO.Path]::GetFullPath($testRoot)
    $resolvedTempRoot = [IO.Path]::GetFullPath($env:TEMP).TrimEnd('\') + '\'
    if ($resolvedTestRoot.StartsWith($resolvedTempRoot, [StringComparison]::OrdinalIgnoreCase) -and
        (Test-Path -LiteralPath $resolvedTestRoot -PathType Container)) {
        Remove-Item -LiteralPath $resolvedTestRoot -Recurse -Force -ErrorAction SilentlyContinue
    }
    Write-Verbose 'Word test cleanup finished.'
}

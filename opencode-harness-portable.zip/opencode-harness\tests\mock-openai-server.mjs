import http from "node:http"

const port = Number(process.env.MOCK_OPENAI_PORT || 18765)
const requiredTools = [
  "office_memory_list",
  "office_word_inspect",
  "office_excel_inspect",
  "office_powerpoint_inspect",
  "office_slurm_status",
]

function writeChunk(response, payload) {
  response.write(`data: ${JSON.stringify(payload)}\n\n`)
}

function baseChunk(model, choices, usage) {
  return {
    id: "mock-completion",
    object: "chat.completion.chunk",
    created: Math.floor(Date.now() / 1000),
    model,
    system_fingerprint: null,
    choices,
    ...(usage ? { usage } : {}),
  }
}

const server = http.createServer((request, response) => {
  if (request.method === "GET" && request.url === "/v1/models") {
    response.setHeader("content-type", "application/json")
    response.end(JSON.stringify({ object: "list", data: [
      { id: "qwen35-122b-a10b", object: "model" },
      { id: "qwen-next-80b-coder", object: "model" },
    ] }))
    return
  }

  if (request.method !== "POST" || request.url !== "/v1/chat/completions") {
    response.statusCode = 404
    response.end("not found")
    return
  }

  let body = ""
  request.setEncoding("utf8")
  request.on("data", (chunk) => { body += chunk })
  request.on("end", () => {
    try {
      const payload = JSON.parse(body)
      const names = (payload.tools || []).map((entry) => entry?.function?.name).filter(Boolean)
      const isToolEnabledTurn = requiredTools.some((name) => names.includes(name))
      const missing = requiredTools.filter((name) => !names.includes(name))
      if (isToolEnabledTurn && missing.length) {
        response.statusCode = 422
        response.setHeader("content-type", "application/json")
        response.end(JSON.stringify({ error: { message: `Missing custom tools: ${missing.join(", ")}` } }))
        return
      }

      if (payload.stream === false) {
        response.statusCode = 200
        response.setHeader("content-type", "application/json")
        response.end(JSON.stringify({
          id: "mock-completion",
          object: "chat.completion",
          created: Math.floor(Date.now() / 1000),
          model: payload.model,
          choices: [{
            index: 0,
            message: { role: "assistant", content: "mock title" },
            logprobs: null,
            finish_reason: "stop",
          }],
          usage: { prompt_tokens: 10, completion_tokens: 2, total_tokens: 12 },
        }))
        return
      }

      response.statusCode = 200
      response.setHeader("content-type", "text/event-stream")
      response.setHeader("cache-control", "no-cache")
      const hasToolResult = (payload.messages || []).some((message) => message.role === "tool")
      if (isToolEnabledTurn && !hasToolResult) {
        writeChunk(response, baseChunk(payload.model, [{
          index: 0,
          delta: {
            role: "assistant",
            tool_calls: [{
              index: 0,
              id: "call_memory_list",
              type: "function",
              function: { name: "office_memory_list", arguments: "{\"status\":\"Approved\"}" },
            }],
          },
          logprobs: null,
          finish_reason: null,
        }]))
        writeChunk(response, baseChunk(payload.model, [{ index: 0, delta: {}, logprobs: null, finish_reason: "tool_calls" }], {
          prompt_tokens: 10, completion_tokens: 10, total_tokens: 20,
        }))
      } else {
        writeChunk(response, baseChunk(payload.model, [{
          index: 0,
          delta: { role: "assistant", content: "mock tool execution passed" },
          logprobs: null,
          finish_reason: null,
        }]))
        writeChunk(response, baseChunk(payload.model, [{ index: 0, delta: {}, logprobs: null, finish_reason: "stop" }], {
          prompt_tokens: 10, completion_tokens: 5, total_tokens: 15,
        }))
      }
      response.end("data: [DONE]\n\n")
    } catch (error) {
      response.statusCode = 400
      response.end(JSON.stringify({ error: { message: String(error) } }))
    }
  })
})

server.listen(port, "127.0.0.1", () => {
  console.log(`mock-openai-ready:${port}`)
})

setTimeout(() => {
  console.error("mock-openai-timeout")
  server.close()
}, 180000).unref()

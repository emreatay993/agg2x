# Portable Word Workspace

This folder is the complete persistent workspace for supervised Word automation. Start at `CONTEXT.md`; load only the current stage contract and its declared inputs.

- Complete one stage per turn in this order: prepare, edit, verify.
- Store the visible handoffs under `current/`; never use chat history as the only state.
- Preparation ends at a human checkpoint. Do not edit a document until the user explicitly approves `current/02-plan.json`.
- Use Word tools for document access. Never overwrite a source document or an existing output.
- Stop after a failed mutation; do not retry or create another output path.
- Reinstallation must preserve this folder and its current run.

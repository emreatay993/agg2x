# Word Workflow Router

Use the first applicable route and read only that stage contract.

| Current state | Load |
|---|---|
| No `current/02-plan.json` | `stages/prepare/CONTEXT.md` |
| Plan exists; user has not explicitly approved it | Stop and ask the user to review `current/02-plan.json` |
| User explicitly approves the persisted plan; no edit result | `stages/edit/CONTEXT.md` |
| Edit result exists; no verification | `stages/verify/CONTEXT.md` |
| Verification exists | Report completion and wait for the user to archive or clear `current/` |

`current/` is the only active run. Do not overwrite a completed handoff or infer approval from a prior session. A new task starts only after the user intentionally clears or archives the previous run.

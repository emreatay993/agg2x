# Active Word Run

The staged Word agent writes one visible handoff here:

1. `01-inspection.md`
2. `02-plan.json`
3. `03-edit-result.md`
4. `04-verification.md`

Review the plan before approving the edit. Archive or clear completed run files before starting another document task; reinstalling the harness preserves this folder.

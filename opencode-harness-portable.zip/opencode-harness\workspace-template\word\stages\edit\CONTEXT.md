# Edit

## Inputs

| Source | Scope |
|---|---|
| `current/01-inspection.md` | Source path, hash, and targets |
| `current/02-plan.json` | Full approved operations array |

## Checkpoint

Proceed only after the user explicitly approves the persisted plan in the current conversation. Never treat the plan's pending status as approval.

## Process

1. Recheck that every operation still matches the approved persisted plan, then call `office_word_apply_saved_plan` exactly once with `current/02-plan.json`. Do not retype its operations or paths.
2. On failure, write the exact error to `current/03-edit-result.md` and stop without retrying.
3. On success, write the tool result, explicit user approval, output hash, operation statuses, and source-hash verification to `current/03-edit-result.md`.
4. Stop. Verification is a separate stage.

## Output

`current/03-edit-result.md`

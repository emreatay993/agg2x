# Prepare And Review

## Inputs

| Source | Scope |
|---|---|
| User request | Exact task, source path, intended DOCX/PDF paths, and requested coverage |
| Source document | Only the focused Word inventories needed for each requested change class |

## Process

1. Confirm source and output paths are distinct and outputs do not exist.
2. Make a checklist of every requested change class. Proofing, formatting, media, and cross-reference requests require their matching focused inspection mode.
3. Use `find` with one distinctive exact marker or phrase instead of guessing paragraph pages. Inspect the smallest additional ranges needed and record exact indices, text, hashes, truncation, and uncertainties in `current/01-inspection.md`.
4. Build the smallest guarded operations array from inspected values only. A native cross-reference must use `replace_text_with_cross_reference` with the exact returned target type, one-based target index, and target text; never substitute literal placeholder text. Record a blocker when a requested Figure or Table is not a native Word caption target.
5. Audit the plan: every requested change has one operation or an explicit blocker; no operation changes an unrequested property; each operation agrees with its written rationale. To preserve bold, italic, underline, font, or size, omit that field.
6. Write source/output paths, source hash, operations, coverage, blockers, `approvalRequired: true`, and `status: "pending_approval"` to `current/02-plan.json`.
7. Ask the user to review the plan and stop. Do not call a mutation tool.

## Outputs

- `current/01-inspection.md`
- `current/02-plan.json`

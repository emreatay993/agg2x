# Verify

## Inputs

| Source | Scope |
|---|---|
| `current/01-inspection.md` | Original request, source hash, and targets |
| `current/02-plan.json` | Expected operations |
| `current/03-edit-result.md` | Output path, hash, and operation results |

## Process

1. Re-inspect only the affected ranges and compare each requested change with the plan. For cross-references, require the intended target plus a nonempty native `REF` or `PAGEREF` field result; literal replacement text is a failure.
2. Confirm the original source hash is unchanged through the smallest focused inspection; do not run the default full inventory only to obtain a hash.
3. Render the edited document once to the planned nonexistent PDF path.
4. Write `current/04-verification.md` with one pass/fail line per requested change, hashes, PDF path/page count, truncation, and visual-QA limits.
5. Stop and report completion. Do not perform additional edits.

## Output

`current/04-verification.md`
